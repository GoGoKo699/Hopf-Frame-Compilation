# Complete Haar frame and dirty-seed fingerprints

The main research note gives the unconditional upper bound, the three-basis construction, the scope of the signed-frame extension, and the remaining unrestricted bound. The appendices develop its complete Haar application, a conditional general transfer, two independent structural lower bounds and a near-minimal field multiplication target.

To run the seven finite checks use `python run_checks.py` in the extracted directory. Python 3.10+ and NumPy are required. The operator-norm bounds, finite-field existence and all-size resource statements are proved analytically. The checks exercise finite instances of these arguments, including coherent vote errors and every column of reduced stages.

Baseline: GoGoKo699/Hopf-Frame-Compilation at ae613bf8e8a38f6d0407c25910b83d69f01a2733.
