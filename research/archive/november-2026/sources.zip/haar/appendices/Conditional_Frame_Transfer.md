# A smaller conditional remainder for complete frames

Put $N=2^n$ and fix the requested frame accuracy $2^{-L}$. Under the **exact** complete word-query premise of R98 with constant additive T-depth, there is a circuit for every prescribed real or complex magnitude frame satisfying the original one-clean, arbitrary dirty, full-return contract and
$$
D_T=O_L\left(N/b^2+(1+\log^*n)\log(2+\log^*n)\right),\qquad
T=O_L(\sqrt N+N/b),\qquad G=O_L(N).
$$
The second result needs an appropriate complete word-query family only at each **fixed requested tolerance**. For every fixed positive integer $k$ there is a fixed query tolerance $\tau(L,k)>0$ such that
$$
D_T=O_{L,k}\left(N/b^2+d_{\tau(L,k)}(2n+10)+\lambda_k(n)\right)
$$
with the same count and width orders at fixed $L,k$. Here $\lambda_1(x)=\log_2(x+2)$ and $\lambda_{k+1}(x)=\log_2(2+\lambda_k(x))$. The required table resources are those in R98 with the approximate complete query budget and width threshold at this fixed tolerance. The existing constant-query reduction from an eligible indicator supplies such an interface, with its constant error factor and address rescaling. The one-clean width thresholds are $17(L+n+7)$ for real and $17(L+n+8)$ for complex. Neither premise currently supplies an unconditional faster general source.

## The early-stage circuit

At remaining height $m$ and stage precision $l$, keep the global-stage notation
$$
 t=\lceil\log_2(m+2)\rceil,\quad
 \chi=\lceil\log_2(l+2)\rceil+t^3,\quad K=m+l+2,\quad r=\lceil A\chi\rceil.
$$
R98 already handles a constant number of sequential, packed long-table positions. Its other logarithmic contributions need separate native replacements.

* Concatenate the outputs at each short-table position. Their actual inputs are the shared activity and coarse bins, ordinary short tags/source fields, and the interval, geometric or catalogue fields across the compact blocks. The latter have $O(t)$ bits each for $O(t^2)$ blocks. The union is $O(\chi)$; long logical/label banks occur in already audited long positions, and arbitrary precision cores are targets/work. The inputs and outputs are disjoint at each position. Use one returned-address word query on the union, reproducing every old row, including malformed ones. Global stage §6 permits these short tables to be included in the global family.
* Use the paid paired layout and pack/unpack shears, replacing their program toggle by a joint short word. Across disjoint-array blocks this adds the concatenation of their private program indicators at all physical metadata values, including the shared activity flag. Its input union is the same $O(\chi)$ short metadata. Each selected shear executes a grid, toggles the whole arbitrary program, reverses the grid and actually unqueries. A fixed number of shears suffices, with each auxiliary array parked through its body. The short table volume, grids and working width are $2^{O(\chi)}$. No temporally address-moving words are interleaved on a common selector.
* Treat the original suffix test and all-used-work tests as complete short Boolean queries, incorporating the tested zero/phase echo as appropriate. The suffix itself has $r$ bits. Its local table can have size $2^{O(A\chi)}$. This term is additive and does not enter the global address exponent used to choose $A$.
* For a capped geometric reference of length $R$, prepare $R-1$ clean-at-the-column bits $A$ in $+$. Compute their first-one position into a zero $\log_2R$-bit label $J$, using $R-1$ as sentinel. Conditional on $J=j<R-1$, the first $j$ bits of $A$ are zero, bit $j$ is one, and later bits are in $+$. In the sentinel branch all are zero. Query all $[i>J]$ into clean-at-column flags, apply disjoint controlled Hadamards to those $A_i$, actually unquery the flags and XOR the word $[i=J]$ into $A$. The resulting positive label amplitudes are the exact capped reference $g_R$, and all added bits return to zero on the specified column. The emitted word is unitary on arbitrary inputs. Include all added $A$ and flags in the original augmented zero tests. Transport the prepared column to the target full reference by the repository's padded-unitary comparison, retaining its preassigned cap error. At each of four chronological query positions, concatenate all cell tables into a *single* word query on their union. When $l\le\log_2(t+2)$, $O(t^2)$ disjoint cells have $R=O(l+\log(t+2))$, giving a total $O(t^3)$ new bits. The augmented long readout still fits $n-r+C\chi$. When $l>\log_2(t+2)$ use the original reference, whose depth already fits $O(l)$ and which keeps its previous width.
* All remaining entries in the R98 §2 depth ledger are ordinary source or coefficient banks of depth $O(l)$. Long anchors remain long queries. Recovery, echoes and actual inverse words multiply the number of chronological positions by a constant independent of cell count and stage height. Charge full operator error once per each whole query and its occurrences. The ideal hybrid respects all clean sectors, while errors including leakage propagate through actually emitted unitaries.

For the exact premise with constant depth, choose the queried short tables' pools of square-root volume. Each stage now costs
$$
D_E=O\left(l+1+K^D2^{n-r+C\chi}/b^2\right).
$$
The long table T-count is $O(K^D(\sqrt{2^{n-r+C\chi}}+2^{n-r+C\chi}/b+1))$ and its Clifford count is $O(K^D(2^{n-r+C\chi}+1))$. The additive count and simultaneous-width cost of all local components, including new short pools, is $2^{O_A(\chi)}$. Global $C,D$ precede the fixed reserve coefficient $A$. The local suffix table whose input is $r$ is deliberately excluded from the global address envelope. In the wide branch $b\ge\sqrt N/n$ these local pools are $N^{o(1)}$ on the schedules below, with room for the exclusive long-query pool. Use original R96 in narrow or bounded dimension branches.

## A summable variable stage schedule under the exact query premise

Let $h(m)\ge1$ be the least $j\ge1$ for which applying the ordinary base-two logarithm $j$ times to $m$ gives at most 2, setting $h(m)=1$ when $m\le2$. Choose
$$
l(m)=L+C_0+2\lceil\log_2(1+h(m))\rceil .
$$
For all sufficiently large $m$ at fixed $L,C_0,A$, the next height obeys $r(m)\le C_L\log_2^3(m+2)$ and $r(r(m))\le\log_2m$. Stop at a fixed sufficiently large height, before the reserve condition $r<m/2$ can fail. At most two executed stages occupy each large value of $h$. The number of stages is $O(1+\log^*n)$ and $\sum_i 2^{-l(m_i)}\le C2^{-L-C_0}$ by the reciprocal-square series. The exact-query early-stage error is $2^{-l}/16$. Choose $C_0$ to accommodate the magnitude/sign reduction and fixed-precision terminal and diagonal. The terminal's height is bounded at this fixed final precision, so its catalogue and fixed words have bounded nonquery depth and its boundedly many long queries keep their R98 allocation. The complex diagonal and initial signs retain a fixed number of full-address queries.

Choose $A$ large enough that every executed stage's long T, Clifford and depth volume terms are suppressed against the respective $\sqrt N,N/b,N,N/b^2$ terms by at least $2^{-4\chi(m_i)}$. Heights decrease strictly and $\chi(m)\ge\log_2(m+2)$, so this suppression sums to an absolute constant. The sum of all local counts is bounded by $n\,2^{O_L(\log_2^3(n+2))}=N^{o(1)}$. Width takes a maximum across completed stage boundaries. The residual depth is $O(\sum_i(l(m_i)+1))=O_L((1+\log^*n)\log(2+\log^*n))$. The total uses only one external initialized bit.

For the fixed-tolerance version use $j=k+3$ improved stages with constant $l=L+\lceil\log_2(j+1)\rceil+C_0$, stopping early at bounded height. For fixed $i$, $m_i=O_{L,k}(\lambda_i(n)^3)$. Both the final R90 program length and individual fixed word length are $2^{O_{L,k}(m_j)}=O_{L,k}(\lambda_k(n))$, since $\lambda_{k+3}(n)^3=o(\lambda_{k+1}(n))$. The total terminal catalogue width is $n^{o(1)}$, and its long program query retains $Qq=O_{L,k}(N)$. There are $O_{k}(1)$ completed approximate query occurrences including actual unqueries, so one sufficiently small *fixed* tolerance absorbs all errors. The narrow/bounded branches use R96 at their literal minimum widths. The dependence on $k$ cannot be reinterpreted as a varying-accuracy statement.

The relevant repository proofs are QUERY_DEPTH_FRAME_TRANSFER §§2–5, GLOBAL_BORROWED_PRECISION_STAGE §§5–6, FAST_CAPPED_GEOMETRIC_REFERENCE §§1–3, PAIRED_PERMUTATION_ROUTING §§2–5, APPROXIMATE_QUERY_FRAME_TRANSFER §3 and WHOLE_FRAME_BINARY_DEPTH, all under research/depth at commit ae613bf8e8a38f6d0407c25910b83d69f01a2733.
