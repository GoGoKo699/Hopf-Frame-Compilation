# A complete-frame lower bound for the interference outside a largest Hadamard wall

Let $p=n-1$, $m=2^p$. The deepest-angle family $\sum_x |x\rangle\langle x|\otimes(XZ)^{f(x)}$ realizes all $2^m$ Boolean tables. Its return amplitude on the basis input $(x,0,0_{\rm work})$ has modulus $1-f(x)$. It is enough to test this one basis input for every x. Error $\epsilon<1/2$ in the full clean-code contract therefore distinguishes the two cases by margin $\gamma=1/2-\epsilon$. This applies to fixed common global phases as well. Unrestricted numbers of dirty and clean wires, arbitrary interstage input motion, and table-dependent compilation are allowed.

## Statement for native Clifford+T circuits

Write a literal native circuit in Clifford/T-layer form, and put each Clifford interlayer in Hadamard-free, tensor-Hadamard, Hadamard-free form, absorbing qubit permutations into the adjacent Hadamard-free circuits. This is the canonical form of [Bravyi and Maslov](https://arxiv.org/abs/2003.09412). Equivalently the proof below applies to any circuit word expressed with arbitrary tensor-Hadamard walls and intervening Hadamard-free Clifford+T words. Let the wall widths be $h_1,\ldots,h_t$ and put
$$
E=\max\{0,\ \sum_i h_i-2\max_i h_i\}.
$$
An empty wall list has $E=0$. If every table can be compiled with common upper bound $E\le e$, then at fixed $\epsilon<1/2$,
$$
e\ \ge\ p-3\log_2(p+2)-O_\epsilon(1).
$$
In fact the exceptional fraction of tables attainable with a cap $e$ is at most $2^{-(1-h_2(1/10))m+O_\epsilon(2^e(p+2)^3+p)}$. There is no restriction on the location or widths of the walls, the number of native T gates or the amount of uninitialized space. The lower bound uses the actual sequence of walls. Inserting canceling gates can raise E and does not create a stronger lower bound. It implies at least three effective walls for a worst-case frame at large p. If there are exactly three, their two smaller widths must exceed the largest by at least $p-O(\log p)$ in sum. This allows huge balanced walls at constant native T-depth. The unrestricted depth frontier remains open.

## Sampling a whole complete return amplitude

Select a largest Hadamard wall on wire set W, width $h_*$. On its input side propagate the starting basis word forward, sampling each Hadamard's *output* bit uniformly. On its output side propagate the specified final basis word backward, sampling each earlier-in-this-reversed-word Hadamard's output uniformly. All random bits in both partial paths are independent. Each Hadamard-free segment has a definite reversible action on every basis word and a literal phase. For a Hadamard with fixed sampled output the phase is $(-1)^{ab}$ with input a and sampled bit b, and its magnitude is $1/\sqrt2$. Multiply the forward phases, the conjugates of the backward phases, and the sign of the bridge, $(-1)^{\ell_W\cdot r_W}$, where $\ell,r$ are the two arrived-at words. Multiply by the condition $\ell_{W^c}=r_{W^c}$, since the bridge acts as the identity on its complementary wires. The resulting feature $F(x)$ has modulus at most one.

The return amplitude for each fixed x is exactly
$$
A(x)=c\,\mathbb E F(x),\qquad c=2^{(\sum_i h_i-2h_*)/2}.
$$
Indeed the number of paired partial paths is $2^{\sum_i h_i-h_*}$ and the magnitude of each complete Hadamard scalar, including the bridge, equals $2^{-\sum_i h_i/2}$. These factors give c, including the case $c<1$. If the circuit has no H wall, insert a width-zero bridge. No postselection probability is being used to certify the approximation.

For a fixed sample of all the random bits, every bit in each arrived-at word is affine in the p address bits. The starting and final remaining coordinates are zero, and signed CNOT/S/T/X/Z/controlled-Z permutations preserve this label property in the two directions. The guard therefore defines an affine subspace (possibly empty), describable by at most $p+1$ affine equations. The phase is $\omega^{P(x)}$, $\omega=\exp(i\pi/4)$, where P is multilinear of degree at most 3 modulo eight. A T/S/Z gate adds an integer multiple of one bit of an affine label: XOR lifted to an integer mod 8 has no monomial above degree three, since the k-way coefficient is $(-2)^{k-1}$. A Hadamard with sampled output contributes four times an affine bit. CZ and bridge products contribute four times the product of two affine bits, which has degree at most two modulo eight after the factor four. Clifford phases in a Hadamard-free normal form decompose into these gates up to a common scalar, which cancels when taking moduli. These assertions likewise hold for actual inverses. The number of distinct possible features is at most
$$
2^M,\qquad M=(p+1)^2+1+3\sum_{j=0}^3{p\choose j}=O((p+2)^3).
$$
This bound is independent of the original work dimension, the number of elementary gates, and their synthesis settings.

Take a common sample size $N=\lceil 10\,2^e/\gamma^2\rceil$ for each table. The squared deviation from A for the scaled empirical mean of N independently chosen complex features has expectation at most $c^2/N\le\gamma^2/10$. By Markov's inequality and averaging over x, for each compiled table there exists a fixed feature list whose empirical amplitude differs by strictly less than $\gamma$ on at least nine tenths of the addresses (use a constant 11 in N if one wants a strict slack). On these addresses thresholding the modulus of the empirical mean at $1/(2c)$ recovers $1-f(x)$. For a given unscaled feature list there are at most $m+1$ resulting strict threshold labelings with arbitrary positive threshold: sort the m moduli. Hence at most $(m+1)2^{MN}$ approximate labelings have been described. Each lies in a Hamming ball containing at most $2^{h_2(1/10)m}$ truth tables, where $h_2$ is binary entropy. Taking logs gives
$$
(1-h_2(1/10))2^p\le M\lceil 10\,2^e/\gamma^2\rceil+\log_2(m+1).
$$
The claimed bound follows, as does the exceptional-fraction statement after dividing by $2^m$.

## Low-degree nonlinear data motion

One may instead allow arbitrary signed monomial data changes between arbitrary tensor-Hadamard walls, with both forward and inverse coordinate and sign degrees charged. Every sample is again a signed zero-vector test. If all sampled signs and individual guard coordinates have degree at most D in x, set $M_D=\sum_{j\le D}{p\choose j}$. For example, one may bound the degree on each partial path by the product of the respective per-interval degree bounds; the dot-product sign at the bridge adds the degrees of the two boundary words. Conditional on any fixed correct sample list, replace each of its guards by the AND of $r=\lceil\log_2(20N)\rceil$ independent random homogeneous binary linear hashes testing its guard vector for zero. Each false guard becomes true with probability $2^{-r}$. There exists a choice corrupting at most one twentieth of the addresses in any sampled feature. Use $N\ge20\,2^e/\gamma^2$ for the first sampling stage. The two error sets cost at most a tenth in total. Each resulting feature now has a description by at most $(r+1)M_D$ bits. Therefore
$$
(1-h_2(1/10))2^p\le N(r+1)M_D+\log_2(m+1).
$$
For $e\le p$, $D\le p/2$ this yields
$$
e/p+h_2(D/p)\ \ge\ 1-O_\epsilon(\log(p+2)/p).
$$
In particular two arbitrarily wide parallel Hadamard walls separated and surrounded by bounded-degree nonlinear reversible data motion require $D\ge p/2-o(p)$ in a universal worst-case frame construction. The library's constant-depth one-point equality filter is consistent with this obstruction: it computes a specified family of simple tables, not an arbitrary deepest-corner table.
