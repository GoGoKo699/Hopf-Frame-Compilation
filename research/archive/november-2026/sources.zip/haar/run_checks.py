from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
environment = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
for check in sorted((root / 'checks').glob('*.py')):
    print(f'Running {check.name}', flush=True)
    subprocess.run([sys.executable, '-B', str(check)], cwd=root, env=environment, check=True)
