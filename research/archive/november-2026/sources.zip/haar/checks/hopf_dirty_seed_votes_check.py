"""Finite operator and finite-field checks for the dirty-seed construction."""
from itertools import combinations, product
import math
import numpy as np

def tensor_power(gate, count):
    total = np.ones((1, 1), dtype=complex)
    for _ in range(count):
        total = np.kron(total, gate)
    return total

def check_seeds():
    h = np.array([[1, 1], [1,-1]]) / math.sqrt(2)
    sh = np.diag([1, 1j]) @ h
    checked = 0
    for bits in [2, 3, 4]:
        dim = 2**bits
        eye = np.eye(dim)
        bases = (eye, tensor_power(h, bits), tensor_power(sh, bits))
        for left, right in combinations(bases, 2):
            assert np.allclose(np.abs(left.conj().T @ right), 1/math.sqrt(dim))
        bad_sets = [()] + [(i,) for i in range(dim)]
        if bits == 4:
            bad_sets += list(combinations(range(8), 2))
        for bad in bad_sets:
            projectors = [frame[:,list(bad)] @ frame[:,list(bad)].conj().T for frame in bases]
            mu = len(bad)/math.sqrt(dim)
            for i,j in combinations(range(3), 2):
                assert np.linalg.norm(projectors[i] @ projectors[j], 2) <= mu + 1e-11
            for answer in (0,1):
                all_branches = np.zeros_like(eye, dtype=complex)
                wrong = np.zeros_like(eye, dtype=complex)
                # Orthogonal vote records mean the exact effect is a sum of K^*K.
                for votes in product(range(2),repeat=3):
                    op = eye
                    for vote, p in zip(votes,projectors):
                        op = (p if vote != answer else eye-p) @ op
                    effect = op.conj().T @ op
                    all_branches += effect
                    if int(sum(votes)>=2) != answer:
                        wrong += effect
                assert np.allclose(all_branches,eye)
                error = 2*math.sqrt(max(0,np.linalg.eigvalsh(wrong)[-1]))
                assert error <= 4*(mu+mu*mu)+1e-10
                checked += 1
    return checked

def multiply(a,b,field_order,irreducible):
    result = 0
    while b:
        if b & 1:
            result ^= a
        b >>= 1
        a <<= 1
        if a & field_order:
            a ^= irreducible
    return result

def polynomial_value(bits,a,order,modulus):
    out=0
    for bit in reversed(bits):
        out=multiply(out,a,order,modulus)^bit
    return out

def verify_root_budget():
    checks=0
    for order,modulus in ((8,0b1011),(16,0b10011),(32,0b100101)):
        for length in range(1,7):
            for x in product(range(2),repeat=length):
                suffixes=[x[j+1:] for j in range(length) if x[j]]
                true=next((j for j in range(length,0,-1) if x[j-1]),0)
                bad=0
                for seed in range(order):
                    last=0
                    for j in range(length):
                        if x[j] and polynomial_value(x[j+1:],seed,order,modulus)==0:
                            last ^= j+1
                    bad += last != true
                assert bad <= sum(len(bits)-1 for bits in suffixes if any(bits))
                checks+=1
    return checks

if __name__ == '__main__':
    print(f'{check_seeds()} coherent majority operator tests and {verify_root_budget()} whole-tag fingerprint tests passed')
