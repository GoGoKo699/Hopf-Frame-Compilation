"""Exact finite checks for the temporal commutation-entropy bound (standard library)."""
from itertools import combinations
from random import Random

def rank(words):
    pivots={}
    for word in words:
        while word:
            p=word.bit_length()-1
            if p not in pivots:
                pivots[p]=word
                break
            word ^= pivots[p]
    return len(pivots)

def coordinates(word,basis):
    pivots={}
    for i,vector in enumerate(basis):
        mask=1<<i
        while vector:
            j=vector.bit_length()-1
            if j not in pivots:
                pivots[j]=(vector,mask)
                break
            a,b=pivots[j]
            vector^=a
            mask^=b
    mask=0
    while word:
        j=word.bit_length()-1
        if j not in pivots:
            return None
        a,b=pivots[j]
        word^=a
        mask^=b
    return mask

def encode(rows):
    n=len(rows)
    basis=[]
    out=[]
    maximum=0
    for j in range(n):
        maximum=max(maximum,len(basis))
        column=sum((x&1)<<i for i,x in enumerate(basis))
        shrunk=[x>>1 for x in basis]
        relation=0
        if rank(shrunk)<len(shrunk):
            for i,x in enumerate(shrunk):
                coeff=coordinates(x,shrunk[:i])
                if coeff is not None:
                    relation=coeff^(1<<i)
                    shrunk.pop(i)
                    break
        word=rows[j]>>(j+1)
        coeff=coordinates(word,shrunk)
        if coeff is None:
            shrunk.append(word)
        out.append((column,relation,coeff))
        basis=shrunk
    return out,maximum

def decode(description):
    n=len(description)
    coordinates_=[]
    rows=[0]*n
    width=0
    for j,(column,relation,coeff) in enumerate(description):
        for i,old in enumerate(coordinates_):
            if (column&old).bit_count()%2:
                rows[i]|=1<<j
                rows[j]|=1<<i
        if relation:
            pivot=relation.bit_length()-1
            for i,old in enumerate(coordinates_):
                if (old>>pivot)&1:
                    old^=relation
                coordinates_[i]=(old% (1<<pivot))|((old>>(pivot+1))<<pivot)
            width-=1
        if coeff is None:
            coeff=1<<width
            width+=1
        coordinates_.append(coeff)
    return rows

def check(rows):
    code,actual=encode(rows)
    assert decode(code)==rows
    measured=max(rank([x>>j for x in rows[:j]]) for j in range(len(rows)+1))
    assert actual==measured

def run():
    number=0
    for n in range(1,7):
        entries=list(combinations(range(n),2))
        for label in range(1<<len(entries)):
            rows=[0]*n
            for e,(i,j) in enumerate(entries):
                if label>>e&1:
                    rows[i]|=1<<j
                    rows[j]|=1<<i
            check(rows)
            number+=1
    print(number,"undirected ordered matrices encoded, reconstructed, and compared to every actual cut")
    rng=Random(821831)
    number=0
    for _ in range(300):
        lengths=[rng.randint(1,7) for layer in range(rng.randint(1,6))]
        ends=[sum(lengths[:j]) for j in range(len(lengths)+1)]
        n=ends[-1]
        layers=[j for j,k in enumerate(lengths) for _ in range(k)]
        rows=[0]*n
        for i,j in combinations(range(n),2):
            if layers[i]!=layers[j] and rng.randrange(2):
                rows[i]|=1<<j
                rows[j]|=1<<i
        check(rows)
        cuts=[rank([row>>j for row in rows[:j]]) for j in range(n+1)]
        for a,b in zip(ends,ends[1:]):
            assert max(cuts[a:b+1])<=cuts[a]+cuts[b]
        number+=1
    print(number,"multi-layer fixtures checked against the neighboring-boundary bound")
    for k in range(1,5):
        for _ in range(100):
            M=[rng.getrandbits(k) for j in range(k)]
            block=[sum(((row>>i)&1)<<(k+j) for j,row in enumerate(M)) for i in range(k)] + M
            check(block)
            assert rank(block)==2*rank(M)
    print(400, "two-layer arbitrary-table symplectic realizations checked")
if __name__=="__main__":
    run()
