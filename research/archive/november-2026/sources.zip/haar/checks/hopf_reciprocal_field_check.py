"""Exact binary-field tests using integers for polynomials over GF(2)."""
from random import Random

def rem(x, f):
    while x.bit_length() >= f.bit_length():
        x ^= f << (x.bit_length() - f.bit_length())
    return x

def mul(a, b, f):
    prod = 0
    while b:
        if b & 1:
            prod ^= a
        a <<= 1
        b >>= 1
    return rem(prod, f)

def power(a, n, f):
    out = 1
    while n:
        if n & 1:
            out = mul(out, a, f)
        a = mul(a, a, f)
        n >>= 1
    return out

def gcd(a, b):
    while b:
        a,b=b,rem(a,b)
    return a

def is_irreducible(f, h):
    x = 2
    for step in range(1,h+1):
        x=mul(x,x,f)
        if step<=h//2 and gcd(x^2, f) != 1:
            return False
    return x==2

def get_field(h,rng):
    while True:
        f=(1<<h) | rng.getrandbits(h) | 1
        if is_irreducible(f,h):
            return f

def get_basis(columns):
    basis={}
    for i,col in enumerate(columns):
        tag = 1 << i
        while col:
            j=col.bit_length()-1
            if j not in basis:
                basis[j]=(col,tag)
                break
            old, lab=basis[j]
            col ^= old
            tag ^= lab
    return basis

def coords(y,basis):
    tag=0
    while y:
        old, lab=basis[y.bit_length()-1]
        y ^= old
        tag ^= lab
    return tag

rng = Random(20261119)
for p in range(1,7):
    m=1<<p
    for h in (m, m+p):
        f=get_field(h,rng)
        for _ in range(1000):
            alpha=rng.randrange(m,1<<h) if (1<<h)>m else 0
            if not alpha:
                continue
            reciprocals=[power(alpha^s,(1<<h)-2,f) for s in range(m)]
            basis=get_basis(reciprocals)
            if len(basis)==m:
                break
        else:
            raise AssertionError(('no suitable slice in finite search',p,h))
        # Extend to an ambient basis and coordinate extractor.
        cols=list(reciprocals)
        for j in range(h):
            test=cols+[1<<j]
            if len(get_basis(test))>len(cols):
                cols=test
        assert len(cols)==h
        ambient=get_basis(cols)
        for s,g in enumerate(reciprocals):
            assert mul(alpha^s,g,f) == 1
            assert coords(g,ambient) == 1<<s
            for _ in range(4):
                y=rng.randrange(1<<h)
                back=mul(mul(y,alpha^s,f)^1,g,f)
                assert back==y^g
                assert coords(y,ambient)^coords(back,ambient)==1<<s
        print(f'p={p}, h={h}: rank {m}, full basis extension and multiplier echo passed')
