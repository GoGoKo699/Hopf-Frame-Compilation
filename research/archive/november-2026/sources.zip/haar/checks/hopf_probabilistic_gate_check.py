"""Finite exhaustive checks for GF(2) probabilistic OR, AND and composed sign circuits."""
from itertools import product


def estimate_or(a, b, choices):
    return int(any(((a & (mask & 1)) ^ (b & (mask >> 1))) for mask in choices))


def squarefree_degree(table, arity):
    coefficients = list(table)
    for bit in range(arity):
        for x in range(1 << arity):
            if x & (1 << bit):
                coefficients[x] ^= coefficients[x ^ (1 << bit)]
    return max((x.bit_count() for x, occupied in enumerate(coefficients) if occupied), default=0)


def check():
    single = 0
    for r in range(1, 6):
        for a, b in product(range(2), repeat=2):
            wrong = sum(estimate_or(a, b, choices) != (a | b)
                        for choices in product(range(4), repeat=r))
            assert wrong == (0 if not (a | b) else 2**r)
            single += 4**r

    choices = list(product(range(4), repeat=2))
    inputs = list(product(range(2), repeat=4))
    truth = [(a | b) ^ ((b & c) | (a ^ d)) for a, b, c, d in inputs]
    bad = [0]*len(inputs)
    total = 0
    maximum_degree = 0
    for or1, and2, or3 in product(choices, repeat=3):
        estimates = []
        for at, (a, b, c, d) in enumerate(inputs):
            left = estimate_or(a, b, or1)
            inner = 1 ^ estimate_or(1 ^ b, 1 ^ c, and2)
            out = left ^ estimate_or(inner, a ^ d, or3)
            estimates.append(out)
            bad[at] += out != truth[at]
        maximum_degree = max(maximum_degree, squarefree_degree(estimates, 4))
        total += 1
    assert all(4*count <= 3*total for count in bad)
    assert maximum_degree <= 4
    print(f'{single:,} exact two-input OR random tapes; one-sided error exactly 2^-r off zero')
    print(f'{total:,} composed probabilistic polynomials x {len(inputs)} inputs; max estimated degree {maximum_degree}, worst bad count {max(bad)}/{total} within circuit union bound')


if __name__ == '__main__':
    check()
