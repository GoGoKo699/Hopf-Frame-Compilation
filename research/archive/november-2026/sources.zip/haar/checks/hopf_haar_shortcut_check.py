"""Full-matrix checks of the protected Haar stage and the signed-corner embedding."""
import math
import numpy as np


def mask(n, pos):
    return 1 << (n - pos - 1)


def permute(rows, images):
    result = np.empty_like(rows)
    result[images] = rows
    return result


def target(rows, n, pos, gate, guard):
    bit = mask(n, pos)
    lower = np.array([x for x in range(len(rows)) if not x & bit and guard(x)], dtype=int)
    upper = lower | bit
    a, b = rows[lower].copy(), rows[upper].copy()
    rows[lower] = gate[0, 0] * a + gate[0, 1] * b
    rows[upper] = gate[1, 0] * a + gate[1, 1] * b


def direct_layers(rows, n, gates, positions):
    for pos in positions:
        low_mask = mask(n, pos) - 1
        target(rows, n, pos, gates[pos], lambda x: not x & low_mask)
    return rows


def last(x, h):
    return h + 1 - (x & -x).bit_length() if x else 0


def protected_then_bottom(gates, r):
    n = len(gates)
    h = n-r
    s = h.bit_length()
    assert s <= r
    flag = 1 << n
    N = 1 << n
    rows = np.zeros((2*N, N), dtype=complex)
    rows[:N] = np.eye(N)
    lo = (1 << r)-1
    tag = (1 << s)-1

    save = [a ^ (flag if not a & lo else 0) for a in range(2*N)]
    tag_xor = [a ^ (last((a % N) >> r, h) if a & flag else 0) for a in range(2*N)]
    rows = permute(rows, save)
    rows = permute(rows, tag_xor)
    for j in range(h):
        target(rows, n+1, j+1, gates[j], lambda a: a & flag and (a & tag) <= j+1)
    for j in range(h):
        target(rows, n+1, j+1, gates[j].conj().T, lambda a: True)
    rows = permute(rows, tag_xor)
    for j in range(h):
        target(rows, n+1, j+1, gates[j], lambda a: True)
    rows = permute(rows, save)
    direct_layers(rows, n+1, [None]+gates, range(h+1, n+1))
    return rows


def check_stage():
    haar = np.array([[1.,-1.],[1.,1.]])/math.sqrt(2.)
    y = np.array([[0.,-1.],[1.,0.]])
    had = np.array([[1.,1.],[1.,-1.]])/math.sqrt(2.)
    t = np.diag([1., np.exp(1j*np.pi/4)])
    complex_gates = [y, had@t, t@had, haar]
    cases = 0
    columns = 0
    maximum = 0.
    for n in range(3,9):
        for r in range(1,n):
            if (n-r).bit_length() > r:
                continue
            for gates in ([haar]*n, [complex_gates[j%4] for j in range(n)]):
                actual = protected_then_bottom(gates, r)
                expected = direct_layers(np.eye(1<<n,dtype=complex),n,gates,range(n))
                err = max(np.linalg.norm(actual[:1<<n]-expected,'fro'),
                          np.linalg.norm(actual[1<<n:],'fro'))
                assert err < 2e-13, (n,r,err)
                maximum = max(maximum, err)
                cases += 1
                columns += 1<<n
    print(f'{cases} full protected-stage matrices; {columns:,} initialized columns including leakage; max Frobenius error {maximum:.2g}')


def check_signed_corner():
    haar = np.array([[1.,-1.],[1.,1.]])/math.sqrt(2.)
    cases = 0
    for n in range(1,5):
        N=1<<n
        positive=direct_layers(np.eye(N),n,[haar]*n, range(n))
        upper=direct_layers(np.eye(N),n,[haar]*n,range(n-1))
        for f in range(1<<(N//2)):
            actual=upper.copy()
            target(actual,n,n-1,haar,lambda a: not ((f>>(a>>1))&1))
            target(actual,n,n-1,-haar,lambda a: (f>>(a>>1))&1)
            sign=np.array([1-2*((f>>(a>>1))&1) for a in range(N)])
            assert np.array_equal(actual, sign[:,None]*positive)
            cases+=1
    print(f'{cases} complete deepest-sign tables, entrywise identity with D_f times positive Haar')


def check_hash():
    hmax=10
    def mul(a,b):
        z=0
        while b:
            if b&1:
                z^=a
            a <<= 1
            if a&32:
                a^=0b100101
            b>>=1
        return z

    cases=0
    for h in range(1,hmax+1):
        for x in range(1<<h):
            bits=[(x>>j)&1 for j in reversed(range(h))]
            true=last(x,h)
            bad=0
            for a in range(32):
                inner=0
                candidate=0
                for j in reversed(range(h)):
                    if bits[j] and inner==0:
                        candidate^=j+1
                    inner=mul(a,inner)^bits[j]
                bad+=(candidate!=true)
            degree_sum=sum(max(0,h-j-2) for j in range(h) if bits[j] and any(bits[j+1:]))
            assert bad<=degree_sum,(h,x,bad,degree_sum)
            cases+=1
    print(f'{cases} last-one words tested on every seed in GF(32); root-count bound passed')


if __name__=='__main__':
    check_stage()
    check_signed_corner()
    check_hash()
