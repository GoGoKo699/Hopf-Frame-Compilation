"""Finite checks for geometric reference and the packed simultaneous router."""
from fractions import Fraction
from itertools import product


def first_position(word, width):
    return next((i for i in range(width) if (word >> i) & 1), width)


def test_geometric():
    cases = 0
    for length in (2, 4, 8, 16):
        size = length - 1
        histogram = [0] * length
        for first_word in range(1 << size):
            label = first_position(first_word, size)
            histogram[label] += 1
            head = first_word & ((1 << min(label + 1, size)) - 1)
            assert head == (0 if label == size else 1 << label)
            cases += 1
        for label, frequency in enumerate(histogram):
            expected = 1 << max(size - label - 1, 0)
            assert frequency == expected
            assert Fraction(frequency, 1 << size) == Fraction(1, 1 << min(label + 1, size))
    return cases


def grid(bank, program, address_map):
    result = 0
    for i, row in enumerate(address_map):
        if program & (1 << i):
            result ^= row[bank]
    return result


def test_shared_metadata():
    # Three simultaneous block rows depend on a common physical tag plus one
    # separate bit, and the middle block uses a complemented local bit.
    static_rows = ((0, 1), (0, 0), (0, 0), (0, 1))
    tested = 0
    for common, local, words, old_program in product(range(2), range(8), range(8), range(16)):
        for j in range(3):
            addr = 2 * common + (((local >> j) & 1) ^ (j & 1))
            word = (words >> j) & 1
            a = grid(word, old_program, static_rows)
            b = grid(word, old_program ^ (1 << addr), static_rows)
            assert a ^ b == static_rows[addr][word]
            tested += 1
    return tested


if __name__ == '__main__':
    print(f'{test_geometric():,} finite reference fibers for all power-of-two caps up to 16')
    print(f'{test_shared_metadata():,} shared/independent metadata block-shear fibers')
