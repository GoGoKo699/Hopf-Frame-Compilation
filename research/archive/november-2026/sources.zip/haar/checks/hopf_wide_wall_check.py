"""Independent direct matrices versus split-path expectation, using Python's standard library."""
from itertools import product
from cmath import exp
from math import pi, sqrt
from random import Random


omega = exp(1j * pi / 4)


def parity(x):
    return x.bit_count() % 2


def apply_monomial(bits, gates, reverse=False):
    phase = 1.0 + 0j
    for kind, a, b in reversed(gates) if reverse else gates:
        if kind == 'x':
            bits ^= 1 << a
        elif kind == 'c':
            bits ^= ((bits >> a) & 1) << b
        elif kind == 'z':
            phase *= (-1) ** (((bits >> a) & 1) * ((bits >> b) & 1))
        elif kind == 't':
            phase *= omega ** ((-1 if reverse else 1) * b * ((bits >> a) & 1))
        else:
            raise ValueError(kind)
    return bits, phase


def h_entry(a, b, mask):
    if (a ^ b) & ~mask:
        return 0.
    return (-1) ** parity(a & b & mask) / sqrt(2 ** mask.bit_count())


def columns(x, n, walls, segments):
    state = [0j] * (1 << n)
    state[x] = 1
    for j, segment in enumerate(segments):
        moved = [0j] * len(state)
        for y, val in enumerate(state):
            z, phase = apply_monomial(y, segment)
            moved[z] += phase * val
        state = moved
        if j < len(walls):
            state = [sum(h_entry(a, b, walls[j]) * state[a] for a in range(len(state))) for b in range(len(state))]
    return state


def partial(x, n, walls, segments, reverse):
    # Enumerate the uniformly sampled partial paths with unnormalized signs.
    paths = [(x, 1+0j)]
    for i, segment in enumerate(segments):
        paths = [(z, v * phase) for y, v in paths for z, phase in [apply_monomial(y, segment, reverse)]]
        if i < len(walls):
            mask = walls[i]
            opts = [z for z in range(1 << n) if z & ~mask == 0]
            paths = [((y & ~mask) | opt, v * (-1) ** parity(y & opt & mask)) for y, v in paths for opt in opts]
    return paths


def check():
    rng = Random(341455)
    circuits = 0
    entries = 0
    widths = set()
    for n in (2, 3):
        for _ in range(56):
            num = rng.choice((1, 2, 3, 4))
            walls = [rng.randrange(1 << n) for _ in range(num)]
            segments = []
            for i in range(num + 1):
                gs = []
                for _ in range(4):
                    a, b = rng.sample(range(n), 2)
                    kind = rng.choice(('c', 'z', 'x', 't'))
                    gs.append((kind, a, rng.randrange(1, 8) if kind == 't' else b))
                segments.append(gs)
            j = max(range(num), key=lambda i: walls[i].bit_count())
            hsum = sum(w.bit_count() for w in walls)
            excess = hsum - 2 * walls[j].bit_count()
            widths.add((num, (excess > 0) - (excess < 0)))
            left = [partial(x, n, walls[:j], segments[:j+1], False) for x in range(1 << n)]
            right = [partial(x, n, list(reversed(walls[j+1:])), list(reversed(segments[j+1:])), True) for x in range(1 << n)]
            for x, lp in enumerate(left):
                real = columns(x, n, walls, segments)
                for y, rp in enumerate(right):
                    total = sum(
                        lz * rz.conjugate() * (-1) ** parity(a & b & walls[j])
                        for a, lz in lp for b, rz in rp
                        if ((a ^ b) & ~walls[j]) == 0
                    )
                    projected = 2 ** (excess / 2) * total / (len(lp) * len(rp))
                    assert abs(real[y] - projected) < 2e-10, (real[y], projected)
                    entries += 1
            circuits += 1
    print(f'{entries} split-path versus full matrix entries in {circuits} circuits; {len(widths)} wall-count/excess classes')


if __name__ == '__main__':
    check()
