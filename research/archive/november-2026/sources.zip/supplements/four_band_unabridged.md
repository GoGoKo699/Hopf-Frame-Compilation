# A width-independent normalized gap for all four native T bands

Let R be any zero-clean four-band Clifford+T unitary, including arbitrary interlayer Cliffords, T/T† on arbitrary physical wires, unlimited dirty width and any final address motion. For arbitrary Hermitian input/output Paulis P,Q put e=(1−Re Tr(Q R P R†)/D)/2 for physical dimension D. For single-bit computational readout this is the mean disagreement probability of the designated input and output bits on uniform full basis inputs. Then
$$
 Q R=R P \quad\text{or}\quad e>2^{-28}.
$$
In particular a raw bit response which vanishes off one k-bit address and occurs with positive probability somewhere on that address requires at least five T bands when k≥28. A response supported on a set of total relative address size at most 2^{-28} is excluded in the same manner. This is an absolute constant gap, with no claim that the number 28 is optimal. All tests are on arbitrary input, include all private columns, and permit arbitrary garbage on the output wires.

The four-band normalized scalar-overlap question is identified as open in R75 §7. The proof below differs from that theorem's argument using the full centralizers of both middle bands. It tests a generating set of Paulis with *at most one* active first-side middle rotation. The comparison after this step contains three decorated stabilizer vectors at most, even at arbitrary crossing rank. Related finite-cluster estimates appear in R74 §5.1 for bounded crossing rank. Here the reduction to an absolute number of terms in a single diagonal phase frame is independent of that rank.

## A generating set of sparse Pauli probes

Split the four physical bands into two pairs as in R75. In a common midpoint work frame the two resulting Hermitian Pauli images take the form A=E_A K_A E_A† and B=E_B K_B E_B†. Each E is one fixed-Clifford conjugate of a physical T band, and each K is a Hermitian Clifford. Moves of frame cost nothing in the proof. With the normalized Hilbert–Schmidt norm, ||A−B||₂=2√e. This applies to an arbitrary physical input or output Pauli; the two need not be the same.

The transported binary axes of E_A are linearly independent, since the physical T axes in each band have disjoint wires. Therefore there is a basis of the full work Pauli label space whose each member anticommutes with zero or one of these axes. Choose a basis of the common commutant and extend it by one preimage of each coordinate vector under the map of symplectic pairings with the axes. The map is onto by independence and nondegeneracy. Use the Hermitian representative H for every selected label.

Set A_H=AHA and B_H=BHB. Then ||A_H−B_H||₂≤2||A−B||₂. If H anticommutes with just one E_A axis, E_A† H E_A is the sum of two Hermitian Paulis with signed coefficients 1/√2. K_A maps each term to a Hermitian Pauli. E_A maps each resulting Pauli to a Hermitian Clifford, since a tensor T band is third level and fixed Clifford conjugation preserves that property. Thus A_H is a sum of two Hermitian Cliffords with coefficients ±1/√2. If H commutes with all E_A axes it is a single Hermitian Clifford. On the other side,
$$
 B_H=E_B [K_B(E_B^\dagger H E_B)K_B^\dagger] E_B^\dagger
$$
has a Hermitian Clifford in brackets, for every H. Normalized vectorization preserves the norm₂ exactly. Diagonalize E_B by a Clifford, applying the corresponding basis change to both vectorizations. Every summand from A_H is now a normalized stabilizer vector. The vector of B_H is one normalized stabilizer vector multiplied pointwise by the diagonal eighth-root phase from E_B⊗conjugate(E_B). This phase is a signed sum of computational bits in the physical diagonal basis, equivalently a weighted cubic after an affine restriction.

Canonical phases are important. For a Hermitian Clifford all its nonzero computational entries share a magnitude and have phases in the eighth roots of unity. A Pauli generator convention gives fourth-root relative phases on an affine coordinate parametrization. Hermiticity forces the square of the remaining global scalar to be a fourth root by comparing a nonzero entry with its transposed conjugate. This is the same physical-phase argument in R75 §2. Thus after normalization every vectorized term is supported on an affine binary space S, with nonzero entries of magnitude 2^{-dim(S)/2}. Its phase is a fixed eighth root times i raised to a sum of affine binary coordinates, times minus one to a binary quadratic. For the B_H term there is also the indicated weighted mod-eight cubic. All phases have polynomial descriptions on affine coordinates of their own supports.

## Three-term gap

Let F be the preceding difference of vectorizations. Its coefficient magnitudes are either (1,1) or (1,1/√2,1/√2). We prove that F≠0 implies ||F||>2^{-12}.

For supports S_i,S_j that meet define their integer distance to be d_i+d_j−2dim(S_i∩S_j), with d_i=dim S_i. Set their distance infinite if they do not meet. The modulus of the inner product of unit vectors flat on these supports is at most 2^{-distance/2}. Connect two terms if the distance is at most two. If this graph is disconnected, it has a singleton i since there are at most three terms. Project F on that term's unit vector. In the three-term case the projection magnitude is at least the smaller of 1−√2·2^{-3/2} and (1/√2)−(1+1/√2)·2^{-3/2}, which exceeds 0.1. In the two-term case the bound is 1−2^{-3/2}. Both exceed 2^{-12}.

Now suppose the graph is connected. Write V for the affine hull of all supports, and L for the intersection of their direction subspaces. Then
$$
 \dim V-\dim L\le 2(\#\text{terms}-1)\le4.
$$
Indeed start from one support and add children along a spanning tree. A child meets its parent. Their intersection direction is the intersection of their two direction spaces. The hull dimension increases by at most the child dimension minus the intersection dimension. The running common tangent dimension decreases by at most the parent dimension minus the intersection dimension. The sum is bounded by their edge distance. In particular d_i is within four of dim V for each i.

Choose z₀ where F(z₀)≠0. On z₀+L the same set of supports is active everywhere. Their relative phases, rather than their common absolute phase, determine the modulus of F. If there is at least one active ordinary stabilizer term choose it as reference. The only possible other ordinary stabilizer relative phase is a constant times a mod-four Clifford phase. Its two variable binary digits are Boolean polynomials of degrees ≤1 and ≤2. The B_H relative phase has three digits of degrees ≤1, ≤2 and ≤4. One proof writes the mod-eight exponent as a signed weighted sum of affine bits and four times a binary quadratic, up to a fixed additive constant; intrinsic stabilizer phase factors have the same form with even coefficients. The bit of order j in an integer sum of binary bits is the elementary symmetric polynomial of order 2^j, by the binomial formula in characteristic two. Repeat terms according to coefficient modulo eight, so negative coefficients cause no exception. Four times a binary quadratic affects only the highest digit. The same argument modulo four, with two times a quadratic, gives the two-digit assertion for an ordinary stabilizer ratio. Restricting to the affine coset preserves these degree bounds. If the B_H term is alone there is no relative phase to fix.

The indicator that all relative phase digits equal their values at z₀ thus has binary degree ≤1+2+1+2+4=10 and is nonzero. It is one on at least a 2^{-10} fraction of the coset by the minimum weight of a nonzero degree-ten Boolean polynomial. At those points |F| equals its nonzero value at z₀. The coset itself occupies at least 2^{-4} of V.

Put d=dim V. The number α=√2·2^{d/2}F(z₀) is in Z[ω] with ω=exp(πi/4), since each support codimension d−d_i is an integer, the nonzero entries have eighth-root phases, and the additional √2 clears both possible coefficients. The nonconjugate embedding σ:ω↦ω³ has
$$
 |\sigma(\alpha)|\le \sqrt2\,2^2(1+\sqrt2)<14
$$
in both coefficient cases (the worst sum of coefficient magnitudes is 1+√2). Algebraic integrality gives 1≤|Norm(α)|=|α|²|σ(α)|². Hence |F(z₀)|>2^{-d/2}/20. Summing on at least 2^{d-14} points yields ||F||>2^{-7}/20>2^{-12}. This proves the uniform three-term gap.

## Closing the circuit gap

If ||A−B||₂≤2^{-13}, then all the chosen generators satisfy A_H=B_H by the three-term gap. It follows by multiplication with B,A that BA commutes with each generator. The full Pauli algebra has only scalar commutant. Since A and B are Hermitian unitaries, scalar proportionality means A=±B. The minus option has distance two, so A=B. Equivalently for unequal A and B one has ||A−B||₂>2^{-13}, loss 1−Re Tr(AB)/D>2^{-27}, and mean bit disagreement e>2^{-28}. The width-independent normalized alternative follows without assuming rarity on an address subset or first invoking central normalization.

The proof uses linear independence of each native band's physical T axes to produce sparse probes; generally correlated formal cubic-phase rotation lists do not inherit this step. An initialized-only promise is different because the normalized trace then averages over many unconstrained columns. These are limitations of this particular obstruction, and the unrestricted complete-frame depth question remains open.

## A shorter support classification gives a larger constant

There is a stronger direct estimate. Set b=2 sin(π/24). For the same decorated Choi difference one has F=0 or ||F||≥b. Thus for four bands e=0 or
$$
 e\ge b^2/16=(1-\cos(\pi/12))/8>2^{-8}.
$$
If instead exact silence holds outside a single k-bit row, already k≥7 is impossible. This also excludes exact silence outside any set of physical columns of relative dimension at most 1/128 if it means the original readout observables agree on that entire subspace.

Here C denotes the normalized Choi vector of B_H in the decorated frame and U,V the two ordinary stabilizer Choi vectors in A_H. Their native signed coefficients can be absorbed into the respective phases. The vectors U and V are orthogonal: before their identical Clifford/phase conjugations they were distinct Paulis. Thus (U+V)/√2 has unit norm. In the case of one left term, the R75 one-phase stabilizer overlap gap already gives distance at least sqrt(2δ)>b, or equality.

If either |⟨C,U⟩| or |⟨C,V⟩| is at most 1/2, Bessel's inequality on these orthonormal unit vectors gives
$$
 \operatorname{Re}\langle C,(U+V)/\sqrt2\rangle
 \le (1+\sqrt3)/(2\sqrt2)=\cos(\pi/12).
$$
In this inequality maximize a+sqrt(1−a²) for 0≤a≤1/2. Thus assume both overlaps exceed 1/2, so both support distances from S=supp C are at most one. Each is equal to S, contains it with index two, or has index two within it. Incidence is affine.

* If a support is double S and the other has no support outside S, the outside contribution has norm 1/2. Two distinct double supports have disjoint outside cosets and give norm at least 1/2 there. If both double supports coincide, on S each summand carries one half of the target magnitude. The squared norm of the discrepancy equals the sum of the two losses 1 minus the real phase-mean on S, since both original states are normalized. Each loss is zero or at least 1/8 by the weighted-phase digit argument below. If both vanish the norm is zero.
* Two half supports which are not complementary leave at least one quarter of S uncovered. If complementary, on each half there is one unit-magnitude relative phase. The squared norm is either zero or at least 1/8 by the same one-phase estimate. If one support is half and the other equal, the norms of (U+V)/√2 on that half and its complement are √3/2 and 1/2. Orthogonality holds on the only shared half, and the complement mass is 1/4. The respective norms of C are 1/√2 and 1/√2. The triangle inequality on each block gives squared distance at least b².
* Suppose all three supports equal S. On S put r=V/U using the ordinary stabilizer phases. This is a fixed eighth root times a mod-four Clifford phase. If r always has odd eighth-root exponent, the magnitude of (1+r)/√2 differs from one at every point by at least sqrt(1+1/√2)−1>b. Otherwise r takes only fourth roots. Its real-valued positions are either empty or occupy at least half of S, since the lowest bit of its mod-four exponent is affine. On each real position the modulus differs from one by at least √2−1. The resulting distance is at least (√2−1)/√2>b. If there are no real positions, write r=i(−1)^q where q is binary of degree at most two (the high bit of its Clifford phase exponent). Then (U+V)/√2 equals U·ω i^{-q} on the entire support. The relative phase with C has three binary exponent digits of degrees at most 1,2 and 4 respectively. In particular adding the exponent −2q preserves these bounds, including its carry into the top digit. If the phase is ever not one, take its lowest nonzero digit. At least 1/2, 1/4, or 1/16 of positions have that digit nonzero, respectively. At these positions the real cosine loss is at least 1−1/√2, 1 or 2 respectively, since all lower digits vanish identically. Thus the mean one-phase loss is at least 1/8. Here the squared norm is twice this loss. The same lower 1/8 bound applies to every one-phase loss above.

Every displayed alternative gives either equality or distance at least b. Combining with the sparse-generator argument proves the mean disagreement bound. For the exact-support refinement, W=BA and its defect rank satisfies rank(W−I)≤D2^{-k} by unitary transport from the original input subspace. For every H,
$$
 \|AHA-BHB\|_2^2=\|W H W^\dagger-H\|_2^2
 \le 8\operatorname{rank}(W-I)/D.
$$
The operator on the right has norm at most two and rank at most twice the defect rank of W by telescoping. If k≥7 this is at most 1/16, strictly smaller than b². The equalities on all generators force W scalar and the rank hypothesis then forces W=I. This use of exact silence does not require centralizing W first.
