from itertools import permutations, product
from random import Random
from functools import reduce
from operator import xor


def setup(k, mod):
    q=1<<k
    def mul(a,b):
        c=0
        while b:
            if b & 1:
                c^=a
            b>>=1; a<<=1
            if a&q:
                a^=mod
        return c
    def power(a,e):
        c=1
        while e:
            if e&1:
                c=mul(c,a)
            a=mul(a,a);e>>=1
        return c
    trace=[reduce(xor,(power(a,1<<i) for i in range(k)),0) for a in range(q)]
    assert set(trace)=={0,1}
    return q,mul,power,trace


def check():
    rng=Random(431)
    total,cases=0,0
    for k,mod in [(3,0b1011),(4,0b10011),(5,0b100101),(6,0b1000011),(7,0b10000011),(8,0x11b)]:
        q,mul,power,tr=setup(k,mod)
        f=[tr[power(a,15)] for a in range(q)]
        if k<=4:
            triples=list(product(range(q),repeat=3))
        else:
            triples=[tuple(rng.randrange(q) for _ in range(3)) for _ in range(140)]
        for h in triples:
            def minor(skip):
                columns=[i for i in range(4) if i!=skip]
                return reduce(xor,(reduce(mul,(power(a,1<<j) for a,j in zip(h,p)),1)
                                   for p in permutations(columns)),0)
            c=[minor(j) for j in range(4)]
            coeff=reduce(xor,(power(c[j],1<<(3-j)) for j in range(4)),0)
            dirs=(0,h[0],h[1],h[2],h[0]^h[1],h[0]^h[2],h[1]^h[2],h[0]^h[1]^h[2])
            off=reduce(xor,(f[d] for d in dirs),0)
            samples=[]
            for v in range(q):
                got=reduce(xor,(f[v^d] for d in dirs),off)
                assert got==tr[reduce(xor,(mul(c[j],power(v,1<<j)) for j in range(4)),0)]
                samples.append(got)
                total+=1
            assert (not any(samples))==(coeff==0)
            cases+=1
    return cases,total

if __name__=='__main__':
    print('Triple vanishing tests and fourth derivatives:',check())
