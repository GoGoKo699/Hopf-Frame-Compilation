# An explicit trace-quartic frame witness

In the bounded-mixing full-frame decomposition, let k=n−1, F be GF(2^k) for k≥3 and f(x)=Tr(x^15). The corresponding real complete Hopf frame uses zero upper angles and last real angles π f(x). For every unit-modulus nonclassical cubic φ on the binary address space, meaning its fourth multiplicative differences vanish (equal one),
$$
 |\mathbb E_x(-1)^{f(x)}\phi(x)|\le \min(1,(112\,2^{-k})^{1/8}).
$$
This applies to every weighted mod-eight phase from an internal monomial path of the native frame construction. It also applies when multiplied by the indicator of any affine subspace, since that indicator has a linear-character expansion of total coefficient modulus at most one. Affine retractions extend the conditional phase to all addresses with its third-degree property.

Three Cauchy–Schwarz differences give the eighth power of the correlation bounded by the average over h₁,h₂,h₃ of the modulus of the x-mean of the third derivative of (-1)^fφ. The third derivative of φ is constant. The multiplicative third derivative of (-1)^f is an affine binary phase as a function of x. Its x-mean has modulus one or zero according as its linear part vanishes or not.

The linear part is the fourth derivative of f evaluated in (h₁,h₂,h₃,x). Since x^15=x·x²·x⁴·x⁸ and the four factors are binary-linear, the polarized coefficient is the trace of the 4-by-4 Moore determinant (in characteristic two all permutation signs are one). Expand in the last row as Σ_{j=0}³ C_j x^{2^j}. Trace duality and the fact a nonzero trace pairing is nondegenerate show that the linear form vanishes exactly if
$$
 C_0^8+C_1^4+C_2^2+C_3=0.
$$
Indeed the fourth power directions in the usual trace adjoint can all be raised to 8 simultaneously. The displayed polynomial in the three uniform field directions is nonzero as an ordinary polynomial: each minor C_j has disjoint determinant monomials and is homogeneous of degree 15−2^j. After the indicated powers the four degrees are 112,52,22,7, so the leading part cannot cancel. The elementary polynomial zero bound over the finite field gives the exceptional probability at most 112/2^k. This proves the correlation statement, trivial for bounded small k. The same three-difference observation upgrades the disjoint-block quartic witness from the sixteenth root to the eighth root, since each third derivative is affine there as well.

For an ε-accurate native frame let H_min be the minimum total stabilizer-basis changes for band-by-band diagonalization (sum of the Lagrangian intersection codimensions) and let Γ_all be the single common isotropic-space distance parameter. Every path bound with ≥1−ε²/2 target correlation gives
$$
 \Gamma_{\rm all}\ge (k-\log_2 112)/8+\log_2(1-\epsilon^2/2),
 \qquad
 H_{\min}\ge (k-\log_2 112)/4+2\log_2(1-\epsilon^2/2).
$$
The first drops the nonnegative-part operation on its right if that right side is negative. The second uses H_min actual internal Hadamard gates with free Clifford boundaries and path coefficient modulus 2^{H_min/2}. A random sign can give the stronger near k/2 and k bounds respectively. The trace monomial gives one fully specified target without a classical truth-table search.
