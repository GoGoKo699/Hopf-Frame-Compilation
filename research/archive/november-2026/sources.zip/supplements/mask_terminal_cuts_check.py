"""Direct Pauli-coefficient checks of terminal native-band cosets."""
from itertools import product
from random import Random
import math
import numpy as np
rng=Random(32277)

def reduce(value,basis):
    for bit,u in sorted(basis.items(),reverse=True):
        if value>>bit&1:
            value^=u
    return value

def form(values):
    b={}
    for u in values:
        u=reduce(u,b)
        if u:
            b[u.bit_length()-1]=u
    return b

def fullspan(values):
    out=[0]
    for value in values:
        out += [x^value for x in out]
    return out

def random_basis(values):
    a=values.copy()
    for _ in range(8*len(a)):
        if len(a)>1:
            i,j=rng.sample(range(len(a)),2)
            a[i]^=a[j]
    rng.shuffle(a)
    return a

def paulis(n):
    m=1<<n
    out=[]
    for p in range(m*m):
        x,z=p%m,p//m
        mat=np.zeros((m,m),complex)
        for j in range(m):
            mat[j^x,j]=(1j**((x&z).bit_count()))*(-1)**((j&z).bit_count())
        out.append(mat)
    return np.array(out)

def sym(p,q,n):
    mask=(1<<n)-1
    return (((p&mask)&(q>>n)).bit_count()+((q&mask)&(p>>n)).bit_count())%2

def masses(P,O,quotient):
    coeff=np.einsum('aij,ij->a',P.conj(),O)/len(O)
    output={}
    for lab,alpha in enumerate(coeff):
        key=reduce(lab,quotient)
        output[key]=output.get(key,0)+abs(alpha)**2
    return {k:v for k,v in output.items() if v>1e-9}

def random_symplectic(n):
    images=[1<<i for i in range(2*n)]
    for _ in range(6*n):
        p=rng.randrange(1,4**n)
        images=[x^p if sym(x,p,n) else x for x in images]
    return fullspan(images)

def band(a,P):
    out=np.eye(P.shape[1],dtype=complex)
    for b in a:
        out=out@(math.cos(math.pi/8)*np.eye(len(out))+rng.choice([-1,1])*1j*math.sin(math.pi/8)*P[b])
    return out

trials=cells=overlap=quadratic=prior=0
for n in range(2,6):
    P=paulis(n); m=1<<n
    for _ in range(65):
        perm=random_symplectic(n)
        h=rng.randrange(n+1)
        # shared directions, then transverse directions. Mix the individual native axes.
        B=[perm[b] for b in random_basis([1<<(n+i) for i in range(n)])]
        A=[perm[b] for b in random_basis([1<<(n+i) if i<h else 1<<i for i in range(n)])]
        a=form(A)
        all_active=rng.choice([True,False])
        possible=[p for p in range(1,4**n) if not all_active or all(sym(p,x,n) for x in B)]
        p=rng.choice(possible)
        active=[x for x in B if sym(p,x,n)]
        bq=form(reduce(x,a) for x in active)
        q=len(bq)
        if len(active)>q: overlap+=1
        coset_base=reduce(p,a)
        labels=fullspan(list(bq.values()))
        EA=band(A,P); EB=band(B,P)
        interior=EB.conj().T@P[p]@EB
        C=EA.conj().T@interior@EA
        before=masses(P,interior,a)
        full=masses(P,C,{})
        directions=[]; offsets={}
        for i,val in enumerate(labels):
            group={k:v for k,v in full.items() if reduce(k,a)==(val^coset_base)}
            assert group and abs(sum(group.values())-1/2**q)<1e-7
            assert max(group.values())-min(group.values())<1e-7
            f=next(iter(group))
            cur=form(x^f for x in group)
            assert len(group)==2**len(cur)
            directions.append(cur)
            offsets[i]=f
            assert abs(before[val^coset_base]-1/2**q)<1e-7
            cells+=1
        D=form(v for d in directions for v in d.values())
        assert len(D)<=(q+1)*max(map(len,directions))
        offset_vals=[reduce(offsets[i],D) for i in range(1<<q)]
        for j in range(q):
            for i in range(1<<q):
                if i>>j&1: offset_vals[i]^=offset_vals[i^(1<<j)]
        assert all(val==0 for i,val in enumerate(offset_vals) if i.bit_count()>2)
        quadratic+=sum(i.bit_count()>2 for i in range(1<<q))
        Small=[rng.randrange(1,4**n) for _ in range(rng.randrange(1,4))]
        S=form(Small); R=band(Small,P)
        left=masses(P,C,S); right=masses(P,R.conj().T@C@R,S)
        assert left.keys()==right.keys() and max(abs(left[k]-right[k]) for k in left)<1e-7
        prior+=len(left); trials+=1
print(f"{trials} two-band matrix trajectories, {overlap} overlapping active-axis trials, {cells} affine stabilizer cells, {quadratic} cubic-or-higher offset coefficients, {prior} preserved early-rotation quotient masses")

# Check the vector-quadratic small-image proof, including the filtration bound.
from itertools import combinations
from collections import Counter
quad_sites=filtration=0
for n in range(2,8):
    for _ in range(28):
        w=rng.randrange(1,n+4); imask=1<<w
        bias=rng.randrange(imask)
        linear=[rng.randrange(imask) for j in range(n)]
        coeffs=[(i,j,rng.randrange(imask)) for i,j in combinations(range(n),2)]
        vals=[]
        for x in range(1<<n):
            val=bias
            for i,a in enumerate(linear):
                if x>>i&1: val^=a
            for i,j,a in coeffs:
                if x>>i&x>>j&1: val^=a
            vals.append(val)
        ranks=[]
        U={}; steps=0
        for y in range(1<<n):
            col=[vals[(1<<i)^y]^vals[1<<i]^vals[y]^vals[0] for i in range(n)]
            V=form(col)
            ranks.append(len(V))
            if any(reduce(a,U) for a in V.values()):
                steps+=1
                U=form(list(U.values())+list(V.values()))
        assert steps<=2*max(ranks) and len(U)<=2*max(ranks)**2
        freq=Counter(vals)
        for target_size in sorted({len(freq),max(1,len(freq)-1),max(1,int(.8*len(freq)))}):
            d=1-sum(c for a,c in freq.most_common(target_size))/(1<<n)
            if d>=.5: continue
            h=math.log2(target_size**2/(1-2*d))
            assert max(ranks)<=h+1e-8
            projected=form(reduce(v^vals[0],U) for v in vals)
            assert len(projected)<=math.log2(target_size/(1-d))+1e-8
            quad_sites+=1
        filtration+=steps
print(f"{quad_sites} robust quadratic-image bounds and {filtration} independent bilinear filtration increments")
