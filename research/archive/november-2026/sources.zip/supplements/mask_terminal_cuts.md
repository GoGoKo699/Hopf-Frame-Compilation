# Native gate populations before the last bands of an observable encoder

Write m=2^k and a desired full-space mask translation as
[
 W_v|x,z,w\rangle=|x,z+v_x,w\rangle .
]
The m-by-width binary matrix with rows v_x has rank r. Suppose the **actual** observable V† P V, for one fixed nonidentity Hermitian physical Pauli P, is within full operator norm ε of W_v. All physical inputs are arbitrary. No read-only address restriction, intermediate Pauli promise, architectural assumption, maximum dirty width or maximum final layer size occurs in the following gate-count inequalities. Initialize no private wire. The result is for this one-observable representation; it is not a general growing depth lower bound for complete frames.

For fixed ε<1/√2, let s_j count the native T/T† gates in V chronologically *before* its last j T bands (pad with empty bands if needed). Then
[
 s_1\ge r-k-1,qquad s_2\ge \sqrt{2r}-O_\epsilon(k+1).
]
For the second claim there is an integer q≤s₂+2k and any positive integer c with ε²<(1−2⁻ᶜ)/2 gives the explicit inequality
[
 r\le 1+s_2+(2k+c)(q+1)+q(q+1)/2 .
]
For exact equality one may take c=0. For the near-full-rank goal these bounds force Ω(m) gates before the last pulse and Ω(√m) before the last pair even when the latter gates act on wholly different and arbitrarily many physical qubits. A shallow circuit with several wide layers can obey both inequalities.

## Pauli coefficients and blind directions

Use the unit-normalized Hilbert–Schmidt inner product and the orthonormal Pauli basis. A unitary has a norm-one coefficient vector, giving a probability distribution on binary Pauli labels via squared coefficient magnitudes. Conjugation by a product of rotations on axes in a binary space S preserves the mass in each coset of S: on the operator subspace spanned by a coset it acts unitarily with no matrix elements outside that coset. This holds equally after any further binary linear projection of those cosets. Absorb all Clifford intervals of V into fixed axis choices. The trailing Clifford at its output can be absorbed into P, and the choice of absorbed coordinates can leave the original input basis intact. Native axes within one band are independent and commute.

The Pauli support of W_v has at most m² labels: expand each address projector |x⟩⟨x| into the m address-Z characters and attach X(v_x). The distribution after projection to the bank X label has at most m possible values. For any projection the mass of the actual observable outside the projected target support is at most ε², since normalized Hilbert–Schmidt distance is bounded by operator norm. Furthermore every desired bank-X value occurs in the actual observable support: otherwise the corresponding matrix element from a computational input to its prescribed basis output would vanish, contradicting ε<1. In particular any affine hull containing the actual full Pauli support must project onto an affine hull of dimension at least r−1 in bank-X coordinates.

The final T band acting on P gives one Clifford C whose Pauli expansion has equal magnitudes on a single affine subspace. Indeed let B₁,…,B_b be exactly the mutually commuting independent axes of that band that anticommute with P. The answer up to fixed scalar is
[
 C=2^{-b/2}\sum_{u\in\mathbb F_2^b}i^{\sum_j e_j u_j} B(u)P,
 \qquad B(u)=\prod_j B_j^{u_j},\quad e_j\in\{1,-1\}.
]
After quotient by the span S of earlier axes, dim S≤s₁, this law is still exactly uniform on an affine subspace, also after projecting onto bank-X labels modulo the bank X projection of S. The ≤m target values contain mass at least 1−ε²>1/2 so the projected affine dimension is at most k (powers of two). Lifting back adds at most s₁, giving the first claim.

## Slicing the penultimate native band

Write s=s₂, let S be the span of these earlier gates and π the projection of the full binary physical Pauli space modulo S. Let A₁,…,A_a be the penultimate-band axes, with span A, and let B be the span of the b final active axes above. Set H=A∩B and q=dim B−dim H. Projecting labels modulo A+S ignores all remaining conjugations. The result is uniform on an affine space of dimension at least q−s, because projecting the uniform final-band labels modulo A gave dimension q. Since the ideal has ≤m² labels and ε²<1/2, the resulting dimension is ≤2k. Hence q≤s+2k.

Before applying earlier gates, resolve the coefficient vector into its 2^q cosets modulo A, all of equal mass. Parameterize the cosets linearly by l∈F₂^q and choose representatives Q_l=B_c(l)P, whose physical Pauli labels are affine in l. Inside a coset use the orthonormal basis A(g)Q_l, g∈F₂^a, with A(g) the honest product representation of the fixed commuting Hermitian A axes. This basis differs from the standard Pauli section only in phases. The normalized coefficient vector arriving from the final-band Clifford is, up to scalar,
[
 |\psi_l\rangle=Z^{w(l)}|\psi_0\rangle
]
for one fixed stabilizer state and one linear w(l). To see this, choose linear final-axis coordinates u=Dl+Th for h ranging over H. The physical group product B(Th) equals A(Mh) times a sign character of h. Flipping the T orientation/sign contributes only the coefficients e_j in the previous display. Splitting the bitwise XOR Dl+Th in the exponent i^{Σ e_j u_j} yields, besides an l-only scalar and the h-only phase, the binary sign (−1)^{(Dl)·(Th)}. This extends linearly to a Z phase on the coordinates Mh. The h-only phase i^{Σ e_j (Th)_j} is a restriction of diagonal Clifford S gates to a linear embedding; equivalently, prepare the uniform linear-code state and apply commuting Clifford parity phases. Thus ψ₀ is a stabilizer state.

Write t_j(l)=⟨A_j,Q_l⟩ for the symplectic commutation bit, an affine binary function of l. Conjugation by the penultimate layer inside this coset applies the ordinary **Clifford** on the coefficient register
[
 K_l=\left(\prod_j e^{i\sigma_j\pi t_j(l)X_j/4}\right) Z^{w(l)}
]
to |ψ₀⟩, with fixed orientation signs σ_j. Indeed A(g) commutes with every penultimate rotation, and left multiplication by A_j is the coordinate bit flip g_j on A(g)Q_l. The conditional distribution after this band is the computational probability distribution of K_l ψ₀. Earlier rotations preserve its unconditional marginal modulo S. Coset weights are probabilities and add even when a projection identifies distinct cosets.

Let D_A:g↦label(A(g)) and M=πD_A. The projected distribution conditional on l is uniform on an affine coset with direction
[
 D_l=\mathrm{im}\,M[X+\mathrm{diag}(t(l))Z],
]
where the columns of (X,Z) are the binary stabilizer-generator labels of ψ₀. This follows because the translation directions of the computational support of a stabilizer are the X-projections of its stabilizer, and rotations of π/4 about X transform (x,z) to (x+t⊙z,z). If dim D_l>2k+c, at least 1−2⁻ᶜ of this conditional distribution lies outside the ≤m² projected target labels. Under the stated condition on c, strictly more than half the l have dim D_l≤2k+c. These good l contain an affine basis of F₂^q, since any proper affine flat contains at most half of that space. The matrix defining D_l is affine in l. Consequently the span D of ALL D_l is contained in the sum of their images on the selected q+1 good points and dim D≤(q+1)(2k+c). At ε=0 every cell is good at c=0.

## The centers modulo the common direction space

After quotient by D, the conditional projected output at each l is a *point* z(l). Every binary functional η that kills D gives a sign (−1)^{η·z(l)}. Apart from the affine sign for πQ_l this equals the stabilizer expectation of K_l† Z(Mᵀη) K_l in ψ₀. Put y=Mᵀη. In the untwisted section X^a Z^b, the resulting Pauli has label (t(l)⊙y,y). Its phase has the form i^{c+Σ e_j t_j(l)y_j}(−1)^{w(l)·(t(l)⊙y)} with fixed e_j∈{−1,1}. Its expectation has magnitude one for every l, so these unsigned labels belong to the binary stabilizer. Their generator coordinates are affine bits of l. The phase of a stabilizer product in that section is i^{Σ d_j b_j+2Σ_{i<j}e_{ij}b_i b_j} in its binary generator coordinates b_j, by collecting ordered Pauli products. Composing these expressions with affine Boolean bits gives a mod-four constant-plus-linear-plus-even-quadratic polynomial in l: modulo four an XOR of affine input bits is their sum minus twice the sum of pair products (with a constant if needed). The total phase is real at every l; testing at zero and each unit vector shows its constant and all linear coefficients are even. Therefore η·z(l) has Boolean degree at most two. In a binary basis of the quotient this proves the vector-valued z(l) is quadratic. Its affine hull has dimension at most q+binom(q,2).

The actual full Pauli support thus lies in an affine space of dimension ≤dim S+dim D+q+binom(q,2), since conjugation by earlier rotations cannot leave the cosets of S. Every desired mask is present after projection to bank-X, proving the displayed two-band bound. This proof uses the sparse *entire* Pauli support of the required returned operator. A guarantee on one initialized state alone does not imply it.

## A separate diagnostic when the physical address is a sector label

Assume each interlayer Clifford takes the computational address fibers into themselves (a fixed invertible affine relabeling of the address at a boundary is harmless), and native T bands are on the actual computational wires in those frames. Independent helper basis changes, including Hadamards, are allowed. Fiberwise each interlayer Clifford is, up to scalar, a fixed helper Clifford followed by a helper Pauli P_{Lx} with affine labels. Indeed conjugation of any helper Pauli yields a fixed helper Pauli and an address-Z character, and the relative character map is represented by such a helper Pauli. A native T band on the actual wires is a fixed band on the helpers up to address-only scalar. This section concerns V, not an arbitrary equivalent decomposition of the complete echo.

Use projective operator distance and set e_*=sqrt(2−sqrt 2). Any two projectively different Clifford unitaries have distance ≥e_*: the normalized trace of their relative Clifford has magnitude at most 1/√2. Indeed its squared magnitude is the normalized trace of the superoperator, the signed count of fixed Pauli labels divided by all labels. If its symplectic map is nonidentity, at most half of those labels are fixed; a nontrivial Pauli has zero trace. The normalized Hilbert–Schmidt distance gives the claimed bound. A fixed three-band unitary U=E₃E₂E₁ can send a Pauli arbitrarily close to a Pauli at distance <e_*/2 only when the two coincide projectively. Reduce to E₂ C E₂† close to a Clifford D, with C,D Cliffords obtained by conjugating the comparison Paulis by the endpoint bands. For each Pauli Q, E₂ Q E₂† is a Hermitian Clifford. Both E₂ C Q C† E₂† and D(E₂ Q E₂†)D† are consequently Hermitian Cliffords at literal distance <e_* when the assumed projective error for E₂ C E₂† vs D is <e_*/2. They agree projectively by the gap and hence literally since the two possible Hermitian signs differ by 2. Their agreement for every Q implies E₂ C E₂† equals D up to scalar. The same bound covers shorter blocks by padding.

In any block of at most three consecutive bands, move its internal address-dependent Paulis to the nearest outside boundary. Each crosses at most one T band. The resulting block on address x has form A_x U B_x, U fixed, and A_x,B_x helper Cliffords. The symplectic map of a moved guard E P_{Lx} E† is affine in x: it is the product of transvections along the commuting axes a_i of E activated by the bits ⟨a_i,Lx⟩, with no cross terms because those axes are isotropic. After absorbing fixed Clifford basis changes, a length-three block has one such variable symplectic map on each side; a length-two block has one in total and a length-one block none. Ordinary endpoint Paulis change only signs. Suppose a block starts and ends at distance <e_*/4 from a projective Pauli along the actual propagated-probe trajectory of this x. Substitution of nearest endpoint Paulis yields a fixed U mapping the B_x-transformed Pauli within <e_*/2 of the A_x-inverse-transformed result. Exact projective matching follows by the three-band rounding just proved. The binary map of U on its Pauli-preserving domain is linear. Extend it linearly to all binary labels (the arbitrary extension is used only for polynomial evaluation). Each such block incurs at most its length minus one in Boolean degree, regardless of the two intermediate trajectories.

Write d for the native band count. Assume the target is literally fiberwise Pauli or is within <e_*/4 of it. For each x whose non-Pauli excursions stay below *three consecutive boundaries* at distance ≥e_*/4, there exists a partition into blocks of lengths 1,2 or 3 with pure-enough endpoints. On the addresses admitting any one specified partition, the labels agree with a single vector polynomial of degree ≤d−ceil(d/3), obtained by composing the affine Clifford symplectic maps with the fixed linear extensions. At most 2^d distinct partitions are possible. If B addresses have a three-boundary excursion then
[
 r\le B+2^d\sum_{i=0}^{\min(k,\lfloor 2d/3\rfloor)}\binom{k}{i}.
]
At d=o(log k) and r≥2^k−2^{k/2}, all but at most 2^{k/2}+2^{o(k)} addresses must therefore have three consecutive boundaries at constant distance from every projective Pauli. A bounded number of isolated non-Pauli steps at variable locations, or arbitrarily many separated runs of one or two such steps, cannot carry the required rank. This diagnostic does not assume a fixed helper Clifford on each whole address history; its address-sector hypothesis nevertheless excludes unrestricted motion entangling the represented address and helpers at the T boundaries.

## Removing dependence on the number of coarse bits

At the small fixed errors relevant to the frame, the previous two-band inequality sharpens to
[
 \boxed{s_2\ge r-O_\epsilon((k+1)^2),\qquad 0\le\epsilon<1/2.}
]
In particular a final pair of arbitrarily wide bands leaves a linear-size earlier T population for a near-full mask family. This does not force many earlier layers; that linear population could itself occupy a single wide layer.

Here is an elementary small-image lemma for Boolean vector quadratics. Let F:F₂^n→F₂^w have multilinear degree ≤2 and suppose F(x) belongs to a set of size K with probability ≥1−δ for uniform x, δ<1/2. Put h=log₂(K²/(1−2δ)). Then the affine hull of its *whole* image has dimension at most
[
 Q(K,\delta)=2h^2+\log_2(K/(1-\delta)).
]
For each fixed y the derivative F(x+y)+F(x) belongs to the pairwise sumset with probability ≥1−2δ by the union bound and translation invariance. Its distribution is uniform on an affine space of direction B(y,·), where B(x,y)=F(x+y)+F(x)+F(y)+F(0) is symmetric bilinear. Each directional rank is therefore ≤h. Starting with U₀=0, successively adjoin a new range B(v_i,·) not contained in its previous span U_{i−1}, until their common span is exhausted. At each step the chance over one uniform x that B(x,v_i) lies outside U_{i−1} is ≥1/2 by linearity and the choice of v_i. By symmetry B(x,v_i) belongs to U_i for every x. For a fixed x all vectors witnessing such a step are independent by filtration, and they all belong to the at-most-h-dimensional space B(x,·). Taking expectations gives at most 2h steps; independence of the events is unnecessary. Every step adds at most h dimensions, so the complete derivative span has dimension at most 2h². Modulo it F is affine, hence contributes at most log₂(K/(1−δ)) further dimensions. This proof is independent of the number of input, output and dirty wires.

Apply the lemma to the output label Y of the penultimate coefficient experiment, projected modulo S. It has mass ≥1−ε² on a set T of K≤m² labels. Choose one random coset l and two independent conditional outcomes Y,Y' from that same coset. Both marginal laws are the measured output law. Their difference belongs to T+T with probability at least 1−2ε², and conditional on l it is uniform on the direction D_l. Consequently its law equals that of the vector polynomial
[
 G(l,u)=M[X+\mathrm{diag}(t(l))Z]u
]
with l,u independent uniform binary vectors. This is an actual degree≤2 polynomial on their concatenated bits. Its image spans the entire D=span_l D_l and contains 0. The lemma proves dim D≤Q(K²,2ε²), independently of q and all widths. In the quotient by D the output is the deterministic vector polynomial z(l) of degree≤2 from the preceding section. Its probability mass on at most K labels is ≥1−ε², so its affine span has dimension at most Q(K,ε²). Lifting the two spans and the s earlier axes yields
[
 r\le1+s+Q(m^4,2\epsilon^2)+Q(m^2,\epsilon^2).
]
At fixed ε<1/2 both added terms are O_ε((k+1)²). At ε=0 their sum equals 160k²+6k. If desired, replace 2ε² by 1−(1−ε²)² by conditioning on l and using Jensen's inequality on the probability that both outcomes lie in T. This extends the same conclusion up to ε<sqrt(1−1/√2).

## Strongest version: only heavy masks are needed

Let a physical observable echo have a list of at most m desired bank-X labels of rank r, each having probability at least p>0 in its squared Pauli coefficient distribution. The rest of the actual echo can be arbitrary. The full operator approximation on a selected address implies p≥(1−ε²/2)²/m for each such mask, ε<√2, because the required computational output has that success probability on every computational bank/work input at that address. Parseval identifies the mean computational probability of a bank flip with its squared Pauli marginal. For c₀ initialized clean bits and correctness only on their zero sector, average only those physical inputs and pay a factor 2⁻ᶜ⁰ in p. Other address sectors can be unrestricted. These estimates also apply if only the mean computational success on the good address is certified, using that success directly in p.

The final-band uniformity gives immediately s₁≥r−1−log₂(1/p): after projection mod the earlier bank axes every witnessed label remains heavy, and a uniform affine law with an atom ≥p has at most 1/p points. There is a stronger two-band bound:
[
 H=\lceil\log_2(2/p)\rceil,\quad L=\lceil\log_2(2m/p)\rceil+1,
 \qquad r\le 1+s_2+H(L+1)+L(L+1)/2.
]
In particular the number of earlier gates is at least r−4k²−O_{ε,c₀}(k+1) at fixed error/clean count. No complete ideal translation is needed on any unwitnessed address. This also sharpens constants for the full-source case.

Apply the two-band conditional-cell construction directly to the linear projection onto bank-X modulo the projected space of the earlier s₂ axes, with M taking values in this smaller quotient. Every specified projected label y has weight ≥p, even if some labels collide. A cell of dimension >H contributes at most p/2 to its conditional probability. Hence with probability at least p/2 over uniform l, the cell has dimension ≤H *and* contains y. Distinct masks can use different such l's. A uniformly random affine map from L bits into the coset-label bits has pairwise independent values on any two distinct inputs. The number of hits of y's good l's has mean ≥2^L p/2, variance at most its mean. A union bound over ≤m labels proves some one affine map hits a good small cell for every desired label.

Inside its image take the affine hull A' of only the visited small-cell l's. Its dimension is ≤L. They contain an affine basis of A' by definition, and every one of these basis cells has rank ≤H. Since the direction matrix is affine in l, the span D' of all directions for l∈A' has dimension ≤H(L+1). The existing stabilizer-offset proof applies to this restricted affine family: after quotienting by D' the output is deterministic in every cell of A', and the unsigned Pauli and stabilizer generator coordinates are affine functions of its ≤L affine coordinates. The offsets have Boolean degree ≤2 on A', so their affine span contributes at most L(L+1)/2. All desired projected masks belong to this affine hull plus D', since each was hit in one of the selected cells. Lifting the earlier-axis space adds at most s₂. This establishes the stated inequality independently of q, total width and total axis overlaps.
