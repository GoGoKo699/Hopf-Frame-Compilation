# Fresh-workspace reproducibility audit

I checked the standalone research artifacts against repository commit ae613bf8e8a38f6d0407c25910b83d69f01a2733. The working tree was clean. No repository files were changed.

Eight ZIPs supplied 184 entries and 81 checker invocations (including repeated checks where a later packet includes a dependency). All eight ZIP integrity checks and runners passed after extraction into separate empty directories. Six additional standalone checks passed, making 14 independent runner logs. The selected-matching checker ran with its optional --operator-check, including the six nontrivial perturbations. Python was 3.12.14 with NumPy 2.3.5. Thread counts were one, inherited Python import paths and user site-packages were disabled, and no repository checkout or sibling packet was available in the individual extraction directories. Raw stdout/stderr, status, SHA-256 and exact invocation are in ../receipts/original/. The original aggregate summary is summary.json. The handoff replay command is given in ../REPLAY.md.

| ZIP (prefix Hopf_) | Finite checks | Additional package |
|---|---:|---|
| Encoder_Verification | 5 | Standard library |
| Joint_Readout_Verification | 6 | Standard library |
| Haar_Verification | 7 | NumPy |
| Scalar_Verification | 11 | NumPy |
| Prefix_Profile_Verification | 13 | NumPy |
| Mask_Proofs_and_Checks | 9 | NumPy |
| Zero_Test_and_Precision_Proofs | 19 | NumPy |
| Four_Layer_Proofs_and_Checks | 11 | NumPy |

Three prior reports and three public checker files had no byte-identical copy in any ZIP: the Field Decoder report; Selected Matching report and checker; Two-Batch Composition report, Block Composition checker and Indicator Fusion checker. For the Field Decoder the complete original finite evidence is recoverable from exactly three additional sources:

| Source on the originating workspace | Independent fresh result |
|---|---|
| ../early/field_checks/decoder_primary.py | 512 and 131,072 addressed core/helper/mask/inverse cases |
| ../early/field_checks/decoder_independent.py | 128 and 16,384 full augmented cases, the same counts for occupied paired routing, and exact coordinate degrees 2 and 3 |
| ../early/field_checks/decoder_gray_and_ranked.py | 16 Gray phase rows, 84 seeded ranked-convolution and occupied-shear trials, and 16,512 four-call schedules |

These paths identify the three archived scripts in this handoff. The two original decoder tests cover GF(4) and GF(16), at address widths p=2,3 respectively. The three additional checks account for every number in the Field Decoder report's verification section. The tests exercise finite identities. The resource bounds 4d_I(p−1)+56, O(mp²) T-count/dirty width and O(m²) elementary Cliffords follow from the construction; no finite check alone establishes asymptotics.

The archived scripts and notes contain no hard-coded source workspace path. All explicit commit-pinned upstream Markdown links in these packets have a matching path in this checkout. Seven relative Markdown links inside the vendored scalar appendix proofs/dirty_sum_compression.md still resolve relative to its original repository docs/ location. They refer to docs/PARALLEL_DIRTY_LOOKUP.md, docs/AMORTIZED_DIRTY_LOOKUP.md and two existing test files. If preserving archived bytes, give a direct pointer to the original docs/DIRTY_SUM_COMPRESSION.md in the index. No checker depends on these Markdown references.

The headline distinctions matter for indexing. The assembled unconditional specialized upper is O_L(log(q+log(n+4)+2)) for q=n^{o(1)} arbitrary top depths, then independent level profiles per resulting subtree, at square-root dirty width; positive Haar and level-homogeneous arbitrary angles give O_L(log log n). The all-frame fixed-accuracy depth bounds at that width remain Ω(1) and O_L(log n). Rank lower bounds in n or L, the clean-sector restrictions and five-band rare-response structure do not establish worst-case depth growth at unrestricted width. The four-layer report supersedes the prior trace-inversion report's proposed zero-clean four-band single-mark search for k≥7. Small-field halving, algebraic and conditional source constructions remain scoped to their proven interfaces.

Two separately recoverable mathematical refinements do not appear in the eight published packets. The Moore-minor calculation in ../supplements/moore_quartic_frame.md bounds the weighted-cubic correlation of the explicit sign Tr(x¹⁵) by (112·2⁻ᵏ)^{1/8}, giving a leading k/8 lower bound for the common-basis rank of a prescribed sign frame, and k/4 for consecutive basis changes. The existing random-sign bound remains stronger but nonexplicit. Its independent checker passed 5,168 vanishing tests and 136,832 derivative evaluations. The local ../supplements/mask_terminal_cuts.md gives r−k−1 and √(2r)−Oε(k+1) lower bounds on native T gates before, respectively, the final one and final two bands of a single-Pauli mask encoder of binary output rank r on k address bits. Its companion checker passed as well. These two supplemental receipts are under ../receipts/supplemental/, separate from the 14 public/early checks.
