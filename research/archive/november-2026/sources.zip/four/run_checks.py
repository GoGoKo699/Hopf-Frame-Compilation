from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
env = dict(os.environ, OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', OMP_NUM_THREADS='1')
for checker in sorted(root.rglob('*_check.py')):
    print(checker.relative_to(root), flush=True)
    subprocess.run([sys.executable, str(checker)], check=True, env=env, cwd=root)
