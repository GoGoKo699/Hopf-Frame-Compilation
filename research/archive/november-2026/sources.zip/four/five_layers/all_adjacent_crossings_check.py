"""Deterministic small-register checks of the five-band bounded-pair reduction.

Uses independent dense Walsh/native products and discrete unitary Clifford
certification. Run with OPENBLAS_NUM_THREADS=1 for tiny dense matrices.
"""

import itertools
import math
import numpy as np

RNG = np.random.default_rng(2148913)
OMEGA = np.exp(1j * np.pi / 4)
TOL = 3e-12


def parity(x):
    return x.bit_count() & 1


def pauli(n, shift, phase_mask):
    dim = 1 << n
    result = np.zeros((dim, dim), dtype=complex)
    prefactor = 1j ** ((shift & phase_mask).bit_count())
    for x in range(dim):
        result[x ^ shift, x] = prefactor * (-1) ** parity(x & phase_mask)
    return result


def random_pauli(n):
    return pauli(n, int(RNG.integers(1 << n)), int(RNG.integers(1 << n)))


def random_clifford(n):
    dim = 1 << n
    unitary = np.eye(dim, dtype=complex)
    for _ in range(3 * n + 2):
        wire = int(RNG.integers(n))
        kind = int(RNG.integers(3))
        if kind == 0:
            gate = (pauli(n, 1 << wire, 0) + pauli(n, 0, 1 << wire)) / math.sqrt(2)
        elif kind == 1:
            gate = np.diag([1j ** ((j >> wire) & 1) for j in range(dim)])
        else:
            target = (wire + 1 + int(RNG.integers(n - 1))) % n
            columns = np.arange(dim)
            gate = np.eye(dim)[columns ^ (((columns >> wire) & 1) << target)].T
        unitary = gate @ unitary
    return unitary


def is_pauli_up_to_phase(values):
    dim = len(values)
    shift = int(np.argmax(abs(values[:, 0])))
    scalar = values[shift, 0]
    if abs(abs(scalar) - 1) > TOL:
        return False
    mask = 0
    for j in range(dim.bit_length() - 1):
        x = 1 << j
        phase = values[x ^ shift, x] / scalar
        if abs(phase - 1) > TOL:
            if abs(phase + 1) > TOL:
                return False
            mask |= x
    desired = np.zeros_like(values)
    for x in range(dim):
        desired[x ^ shift, x] = scalar * (-1) ** parity(x & mask)
    return np.max(abs(values - desired)) < TOL


def is_clifford(values):
    n = len(values).bit_length() - 1
    for wire in range(n):
        for shift, mask in [(1 << wire, 0), (0, 1 << wire)]:
            if not is_pauli_up_to_phase(values @ pauli(n, shift, mask) @ values.conj().T):
                return False
    return True


def random_parities(n):
    terms = []
    for _ in range(2 * n + 3):
        terms.append((int(RNG.integers(1, 1 << n)), int(RNG.integers(2)),
                      int(RNG.choice([-1, 1]))))
    return np.array([sum(sign * (parity(z & mask) ^ bias)
                         for mask, bias, sign in terms) % 8
                     for z in range(1 << n)], dtype=int)


def diag_band(n):
    return np.diag(OMEGA ** random_parities(n))


def assert_close(a, b):
    err = np.max(abs(a - b))
    assert err < TOL, err
    return err


def test_pair_normal_form(n, r):
    active = 1 << r
    dim = 1 << n
    spectators = dim // active
    f = random_parities(n)
    g = random_parities(n)
    walsh = np.array([[(-1) ** parity(a & c) for c in range(active)]
                      for a in range(active)]) / math.sqrt(active)
    hadamards = np.kron(np.eye(spectators), walsh)
    direct_s = np.diag(OMEGA ** f) @ hadamards @ np.diag(OMEGA ** g) @ hadamards
    base = np.repeat(g[::active], active)
    diagonal = np.diag(OMEGA ** ((f + base) % 8))
    terms = []
    for d, c in itertools.product(range(active), repeat=2):
        phases = OMEGA ** ((g[c::active] - g[::active]) % 8)
        spectator_phase = np.diag(np.repeat(phases, active))
        branch = (-1) ** parity(d & c) * pauli(n, d, 0) @ spectator_phase
        assert is_clifford(branch), (n, r, d, c)
        terms.append(branch)
    short_f = sum(terms) / active
    factor_error = assert_close(direct_s, diagonal @ short_f)
    h = random_pauli(n)
    dressed = diagonal.conj().T @ h @ diagonal
    assert is_clifford(dressed)
    explicit_transport = sum(left.conj().T @ dressed @ right
                             for left in terms for right in terms) / active**2
    transport_error = assert_close(direct_s.conj().T @ h @ direct_s, explicit_transport)

    # Interior pair. Build B and H by independent dense multiplication.
    c = random_clifford(n)
    outside = c @ diag_band(n) @ c.conj().T
    j = outside @ random_pauli(n) @ outside.conj().T
    assert is_clifford(j)
    direct_b = direct_s @ j @ direct_s.conj().T
    interior = diagonal @ (short_f @ j @ short_f.conj().T @ dressed @
                           short_f @ j.conj().T @ short_f.conj().T) @ diagonal.conj().T
    interior_error = assert_close(direct_b @ h @ direct_b, interior)

    # Exterior pair in the opposite orientation. Use the explicitly enumerated
    # Clifford transport terms, plus an independent directly constructed band.
    t = diag_band(n)
    ext_h = random_pauli(n)
    middle = t.conj().T @ ext_h @ t
    assert is_clifford(middle)
    ext_direct_b = t @ (direct_s.conj().T @ h @ direct_s) @ t.conj().T
    exterior = t @ explicit_transport @ middle @ explicit_transport.conj().T @ t.conj().T
    exterior_error = assert_close(ext_direct_b @ ext_h @ ext_direct_b, exterior)
    return factor_error, transport_error, interior_error, exterior_error, len(terms)


if __name__ == '__main__':
    worst = np.zeros(4)
    trials = 0
    terms = 0
    for n, r in [(2, 0), (2, 1), (3, 1), (3, 2), (4, 1), (4, 2), (4, 3)]:
        for _ in range(3):
            outcome = test_pair_normal_form(n, r)
            worst = np.maximum(worst, outcome[:4])
            trials += 1
            terms += outcome[4]
    print(f'{trials} dense trials, {terms} branch Clifford checks')
    print('max absolute error: factor %.3g, transport %.3g, interior %.3g, exterior %.3g'
          % tuple(worst))
