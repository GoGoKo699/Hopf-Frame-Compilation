# Every adjacent pair matters for a five-band rare bit flip

Let R act unitarily on every input qubit, including any borrowed qubits. There are no initialized qubits. The five native T bands act on arbitrary disjoint sets of physical wires within each band; every intervening Clifford is unrestricted. For boundary Hermitian Paulis P,Q, set
$$
 e=(1-\operatorname{Tr}(Q R P R^\dagger)/2^n)/2.
$$
For computational Z inputs and outputs it is the mean bit disagreement on uniform full basis inputs. Let r be the crossing rank of **any one of the four adjacent pairs** of this native representation, as defined by the binary symplectic pairing of their transported active axes. Then either e=0 or
$$
 e\ge 2^{-T-4},\qquad
 b=8r+1,\quad K=2^{16r+3},\quad A_*=2(K^2-1),\quad
 T=(7K+b+4\log_2 K+1)\frac{A_*^K-1}{A_*-1}.
$$
In particular for a nontrivial response confined to an address subset of density at most $2^{-k}$, **all four ranks are $\Omega(\log\log(k+4))$ asymptotically**. The requirement on each rank applies to every five-band representation. The model uses zero clean qubits. It allows arbitrary private outputs and moving addresses and averages over all physical input columns. The result does not exclude high-rank five-band constructions at growing width. The same operator statement applies to approximating the complete-frame witness, by testing its preserved Paulis and using R73's unit-circle argument as in R74.

## A pair factors as a diagonal times a short Clifford sum

Let S be the product of a pair of Clifford-conjugate native bands with crossing rank r. The elementary simultaneous symplectic normal form in R74 §3 puts the first axis span in the Z coordinates and the second in the span of X on r active qubits and Z on the remaining spectators. Therefore, in a single Clifford frame (and up to a common scalar which drops out of conjugation),
$$
 S=D_f H_r D_g H_r
$$
for integer signed sums f,g of Boolean affine parities, with $D_f$ multiplying coordinate $u,a$ by $\omega^{f(u,a)}$, $\omega=e^{\pi i/4}$. Here u ranges over spectators, and a is the active r-bit coordinate. Set $g_0(u)=g(u,0)$, $D=D_{f+g_0}$, and $F=D^\dagger S$. The active Walsh transform gives the exact unitary identity
$$
 F=2^{-r}\sum_{d,c\in\mathbb F_2^r}(-1)^{d\cdot c}
 X^d_{\mathrm{act}}\otimes\operatorname{diag}_u
 \big(\omega^{g(u,c)-g(u,0)}\big).
$$
Indeed the active matrix element has c-sign $(-1)^{(a'+a)\cdot c}$, and the output shift is $d=a'+a$. For each fixed c, any constituent affine parity in g either gives zero difference or gives $\pm(1-2\ell(u))$ for some affine Boolean parity $\ell$. Thus the diagonal is an eighth-root scalar times a signed product of $i^{\ell(u)}$, and is Clifford: a parity S gate is a Clifford conjugate of a one-qubit S gate, with constants allowed. Consequently F is a sum of at most $2^{2r}$ actual Clifford unitaries multiplied by eighth roots times $2^{-r}$. The residual D can have dependent phase axes, but is a diagonal weighted cubic and satisfies $D^\dagger H D\in\mathcal C_2$ for every Pauli H, by the same parity-difference identity for its fixed coordinate shift.

In particular $S^\dagger H S=F^\dagger(D^\dagger H D)F$ is a sum of at most $2^{4r}$ full-register Clifford unitaries with coefficient magnitudes $2^{-2r}$. The corresponding result for $S H S^\dagger$ follows by applying the factorization to $S^\dagger$, whose pair has the same crossing rank. These statements hold in the external frame too, because Clifford conjugation preserves each term.

## Sparse generator on the two-band side

Split five bands as two on one side of a midpoint and three on the other. Taking the adjoint of R exchanges the boundary Paulis and preserves e, so choose orientation to put the pair of interest on the three-band side. Moving fixed interlayer Cliffords into the common frame, the shorter-side transport of its boundary Pauli is $A=E K_A E^\dagger$, where E is one transported native band and $K_A$ is a Hermitian Clifford. Let B be the opposite transport. Both A,B are Hermitian unitaries, and their normalized Hilbert--Schmidt difference is $2\sqrt e$.

The active axes of E are independent. Choose a symplectic-label-space basis of Pauli probes H with at most one nonzero pairing against those axes, using a basis of the kernel of the pairing map and lifts of the unit vectors. For each H the operator $A_H=AHA$ is one Hermitian Clifford or a sum of two Hermitian Cliffords with coefficients $\pm 1/\sqrt2$. The middle $E^\dagger H E$ has at most two Pauli terms, $K_A$ sends these to Paulis, and forward E sends each to a Hermitian Clifford. Put $B_H=BHB$. Then
$$
 \|A_H-B_H\|_{2,\mathrm{tr}}\le 2\|A-B\|_{2,\mathrm{tr}}=4\sqrt e.
$$

## Both positions of the specified pair on the longer side

1. **Nearest the midpoint.** We have $B=S J S^\dagger$, where S is the low-crossing two-band word and J a Hermitian Clifford from the outermost band. In the pair's diagonal frame write $S=DF$ as above. Then
$$
 B_H =D\,[F J F^\dagger (D^\dagger H D) F J^\dagger F^\dagger]D^\dagger .
$$
Inside the brackets are four short Clifford sums and three fixed Cliffords. This makes at most $2^{8r}$ Clifford products with coefficients eighth-root multiples of $2^{-4r}$. All are conjugated by the same diagonal D.

2. **Nearest the exterior.** We have $B=D J D^\dagger$, with D one transported native band and $J=S H_0 S^\dagger$ for the low-crossing pair at the exterior and the boundary Pauli $H_0$. Use D's diagonalizing frame. J and $J^\dagger$ each have at most $2^{4r}$ Clifford summands with coefficient magnitudes $2^{-2r}$. Then
$$
 B_H=D\,[J(D^\dagger H D)J^\dagger]D^\dagger ,
$$
which again has at most $2^{8r}$ products under the common diagonal.

## Gap and dependence on r

Normalized vectorization of each Clifford term gives one unit stabilizer vector with a flat affine support, a Clifford phase and an eighth-root global phase. Fixed ring-valued Clifford representatives may be used. The actual physical Hermitian Cliffords generated by Pauli transport have canonical eighth-root phases by R75 §2, and products of Clifford representatives preserve this convention. Diagonal conjugation multiplies the Choi vector at output,input labels (y,x) by $\omega^{h(y)-h(x)}$ for a signed sum of affine parities h. This is an eighth-root weighted cubic on every affine support. Thus the difference of vectorizations fits R74 §5.1 finite-boundary form with zero active Hadamards. The at most two shorter-side terms are ordinary stabilizers. Harmonize all magnitudes to $2^{-b/2}$ for $b=8r+1$ by replacing each extra power of $\sqrt2$ by $\omega+\omega^{-1}$. At most $(2^{8r}+2)2^b\le 2^{16r+3}$ terms result. This cap can be substituted monotonically in the finite-boundary estimate. If there is just one term its norm is already $2^{-b/2}$.

Hence $\|A_H-B_H\|_{2,\mathrm{tr}}^2$ is zero or at least $2^{-T}$. For $e<2^{-T-4}$ all the probes give equality. Then BA commutes with every Pauli generator and is scalar. Since A,B are Hermitian unitaries, proportionality is by a sign; the minus sign would yield e=1. Thus e=0, as claimed. Finally $T\le 2^{2^{O(r+1)}}$ by the displayed parameters. Combining a nonzero e with $e\le2^{-k}$ forces the stated asymptotic. Comparing R with its adjoint in the proof does not require that a reversed circuit obey the original address-locality promise: only its identical scalar e occurs.

References in the repository: research/depth/FOUR_LAYER_CROSSING_RANK.md §§3 and 5.1; research/depth/FOUR_LAYER_OPERATOR_RIGIDITY.md §2. The sparse-probe argument for four bands is also developed in the companion four-band research note.
