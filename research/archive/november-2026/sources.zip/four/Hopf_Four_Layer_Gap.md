# Four native T layers cannot isolate one address

Let a Clifford+T circuit act on the whole physical Hilbert space, with arbitrary Clifford gates between T layers, arbitrary dirty inputs, and no initialized work. Four native T layers cannot flip a monitored bit at a single seven-bit address while preserving that bit everywhere else. This holds even for a positive flip probability on just one private state, with no requirement to return the address or the other outputs.

The result settles the scalar question in R75 §7. It also gives a constant operator-error lower bound for the complete dirty indicator. At fixed precision and square-root dirty width, the general one-clean complete-frame depth bounds remain $\Omega(1)$ and $O_L(\log n)$, where $N=2^n$. [R75 scalar question](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/FOUR_LAYER_OPERATOR_RIGIDITY.md#7-what-remains-open-for-scalar-overlaps) · [R96 general frontier](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/OPEN_PROBLEM.md#large-width-t-depth)

## The full-space theorem

For a native word $V$ of T-depth at most four, Hermitian input and output Paulis $P,Q$, and physical dimension $D$, let
$$
 e=\frac{1-\operatorname{Re}\operatorname{Tr}(QV P V^\dagger)/D}{2}.
$$
For computational bit readout, $e$ is the mean bit-change probability over all physical input columns. Set $b_*=2\sin(\pi/24)$. Either $QV=VP$ exactly, or
$$
 e\ge\frac{b_*^2}{16}
   =\frac{1-\cos(\pi/12)}{8}
   \simeq0.00425927.
$$
A separate rank bound applies when the observables agree on a whole subspace. If
$$
 \operatorname{rank}(V^\dagger Q V-P)/D<b_*^2/8,
$$
then they agree everywhere. The right side is approximately $0.008519$. One seven-bit address occupies $1/128=0.0078125$ of input space. No crossing-rank cap, gate-count cap or bound on dirty width enters either statement. The constants are sufficient bounds. Sharpness remains open.

## Why four arbitrarily wide layers reduce to three states

Split the word into two pairs of layers. At the midpoint compare two involutions $A=E_A K_A E_A^\dagger$ and $B=E_B K_B E_B^\dagger$, where each $E$ is a physical T layer transported through a Clifford and each $K$ is a Hermitian Clifford. Normalizing the Hilbert–Schmidt norm by $\sqrt D$ gives $\|A-B\|_2=2\sqrt e$.

The T axes within $E_A$ are independent commuting Paulis. Complete them to a Pauli basis with symplectic duals. This gives a generating set of probes $H$, each anticommuting with at most one active axis. Consequently $E_A^\dagger H E_A$ is a Pauli or a sum of two orthogonal Paulis with coefficients $\pm1/\sqrt2$. Transport through $K_A$ and back through $E_A$ gives one Clifford or two orthogonal Cliffords. On the other side, $BHB$ is a single Clifford conjugated by $E_B$.

In coordinates diagonalizing $E_B$, the normalized vectorization of $BHB$ is a flat affine stabilizer state multiplied by a weighted cubic eighth-root phase. The vectorization of $AHA$ is an ordinary stabilizer state or $(U+V')/\sqrt2$ for orthonormal stabilizer states $U,V'$. The latter two share the coefficients and phases fixed by the physical conjugation. The full proof in the companion package shows that this vector difference vanishes or has norm at least $b_*$. Two observations explain the uniform bound.

- If either ordinary stabilizer has overlap of magnitude at most $1/2$ with the weighted state, orthogonality and Bessel's inequality bound the combined real overlap by $(1+\sqrt3)/(2\sqrt2)=\cos(\pi/12)$.
- If both magnitudes exceed $1/2$, each affine support must equal the weighted state's support, contain it at index two, or lie inside it at index two. The unequal-support cases give a gap by comparing masses on the affine halves or by a single weighted-phase comparison. On equal supports, the ratio of the two stabilizer phases is a fourth-root Clifford phase times a constant eighth root. If their sum has unit magnitude at every point, its relative exponent has three binary digits of Boolean degrees at most $1,2,4$. Any nonconstant discrepancy then occurs on a fraction bounded below independently of the number of wires.

Since $\|AHA-BHB\|_2\le 2\|A-B\|_2$, sufficient closeness forces equality on every generator. Then $BA$ commutes with the full Pauli algebra and is a scalar. Hermiticity leaves the two signs, and closeness fixes the positive sign.

For the rank bound write $W=BA$. The rank of $WHW^\dagger-H$ is at most $2\operatorname{rank}(W-I)$, and its operator norm is at most two. Thus its squared normalized Hilbert–Schmidt norm is at most $8\operatorname{rank}(W-I)/D$. The same generator argument now uses the exact dimension of the exceptional input subspace.

## Constant-error consequences for complete operators

For $p\ge7$, the complete dirty indicator $I_p|x,Y,w\rangle=|x,Y\oplus e_x,w\rangle$ has operator distance at least
$$
 \tau=\frac{\sin(\pi/8)}{2\sqrt2}\simeq0.135299
$$
from every zero-clean four-layer circuit, even up to common phase. The same lower bound holds for a fully returned $p$-controlled NOT.

To see this, Fourier-transform the output bank (or the one target). The ideal physical operator is a diagonal sign, including identity on dirty work. If an implementation were within $\tau$, applying R75's operator rigidity to each computational $Z$ would force the whole implementation to be diagonal. In a fixed native phase convention, its diagonal entries are modulus-one elements of $\mathbb Z[i,1/\sqrt2]$, hence eighth roots. A disk of radius $\tau$ has diameter below the separation $2\sin(\pi/8)$ of distinct eighth roots. After multiplication by the desired signs all entries must therefore be identical. This would implement the exact target up to one global phase. Monitoring one output bit of the exact oracle contradicts the single-address theorem. The argument applies only to a complete physical operator specified on all dirty and logical inputs. [R75 operator threshold and entry-ring argument](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/FOUR_LAYER_OPERATOR_RIGIDITY.md)

There is also a complete **real Hopf frame** realizing this lower bound on required depth. Set all but the deepest real angles to zero, and the deepest angle to $\pi$ at one prefix and zero elsewhere. This gives a minus sign at one $(n-1)$-bit prefix, tensored with identity on the leaf bit. Hadamards on one prefix bit turn that block into a target flip, up to sign, exactly when the other $n-2$ prefix bits match. Thus at $n\ge9$ this explicit frame also needs at least five native layers below $\tau$ in the zero-clean model. The prescribed complex family can realize the same diagonal by leaf phases. [Canonical angle domains](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/HOPF_INTERFACE.md#canonical-domains)

## What one initialized qubit changes

For the R74 rotation witness $I\otimes R_y(\tfrac12\arccos(1/3))$, suppose a four-layer circuit with one external clean qubit achieves full initialized-isometry error $2^{-L}$. As precision increases, the crossing rank at **each of the three adjacent pairs** must be $\Omega(L)$. In addition, the two middle axis spans must **intersect** in $\Omega(L)$ independent directions. Directions in this intersection have zero symplectic pairing against either middle span. Thus each middle layer must supply both kinds of directions on the same circuit. The estimate applies to every physical decomposition, with unrestricted dirty width.

Here is how the clean qubit enters the proof. At sufficiently small error, R75 forces the terminal clean $Z$ to be exactly preserved. Call its common midpoint image $S$, so that from either side $S=E_j J_j E_j^\dagger$ with a Hermitian Clifford core $J_j$ and middle axis span $L_j$. Write $F_j$ for the binary symplectic action of $J_j$ and put $u_j=\operatorname{rank}(\langle L_j,F_j L_j\rangle)$. Two independent facts give the result.

1. The two representations of the same $S$ imply $u_j\le\dim(L_A\cap L_B)$ on either side. Conjugate Pauli probes from the respective centralizers by $S$. The resulting Clifford symplectic maps commute, and their cross products have image in $L_A\cap L_B$. Applying the independence of each band's physical axes to these products gives the rank bound. Each $u_j$ is also bounded by its adjacent outer-to-middle crossing, since $F_j-I$ is a sum of transvections from the outer axes activated by the clean Pauli.
2. In a computational Pauli basis containing $L_j$, the least possible number of Hadamard coordinates in $J_j$ is exactly $u_j$. On the code projector $\Pi=(I+S)/2$, use the symmetrized probes $(H+SHS)/2$. Multiplying the compressed comparison on the right by a fixed unitary exposes a fixed number of flat, weighted-cubic terms. The only remaining Walsh transform acts on those $u_j$ coordinates. The cyclotomic estimate from the preceding precision proof bounds a nonzero squared discrepancy below by $2^{-O(u_j+1)}$. At sufficiently small error, exact preservation of the occupied observables would force a single-qubit rotation in multiples of $\pi/8$, separated from the chosen witness. Consequently $u_j=\Omega(L)$ for both choices of side.

A related result applies to a one-clean zero test with exact terminal return of the clean bit. If a flip is possible on just one of $2^k$ addresses, the squared full-space Hilbert–Schmidt defect restricted to the initialized subspace is at most $2^{1-k}$. The occupied-subspace gap then forces both outer-to-middle crossing ranks and the common middle-axis dimension to be $\Omega(k)$. This leaves high-rank circuits eligible.

For the rotation witness, the separate linear middle-to-middle crossing estimate from the preceding round supplies the third adjacent pair. This proof gives a growing requirement on each interface within four layers. The unrestricted one-clean depth question at fixed accuracy remains open. [R74 witness](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/FOUR_LAYER_CROSSING_RANK.md) · [R76 compressed commutant](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/ONE_CLEAN_MIDPOINT_RIGIDITY.md#lifting-the-compressed-commutant)

## Where the constructive search moves

For an exact-silence source at five native layers, every one of its **four adjacent crossings** has a necessary condition. If a raw response is nonzero on a set of address density at most $2^{-k}$ and vanishes elsewhere, the binary symplectic rank of each adjacent pair is $\Omega(\log\log(k+4))$ as $k$ grows. At fixed rank $r$, the proof factors a two-band word into a diagonal weighted cubic followed by a sum of at most $4^r$ ordinary Cliffords. The same Pauli probes and R74's finite-sum gap apply in each time orientation. The quantitative constants are large. This is a growing-rank filter for five-band candidates and imposes no order-of-growth lower bound on depth at unrestricted width. [R74 finite-sum bound](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/FOUR_LAYER_CROSSING_RANK.md#finite-boundary-form)

For physically read-only addresses, the four-layer obstruction also bounds the Boolean degree of a deterministic observed displacement by six even if the other outputs are arbitrary. Restrict a degree-at-least-seven function to an odd-weight seven-dimensional affine cube. In parallel evaluate all 128 shifts into disjoint dirty targets. On this cube the binary convolution matrix of an odd-weight truth table is its own inverse. A Clifford linear change of target coordinates therefore gives an output bit with a single exceptional address. Physical read-only controls permit those parallel calls and the affine substitution. The existing sharper degree-two result applies to the stronger contract with full query return. [Read-only full-query result](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/READ_ONLY_THREE_LAYER_RIGIDITY.md)

The next five-band test is to construct a pair of transported readout observables whose relative unitary equals identity off the chosen address and is close to the negative sign on its entire marked input sector. All four adjacent ranks must grow. A small average signal on a few private states would pass a necessary test but would still leave the worst-case marked-row amplitude unpaid. A verified constant-depth source with the required uniform amplitude would give the earlier conditional $O_L(\log\log n)$ complete-frame upper at square-root dirty width. R96 continues to give the general upper bound with simultaneous T-count, width, precision and work return.

Baseline examined: commit ae613bf8e8a38f6d0407c25910b83d69f01a2733. Detailed proofs and executable checks are supplied separately.
