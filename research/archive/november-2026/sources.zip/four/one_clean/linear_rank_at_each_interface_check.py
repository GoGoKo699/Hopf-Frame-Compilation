"""Finite checks for the midpoint Fourier-rank argument; requires NumPy."""
from itertools import combinations
from math import prod
import numpy as np


def connected(points, radius=3):
    if not points:
        return True
    seen = {next(iter(points))}
    frontier = set(seen)
    while frontier:
        neighbors = {p for p in points - seen if any((p ^ q).bit_count() <= radius for q in frontier)}
        seen |= neighbors
        frontier = neighbors
    return seen == points


def affine_flats(n):
    linear = {frozenset([0])}
    for _ in range(n):
        linear |= {s | frozenset(v ^ w for w in s) for s in linear for v in range(1 << n)}
    return {frozenset(w ^ v for w in s) for s in linear for v in range(1 << n)}


def check_geometry():
    quadratic_cases, affine_cases = 0, 0
    for n in range(1, 5):
        cube = set(range(1 << n))
        masks = [0] + [1 << i for i in range(n)] + [(1 << i) | (1 << j) for i, j in combinations(range(n), 2)]
        monomials = [sum(1 << v for v in cube if v & mask == mask) for mask in masks]
        tables = [0]
        for table in monomials:
            tables += [f ^ table for f in tables]
        for table in tables:
            assert connected({v for v in cube if table >> v & 1})
            quadratic_cases += 1
        for flat in affine_flats(n):
            if flat == cube:
                continue
            vertices = list(flat)
            for mask in range(1 << len(vertices)):
                added = {v for i, v in enumerate(vertices) if mask >> i & 1}
                assert connected((cube - flat) | added, radius=2)
                affine_cases += 1
    return quadratic_cases, affine_cases


def affine_support(matrix):
    support = set(np.flatnonzero(abs(matrix.reshape(-1)) > 1e-9))
    base = min(support)
    span = {v ^ base for v in support}
    assert all(x ^ y in span for x in span for y in span)
    coeffs = matrix.reshape(-1)[list(support)]
    scaled = coeffs * np.sqrt(len(coeffs) / matrix.shape[0])
    assert np.allclose(scaled ** 8, 1, atol=1e-8)


def check_partial_hadamards():
    n = 3
    d = 1 << n
    rng = np.random.default_rng(72809)
    h = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
    zeta = np.exp(1j * np.pi / 4)
    identity = np.eye(d, dtype=complex)
    def mono():
        s, t = rng.choice(n, 2, replace=False)
        return identity[:, [v ^ (((v >> s) & 1) << t) for v in range(d)]] @ np.diag([1j ** ((v >> t) & 1) * (-1) ** (((v >> s) & 1) * ((v >> t) & 1)) for v in range(d)])
    def hmask(mask):
        result = np.array([[1.]])
        for i in range(n):
            result = np.kron(h if mask >> i & 1 else np.eye(2), result)
        return result
    def cliff():
        return mono() @ hmask(rng.integers(d)) @ mono() @ hmask(rng.integers(d)) @ mono()
    count = 0
    for mask in range(d):
        hs = hmask(mask)
        for _ in range(16):
            c, k, m1, m2 = cliff(), cliff(), mono(), mono()
            e = np.diag([prod(zeta ** (((v & a).bit_count() & 1) * sign) for a, sign in [(3, 1), (4, -1), (7, 1)]) for v in range(d)])
            g = m2 @ hs @ m1
            assert all(np.sum(abs(col) > 1e-9) == 1 << mask.bit_count() for col in g.T)
            terms = [c @ e, c @ e @ g, e @ k, e @ k @ g]
            shapes = [t @ m1.conj().T for t in terms]
            shapes[1] = shapes[1] @ hs
            assert np.allclose(shapes[1], c @ e @ m2)
            for term in shapes:
                affine_support(term)
                count += 1
    return count


def binary_rank(rows):
    pivots = {}
    for row in rows:
        while row:
            bit = row.bit_length() - 1
            if bit not in pivots:
                pivots[bit] = row
                break
            row ^= pivots[bit]
    return len(pivots)


def check_outer_crossing():
    cases = 0
    for a in range(1, 5):
        for b in range(1, 5):
            mask = (1 << b) - 1
            for flat in range(1 << (a * b)):
                rows = [mask & (flat >> (i * b)) for i in range(a)]
                form = [sum((((x & y).bit_count() & 1) << j) for j, y in enumerate(rows)) for x in rows]
                assert binary_rank(form) <= binary_rank(rows)
                cases += 1
    return cases


if __name__ == '__main__':
    q, a = check_geometry()
    print(f'{q} quadratic supports, {a} affine-complement extensions, {check_partial_hadamards()} normalized frontier terms, {check_outer_crossing()} outer crossing matrices')
