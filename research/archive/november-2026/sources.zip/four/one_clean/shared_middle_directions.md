# A one-clean four-band approximation requires growing common middle-axis dimension

Take a native word $V=V_2V_1$ with two T bands in each half, one external clean bit and arbitrarily many dirty bits. Let $P$ be a Hermitian data Pauli, and put
$$
 A=V_2^\dagger P V_2=E_A K_A E_A^\dagger,\qquad
 B=V_1 P V_1^\dagger=E_B K_B E_B^\dagger .
$$
Each $E_j$ is one Clifford-conjugated physical T band, with sign choices arbitrary and independent unsigned binary axis generators spanning $L_j$. Each $K_j$ is a Hermitian Clifford. If the terminal clean Z is preserved, let
$$
 S=V_2^\dagger Z_c V_2=V_1 Z_c V_1^\dagger
  =E_A J_A E_A^\dagger=E_B J_B E_B^\dagger,\qquad Q=(I+S)/2 .
$$
The clean Clifford cores $J_A,J_B$ are Hermitian, and $A,B$ both commute with $S$. R75 establishes terminal preservation automatically once the initialized complete-return accuracy is below its absolute threshold. Let $F_j$ be the binary symplectic action of $J_j$, an involution, and define
$$
 u_j=\operatorname{rank}_{\mathbb F_2}\big(\langle x,F_jy\rangle\big)_{x,y\in L_j},\qquad
 r=\dim(L_A\cap L_B).
$$
There is no bound on the inter-band crossing rank $\operatorname{rank}\langle L_A,L_B\rangle$.

**Theorem.** The exact shared clean midpoint implies $u_A,u_B\le r$. For each fixed upper bound on either $u_A$ or $u_B$, there is a positive threshold, independent of total width and of the inter-band crossing rank, below which $\|(A-B)Q\|_{\rm op}$ must vanish. Hence a four-band, one-clean sequence approximating the R74 complete-frame witness with errors tending to zero must have $u_A,u_B,r\to\infty$ in every such split. This complements the growing middle crossing rank in R74. It gives no general T-depth growth at unrestricted width.

## Bounding the inner rank by the common span

Write $I=L_A\cap L_B$. For $h\in L_A^\perp$, the conjugate of its Pauli by the common $S$ is a one-band image of a Pauli with binary label $F_Ah$. This is a Clifford. Its symplectic matrix is $I_{\rm symp}+N_A(h)$, where
$$
 N_A(h)b=\sum_{g\ {\rm an\ A\ axis}}\langle F_Ag,h\rangle\langle g,b\rangle\,g.
$$
The formula uses transvections of commuting axes; signs do not affect it. Independence of the native band axes ensures the image is exactly the span of the active axes in this sum. Define $U_A$ as the span of all axes that can activate for some such $h$, namely those $g$ with $F_Ag\notin L_A$. Define $N_B(h'),U_B$ symmetrically for $h'\in L_B^\perp$.

For $h\in(L_A+L_B)^\perp$ the images in both presentations agree, so the image of $N_A(h)$ belongs to $I$. If an individual axis $g\notin I$ were active for such $h$, its inclusion in this image would be a contradiction. Therefore every such generator satisfies $F_Ag\in L_A+L_B$.

For $h\in L_A^\perp,h'\in L_B^\perp$ the two Clifford images $S P_h S,S P_{h'} S$ commute projectively. Their symplectic matrices commute, so $N_A(h)N_B(h')=N_B(h')N_A(h)$ has image in $I$. On spanning over $h'$, this shows $N_A(h)b\in I$ for every $b\in U_B$. In A axis coordinates these vectors are the entrywise products $c(h)\odot d(b)$, where $c_g(h)=\langle F_Ag,h\rangle$ and $d_g(b)=\langle g,b\rangle$. If $g\in I$ then $d_g(b)=0$. Let $r_0$ count the A axis generators lying in $I$. The intersection of $I$ with the coordinate subspace omitting these $r_0$ coordinates has dimension exactly $r-r_0$: subtract the individual basis generators in $I$ from any vector to remove its entries there.

Restrict the $c,d$ coordinates to the globally active A axis generators. Extending scalars from $\mathbb F_2$ to its algebraic closure does not change the binary dimensions or the product inclusions. The linear space spanned by the activation words has full support on these coordinates, so contains a word nonzero at *every* one (a finite union of proper linear hyperplanes cannot cover a vector space over an infinite field). Multiplication by this word is injective. Every product still lies in the projected space of dimension at most $r-r_0$. Hence $\operatorname{rank}\langle U_A,U_B\rangle\le r-r_0$.

The part $K=L_B\cap F_BL_B$ is $F_B$-invariant. For $b\in K$, conjugation by $S$ gives a Pauli with label $F_Bb$ because $E_B$ commutes with both $b$ and $F_Bb$. Consequently each $S P_h S$ for $h\in L_A^\perp$ fixes every Pauli in $K$ projectively: its commutation sign with $b$ is the original Pauli commutation sign of $P_h$ with $S P_b S$. Thus $K\subseteq\ker N_A(h)=(\operatorname{im}N_A(h))^\perp$, giving $U_A\perp K$. Every inactive B generator lies in $K$, so the rank of $\langle U_A,L_B\rangle$ is at most $r-r_0$.

In the matrix for the symmetric form $\langle g_i,F_Ag_j\rangle$, rows for inactive A generators are zero by symmetry. On all columns indexed by $g_j\notin I$ the vectors $F_Ag_j$ lie in $L_A+L_B$, as proved above. Pairing them against the active A rows has total rank at most $r-r_0$. The remaining $r_0$ columns add at most $r_0$. This proves $u_A\le r$; interchange A and B to obtain $u_B\le r$.

## The finite-rank initialized gap

Suppose $u=u_B$ is bounded. There is a maximal commuting Pauli space $M$ containing $L_B$ with $\operatorname{codim}_M(M\cap F_BM)=u$. Indeed, on $L_B$ the pairing $\beta(x,y)=\langle x,F_By\rangle$ is symmetric since $F_B^2=I$. Choose a complement $U$ to its radical $R$, so the form on $U$ is nonsingular. The space $T=U\oplus F_BU$ is nondegenerate symplectic and invariant. In $T^\perp$ the space $R+F_BR$ is isotropic and invariant. Extend it to an invariant Lagrangian $M'$: on its symplectic quotient the involution has isotropic image of $F_B-I$, and any Lagrangian containing that image is invariant. Lift this Lagrangian to $T^\perp$. Then $M=U+M'$ works. Conversely the rank of the pairing on any extension $M$ is at least its rank on $L_B$, proving optimality.

Use this $M$ as computational Pauli axes. The band $E_B$ is diagonal with weighted-cubic eighth-root phases. By the Clifford partial-Hadamard normal form the core $J_B$ is a product of two monomial Cliffords with a parallel layer of exactly $u$ Hadamards between them, up to a fixed eighth-root phase. The expansion $H=(X+Z)/\sqrt2$ makes $S$ a sum of $2^u$ monomial unitaries of common coefficient $2^{-u/2}$; each carries a weighted-cubic phase in the computational input. This includes arbitrary Clifford signs and all basis-dependent phases.

For every Pauli $H$ commuting with $L_A$, $G=AHA$ is a plain Hermitian Clifford. Meanwhile $BHB=E_B C_H E_B^\dagger$ with a plain Hermitian Clifford $C_H$. Expand the two terms of $Q(G-BHB)Q$ in the B basis. The first term is $(I+S)G(I+S)/4$, with at most $(1+2^u)^2$ contributions. Each has a flat affine stabilizer Choi support carrying a weighted-cubic phase: pre- or post-multiplying a Clifford by a monomial weighted-cubic unitary permutes only row/column labels affinely and adds weighted-cubic phases on those labels. The second term has four contributions of the form $E_B C E_B^\dagger/4$ for plain Cliffords $C$, using $S=E_B J_B E_B^\dagger$. These have the same type of normalized flat affine Choi vector in the **same** computational coordinates. All coefficients are bounded-denominator powers of $\sqrt2$; clear to a common denominator using $\sqrt2=\omega+\omega^{-1}$, absorbing roots into the phases. The resulting number of terms depends only on $u$. The R74 finite-boundary gap at zero active Hadamard coordinates forces this discrepancy either to vanish or to have normalized Hilbert–Schmidt norm above a strictly positive bound depending only on $u$. On the other hand its operator norm is at most $2\|(A-B)Q\|_{\rm op}$, by compressing $H$ and using $[A,Q]=[B,Q]=0$. Therefore the discrepancy vanishes for **all** these Paulis below a uniform threshold.

The R76 compressed-commutant lifting proof now applies: on the occupied code $Y=BA|_{Q\mathcal H}$ commutes with the compressions of every $L_A^\perp$ Pauli. In a frame diagonalizing $L_A$, $X=BAQ=D_0Q=QD_0$ for a unitary $D_0$ acting by a scalar $\lambda_z$ on each eigenspace of $L_A$ that meets the code. Its proof identifies the images of the projected sector subspaces on the code and uses all their compressed matrix units; it requires no Clifford assumption on $S$.

In this A-adapted frame $S=E_A J_A E_A^\dagger$. Every nonzero off-diagonal entry of $S$ is a unit of $\mathcal R=\mathbb Z[i,1/\sqrt2]$, since the diagonal entries of $E_A$ are eighth roots and $J_A$ is Clifford. For each occupied sector choose a nonzero row of $Q$. If its row of $S$ is not diagonal, a nonzero off-diagonal entry of $Q$ is also a ring unit. If the row is diagonal, then $Q_{ii}=1$. The identity $X_{ij}=\lambda_z Q_{ij}$ therefore implies $\lambda_z\in\mathcal R$. R75's unit-circle lemma forces each $\lambda_z$ to be an eighth root. Nontrivial roots are at distance at least $\sqrt{2-\sqrt2}$ from one. As in R76, $\|(A-B)Q\|_{\rm op}$ bounds every occupied $|\lambda_z-1|$, so small error forces $X=Q$, proving exact preservation on the occupied code. The same proof works with A and B interchanged.

For completeness, the R74 witness is a prescribed complete frame $I\otimes R_y(\frac12\arccos(1/3))$. Each dirty/logical Pauli commuting with that rotation gives initialized discrepancy at most twice the approximation error. The preceding argument makes all these preservations exact on the code. R76's final single-qubit ring argument then gives its fixed positive floor for the remaining rotation. Thus bounded $u_j$, hence bounded common dimension $r$, rules out arbitrary precision in four T layers with one clean qubit. This reduction does not say that an arbitrary one-clean four-band circuit has bounded $r$, and it does not assert five layers at a specified small integer precision.

References within the project: research/depth/FOUR_LAYER_CROSSING_RANK.md (finite-boundary form), research/depth/FOUR_LAYER_OPERATOR_RIGIDITY.md (terminal clean return), research/depth/ONE_CLEAN_MIDPOINT_RIGIDITY.md (compressed commutant and witness).
