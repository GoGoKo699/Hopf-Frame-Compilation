"""Two-qubit independent enumeration of shared-midpoint geometry."""
from collections import defaultdict
from itertools import combinations, product
import numpy as np

I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Z=np.diag([1,-1]).astype(complex)
Y=1j*X@Z

def label_mat(v,n):
    m=np.array([[1]],complex)
    for i in range(n):
        m=np.kron([I,X,Z,Y][((v>>i)&1)+2*((v>>(i+n))&1)],m)
    return m

def sp(v,w,n):
    a=(1<<n)-1
    return (((v&a)&(w>>n)).bit_count()+((w&a)&(v>>n)).bit_count())%2

def span(labels):
    s={0}
    for h in labels:
        s|={i^h for i in s}
    return frozenset(s)

def key(m):
    a=m.flatten()
    first=next(x for x in a if abs(x)>1e-7)
    a=a*np.conjugate(first)/abs(first)
    return tuple(np.rint(np.stack((a.real,a.imag))*1e8).astype(int).flatten())

def main(n):
    dim=2**n
    pauli=[label_mat(p,n) for p in range(dim**2)]
    by_matrix={key(v):p for p,v in enumerate(pauli)}
    spaces=set()
    bands=[]; c=np.cos(np.pi/8); s=np.sin(np.pi/8)
    for k in range(n+1):
        for basis in combinations(range(1,dim**2),k):
            L=span(basis)
            if len(L)!=2**k or any(sp(a,b,n) for a,b in combinations(basis,2)):continue
            spaces.add(L)
            for signs in product([-1,1],repeat=k):
                e=np.eye(dim)
                for p,sign in zip(basis,signs):
                    e=(c*np.eye(dim)+1j*sign*s*pauli[p])@e
                bands.append((basis,L,e))
    lagrangians=[L for L in spaces if len(L)==dim]
    # All single-band Pauli images in any signed independent Pauli basis.
    cores={}
    for _,_,e in bands:
        for p in pauli[1:]:
            j=e@p@e.conj().T
            cores[key(j)]=j
    F={}
    for idx,j in cores.items():
        F[idx]=[by_matrix[key(j@p@j)] for p in pauli]
    shared=defaultdict(set)
    matrix_repr={}
    ext=0
    for basis,L,e in bands:
        for idx,j in cores.items():
            sym=F[idx]
            row=[sum(sp(a,sym[b],n)<<i for i,b in enumerate(basis)) for a in basis]
            u=len(span(row)).bit_length()-1
            minimum=min(n-(len(M&{sym[t] for t in M}).bit_length()-1)
                        for M in lagrangians if L <= M)
            assert u==minimum
            ext+=1
            z=e@j@e.conj().T
            mid=key(z)
            if mid in matrix_repr:
                prev=matrix_repr[mid]
                assert min(np.max(abs(z-prev)),np.max(abs(z+prev)))<1e-7
            else:
                matrix_repr[mid]=z
            shared[mid].add((L,u))
    tests=0; sharp=set(); nonzero=0; transverse=0
    for presentations in shared.values():
        for la,ua in presentations:
            for lb,ub in presentations:
                r=len(la&lb).bit_length()-1
                assert max(ua,ub)<=r
                tests+=1
                if la!=lb and max(ua,ub): nonzero+=1
                if r==0 and la!=lb: transverse+=1
                if max(ua,ub)==r: sharp.add(r)
    return ext,len(shared),tests,nonzero,transverse,sharp

if __name__=='__main__':
    for n in [1,2]:
        print(n,'qubits:',main(n))
