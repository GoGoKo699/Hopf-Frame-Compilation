"""Check complete small signed-permutation spectra and larger exact Jordan identities."""
from itertools import product
from random import Random
from collections import Counter

# Irreducible binary polynomials of degrees 1,...,5.
poly={1:3,2:7,3:11,4:19,5:37}
def mul(a,b,k):
    p=poly[k];v=0
    while b:
        if b&1:v^=a
        b>>=1;a<<=1
        if a>>k:a^=p
    return v
def trace(x,k):
    out=0
    for _ in range(k):
        out^=x;x=mul(x,x,k)
    assert out in (0,1)
    return out
def step(a,v,k):
    w=[1]+list(v);M=1<<k
    for parity in (1,0):
        for i in range(1,M):
            if i%2==parity:w[i]^=mul(a,w[i-1],k)
    return tuple(w[1:])
rng=Random(2610)
fixed=0
for j in range(1,5):
    m=1<<j
    for _ in range(80):
        v=rng.randrange(1<<(m-1));v0=v;sgn=0
        for s in range(m):
            sgn^=v>>(m-2)&1
            v^=(v<<1&((1<<(m-1))-1))^1
            if s+1==m//2:assert v!=v0
        assert sgn==1 and v==v0;fixed+=1
print(f'{fixed} complete periods of fixed dirty Clifford clocks')
checked=0;orbits=0
for k in range(1,6):
    m=1<<k
    c=next(z for z in range(m) if trace(z,k))
    for a in range(m):
        cases=product(range(m),repeat=m-1) if k<=2 else [tuple(rng.randrange(m) for _ in range(m-1)) for _ in range(4)]
        for v0 in cases:
            v=tuple(v0);sgn=0
            for s in range(m):
                sgn^=trace(mul(c,v[-1],k),k)
                v=step(a,v,k)
                if s+1==m//2 and a: assert v!=v0
            assert v==v0 and sgn==int(a!=0)
            checked+=1
        zero=(0,)*(m-1);w=zero
        for _ in range(m//2):w=step(a,w,k)
        assert w[-1]==int(bool(a))
        if k<=2 and a:
            words=set(product(range(m),repeat=m-1))
            while words:
                w=next(iter(words));start=w;period=sgn=0
                while w in words:
                    words.remove(w);sgn^=trace(mul(c,w[-1],k),k);w=step(a,w,k);period+=1
                assert w==start and period==m and sgn==1;orbits+=1
print(f'{checked} arbitrary-input field cycles, {orbits} complete short signed orbit spectra; all half-power nonzero-output columns through GF(32)')
