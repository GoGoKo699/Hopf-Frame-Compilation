# A rare read-only response needs a large cumulative change of Pauli bases

Let R(x) be a physical native Clifford+T word reading k computational address bits through fixed Clifford controls. The address is only read by these controls and the T gates are on private spins. On each fixed address, each Clifford interval acts on the work by a fixed Clifford times an address-affine Pauli, up to a scalar. Arbitrarily many private dirty qubits are allowed. Write P and Q for the input and output target Paulis (e.g. Z on the same target bit). Suppose R(x)† Q R(x)=P outside a set S, and suppose the equality fails at least at one address. This includes certainty of preserving the target on all dirty inputs off S, with only a nonzero response on a good address.

Transport the fixed Clifford intervals into the Pauli axes of the d native T bands, absorbing the last one into Q. Transport the affine Paulis as well. The boundary effect of an affine Pauli on Q is an affine sign. In band j the originally fixed sign on each T axis is now multiplied by (−1) to an address-affine bit. This reduction permits arbitrary fixed entangling Cliffords on all work. Write Lⱼ for the isotropic span of the transported axes in the binary work Pauli space. Choose any maximal isotropic Pauli spaces Mⱼ containing Lⱼ and put
$$
 H=\sum_{j=1}^{d-1}\big(w-\dim(M_j\cap M_{j+1})\big)
$$
on w work qubits. For d=0 or 1 set H=0. Then
$$
 k-\lceil\log_2|S|\rceil\ \le\ 2H+2.
$$
This bound holds for every allowed choice of frames, hence also their minimum. When S is a singleton, H≥k/2−1. It applies without assuming that the intermediate observable, output on the exceptional addresses, or private-spin dynamics are Clifford. All-input exact silence off S matters.

Let 2r be the symplectic rank of the joint span of all T axes, P and the fixed transported Q. The symplectic rank is the rank of the restricted alternating commutation form, even when the joint span has a huge radical. One may choose all the frames to differ on at most r qubits: send the radical to private Z axes, bring the nondegenerate part to r full Pauli pairs, and fix all other basis choices once. Extend each projected Lⱼ to a maximal isotropic on just those r qubits. Thus H≤r(d−1) for d≥1. If |S+S|≤2^{(1−α)k}, then
$$
 2r(d-1)\ \ge\ \alpha k-3 .
$$
For α fixed, sublogarithmic depth would need a genuinely noncommuting Pauli span with r growing at least as k/d. Enlarging only the commuting part of the spin register cannot pay that cost. A wide circuit with unrestricted core size remains eligible.

## Proof

Use the stabilizer basis for M₁ as the input/output matrix coordinates in the Heisenberg calculation. In the basis of its own band every phase gate is diagonal. Up to a common address-dependent scalar, its entry is an eighth root of unity raised to an exponent s(−1)^{ℓ(x)} b(z), where s is its fixed sign ±1, z is a fixed work basis label, b is an affine bit on z, and ℓ is address-affine. For a fixed path z the dependence relative to x=0 is a fixed factor times i to a signed integer multiple of ℓ(x). A Pauli in a fixed stabilizer basis is a signed fourth-root monomial permutation. The boundary affine sign has the same form with coefficient two.

The change of stabilizer coordinates from Mⱼ to Mⱼ₊₁ has either zero entries or entries of magnitude 2^{-hⱼ/2}, with hⱼ=w−dim(Mⱼ∩Mⱼ₊₁). The nonzero phases are eighth roots for a standard native choice of stabilizer bases. To see the magnitude, joint basis labels must agree on the common generators. A complete state from Mⱼ is uniform over the 2^{hⱼ} compatible Mⱼ₊₁ labels. Indeed every Pauli outside Mⱼ has zero expectation on it, while all common stabilizers have their fixed signs. Its amplitudes in the new stabilizer coordinates have the usual quadratic Clifford phases. This argument is insensitive to choices of Clifford lift and global basis phases around the Heisenberg echo.

Fix the matrix entry f(x) of R(x)† Q R(x)−P that is nonzero at one active x⋆. Expand its forward and backward paths. Each adjacent basis change occurs twice and the central Q is monomial in the last basis. Thus
$$
 f(x)=2^{-H}\sum_t c_t\,i^{\sum_l n_{t,l}\ell_l(x)}
$$
with cₜ algebraic integers in Z[ζ₈] (normally eighth roots, with the constant subtraction also absorbed) and nₜ,ₗ integers. This expression uses only work paths compatible with the fixed input and output entries. It is independent of the number of axes within a band. In particular the address quadratic phases arise because a sign flip of an actual T gate produces only a Clifford phase relative to its original sign.

Choose an affine a-cube through x⋆ avoiding all other S, with a=k−ceil(log₂|S|). For singleton S take the full cube. Otherwise a random a-dimensional linear direction includes each fixed other point with probability (2^a−1)/(2^k−1). The expected number of other S points is below one. For a=0 the argument below is immediate. On any affine a-cube, each signed integer sum of affine parities in the phase above is a Z₄ quadratic polynomial with its off-diagonal quadratic coefficients even. In fact lifting the parity of binary coordinates as an integer modulo 4 gives the sum of those coordinates minus twice the sum of their pairwise products.

For such a phase define G=Σ_z i^{q(z)} on the a-cube. The polar q(z+u)−q(z)−q(u)+q(0) is twice a binary bilinear form B(z,u). Expanding |G|² and summing first over z gives zero or 2^{a+dim(rad B)}: the remaining phase on the radical is a character, whose sum is either zero or the radical size. Thus v₂(G)≥a/2 at the unique dyadic prime of Q(ζ₈), normalized by v₂(2)=1; conjugation preserves that valuation. The nonarchimedean triangle inequality in the sum of path expressions gives v₂(Σ_{x in cube} f(x))≥a/2−H. Exact silence off S makes the sum precisely f(x⋆).

Finally f(x⋆) lies in Z[ζ₈,1/2], and all four Galois conjugates of its matrix entry have absolute value at most two. Indeed applying such a Galois automorphism to Clifford+T matrices and the chosen basis Cliffords preserves unitarity: complex conjugation commutes with each automorphism, so the unitary equations are preserved. Each conjugate echo is a difference of contractions. The nonzero rational norm of f(x⋆) has no odd-prime denominator and therefore has absolute value at least 2^{4v₂(f(x⋆))}, because the dyadic prime is unique and all four valuations equal. Its absolute value is also at most 16. This proves v₂(f(x⋆))≤1 and completes the bound. Matrix entries in the chosen first basis are sufficient because every nonzero operator has one. A weakly nonzero response needs no lower amplitude estimate.

## Boundaries

A restriction with initialized work only on which the measured discrepancy vanishes need not make it vanish as a full operator. General source words allowed to move address qubits beyond the physically read-only model are outside the affine-sign normal form. The four-band midpoint bound in four_band_sparse_crossing.md addresses unrestricted address motion by a different argument. The present result supplies no upper-bound construction and makes no unrestricted Hopf-frame claim.

## Initialized code and heralded events

Suppose R is required to preserve the target bit only on a code defined by c initialized, commuting stabilizers. Assume some active address gives a nonzero compressed difference between R† Q R and P on that code. This follows, for example, when some input eigenstate of the monitored bit changes that bit with positive probability. Let C₀ be the span of the initializer stabilizers. The isotropic space (M₁∩C₀^⊥)+C₀ extends to a maximal Pauli space E containing C₀. Since dim(M₁∩C₀^⊥)≥w−c, the basis change E↔M₁ has rank h₀≤c. The code is a subset of E-basis labels, hence a nonzero compressed entry at the active point is an ordinary physical entry between accepted labels in E. The two extra basis changes contribute at most c to the path denominator exponent. Consequently

$$
 k-\lceil\log_2|S|\rceil\ \le\ 2(H+c)+2 .
$$

For a different raw contract let Π be a joint accepting eigenspace of q commuting *output* Paulis. Suppose the Born probability of acceptance on the c-input-stabilizer code is exactly zero outside S and positive for some code input at an address in S, with arbitrary remaining work. The operator R†ΠR then has zero compression off S and at least one nonzero code entry on S. Use the same argument in E and expand Π as 2^{−q} times a signed sum of Paulis. The extra valuation penalty is at most q. Under all Galois automorphisms the compressed operator still has norm at most one; its nonzero entry therefore has v₂ at most zero. This gives

$$
 k-\lceil\log_2|S|\rceil\ \le\ 2(H+c+q).
$$

For the global core-rank version include the q measured stabilizers in the joint span (and include the c code generators too if useful). The initialized case uses only compressed entries and does not require exact return of the raw work before the actual measurement. This extension supersedes the restriction to full-operator silence in the preceding boundaries paragraph when the tested compression has precisely the stated form.
