"""Exact finite histogram, degree and reachable-signature checks; noncommuting physical witnesses."""
from itertools import product
from math import prod
from random import Random
from collections import Counter
import numpy as np

def p(z):return z.bit_count() & 1
def canon(v):return min(tuple(v),tuple((-z)%3 for z in v))
def add(v,w):return tuple((x+y)%3 for x,y in zip(v,w))
def signatures(columns):
    out={tuple(0 for _ in columns[0])}
    for col in columns:
        out={add(a,tuple(s*b for b in col)) for a in out for s in (1,2)}
    return out
rng=Random(934);hits=0
for dims in (1,2,3):
    for _ in range(40):
        n=5;k=4
        inp=[[(rng.randrange(1<<k),rng.randrange(3),rng.randrange(3)) for j in range(dims)] for i in range(n)]
        grouped={}
        for x in range(1<<k):
            vecs=[tuple((c+a*p(m&x))%3 for m,a,c in bits) for bits in inp]
            hist=Counter(canon(v) for v in vecs if any(v))
            residue=tuple(sorted(j for j,c in hist.items() if c%2))
            sig=signatures(vecs)
            if residue not in grouped:grouped[residue]=sig
            else:grouped[residue]&=sig
        assert all(grouped.values());hits+=sum(map(len,grouped.values()))
print(f'{hits} nonempty intersections of reachable ternary signatures (sum of sizes).')
# Physical controller with noncommuting local SU(2) choices and truly shared coherent controller.
I=np.eye(2);X=np.array([[0,1],[1,0]],complex);Z=np.diag([1,-1]);H=(X+Z)/np.sqrt(2)
Y=np.array([[0,-1j],[1j,0]])
def rotation(axis,theta):return np.cos(theta)*I+1j*np.sin(theta)*axis
G=[I,rotation(X,np.pi/8),rotation(Y,-np.pi/3),rotation(Z,np.pi/6)]
sel=[rotation(Y,np.pi/9),rotation(X,-np.pi/7),rotation(Z,np.pi/5)]
psi=np.array([np.cos(.21),np.sin(.21)*1j])
singlet=np.array([0,1,-1,0])/np.sqrt(2)
# Two histories cancel on an entangled pair wrapped around arbitrary protocol; compare to deletion.
checks=0
for _ in range(42):
    hist1=[(rng.randrange(4),rng.randrange(4)) for _ in sel]
    hist2=[(rng.randrange(4),rng.randrange(4)) for _ in sel]
    full=np.kron(psi,np.kron(singlet,psi)).reshape(2,8)
    small=np.kron(psi,psi).reshape((2,2))
    for c,(a,b),(u,v) in zip(sel,hist1,hist2):
        full=c@full;small=c@small
        for j,gi,gj in ((0,a,u),(1,b,v)):
            g=G[gi];h=G[gj]
            full[j]=np.kron(g,np.kron(g,h))@full[j]
            small[j]=h@small[j]
    assert np.allclose(full@full.conj().T,small@small.conj().T);checks+=1
print(f'{checks} exact-singlet coherent path reductions with noncommuting local rounds (floating check).')
# Lucas bits of arbitrary integer multiplicities after substitution by address functions.
from itertools import combinations
checks=0
for _ in range(60):
    values=[rng.randrange(2) for _ in range(10)]
    for l in range(4):
        bit=sum(prod(e) for e in combinations(values,1<<l))%2
        assert bit==(sum(values)>>l)&1
        checks+=1
print(f'{checks} binary histogram digit identities.')
