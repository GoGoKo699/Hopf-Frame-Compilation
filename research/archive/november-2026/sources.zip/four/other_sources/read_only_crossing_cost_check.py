"""Finite independent checks of the crossing-rank sparse-response estimate."""
from itertools import product
from random import Random

import numpy as np


def gauss_tests(rng):
    tested=0
    for k in range(1,8):
        for _ in range(80):
            forms=[(rng.randrange(2**k),rng.randrange(2),rng.randrange(4)) for _ in range(2*k)]
            real=imag=0
            for x in range(2**k):
                v=sum(c*((((x&a).bit_count()&1)^b)) for a,b,c in forms)%4
                real+=(v==0)-(v==2)
                imag+=(v==1)-(v==3)
            squared=real*real+imag*imag
            assert squared==0 or (squared.bit_count()==1 and squared%(2**k)==0)
            tested+=1
    return tested


def physical_tests():
    # Two spins with an optional entangling Clifford CZ between diagonal frames.
    # J=H on qubit 0 exchanges a single Pauli direction. The support sizes
    # in its matrix are cross-checked before testing the complete echo.
    rng=Random(991)
    h=np.array([[1,1],[1,-1]])/np.sqrt(2)
    identity=np.eye(2)
    z=np.diag([1,-1]); xpauli=np.array([[0,1],[1,0]])
    cz=np.diag([1,1,1,-1]); omega=np.exp(1j*np.pi/4)
    p=np.kron(xpauli,z)
    tested=[0,0,0,0]
    examples=[0,0,0,0]
    for k in range(3,8):
        width=1<<k
        addresses=np.arange(width)
        for case in range(24):
            d=1+case%4
            transitions=[]
            H=0
            for j in range(d-1):
                flips=rng.randrange(3)
                swap=np.eye(4) if flips==0 else np.kron(h,identity) if flips==1 else np.kron(h,h)
                frame=cz@swap
                nz=np.abs(frame)>1e-8
                assert np.all(nz.sum(axis=0)==2**flips)
                transitions.append(frame)
                H+=flips
            bands=[]
            for j in range(d):
                raw=[]
                for t in range(1+rng.randrange(8)):
                    mask=rng.randrange(4)
                    signs=[1-2*(((x&rngmask).bit_count()&1)^bias)
                           for rngmask,bias in [(rng.randrange(width), rng.randrange(2))]
                           for x in addresses]
                    raw.append((mask, np.array(signs) * rng.choice([-1,1]), rng.randrange(2)))
                bands.append(raw)
            net=np.eye(4,dtype=complex)
            for frame in transitions:
                net=frame@net
            q=net@p@net.conj().T
            s=0
            for x in addresses:
                v=np.eye(4,dtype=complex)
                for j,band in enumerate(bands):
                    powers=[sum((signs[x]-signs[0])*(((y&mask).bit_count()&1)^flip)
                                for mask,signs,flip in band) for y in range(4)]
                    v=np.diag([omega**pwr for pwr in powers])@v
                    if j<d-1:
                        v=transitions[j]@v
                obs=v.conj().T@q@v
                s+=int(np.max(np.abs(obs-p))>1e-8)
            if s:
                assert k-(s-1).bit_length()<=2*H+2
                examples[d-1]+=int(s<width)
            tested[d-1]+=1
    return tested, examples


def exact_sparse_family():
    # All-diagonal comparison of signed pi/4 rotations on one X probe.
    # Check the H=0 regime without floating point on all short signed sums.
    count=tight=0
    k=5
    for masks in product((1,2,3,5,9,17),repeat=4):
        for offset in range(8):
            s=sum((offset+sum(1-2*((a&x).bit_count()%2) for a in masks))%8!=0
                  for x in range(1<<k))
            if s:
                assert k-(s-1).bit_length()<=2
                tight+=int(k-(s-1).bit_length()==2)
            count+=1
    for a,b in product(range(1,2**k),repeat=2):
        if a==b:
            continue
        support=0
        for x in range(2**k):
            char=lambda mask: 1-2*((x&mask).bit_count()%2)
            exponent=1-char(a)-char(b)+char(a^b)
            support+=exponent%8!=0
        assert support==2**(k-2)
        tight+=1
        count+=1
    return count,tight


if __name__=='__main__':
    print('Exact quadratic Gauss sums:',gauss_tests(Random(882)))
    print('Two-spin physical complete responses, partially silent:',physical_tests())
    print('Exact single-frame signed rotations, saturating cases:',exact_sparse_family())
