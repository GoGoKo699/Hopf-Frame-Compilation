# Proof and verification guide

The accompanying report gives the theorem statements, their circuit models and the implications for complete-frame depth. Start with four_layers/scalar_and_rank_gap.md. Each proof in this package has a companion Python checker with the same stem.

| Directory | What to use it for |
|---|---|
| four_layers | The three-state proof, an independent weaker quantitative proof, fixed-accuracy operator floors and the observable-only read-only degree corollary. |
| five_layers | An exact factorization of two native bands with crossing rank r, and a bound on each adjacent crossing of a five-band rare response. |
| one_clean | Two independent ingredients give linear rank at all three interfaces and linear common middle dimension for R74's one-clean precision witness. The prior cyclotomic cluster proof is included as a dependency. |
| other_sources | Two architecture-specific lower bounds, and a constant-depth physical field clock with a full nonzero-address primitive spectrum. Its high-power readout still needs a native implementation. |

Run `python run_checks.py` from an extracted copy with Python 3.11+ and NumPy installed. The test output is recorded in TEST_RESULTS.txt. Finite enumeration and floating-point matrix identities check aspects of the general algebraic proofs.

The repository baseline is ae613bf8e8a38f6d0407c25910b83d69f01a2733. The source and build of the three new main claims can be read directly in this package without replaying the research session.
