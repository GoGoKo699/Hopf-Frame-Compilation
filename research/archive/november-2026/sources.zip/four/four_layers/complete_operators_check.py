"""Check the frame, Fourier-bank and finite-rank identities used in the report."""
from itertools import product
from math import cos, pi, sin, sqrt
from random import Random

import numpy as np

rng = Random(407495)
hadamard = np.array([[1, 1], [1, -1]], dtype=float) / sqrt(2)
x_gate = np.array([[0, 1], [1, 0]])
identity = np.eye(2)
b = 2 * sin(pi / 24)
tau = sin(pi / 8) / (2 * sqrt(2))
assert 8 / 128 < b**2 < 8 / 64
assert abs(b**2 / 16 - (1 - cos(pi / 12)) / 8) < 1e-15
roots = np.exp(1j * np.pi * np.arange(8) / 4)
assert all(abs(a - z) > 2 * tau for i, a in enumerate(roots) for z in roots[i+1:])

bank_checks = 0
frame_checks = 0
rank_checks = 0
for p in range(1, 8):
    size = 1 << p
    for address in range(size):
        for i in range(12):
            bank = rng.getrandbits(size)
            mask = rng.getrandbits(size)
            toggle = 1 << address
            assert (((bank ^ toggle) & mask).bit_count() - (bank & mask).bit_count()) % 2 == ((mask >> address) & 1)
            assert ((bank ^ toggle) & 1) ^ (bank & 1) == int(address == 0)
            bank_checks += 1
        leaf_phase = np.diag([-1 if address == 0 else 1, 1])
        actual_leaf_action = hadamard @ leaf_phase @ hadamard
        desired = -x_gate if address == 0 else identity
        assert np.allclose(actual_leaf_action, desired)
        frame_checks += 1
    for rank in (1, max(1, size // 8), max(1, size // 2)):
        for repeat in range(5):
            support = rng.sample(range(size), rank)
            W = np.ones(size, dtype=complex)
            for j in support:
                W[j] = roots[rng.randrange(1, 8)]
            translation = rng.randrange(size)
            discrepancy = W * np.conjugate(W[np.arange(size) ^ translation]) - 1
            assert np.count_nonzero(abs(discrepancy) > 1e-10) <= 2 * rank
            assert np.mean(abs(discrepancy)**2) <= 8 * rank / size + 1e-10
            rank_checks += 1
print(f"{bank_checks} Fourier-bank columns, {frame_checks} signed frame blocks, {rank_checks} rank bounds")
print(f"Mean flip floor {b**2 / 16:.12f}, rank-fraction floor {b**2 / 8:.12f}, full-operator floor {tau:.12f}")
