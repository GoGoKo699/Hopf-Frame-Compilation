"""Finite support geometry, midpoint expansions and complete-column checks."""
import itertools
from random import Random
from math import sqrt
import numpy as np

rng=Random(47121)
I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],dtype=complex)
Z=np.diag([1,-1]).astype(complex)
Y=1j*X@Z
H=(X+Z)/sqrt(2)
S=np.diag([1,1j])
T=np.diag([1,np.exp(1j*np.pi/4)])

def kr(*xs):
    a=np.array([[1]],dtype=complex)
    for x in xs: a=np.kron(a,x)
    return a
def place(m,i,n):
    return kr(*(m if j==i else I for j in range(n)))
def adj(x): return x.conj().T
def norm(x): return np.linalg.norm(x,'fro')/sqrt(len(x))
def cliff(n):
    c=np.eye(2**n,dtype=complex)
    for _ in range(14):
        a=rng.randrange(n)
        opts=[place(H,a,n),place(S,a,n),place(X,a,n)]
        if n>1:
            b=(a+rng.randrange(1,n))%n
            opts.append(place((I+Z)/2,a,n)+place((I-Z)/2,a,n)@place(X,b,n))
        c=rng.choice(opts)@c
    return c
def tb(n):
    return kr(*(rng.choice([T,adj(T),I]) for _ in range(n)))

def clifford_check(u, paulis):
    for p in paulis:
        image=u@p@adj(u)
        if not any(abs(abs(np.vdot(image,q))/len(u)-1)<1e-8 for q in paulis):
            return False
    return True

def run():
    cases=0
    out=0
    for n in (1,2,3):
        ps=[kr(*v) for v in itertools.product([I,X,Y,Z],repeat=n)]
        for _ in range(15):
            cA,cB=cliff(n),cliff(n)
            axisA,axisB=tb(n),tb(n)
            eA,eB=cA@axisA@adj(cA),cB@axisB@adj(cB)
            p,q=rng.choice(ps[1:]),rng.choice(ps[1:])
            aC,bC=cliff(n),cliff(n)
            aO,bO=tb(n),tb(n)
            kA=aC@aO@p@adj(aO)@adj(aC)
            kB=bC@bO@q@adj(bO)@adj(bC)
            A=eA@kA@adj(eA); B=eB@kB@adj(eB)
            d=norm(A-B)
            assert d>1/(16*sqrt(2))-1e-8 or d<1e-8
            for j,mat in itertools.product(range(n),(X,Z)):
                g=cA@place(mat,j,n)@adj(cA)
                # Decompose eA† g eA into the A-coordinate Pauli basis.
                expanded=adj(cA)@adj(eA)@g@eA@cA
                coeffs=[np.vdot(t,expanded)/(2**n) for t in ps]
                terms=[]
                for k,coeff in enumerate(coeffs):
                    if abs(coeff)>1e-9:
                        q0=cA@ps[k]@adj(cA)
                        u=eA@kA@q0@kA@adj(eA)
                        # In the one-band diagonal frame this is Clifford.
                        assert clifford_check(u,ps)
                        terms.append((coeff,u))
                assert len(terms) in (1,2)
                if len(terms)==2:
                    assert abs(np.vdot(terms[0][1],terms[1][1]))<1e-7
                    assert all(abs(abs(c)-1/sqrt(2))<1e-8 for c,u in terms)
                lhs=sum(c*u for c,u in terms)
                rhs=B@g@B
                assert norm(lhs-A@g@A)<1e-8
                assert clifford_check(adj(eB)@rhs@eB,ps)
                dist=norm(lhs-rhs)
                assert dist>1/(8*sqrt(2))-1e-8 or dist<1e-8
                if dist>1e-8: out+=1
                cases+=1
    return cases,out

def check_hulls():
    n=3; q=2**n
    spaces={frozenset([0])}
    for _ in range(n):
        more=set()
        for s in spaces:
            for g in range(q):
                more.add(frozenset(set(s)|{g^v for v in s}))
        spaces|=more
    flats={frozenset(g^v for v in s) for s in spaces for g in range(q)}
    tested=0
    for center in flats:
        close=[a for a in flats if len(a&center)/sqrt(len(a)*len(center))>.5]
        for a,b in itertools.product(close,repeat=2):
            union=center|a|b
            t=min(len(z) for z in flats if z>=union)
            assert t<=4*min(len(center),len(a),len(b))
            tested+=1
    return tested

if __name__=='__main__':
    print('Three intersecting affine supports:',check_hulls())
    print('Actual four-band Pauli-generator probes and nonzero cases:',run())
