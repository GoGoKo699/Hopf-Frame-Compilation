"""Finite checks for the sparse-generator four-band scalar gap."""
import itertools
import math
from functools import reduce
from operator import xor
from random import Random
import numpy as np


def span(vectors):
    out={0}
    for v in vectors:
        out|={v ^ x for x in out}
    return frozenset(out)


def dim(S):
    assert len(S) & (len(S)-1) == 0
    return len(S).bit_length()-1


def direction(S):
    a=next(iter(S))
    return {a ^ v for v in S}


def all_affine_spaces(k):
    spaces=set()
    for size in range(k+1):
        for rows in itertools.combinations(range(1,1<<k),size):
            H=span(rows)
            if dim(H)==size:
                spaces.update(frozenset(z^s for s in H) for z in range(1<<k))
    return list(spaces)


def check_tangent():
    spaces=all_affine_spaces(3)
    examples=0
    for S,T,U in itertools.combinations_with_replacement(spaces,3):
        pairs=((S,T),(T,U),(S,U))
        edges=sum(bool(a&b) and dim(a)+dim(b)-2*dim(a&b)<=2 for a,b in pairs)
        if edges<2:
            continue
        base=next(iter(S))
        H=span((v^base for v in S|T|U))
        L=direction(S)&direction(T)&direction(U)
        assert dim(H)-dim(L)<=4
        examples+=1
    return examples


def check_integral_gap():
    # Integral coordinates represent alpha = sqrt(2)*2^{D/2} F(z) in Z[zeta_8].
    def phase(a,j):
        ans=[0]*4
        for i,c in enumerate(a):
            t=(i+j)%8
            ans[t%4]+=(1 if t<4 else -1)*c
        return tuple(ans)
    def times_sqrt2(a):
        b,c=phase(a,1),phase(a,7)
        return tuple(x+y for x,y in zip(b,c))
    def powers(c):
        a=(1,0,0,0)
        for _ in range(c): a=times_sqrt2(a)
        return a
    def options(extra):
        return {(0,0,0,0)}|{phase(powers(c+extra),j) for c in range(5) for j in range(8)}
    def norm_squared(a):
        # alpha*conj(alpha) = (sum coeff²)+ sqrt(2)*(signed nearest/third pairs).
        A=sum(c*c for c in a)
        B=a[0]*a[1]+a[1]*a[2]+a[2]*a[3]-a[0]*a[3]
        return A,B
    seen=0
    for opts in (itertools.product(options(1),options(0),options(0)),
                 itertools.product(options(1),options(1))):
        for terms in opts:
            z=tuple(map(sum,zip(*terms)))
            if any(z):
                A,B=norm_squared(z)
                assert A*A-2*B*B>=1
                assert A-math.sqrt(2)*B<196+1e-10
            seen+=1
    return seen


def pauli_matrices(q):
    N=1<<q
    ans={}
    for x,z in itertools.product(range(N),repeat=2):
        P=np.zeros((N,N),complex)
        for y in range(N):
            P[y^x,y]=1j**((x&z).bit_count())*(-1)**((y&z).bit_count())
        ans[x | (z<<q)]=P
    return ans


def conj(U,P):
    return U@P@U.conj().T


def native_probe():
    rng=Random(719)
    omega=np.exp(1j*np.pi/4)
    cases=0
    for q in (1,2,3):
        N=1<<q
        P=pauli_matrices(q)
        H=np.array([[1,1],[1,-1]])/np.sqrt(2)
        S=np.diag([1,1j])
        def embed(matrix,k):
            ops=[matrix if i==k else np.eye(2) for i in reversed(range(q))]
            return reduce(np.kron,ops)
        cn=[]
        for a,b in itertools.permutations(range(q),2):
            mat=np.eye(N)
            cn.append(mat[[i^(((i>>a)&1)<<b) for i in range(N)],:])
        gs=[embed(g,i) for i in range(q) for g in (S,H)]+cn
        def cliff():
            out=np.eye(N)
            for _ in range(9): out=rng.choice(gs)@out
            return out
        def band():
            axes=tuple(rng.choice((0,1,-1)) for _ in range(q))
            X=cliff()
            D=np.diag([omega**sum(e*((v>>i)&1) for i,e in enumerate(axes)) for v in range(N)])
            return (X@D@X.conj().T,
                    [conj(X,P[1<<(i+q)]) for i,e in enumerate(axes) if e])
        def core():
            M,_=band()
            return conj(M,rng.choice(list(P.values())[1:]))
        for _ in range(15):
            EA,axes=band()
            EB,_=band()
            KA,KB=core(),core()
            A,B=conj(EA,KA),conj(EB,KB)
            sparse=[]
            for h,X in P.items():
                anti=sum(np.linalg.norm(T@X-X@T)>1e-6 for T in axes)
                if anti>1:
                    continue
                sparse.append(h)
                pulled=conj(EA.conj().T,X)
                coeff={i:np.trace(Y@pulled)/N for i,Y in P.items()}
                coeff={i:float(c.real) for i,c in coeff.items() if abs(c)>1e-8}
                assert len(coeff)==1+anti
                summands=[conj(EA,conj(KA,P[k])) for k in coeff]
                for M in summands+[conj(KB,conj(EB.conj().T,X))]:
                    for k in range(2*q):
                        Y=conj(M,P[1<<k])
                        assert any(abs(np.trace(Y@Z))/N>1-1e-7 for Z in P.values())
                exp=sum(c*M for c,M in zip(coeff.values(),summands))
                np.testing.assert_allclose(exp,A@X@A,atol=1e-10)
                if anti:
                    assert abs(np.trace(summands[0].conj().T@summands[1])/N)<1e-8
                cases+=1
            assert len(span(sparse))==N**2
    return cases



def check_sharper_support():
    r8=[np.exp(1j*np.pi*j/4) for j in range(8)]
    b=2*math.sin(math.pi/24)
    assert b*b>1/16 and b*b/16>2**-8
    assert abs(b*b-((1/math.sqrt(2)-.5)**2+
                       (1/math.sqrt(2)-math.sqrt(3)/2)**2))<1e-14
    for j in range(1,8,2):
        assert abs(abs((1+r8[j])/math.sqrt(2))-1)>b
    assert (math.sqrt(2)-1)/math.sqrt(2)>b and math.sqrt(1/8)>b
    spaces=all_affine_spaces(3)
    cases=0
    for S in spaces:
        near=[T for T in spaces if S&T and dim(S)+dim(T)-2*dim(S&T)<=1]
        for U,V in itertools.product(near,repeat=2):
            for T in (U,V): assert T<=S or S<=T
            if len(U)==2*len(S)==len(V) and U!=V:
                assert not (U-S)&(V-S)
            if len(U)*2==len(S)==2*len(V) and U|V!=S:
                assert 4*len(S-(U|V))>=len(S)
            cases+=1
    return cases

if __name__=='__main__':
    print(check_sharper_support(),'nested-support triples and improved constants')
    print(check_tangent(),'connected triples of finite affine supports')
    print(check_integral_gap(),'cyclotomic amplitude and conjugate norm checks')
    print(native_probe(),'native sparse-generator decompositions with Clifford summands')
