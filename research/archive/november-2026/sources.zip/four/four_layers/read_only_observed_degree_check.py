from random import Random
from math import pi, sin, sqrt
from itertools import product
rng=Random(3062)
def dot(a,b): return (a&b).bit_count()%2
def multiply(matrix,v): return sum(dot(row,v)<<i for i,row in enumerate(matrix))
def matrix_for(h,k):
    n=1<<k
    return [sum(((h>>(a^i))&1)<<i for i in range(n)) for a in range(n)]
def affine_difference_fixture():
    checks=0
    for hdim in (7,8,9,10):
        for _ in range(8):
            M=rng.sample(range(hdim),rng.randint(7,hdim))
            chosen=M[:7]
            supmask=sum(1<<i for i in M)
            mons={supmask}|{rng.randrange(1<<hdim) for _ in range(12)}
            # Use a true maximum monomial for degree witness.
            witness=max(mons,key=int.bit_count)
            chosen=[i for i in range(hdim) if witness>>i&1][:7]
            outside=[i for i in range(hdim) if i not in chosen]
            def g(x): return sum(x&m==m for m in mons)%2
            def lift(mask,q): return sum(((mask>>j)&1)<<i for j,i in enumerate(q))
            tables=[]
            for c in range(1<<len(outside)):
                table=sum(g(lift(c,outside)|lift(x,chosen))<<x for x in range(128))
                if table.bit_count()%2: tables.append(table)
            assert tables
            h=tables[0]
            m=matrix_for(h,7)
            for x in range(128):
                y=rng.randrange(1<<128)
                shift=m[x]
                assert multiply(m,multiply(m,y)^shift) == y^(1<<x)
                checks+=1
    return checks
def geometry():
    xi=128*2**-25
    b=2*sin(pi/24)
    assert 4*sqrt(xi)+.25 < b and 2*sqrt(xi)<2/sqrt(128)
    # Worst support-disjoint X shifts attain the rank estimate for a marked plane.
    for k in range(1,10):
        d=1<<k
        for shift in range(d):
            diff=sum((x==0)!=((x^shift)==0) for x in range(d))
            assert 4*diff/d<=8/d
    return b,4*sqrt(xi)+.25
if __name__=='__main__':
    print('Odd seven-flat parallel normalized physical bank words:',affine_difference_fixture())
    print('Sharp commutator threshold and robust upper:',geometry())
