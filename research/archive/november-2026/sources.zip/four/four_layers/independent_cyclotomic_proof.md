# A uniform normalized Pauli-isolation gap with four native T bands

Let U be an arbitrary unitary native Clifford+T word with at most four T bands, on any number of wires. Let P,Q be prescribed Hermitian physical Paulis; the signed comparison below is literal. Normalize the Hilbert–Schmidt norm by the square root of the full Hilbert-space dimension. Then
$$
 \|U^\dagger Q U-P\|_{2,\mathrm{tr}}<\frac1{16\sqrt2}
   \quad\Longrightarrow\quad U^\dagger Q U=P .
$$
No initialized wires or stationarity assumptions are used in this full-space statement. Compensating a global scalar on U has no effect.

## Four bands reduce to a comparison with one diagonal layer

Split U into two halves. Move the outside Clifford intervals through P and Q, and move all fixed Clifford frames on each half into a common middle coordinate system. In this frame compare A=E_A K_A E_A† and B=E_B K_B E_B†, with A,B Hermitian involutions, K_A,K_B Hermitian Clifford unitaries (a single T band conjugates a Pauli into a Clifford), and each E a single native T/T† band about transported independent commuting axes. Conjugating U† Q U−P by the right half shows its normalized norm is ||A−B||.

There exists a symplectic basis of physical Paulis H such that each anticommutes with at most one of the A band's axes. Extend their independent commuting binary labels to a Lagrangian basis and use its symplectic dual. For any such H, E_A† H E_A is either a single Hermitian Pauli or a signed sum divided by √2 of two anticommuting Hermitian Paulis. The latter comes from a single active axial rotation, with factors from all commuting axes cancelling. K_A maps the appearing Paulis to Paulis. Conjugating by E_A maps each of these to a Hermitian Clifford. Thus the normalized Choi vector of A H A is an individual Clifford vector U₁ or (U₁+U₂)/√2 where U₁,U₂ are orthogonal normalized Clifford vectors, with their signs absorbed. Orthogonality follows already from the anticommutation, and survives both conjugations. In contrast E_B† H E_B is always a Hermitian Clifford, even when many axes activate. Hence B H B has the form E_B D E_B† for a single Hermitian Clifford D.

Choose solely for this H comparison a global Clifford change taking the B band to a computationally diagonal eighth-root parity-phase word. The normalized Choi vectors of U₁,U₂ are normalized stabilizer vectors, each flat on its affine support with an eighth-root global scalar and standard quadratic Clifford phases. Their global scalars are retained: they are concrete conjugates of physical Paulis by Clifford/one-band words. In particular Hermiticity and the usual ring-valued representative ensure eighth-root rather than arbitrary continuous Choi phases, as in R73–R74. The vector C of B H B has the same affine support structure and a weighted-cubic eighth-root phase. There are no residual Hadamards between incomparable frames in this comparison.

## A three-vector gap without scale iteration

Write V=(U₁+U₂)/√2 in the two-vector case. If ||C−V||<1/√2−1/2 then
$$
 |\langle C,U_i\rangle|\ge 1/\sqrt2-\|C-V\|>1/2,\quad i=1,2 .
$$
For any two normalized flat affine vectors, the absolute overlap is at most 2^{-d} where d=(dim T+dim S)/2−dim(T∩S), and is zero for empty intersection. Because d is a nonnegative half-integer, d≤1/2 for both pairs. Thus each T_i equals the support S of C, is a hyperplane of S, or contains S as a hyperplane. Their common affine hull has codimension at most two above each member: two distinct superspaces add at most two dimensions above S; a strict subspace and superspace differ by at most two. This also directly handles partially coincident supports. For a single U₁ with C at distance <1/(8√2), their inner product has modulus >1/√2 and their supports coincide.

Use the full-hull argument in the companion R74 valuation note on C−V, m=0. Every coefficient can be put into ±2^{-1/2} form with an eighth-root phase, since 1=(ζ₈+ζ₈^{-1})/√2. This gives at most K=4 normalized phase vectors, b=1 and ℓ≤2. For completeness, scaling the selected coordinate on the affine hull by (√2)^{1+h}, where h is the hull dimension, gives an algebraic integer α. Each normalized term in α is a weighted-cubic phase times at most ℓ affine support tests, with a factor (√2)^{e_i} for codimension e_i exactly paying those tests in the (1−ζ₈)-adic filtration. The ordinary Boolean multilinear coefficient of size j is divisible by (1−ζ₈)^j. At the smallest finite valuation v of any α the reduced residue is a nonzero degree-≤v Boolean function, so at least 2^{-v} of the hull points have that valuation. There the absolute field norm |α|²|σα|² is at least 2^v, and the conjugate absolute squared is at most K² 2^ℓ (σ fixes i and negates √2). Dividing by the normalization and summing cancels 2^v. Hence any nonzero C−V has squared norm at least 2^{-b−ℓ}/K²≥1/128. The single-vector case admits the same bound. Since 1/(8√2)<1/√2−1/2 this proves
$$
 \|A H A-B H B\|_{2,\mathrm{tr}}<1/(8\sqrt2)
   \ \Longrightarrow\ A H A=B H B .
$$

If ||A−B||<1/(16√2), the triangle inequality and unitary invariance imply this strict premise for every basis H. Thus BA commutes with a generating physical Pauli set. Irreducibility makes BA scalar. Because A and B are both Hermitian involutions, A=±B, and the distance threshold forces A=B.

Consequences include the following. If P and Q observe the computational incoming and outgoing target bit of a raw unitary, its uniform full-column bit-change probability e satisfies ||U†Q U−P||_{2,tr}=2√e. Any nonzero e is at least 1/2048. In particular a completely silent-outside-one-address four-band output displacement on k≥12 address bits is identically silent. For the full-space real frame witness in R74 with zero clean inputs, sufficiently small operator error forces exact preservation of each Pauli commuting with the target rotation. The repository’s unit-circle classification then gives a constant error floor. For one external clean bit, closeness to a returned initialized code forces the physical code flag Z to be preserved exactly at sufficiently small error: the two off-diagonal blocks of a unitary relative to the code have equal operator norm, and ||[U,Z]||_op≤2ε. This alone does not transfer arbitrary data-Pauli commutation from that code to the entire physical Hilbert space.
