# A four-band raw, read-only bit has binary degree at most six

Assume a zero-clean Clifford+T word with at most four native T bands. All T targets are private and its address is gatewise shareable: each Clifford interval is a computational-address-preserving sector word, usable on affine restrictions and in parallel private copies. On address x and a uniformly random computational column of all the private input wires, measure one designated outgoing bit. With probability at least 1−μ its value must equal a designated incoming bit XOR g(x). This is required for every x. Remaining physical outputs may be arbitrary and phaseful; the designated value need not be deterministic when μ is positive.

Then deg_F₂ g≤6 if μ≤2^{-25}. In particular this holds for deterministic output bit displacements on every private input column. The exact rank argument uses only seven address variables. This result relies on the separate four-band full-space Choi-generator distance gap b=2 sin(π/24) in hopf_next_lower.md. The gatewise sharing applies only to assembling the new circuit. The gap applied to that physical circuit itself permits arbitrary address motion.

## Finding one rare output displacement

If deg g≥7, choose seven coordinates from a maximum-degree nonzero ANF monomial. Their mixed difference is not identically zero because that monomial alone contributes the coefficient of its complementary variables to the derivative. Fix the other variables at a nonzero derivative value. The restricted seven-bit predicate h has odd Hamming weight since this derivative is the XOR of the restricted table.

Consider the 128 shifted programs h(x+a), a∈F₂⁷. They run in parallel on the same read-only address and private banks/bits. Logical preservation by an entire Clifford interval suffices if it is re-emitted in its read-only form: apart from a common address phase, its restriction is a private Clifford and a private Pauli with affine labels in x. Public controls can be used sequentially across private copies in each Clifford interval, with all subsequent native T layers executed in parallel; fixed affine address offsets change the signs of these controls. Any phase depending only on x is immaterial to the raw bit measurement. No unknown data need be copied into initialized words. The scalar read-only Clifford form and fusion of simultaneous native layers are also used in the repository's three/four-layer preserved-address proof.

Let M have entries h(a+x), with its columns indexed by the input address x and its rows by physical copies a. Binary group convolution gives M²=I: the diagonal equals the odd weight and every off-diagonal sum cancels in pairs. If the designated incoming and outgoing bits of the raw word are on different wires, arrange each incoming and outgoing bank grouping separately. Precompose the parallel word with b↦M b on the 128 incoming bits; postcompose with b'↦M b' on their 128 outgoing counterparts, applying fixed swaps to name the same destination wires if needed. Each map is a literal invertible Clifford. In the exact case the new bank value is b+e_x on every full basis input, even when unobserved output wires retain arbitrary quantum garbage. In particular the zeroth normalized output displacement is one only at x=0. The resulting all-input circuit has four T bands. For imperfect raw bits let ξ≤128μ be the actual mean disagreement probability of that one normalized bit with the ideal marked-row flip. The union bound over the measured raw bits is valid because the simultaneous premap permutes the uniform full input, leaving each copy with its uniform private marginal for each x. Separate qubit measurements on the raw banks may be used mathematically to compute this probability since the binary postmap permutes their computational basis.

## Using the rank bound stably

For the new four-band circuit C write P,Q for the incoming and outgoing zeroth bit Z's and D_x for the physical diagonal sign, −1 at x=0 and +1 elsewhere. Squaring the normalized Hilbert–Schmidt distance on all input columns gives
$$
 \|C^\dagger Q C-D_x P\|_{2,\mathrm{tr}}=2\sqrt{\xi}.
$$
Split into the two actual halves of C. In the notation A,B for the two transported middle observables, the product W=BA is within 2√ξ of an involution W₀ unitarily conjugate to D_x. Indeed the physical product P C† Q C is conjugated into BA (or reverse orientations with adjoints throughout). W₀ has rank(I−W₀)/D=1/128, where D is the whole physical dimension.

For any physical Pauli H,
$$
 \|W H W^\dagger-H\|_{2,\mathrm{tr}}
 \le 4\sqrt{\xi} + \|W_0 H W_0^\dagger-H\|_{2,\mathrm{tr}}
 \le 4\sqrt{\xi}+\tfrac14 .
$$
The second difference has operator norm at most two and rank at most 2D/128. With ξ≤128·2^{-25}=2^{-18}, this is at most 1/4+1/128, strictly below b. For a symplectic set of generators dual to the axes of A’s middle native T band the sharp Choi gap implies WHW†=H. Their irreducibility forces W scalar, and as B,A are Hermitian involutions that scalar is ±1. But ||W₀−I||₂=2/√128 and ||W₀+I||₂=2√(127/128), contradicting its distance ≤2√ξ to W. In the exact case the same proof uses ξ=0.

## Existing theorem and new scope

The repository already proves deg f≤2 for a **complete returned XOR** Q_f on a preserved address, all work arbitrary, even at full operator error <√2/12; its word-valued generalization is in §8.7. The present bit-observable statement allows unrestricted garbage and asks only a small conditional mean measurement error on the private columns. It does not improve that earlier degree-two conclusion or yield an unrestricted moving-address or one-clean four-band Boolean-degree theorem. [Existing read-only four-layer theorem, §8](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/READ_ONLY_THREE_LAYER_RIGIDITY.md#8-four-layers-with-zero-clean-qubits-degree-at-most-two)
