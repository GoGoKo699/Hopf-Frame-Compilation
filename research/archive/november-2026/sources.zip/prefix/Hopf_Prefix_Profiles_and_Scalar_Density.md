# Complete frames with prefix-dependent rotations, and a density criterion for general depth

Research note, 19 November 2026. All comparisons use \(N=2^n\), fixed complete-operator precision \(2^{-L}\), and one supplied clean qubit. Dirty qubits can be in any joint state with the input and an external reference. The repository reference is `ae613bf8e8a38f6d0407c25910b83d69f01a2733`.

## What improved unconditionally

Suppose the angles at the first \(q\) levels of a real Hopf frame are arbitrary. Below those levels, each of the \(2^q\) prefixes has its own angle list. At a given depth the rotation is shared only by nodes in that same prefix subtree. At square-root dirty width the complete frame has
\[
\boxed{D_T=O_L\big(\log(q+\log(n+4)+2)\big)}
\]
for \(q=n^{o(1)}\), with \(O_L(\sqrt N)\) T gates and \(O_L(N)\) elementary Cliffords. In particular:

| Tree data | Unconditional native T-depth at \(b=\Theta(\sqrt N)\) |
| --- | --- |
| One arbitrary rotation per level, \(q=0\) | \(O_L(\log\log(n+4))\) |
| Arbitrary top \(\lfloor(\log n)^2\rfloor\) levels, then an independent rotation per level for each resulting subtree | \(O_L(\log\log(n+4))\) |
| \(q=n^{o(1)}\) arbitrary top levels, then independent profiles | \(o(\log n)\) |
| Arbitrary rotation at every node | R96 gives \(O_L(\log n)\) |

The rotation angles in the first three rows can be arbitrary effectively prescribed real values. In particular, the earlier dyadic-grid requirement is removed. Sharing just the magnitudes while permitting arbitrary unseen node signs would be a different promise. On the wide branch, the explicit resource bound is \(\exp((q+\log(n+4))^{O_L(1)})\) in gates and dirty wires; for the displayed family this is \(2^{o(n)}\). At the original admissible narrower widths one may use the standard \(N/b^2\) term and count tradeoff as detailed in the proof.

### Why the rotations fit

There is a coherent synthesis of a single rotation to accuracy \(\epsilon\) with \(O(\log(1/\epsilon))\) initialized ancillas and \(O(\log\log(1/\epsilon))\) bounded-width circuit depth. Applying it separately to every site would require storing many initialized registers simultaneously. The new construction puts each synthesis word inside a reflection about its local initialized subspace and supplies many candidate registers in arbitrary states. The first candidate whose work bits are zero determines which reflection acts on the logical qubit. Two swap-and-reflection conjugations cancel the unwanted action on the chosen candidate. [Vasconcelos, Theorem 8](https://arxiv.org/html/2609.34659v1#S3.SS4.SSS1)

This initial construction has small *normalized Hilbert–Schmidt* error. The relevant gain is quantitative. A local reflection error has rank at most two. Across \(h\) candidate registers of \(k\) private initialization bits each, the error is \(O(\epsilon\sqrt{h/2^k})\), plus the contribution when no candidate is usable. A controlled average over a short, fixed list of private Pauli masks upgrades this estimate to the required isometry norm on every dirty state. One coherent seed of \(O_L(\log n)\) bits serves the entire bank. In the complete frame it lives in logical suffix bits that are known zero on the active branch. A conjugation cancels the action on the inactive branch for arbitrary values of those same bits.

For the prefix-selected construction each target has one collection of candidates per prefix. On a fixed prefix the other collections cancel even when their physical synthesis has leakage. The number of prefix values enters the classical routing cost and the finite mask search. It does not multiply the error of one rotation. The shortened terminal is a complete frame on just the prefix and the surviving suffix wires. The proof charges it and the separately guarded arbitrary top frame. [Controlled Clifford+T construction, Theorem 6](https://arxiv.org/html/2512.24982v1#S4.SS2)

A separate construction covers sparse changes at widely separated depths. Starting from the positive balanced frame, let \(s\) nodes receive independent arbitrary rotations and suppose each branch contains at most a fixed number \(K\) of these changes. The depth is \(O_{K,L}(\log\log(n+4)+1+\log\log(s+2))\) when the stated sparse resource budget fits. Thus even polynomially many such changes at arbitrary depths preserve doubly logarithmic depth. Its proof uses the orthogonality of incomparable Haar-node corrections and an explicit error bound for truncating the ancestor part of each correction.

## What would improve the unrestricted frame

There is now a weaker sufficient scalar target. Let \(M=2^a\), and consider all \(2^M\) truth tables on \(a\) address bits. For any fixed \(\eta>0\), it suffices to produce **exact** scalar sign circuits for a fraction
\[
\boxed{\alpha\ge 2^{-M^{1-\eta}}}
\]
of the tables. For the implication to sublogarithmic complete-frame depth these circuits must simultaneously use \(O(\sqrt M+M/B)\) T gates, \(O(M)\) elementary Cliffords and \(O(\log\log(a+4)+M/B^2)\) T-depth at every suitable dirty allocation \(B\), with at most constant clean input. The conclusion is the same as for an exact compiler for *every* table. For example, when \(\eta=1/2\) it suffices to realize \(2^{M-\sqrt M}\) distinct exact sign tables. Proving that a native circuit family reaches this threshold is open.

Here is the proof in brief. Hamming concentration implies that a uniform random table is within expected relative distance \(O(M^{-\eta/2})\) of the easy family. A random address translation distributes that error evenly over the logical inputs. For the desired lift \(F(x,t)=t f(x)\), mask with a uniform table \(U\). Approximate \(U\) and \(U+F\) separately by easy tables and XOR their signs. Each individual input has inverse-polynomial error in this *classical choice of tables*. Take \(O(1/\eta)\) independent pairs. A union bound over addresses proves there is a fixed list whose Boolean majority is correct everywhere. Its native circuit computes each vote using two phases and Hadamards, applies the majority phase, then reverses the actual record. Offline randomness disappears and the compiled sign is exact. This also works directly from an inverse-polynomial expected distortion bound if it is easier to prove than a cardinality bound.

For approximate source words the same correction has full physical error at most \(4K\epsilon\) for \(K\) pairs and per-source error \(\epsilon\). Generic fixed coherent leakage still needs an accuracy argument to reach the iterated scalar-to-frame transfer. The archive gives a parity-check condition under which amplification succeeds and a counterexample for uniform address fingerprinting.

## Where the marked-edge attempt stops

For the two-tree construction, a generic binary cross matrix can be reduced to two invertible ones at the same even-split arity (with bounded small cases handled directly). This allows the programmed crossing itself to be implemented as an in-place linear reversible circuit. A matrix-vector product or an invertible crossing still leaves the coherent phase of the selected entry unpaid. A concrete next test is a family of shallow, fully returned native circuits for random invertible crossings, together with a bound on the average Hamming distortion of the **exact sign tables** they realize. The distortion criterion above says how strong that estimate must be.

The unconditional unrestricted large-width gap remains \(O_L(\log n)\) versus \(\Omega(1)\). A new lower bound shows that, under an \(O_L(\sqrt N)\) T budget, some target requires \(\Omega_L(\sqrt N)\) T gates outside its two widest native layers. It allows arbitrary Clifford interlayers and dirty width. Three or more constant-depth layers can satisfy that distribution, so it does not settle the depth exponent. [R96 and the repository frontier](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/OPEN_PROBLEM.md)

The verification archive contains the mathematical appendices, deterministic small-instance checks, and the repository regression commands. Native asymptotic claims are proved on paper. The checks exercise full matrices, reversals, finite-field and combinatorial identities, and the resource arithmetic on finite instances.
