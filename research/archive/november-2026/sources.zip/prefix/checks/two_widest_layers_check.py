from itertools import combinations, product
from random import Random


def rank(vectors):
    pivots = {}
    for vector in vectors:
        while vector:
            top = vector.bit_length() - 1
            if top not in pivots:
                pivots[top] = vector
                break
            vector ^= pivots[top]
    return len(pivots)


def symplectic(left, right, qubits):
    mask = (1 << qubits) - 1
    cross = ((left & mask) & (right >> qubits)) ^ ((left >> qubits) & (right & mask))
    return cross.bit_count() % 2


def gram_rank(axes, qubits):
    return rank([sum(symplectic(axis, other, qubits) << i for i, other in enumerate(axes)) for axis in axes])


def coefficient_table(parities, width):
    coefficients = {}
    for mask, negative, offset in parities:
        scale = (-1) ** negative
        if offset:
            coefficients[0] = (coefficients.get(0, 0) + scale) % 8
            scale = -scale
        indices = [i for i in range(width) if mask & (1 << i)]
        for size in range(1, min(3, len(indices)) + 1):
            for group in combinations(indices, size):
                monomial = sum(1 << i for i in group)
                coefficients[monomial] = (coefficients.get(monomial, 0) + scale * (-2) ** (size - 1)) % 8
    return coefficients


def random_isotropic(rng, qubits):
    maxsize = rng.randint(1, qubits)
    axes = [1 << i for i in range(maxsize)]
    for _ in range(4 * qubits):
        vector = rng.randrange(1, 1 << (2 * qubits))
        axes = [axis ^ vector if symplectic(axis, vector, qubits) else axis for axis in axes]
    return axes


rng = Random(773)
circuits = 0
for qubits in range(1, 8):
    for _ in range(240):
        layers = [random_isotropic(rng, qubits) for _ in range(rng.randint(1, 8))]
        axes = sum(layers, [])
        t = len(axes)
        v = rank(axes)
        r = gram_rank(axes, qubits) // 2
        sizes = sorted(map(len, layers), reverse=True)
        s = t - sum(sizes[:2])
        assert r <= v - sizes[0]
        assert 2 * r <= s + 2 * max(0, v - t / 2)
        extra = [rng.randrange(1, 1 << (2 * qubits)) for _ in range(rng.randrange(8))]
        assert gram_rank(axes + extra, qubits) <= 2 * r + 2 * len(extra)
        circuits += 1

phases = 0
for width in range(1, 8):
    for _ in range(100):
        parities = [(rng.randrange(1 << width), rng.randrange(2), rng.randrange(2)) for _ in range(rng.randrange(100))]
        coefficients = coefficient_table(parities, width)
        for mask, coefficient in coefficients.items():
            if mask:
                assert coefficient % (1 << (mask.bit_count() - 1)) == 0
        for y in range(1 << width):
            direct = sum((-1) ** neg * (((mask & y).bit_count() % 2) ^ offset) for mask, neg, offset in parities)
            encoded = sum(c for mask, c in coefficients.items() if y & mask == mask)
            assert (direct - encoded) % 8 == 0
            phases += 1

print(f'{circuits:,} symplectic layer/quotient bounds and {phases:,} modulo-eight cubic phase encodings checked')

from fractions import Fraction as Fr


def partitions(total, limit=None):
    if not total:
        yield ()
        return
    for k in range(min(total, limit or total), 0, -1):
        for tail in partitions(total - k, k):
            yield (k, *tail)


def penalty(k, r):
    return (k * k - max(k - r, 0) ** 2) / 2


profile_cases = 0
for t in range(1, 28):
    for sizes in partitions(t):
        max_rank = min(Fr(t, 4), Fr(t, 2) - sizes[0])
        if max_rank < 0:
            continue
        s = t - sum(sizes[:2])
        points = {0, max_rank, *(k for k in sizes if k < max_rank)}
        profile = Fr(3 * t * t, 8) - sum(Fr(k * k, 2) for k in sizes)
        two = (Fr(s * t, 2) + Fr(s * s, 4) if s * 2 <= t
               else Fr(3 * t * t, 8) - Fr((t - s) ** 2, 4))
        for rad in points:
            r = Fr(rad)
            assert 2 * r * t - 2 * r * r - sum(penalty(k, r) for k in sizes) <= min(profile, two)
            profile_cases += 1
print(f'{profile_cases:,} rational layer-profile envelope checks')
