"""Compare full exact prefix-profile frame factorizations, including every marker."""
from itertools import product
from math import cos, sin
import numpy as np

rng=np.random.default_rng(184901)
def physical_layer(columns,n,j,theta):
    suffix=n-j-1
    offset=1<<suffix
    for prefix in range(1<<j):
        i=prefix<<(suffix+1)
        a,b=columns[[i,i+offset]].copy()
        angle=theta[prefix]
        columns[i]=cos(angle)*a-sin(angle)*b
        columns[i+offset]=sin(angle)*a+cos(angle)*b

def compile_frame(n,layers):
    cols=np.eye(1<<n)
    for j,t in enumerate(layers):
        physical_layer(cols,n,j,t)
    return cols

cases=0
columns=0
for n in range(3,8):
    for q in range(1,n-1):
        for r in range(1,n-q):
            h=n-q-r
            for _ in range(2):
                top=[rng.uniform(-3,3,1<<j) for j in range(q)]
                bank=rng.uniform(-3,3,(1<<q,n-q))
                generic=top+[[bank[v>>(j-q),j-q] for v in range(1<<j)] for j in range(q,n)]
                goal=compile_frame(n,generic)
                got=np.eye(1<<n)
                inds=[a<<(n-q) for a in range(1<<q)]
                got[inds,:]=compile_frame(q,top)@got[inds,:]
                for a in range(1<<q):
                    inds=[(a<<(n-q))+(u<<r) for u in range(1<<h)]
                    got[inds,:]=compile_frame(h,[[bank[a,j]]*(1<<j) for j in range(h)])@got[inds,:]
                final=[[0.0]*(1<<j) for j in range(q)]+[[bank[v>>(j-q),h+j-q] for v in range(1<<j)] for j in range(q,q+r)]
                small=compile_frame(q+r,final)
                for u in range(1<<h):
                    inds=[(a<<(n-q))+(u<<r)+v for a in range(1<<q) for v in range(1<<r)]
                    got[inds,:]=small@got[inds,:]
                assert np.max(np.abs(goal-got))<2e-12
                cases+=1
                columns+=len(got)
print(f'{cases} complete prefix-profile frames and {columns} columns, including guarded top and noncontiguous terminal')
