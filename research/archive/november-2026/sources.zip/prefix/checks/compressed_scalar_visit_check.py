"""Finite checks for the one-visit compression estimates. Python 3 and NumPy."""
from itertools import product
from math import comb
from random import Random
import numpy as np

rng = Random(19271118)
np_rng = np.random.default_rng(82936)


def alpha(h):
    return sum(comb(h, j) * abs(h - 2 * j) for j in range(h + 1)) / (h * 2**h)


def row_majority(table, signs, buckets):
    return np.array([
        np.where((table[subset] * signs[subset, None]).sum(axis=0) < 0, -1, 1)
        for subset in buckets
    ])


def check_coding():
    cells = 0
    for m in range(1, 7):
        words = np.array(list(product([-1, 1], repeat=m)))
        for k in range(1, m + 1):
            rows = np.array_split(np.arange(m), k)
            for l in range(1, m + 1):
                cols = np.array_split(np.arange(m), l)
                table = np_rng.choice([-1, 1], size=(m, m))
                buck_row = np.repeat(np.arange(k), [len(b) for b in rows])
                buck_col = np.repeat(np.arange(l), [len(b) for b in cols])
                # Conditional on the first source, sum the true second-source
                # outcomes for one fixed row seed and then apply its proved
                # per-cell bias vector to every first-source outcome.
                rr = words[rng.randrange(len(words))]
                packed = row_majority(table, rr, rows)
                avg = np.zeros((k, m))
                for ss in words:
                    twice = row_majority(packed.T, ss, cols).T
                    avg += ss * twice[:, buck_col] * packed
                expected_col = np.array([alpha(len(cols[b])) for b in buck_col])
                assert np.allclose(avg / len(words), expected_col[None, :])
                avg = np.zeros((m, m))
                for rr in words:
                    packed = row_majority(table, rr, rows)
                    avg += rr[:, None] * packed[buck_row] * table * expected_col
                expected_row = np.array([alpha(len(rows[b])) for b in buck_row])
                assert np.allclose(avg / len(words), expected_row[:, None] * expected_col)
                cells += m**2
    return cells


def unitary(d):
    z = np_rng.normal(size=(d, d)) + 1j * np_rng.normal(size=(d, d))
    return np.linalg.qr(z)[0]


def partial_trace_first(state, a, b):
    return np.trace(state.reshape(a, b, a, b), axis1=0, axis2=2)


def norm1_hermitian(x):
    return np.abs(np.linalg.eigvalsh(x)).sum()


def check_quantum():
    tests = 0
    for m in (2, 4, 8, 16):
        h = np.array([[(-1)**((i & j).bit_count()) for j in range(m)] for i in range(m)])
        for k in (1, 2, 4):
            for b in (1, 2, 4):
                a = 2*k
                dim = a*b
                for c in range(min(2, dim.bit_length()-1) + 1):
                    rank = dim // 2**c
                    u = unitary(dim)[:, :rank]
                    prior = u @ u.conj().T / rank
                    rho = []
                    for _ in range(m):
                        # Add an independent row-message output register carrying
                        # one of m arbitrary local preparations, then exchange
                        # its information with Alice's half of the shared work.
                        new = unitary(k)[:, :1]
                        input_state = np.kron(new @ new.conj().T, prior)
                        loc = np.kron(unitary(k*a), np.eye(b))
                        joint = loc @ input_state @ loc.conj().T
                        rho.append(partial_trace_first(joint, a, k*b))
                    rho = np.array(rho)
                    for item in rho:
                        assert np.max(np.linalg.eigvalsh(item)) <= 2**c/b + 1e-10
                    sums = np.einsum('ij,ikl->jkl', h, rho)
                    corr = sum(norm1_hermitian(x) for x in sums) / m**2
                    assert corr <= np.sqrt(2**c*k/m) + 1e-10
                    assert corr <= k/np.sqrt(m) + 1e-10
                    tests += 1
    return tests


if __name__ == '__main__':
    print(f'{check_coding():,} double-majority pointwise correlations verified')
    print(f'{check_quantum()} arbitrary local quantum encoder and shared-preparation Walsh bounds verified')
