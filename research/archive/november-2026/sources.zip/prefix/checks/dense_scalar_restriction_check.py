"""Finite checks for affine embeddings, concentration decoding, and blind inputs."""
from itertools import combinations, product
from math import exp, log, sqrt
from random import Random

rng = Random(13031)


def rank(vectors):
    basis = {}
    for row in vectors:
        while row:
            pivot = row.bit_length() - 1
            if pivot not in basis:
                basis[pivot] = row
                break
            row ^= basis[pivot]
    return len(basis)


def shift_table(table, offset, length):
    return sum(((table >> (x ^ offset)) & 1) << x for x in range(length))


def check_interpolation():
    cases = 0
    for p in (2, 3, 4):
        for k in range(1, min(6, 1 << p) + 1):
            d = k.bit_length() - 1
            monomials = [s for s in range(1 << p) if s.bit_count() <= d]
            all_rows = [sum((x & m == m) << j for j, m in enumerate(monomials)) for x in range(1 << p)]
            for selection in combinations(range(1 << p), k):
                assert rank(all_rows[x] for x in selection) == k
                cases += 1
    return cases


def check_majority():
    cases = 0
    for r in (1, 2, 3):
        tags = 2**r+1
        for true_bit in (0, 1):
            clean = [t*true_bit for j in range(tags) for t in (0,1)]
            for nbad in range(2**(r-1)+1):
                for bad in combinations(range(2*tags), nbad):
                    v = clean[:]
                    for cell in bad:
                        v[cell] ^= 1
                    votes = [v[2*j]^v[2*j+1] for j in range(tags)]
                    assert (2*sum(votes)>tags) == true_bit
                    cases += 1
    return cases


def check_concentration():
    # Two logical address bits and one probe bit: logical table has 4 entries.
    size = 8
    all_tables = range(1 << size)
    easy_sets = [{g for g in all_tables if g & 0b1011001 == 0},
                 {g for g in all_tables if g.bit_count() % 3 == 2},
                 set(rng.sample(list(all_tables), 49))]
    translations = [[shift_table(g, s, size) for g in all_tables] for s in range(size)]
    cases = 0
    for easy in easy_sets:
        # Fix ties, and measure total errors of a nearest-table decoder.
        nearest = [min(easy, key=lambda a:((a^g).bit_count(),a)) for g in all_tables]
        distances = [(g^nearest[g]).bit_count() for g in all_tables]
        mean_error = sum(distances)/(len(all_tables)*size)
        assert mean_error <= sqrt(log(len(all_tables)/len(easy))/(2*size)) + 1e-12
        for f in range(1 << (size//2)):
            F = sum(((f>>x)&1) << (2*x+1) for x in range(size//2))
            fails = [0]*(size//2)
            for s in range(size):
                perm = translations[s]
                for u in all_tables:
                    # One common translation already suffices for the two tables.
                    pred = perm[nearest[perm[u]] ^ nearest[perm[u^F]]]
                    for x in range(size//2):
                        fails[x] += (((pred>>(2*x))^(pred>>(2*x+1))^(f>>x))&1)
            assert all(count <= 4*mean_error*len(all_tables)*size+1e-12 for count in fails)
            cases += size//2
    return cases


def check_blind():
    count = 0
    for p in (2,3):
        q=1<<p
        for k in range(1, min(4,q)+1):
            for shifts in combinations(range(q),k):
                masks = [sum(1<<(x^s) for s in shifts) for x in range(q)]
                used = 0
                disjoint = []
                for m in masks:
                    if not used & m:
                        disjoint.append(m)
                        used |= m
                assert len(disjoint)*k*k >= q
                total=0
                for E in range(1<<q):
                    b=sum(E&m==m for m in masks)
                    total+=2**(-b)
                # For uniformly random independent target, exp(-..) bound.
                assert total/(1<<q) <= exp(-q*(0.5**k)/(2*k*k))+1e-12
                count+=1
    return count


if __name__ == '__main__':
    print(f'{check_interpolation()} low-degree interpolation restrictions')
    print(f'{check_majority()} exact tagged majority cases')
    print(f'{check_concentration()} exhaustive concentration marginals')
    print(f'{check_blind()} blind-set packing and probability bounds')
