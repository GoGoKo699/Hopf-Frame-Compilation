"""Finite profiles and the cancellation of a disabled dirty rotation cohort."""
from itertools import product
import math
import numpy as np

rng = np.random.default_rng(7412)
Z = np.diag([1.,-1.])
I = np.eye(2)

def rot(a):
    return np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]])

def frame(n, angles):
    value = np.eye(1<<n)
    for j in range(n):
        tail = n - j - 1
        for prefix in range(1 << j):
            block=[(prefix << (tail+1)),(prefix << (tail+1))+(1<<tail)]
            value[block,:] = rot(angles(j,prefix)) @ value[block,:]
    return value

def direct_top_then_rows(n,q):
    p=n-q
    angles={(j,u): rng.uniform(-1.7,1.7) for j in range(q) for u in range(1<<j)}
    profile=rng.uniform(0,math.pi/2,(1<<q,p))
    def prescribed(j,u):
        if j<q: return angles[j,u]
        return profile[u>>(j-q),j-q]
    literal=frame(n,prescribed)
    top=frame(q,lambda j,u:angles[j,u])
    topstage=np.eye(1<<n)
    idx=[u<<p for u in range(1<<q)]
    topstage[np.ix_(idx,idx)]=top
    out=np.zeros((1<<n,1<<n))
    for u in range(1<<q):
        slab=slice(u<<p,(u+1)<<p)
        out[slab,:]=frame(p,lambda j,z:profile[u,j]) @ topstage[slab,:]
    assert np.max(np.abs(literal-out)) < 1e-12
    # Leave r lower tail levels: the remaining operation is an exact
    # (q+r)-frame with zero angles for the first q levels, with intervening
    # physical sites untouched.
    for r in range(1,p+1):
        h=p-r
        tailframe=frame(q+r,lambda j,z: 0 if j<q else profile[z>>(j-q),h+j-q])
        short=frame(n,lambda j,z: 0 if j<n-r else prescribed(j,z))
        embed=np.zeros_like(short)
        for middle in range(1<<h):
            locations=[((tag<<h)|middle)<<r|lower for tag in range(1<<q) for lower in range(1<<r)]
            embed[np.ix_(locations,locations)]=tailframe
        assert np.max(np.abs(embed-short)) < 1e-12
    return p

def inactive_cohort():
    # One logical x, one private qubit per candidate in each of two cohorts.
    # Fixed addresses prepare the conditional swap for the chosen candidate;
    # arbitrary full Hermitian reflections on the disabled cohort may leak.
    k=3
    total=2**6
    for p in (0,1):
        A=rng.normal(size=(2**k,2**k))+1j*rng.normal(size=(2**k,2**k))
        v=np.linalg.qr(A)[0]
        t=v @ np.diag([-1]+[1]*(2**k-1)) @ v.conj().T
        B=rng.normal(size=(2**k,2**k))+1j*rng.normal(size=(2**k,2**k))
        g=np.linalg.qr(B)[0]
        b=g @ np.diag([1,-1]+[1]*(2**k-2)) @ g.conj().T
        left=np.kron(t,b) if p==0 else np.kron(b,t)
        masked=np.kron(t,np.eye(2**k)) if p==0 else np.kron(np.eye(2**k),t)
        left=np.kron(I,left)
        masked=np.kron(I,masked)
        perm=np.zeros((2*total,2*total))
        for a in range(2*total):
            pos=3 if p==0 else 0
            # Swap x with the chosen cohort's q only when its other two bits are zero.
            good=((a>>(pos+1))&3)==0
            dest=a^((1<<6)|(1<<pos)) if good and (((a>>6)^(a>>pos))&1) else a
            perm[dest,a]=1
        assert np.linalg.norm(left@perm@left@perm-masked@perm@masked@perm)<1e-11
    return 2

if __name__=='__main__':
    cases=0
    for n in range(2,8):
        for q in range(1,n):
            for repeat in range(3):
                cases+=direct_top_then_rows(n,q)
    print(f"{cases} guarded-prefix / controlled-tail / embedded-terminal constructions checked; {inactive_cohort()} disabled-cohort leakage cancellations verified")
