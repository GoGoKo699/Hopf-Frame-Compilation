from itertools import product
from math import pi,cos,sin,sqrt
from random import Random
import numpy as np

rng=Random(190117)
def marker(v,n):
    return (int(v+'1',2)<<(n-len(v)-1))
def pos_haar(n):
    M=np.eye(1<<n)
    for j in range(n):
        for u in range(1<<j):
            lo=u<<(n-j)
            hi=lo+(1<<(n-j-1))
            a,b=M[lo].copy(),M[hi].copy()
            M[lo]=(a-b)/sqrt(2)
            M[hi]=(a+b)/sqrt(2)
    return M

def antichains(h):
    if h==0:return [()]
    sub=antichains(h-1)
    return [('',)]+[tuple('0'+v for v in a)+tuple('1'+v for v in b) for a,b in product(sub,repeat=2)]

def father(v,n,D=None):
    D=D or (1<<n)
    a=np.zeros(D);a[0]=1
    for j,ch in enumerate(v):
        a[marker(v[:j],n)]+=1 if ch=='1' else -1
        a/=sqrt(2)
    return a

def rotate(a,b,t):
    I=np.eye(len(a))
    return I+(cos(t)-1)*(np.outer(a,a)+np.outer(b,b))+sin(t)*(np.outer(b,a)-np.outer(a,b))

def mothers(n):
    return np.eye(1<<n)

def tag_circuit(n,angles):
    size=1<<n
    X=np.eye(size)
    D=np.eye(size)
    H=np.array([[1,1],[1,-1]])/sqrt(2)
    for v,t in angles.items():
        remain=n-len(v)-1;start=(int(v,2) if v else 0)<<(remain+1)
        tail=np.array([[1.]])
        for j in range(remain):tail=np.kron(tail,H)
        for b in range(2):
            i=start+(b<<remain)
            X[i:i+len(tail),i:i+len(tail)]=tail
        j=start+(1<<remain)
        D[start,start]=D[j,j]=cos(t)
        D[start,j]=-sin(t);D[j,start]=sin(t)
    W=pos_haar(n)
    return W.T@X.T@D@X@W

total=0
for n in range(1,5):
    e=mothers(n)
    for vs in antichains(n):
        angles={v:rng.random()*2*pi for v in vs}
        M=np.eye(1<<n)
        for v,t in angles.items():
            M=rotate(father(v,n),e[marker(v,n)],t)@M
        np.testing.assert_allclose(M,tag_circuit(n,angles),atol=5e-14,rtol=0)
        total+=1
print(f'{total} complete antichain angle words matched their selected-suffix circuit')
def randommarks(n):
    pool=[''];out=[]
    while pool:
        v=pool.pop()
        if n-len(v)==1 or rng.random()<0.23:
            if rng.random()<0.6:out.append(v)
        else:pool.extend([v+'0',v+'1'])
    return out

total=bridges=0
for n in range(4,8):
  for l in [1,2]:
   for trial in range(6):
    nodes=randommarks(n)
    angles={v:rng.random()*pi for v in nodes}
    patches={}
    for v in nodes:
        g=len(v)//l;c=max(0,(g-1)*l);p=v[:c]
        patches.setdefault((g,p),[]).append(v)
    D=(1<<n)+len(patches);eye=np.eye(D)
    for color in range(2):
        whole_direct=np.eye(D);whole_virtual=np.eye(D);full_ideal=np.eye(D)
        color_used=set()
        error_budget=0
        for pos,((g,p),marks) in enumerate(patches.items()):
            if g%2!=color:continue
            root=0 if not p else (1<<n)+pos
            local={0:root};m=2*l
            local_angles={v[len(p):]:angles[v] for v in marks}
            for v in marks:
                loc=eye[root].copy()
                for j in range(len(p),len(v)):
                    gi=marker(v[:j],n)
                    local[marker(v[len(p):j],m)]=gi
                    loc=(loc+eye[gi]*(1 if v[j]=='1' else -1))/sqrt(2)
                b=marker(v,n);local[marker(v[len(p):],m)]=b
                actual=father(v,n,D)
                np.testing.assert_allclose(loc-actual,(eye[root]-father(p,n,D))/sqrt(2)**(len(v)-len(p)),atol=2e-14,rtol=0)
                whole_direct=rotate(loc,eye[b],angles[v])@whole_direct
                full_ideal=rotate(actual,eye[b],angles[v])@full_ideal
                error_budget+=6*np.linalg.norm(actual-loc)
                bridges+=bool(p)
            assert not(color_used & set(local.values()))
            color_used.update(local.values())
            V=tag_circuit(m,local_angles)
            idx=list(local);vals=list(local.values())
            unmarked=[v for v in range(1<<m) if v not in local]
            if unmarked:
                np.testing.assert_allclose(V[unmarked],np.eye(1<<m)[unmarked],atol=2e-14,rtol=0)
            whole_virtual[np.ix_(vals,vals)]=V[np.ix_(idx,idx)]
        np.testing.assert_allclose(whole_direct,whole_virtual,atol=6e-14,rtol=0)
        assert np.linalg.norm(whole_virtual-full_ideal,2)<=error_budget+1e-12
        total+=1
print(f'{total} whole patch passes, including {bridges} non-root cut replacements, matched on all columns')
terms=0
for n in range(1,8):
    for j in range(n):
        for node in range(1<<j):
            v=format(node,'0%db'%j) if j else ''
            for bit in '01':
                for idx in range(1<<n):
                    x=format(idx,'0%db'%n)
                    last=x.rfind('1')+1
                    direct=(last>j+1 and x.startswith(v+bit)) or (last==j+1 and x.startswith(v))
                    cubes=x.startswith(v+bit)^(x==v+bit+'0'*(n-j-1))^(x==v+'1'+'0'*(n-j-1))
                    assert direct==cubes
                    terms+=1
print(f'{terms} edge/marker sign-gauge cube identities passed')
