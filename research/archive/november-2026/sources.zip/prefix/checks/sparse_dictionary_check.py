from itertools import combinations
from math import comb, cos, pi, sin
from random import Random
import numpy as np

rng = Random(190116)
def image(rows, x):
    return sum((((z & x).bit_count() & 1) << i) for i, z in enumerate(rows))

def inv(rows):
    n = len(rows)
    a = [r | (1 << (n + i)) for i, r in enumerate(rows)]
    for i in range(n):
        j = next(j for j in range(i,n) if a[j] >> i & 1)
        a[i],a[j]=a[j],a[i]
        for j in range(n):
            if j!=i and (a[j] >> i & 1):
                a[j]^=a[i]
    return [v>>n for v in a]

def matrix(n):
    a=[1<<i for i in range(n)]
    for _ in range(8*n):
        i,j=rng.randrange(n),rng.randrange(n)
        if i!=j:
            a[i]^=a[j]
    return a

def mul(x,y):
    s=0
    while y:
        if y & 1: s ^= x
        x <<= 1
        if x & 256: x ^= 0x11b
        y >>= 1
    return s

def poly(coeff,x):
    v=0
    for c in reversed(coeff):
        v=mul(v,x)^c
    return v

pencil=rows_count=0
for p in range(4,10):
    for case in range(18):
        k=(p-1)//2
        w=p-k
        s=rng.randrange(2,2**k+1)
        chosen=rng.sample(range(1<<p),s)
        payload={x:rng.randrange(1,16) for x in chosen}
        coeff=[rng.randrange(256) for _ in range(2+case%4)]
        def split(x):
            tail=x>>k
            return (x ^ poly(coeff,tail)) & ((1<<k)-1), tail
        buckets=[[] for _ in range(1<<k)]
        for x in chosen:
            a,t=split(x)
            buckets[a].append(t)
        maxs=max(map(len,buckets))
        j=min(w, max(0, (maxs*(maxs-1)//2).bit_length()))
        transforms=[]
        for bucket in buckets:
            while True:
                A=matrix(w)
                if len({image(A,t)%2**j for t in bucket})==len(bucket):
                    transforms.append((A,inv(A)))
                    break
        def code(x):
            a,t=split(x)
            A,_=transforms[a]
            b=image(A,t)
            return a|((b%2**j)<<k),b>>j
        table={code(x)[0]:(code(x)[1],payload[x]) for x in chosen}
        assert len(table)==s
        for x in range(1<<p):
            a,t=split(x)
            A,Ai=transforms[a]
            d0=rng.randrange(1<<w)
            # SWAP then three shear operations
            v,d=d0,t
            v^=image(A,d)
            d^=image(Ai,v)
            v^=image(A,d)
            assert (v,d)==(image(A,t),image(Ai,d0))
            z,tail=code(x)
            canonical,f=table.get(z,(0,0))
            E=int(tail==canonical)
            u0,u1=rng.randrange(2),rng.randrange(16)
            output=rng.randrange(16)
            u,v=u0,u1
            y=output^(v if u else 0)
            u^=E
            y^=v if u else 0
            v^=f
            y^=v if u else 0
            u^=E
            y^=v if u else 0
            v^=f
            assert (u,v,y)==(u0,u1,output^payload.get(x,0))
            rows_count+=1
        pencil+=1
print(f'{pencil} conditional perfect dictionaries and {rows_count} complete payload/dirty cases passed')

def frame(n, altered, start=None):
    mat=np.eye(2**n) if start is None else start.copy()
    for j in range(1,n+1):
        for a in range(1<<(j-1)):
            t=altered.get((j,a),pi/4)
            lo=a<<(n-j+1)
            hi=lo+(1<<(n-j))
            u,v=mat[lo].copy(),mat[hi].copy()
            mat[lo]=cos(t)*u-sin(t)*v
            mat[hi]=sin(t)*u+cos(t)*v
    return mat

count=0
for n in range(1,8):
    baseline=frame(n,{})
    for trial in range(12):
        changes={}
        for _ in range(1+trial%5):
            j=rng.randrange(1,n+1)
            a=rng.randrange(1<<(j-1))
            changes[j,a]=rng.random()*2*pi
        whole=baseline.copy()
        for j in sorted({j for j,_ in changes},reverse=True):
            delta=np.eye(1<<n)
            for (level,a),theta in changes.items():
                if level!=j:continue
                i=a<<(n-j+1)
                l=i+(1<<(n-j))
                t=theta-pi/4
                delta[i,i]=delta[l,l]=cos(t)
                delta[i,l]=-sin(t)
                delta[l,i]=sin(t)
            prefix=np.kron(frame(j,{}),np.eye(1<<(n-j)))
            whole=whole@prefix.T@delta@prefix
        np.testing.assert_allclose(whole, frame(n,changes), atol=2e-14, rtol=0)
        count+=1
print(f'{count} complete arbitrary-location perturbation frame matrices matched')
# Exhaustive t-fold collision moments for quadratic Feistel polynomials in GF(4).
def mul4(x,y):
    v=0
    while y:
        if y&1: v^=x
        x<<=1
        if x&4:x^=7
        y>>=1
    return v
from itertools import product
keys=[(a,b) for a in range(4) for b in range(4)]
for selected in combinations(keys,3):
    hits=0
    for c0,c1,c2 in product(range(4),repeat=3):
        values={a^c0^mul4(b,c1)^mul4(mul4(b,b),c2) for a,b in selected}
        hits+=len(values)==1
    assert hits==(4 if len({b for a,b in selected})==3 else 0)
print(f'{comb(16,3)} exact independent-hash collision moments matched')
