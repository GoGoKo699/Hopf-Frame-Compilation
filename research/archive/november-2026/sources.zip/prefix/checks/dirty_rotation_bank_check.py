"""Finite exact and leakage checks of the dirty rotation-bank identities."""
from itertools import product
import math
import numpy as np

rng = np.random.default_rng(74823)
I2 = np.eye(2)
Z = np.diag([1., -1.])

def ry(a):
    return np.array([[math.cos(a), -math.sin(a)], [math.sin(a), math.cos(a)]])

def tensor(mats):
    result = np.ones((1, 1))
    for mat in mats:
        result = np.kron(result, mat)
    return result

def normalized_hs(mat):
    return np.linalg.norm(mat, 'fro') / math.sqrt(mat.shape[0])

def swapped_index(x, h, k):
    def position(j):
        return (h - 1 - j) * (k + 1)
    total = h * (k + 1)
    for j in range(h):
        pos = position(j)
        addr = (x >> (pos + 1)) & ((1 << k) - 1)
        if addr == 0:
            if ((x >> total) ^ (x >> pos)) & 1:
                return x ^ (1 << total) ^ (1 << pos), True
            return x, True
    return x, False

def bank(k, h, theta, epsilon):
    d = 2**(k+1)
    target = ry(theta)
    small_u = ry(-theta/4)
    v0 = np.eye(d)
    v0[:2, :2] = small_u
    if d>2:
        off, _ = np.linalg.qr(rng.normal(size=(d-2, d-2)) + 1j*rng.normal(size=(d-2, d-2)))
        v0 = v0.astype(complex)
        v0[2:, 2:] = off
    gen = rng.normal(size=(d,d)) + 1j*rng.normal(size=(d,d))
    gen += gen.conj().T
    eigs, vec = np.linalg.eigh(gen)
    noise = vec @ np.diag(np.exp(1j*epsilon*eigs/np.max(np.abs(eigs)))) @ vec.conj().T
    v = noise @ v0
    reflector = np.eye(d)
    reflector[1,1] = -1
    t0 = v0.conj().T @ reflector @ v0
    t = v.conj().T @ reflector @ v
    all0 = tensor([I2] + [t0]*h)
    all_t = tensor([I2] + [t]*h)
    size = all_t.shape[0]
    swap = np.zeros((size,size))
    branch = []
    for j in range(size):
        s, good = swapped_index(j,h,k)
        swap[s,j] = 1
        branch.append(good)
    z = np.kron(Z,np.eye(size//2))
    goal = np.kron(target,np.eye(size//2))
    def wrap(tall):
        e = tall @ swap @ tall @ swap
        return e @ z @ e.conj().T @ z
    ideal, actual = wrap(all0), wrap(all_t)
    expect = goal.copy()
    expect[:,np.logical_not(branch)] = np.eye(size)[:, np.logical_not(branch)]
    assert np.linalg.norm(ideal-expect) < 2e-11
    delta = normalized_hs(actual-goal)
    assert normalized_hs(all0-all_t) <= 4*epsilon*math.sqrt(h/2**k)+1e-13
    assert delta <= 16*epsilon*math.sqrt(h/2**k)+2*math.exp(-h/2**k/2)+1e-12
    err = actual-goal
    square = (err.conj().T @ err).reshape(2,size//2,2,size//2)
    partial = np.trace(square, axis1=1, axis2=3)/(size//2)
    assert np.linalg.eigvalsh(partial)[-1] <= 2*delta**2+1e-12
    if k == h == 1:
        xx = np.array([[0.,1.],[1.,0.]])
        yy = np.array([[0.,-1j],[1j,0.]])
        masks=[tensor([I2,u,v2]) for u,v2 in product([I2,xx,yy,Z],repeat=2)]
        total = sum(m.conj().T @ (err.conj().T @ err) @ m for m in masks)/len(masks)
        assert np.allclose(total,np.kron(partial,np.eye(size//2)))
        # A coherent uniform catalyst over each full twirling list has exactly this Gram.
        isom = np.vstack([m.conj().T @ err @ m for m in masks])/math.sqrt(len(masks))
        assert np.allclose(isom.conj().T @ isom,total)
    return len(branch)

count = 0
columns = 0
for k,h in [(1,1),(1,2),(1,3),(2,1),(2,2),(3,1)]:
    for theta in [0.11,0.71,1.3,-0.76]:
        for noise in [0.,1e-3,0.07]:
            columns += bank(k,h,theta,noise)
            count += 1
print(f"{count} full dirty rotation words and {columns} selected-slot columns matched; sparse leakage, partial trace and coherent Pauli twirls passed")
