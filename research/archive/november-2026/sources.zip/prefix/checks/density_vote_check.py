"""Finite checks for the two-mask, controlled-phase-free majority construction."""
from itertools import product
from math import prod
from random import Random
from fractions import Fraction

def phase_word(pair):
    a0,a1,b0,b1=pair
    return a0^b0,(a0^b0)^(a1^b1)

count=0
for entries in product(range(16),repeat=3):
    pairs=[tuple((entry>>j)&1 for j in range(4)) for entry in entries]
    votes=[phase_word(pair) for pair in pairs]
    sign_before=votes[0][0]^votes[1][0]^votes[2][0]
    majority=int(sum(bit for phase,bit in votes)>=2)
    state=[bit for phase,bit in votes]
    phases=sign_before^majority
    for j in reversed(range(3)):
        phase,bit=phase_word(pairs[j])
        state[j]^=bit
        phases^=phase
    assert not any(state) and phases==majority
    count+=1

def rank(rows):
    basis={}
    for value in rows:
        while value:
            top=value.bit_length()-1
            if top not in basis:
                basis[top]=value
                break
            value^=basis[top]
    return len(basis)
matrices=0
for n in (1,2,3,4):
    words=1<<(n*n)
    mask=(1<<n)-1
    invertibles=sum(rank([(word>>(n*i))&mask for i in range(n)])==n for word in range(words))
    assert Fraction(invertibles,words)==prod(1-Fraction(1,2**i) for i in range(1,n+1))
    matrices+=words
print(f'{count} literal three-vote phase and work returns; {matrices} matrices in invertible-density checks')
