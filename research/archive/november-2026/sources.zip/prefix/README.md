# Prefix profiles and scalar density

Read Hopf_Prefix_Profiles_and_Scalar_Density.md first. The proof appendices are organized as follows.

1. dirty_rotation_bank.md proves the unconditional depth theorem for arbitrary level angles. prefix_profiles.md proves the independently chosen profile extension. Both use the cited one-rotation synthesis and the complete three-basis Boolean compiler. The prior Haar and voting proofs are in background.
2. average_scalar_compiler.md proves the density and distortion criteria, value-derivative majority, arbitrary-precision scope and random invertible crossing corollary. The preceding scalar-to-general frame implication is in background/scalar_frame_transfer.md. dense_scalar_restriction.md gives an independent, weaker additive-combinatorics proof and explicit invertible-matrix reductions. dense_affine_readout_limit.md records a limit on constant entropy deficit for affine local queries.
3. antichain_frame.md proves the independent sparse angular perturbation result. sparse_dictionary_frame.md gives the complete dictionary lookup used in related constructions, including the scope of an optional stronger zero test.
4. two_widest_layers.md proves the unrestricted count distribution lower bound. Its stabilizer and counting inputs are in background. checksum_phase_filter.md analyzes accuracy amplification with moving addresses. compressed_scalar_visit.md analyzes reducing the information sent from two address halves in one visit. Each conclusion has its own explicit model.

From the extracted directory run python run_checks.py with Python 3 and NumPy. Each standalone script uses a deterministic seed where sampling is involved. Checks for the same conclusion sometimes use different direct formulations. These finite scripts supplement the mathematical proofs.

The repository anchor is ae613bf8e8a38f6d0407c25910b83d69f01a2733. From that checkout the companion regression command is

    python -m unittest -q tests.test_boolean_query_frame_reduction tests.test_approximate_query_frame_transfer tests.test_joint_native_words tests.test_homogeneous_depth tests.test_causal_compact_coin_depth tests.test_recursive_field_shear_decoder

Primary external synthesis inputs: https://arxiv.org/html/2609.34659v1 (Theorem 8) and https://arxiv.org/html/2512.24982v1 (Theorem 6). The report's conclusions about complete Hopf frames and truth-table density are developed in the appendices.
