from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
environment = dict(os.environ, OPENBLAS_NUM_THREADS='1')
for path in sorted((root / 'checks').glob('*.py')):
    print(path.name, flush=True)
    subprocess.run([sys.executable, str(path)], cwd=root, env=environment, check=True)
