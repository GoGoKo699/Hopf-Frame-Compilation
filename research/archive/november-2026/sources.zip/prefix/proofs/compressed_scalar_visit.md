# How far a table-dependent row and column can be compressed in one visit

Split a prescribed scalar sign into a square table $S_{ij}$ with $m=2^a$ rows and columns. The comparison below concerns one central use of independently encoded halves. The native circuit for the Walsh example itself consists only of two-qubit CZs. Consequently none of these lower bounds on a restricted visit are lower bounds on unrestricted native T-depth.

## Arbitrary table-dependent classical encoders and public seeds

Fix row and column alphabet sizes $1\le K,L\le m$. The public random seed may specify *arbitrary* table-dependent row and column encoder maps, one sign gauge per row and column, and one unrestricted $K\times L$ sign table. On a fixed seed the output is $r_i c_j D_{b(i),e(j)}$. Define $\delta_*(m,K,L)$ as the minimum over prescribed sign tables of the best possible worst-entry sign bias, with the expectation over the public seed. Then up to universal constant factors
$$
\delta_* =
\Theta\!\left(\min\!\left\{\sqrt{\frac{\min(K,L)}m},
 \sqrt{\frac{1+\log_2(KL)}m+\frac{KL}{m^2}}\right\}\right).
$$
In particular constant error below one half in output probability requires both alphabets linear in $m$, even with full table preprocessing, unbounded shared public randomness and local sign gauges.

**Upper bounds.** Every prediction matrix has real rank at most $\min(K,L)$ and Frobenius norm $m$. For the Walsh sign $H_{ij}=(-1)^{i\cdot j}$, the operator norm is $\sqrt m$; nuclear-norm duality bounds the average signed correlation by $\sqrt{\min(K,L)/m}$ on every seed. For the second bound there are at most $2^{KL+2m+m\log_2(KL)}$ fixed predictions. Against a uniform random prescribed table each has probability at most $\exp(-m^2 t^2/2)$ of uniform-input signed correlation at least $t$, by the Rademacher exponential moment bound. Union over all choices yields the second upper bound for at least one table (and with exponentially high probability when the threshold is increased by an absolute factor). A pointwise-bias promise implies its uniform mean on averaging seeds. The two hard target tables may differ; minimax permits this.

More precisely, a worst-entry error promise $e<1/2$ implies
$$
 KL+m\log_2(KL)+2m\ \ge\ (1-H_2(e))m^2.
$$
For every table a deterministic prediction then has uniform Hamming error at most $e$. Covering all $2^{m^2}$ binary strings by Hamming balls of this radius yields the inequality. At error tending to zero it forces $KL\ge (1-o(1))m^2$.

**Lower constructions.** Balanced row buckets have sizes at most $s=\lceil m/K\rceil$. Choose independent fair row signs $r_i$, and store in bucket b the signed majority $U_{bj}=\mathrm{sign}(\sum_{i\in b}r_i S_{ij})$ of each column. On ties use any fixed sign or an independent fair one. For every input pair in a size-h bucket the expectation of $S_{ij}r_iU_{bj}$ is $\alpha_h=\mathbb E|\sum_{k=1}^h\varepsilon_k|/h\ge c/\sqrt h$ by exchangeability and the independent Rademacher signs. For example $\mathbb E Z^2=h,\mathbb E Z^4\le3h^2$, and Paley–Zygmund on $Z^2$ suffices. Now compress the columns of U by a separate independent set of analogous signed-majority choices into L balanced buckets. Conditional on the first choices, this changes each predicted entry by a factor of $\alpha_{h'}$ in expectation, with column-bucket size $h'\le\lceil m/L\rceil$. This gives bias at least $c'\sqrt{KL}/m$ *on every cell of every prescribed table*. The procedure stores only the final K-by-L table on each seed.

Alternatively compress rows to $k=\min(K,1+\lfloor\log_2 L\rfloor)$ buckets. Each column can send its full k-bit majority-sign vector up to a common sign, using $2^{k-1}\le L$ labels and the allowed column sign gauge. This gives bias $c\sqrt{k/m}$. Swap rows and columns for the other orientation. If $K\le L$, then $\log_2(KL)\le2\log_2 L$. When $K\le1+\lfloor\log_2 L\rfloor$ the one-sided construction reaches the square-root rank upper within constants. In the complementary case the larger of the area construction and the row-bucket construction reaches the second upper bound within constants. Symmetry settles $L<K$.

## Quantum fingerprints, coherent return and shared dirty work

Allow arbitrary local quantum encodings into dimensions K and L, arbitrary fixed ancillas at the central receiver, and an arbitrary joint contraction measured for real sign bias; shared classical randomness and table-dependent designs are allowed. With independent input states before encoding, Walsh's worst-cell bias is at most $\sqrt{\min(K,L)/m}$. Indeed freeze the selected column and absorb its encoding and the central operation into a Hermitian contraction $A_j$ on the row message. Let $\rho_i$ denote its density matrix. Put $X_j=\sum_i H_{ij}\rho_i$. Then
$$
 \sum_{ij} H_{ij}\operatorname{Tr}(A_j\rho_i)
 \le \sum_j\|X_j\|_1
 \le \sqrt{K m}\left(\sum_j\|X_j\|_F^2\right)^{1/2}
 \le m\sqrt{Km}.
$$
The Walsh square sum equals $m\sum_i\operatorname{Tr}(\rho_i^2)\le m^2$. Exchange the roles of the halves. Extra local sign gauges can be absorbed into the signed matrices and effects, without changing the squared norms.

In a coherent phase visit, the separately controlled encoders prepare the messages, one central unitary acts, and the actual encoders' adjoints complete the circuit. Full returned error $\epsilon$ gives bias at least $1-\epsilon^2/2$, by taking the real expectation of the central unitary on the encoded states and expanding the squared vector distance to the desired sign. This remains true with mixed inputs by purification. For product fingerprints it follows that
$$
 K,L\ \ge\ (1-\epsilon^2/2)^2 m \quad(\epsilon<\sqrt2).
$$
If $\epsilon<\sqrt{2-\sqrt2}$, no qubit can be omitted from either address half in such a one-visit interface. Here the compressed dimensions count *everything sent from the respective side* to the central operation. A receiver already able to read the original labels has an additional information path.

**Shared dirty preprocessing.** Even if a data-independent unitary acts on the entire shared dirty work and $c$ supplied clean qubits before the labels are encoded, the bound is
$$
 (1-\epsilon^2/2)^2m\ \le\ 2^c K,\quad
 (1-\epsilon^2/2)^2m\ \le\ 2^c L.
$$
Local independent pure ancillas and private registers holding each classical label may be used inside the local channels. Choose the actual initial dirty state maximally mixed, as allowed by complete correctness. After data-independent preparation the joint workspace state obeys $\eta_{AB}\le 2^c I_{AB}/(d_A d_B)$. Put all work on the receiver side of the row cut, including the column encoder's share, in B. Apply the row's local channel depending on i, discard its unsent part, and call the sent K-dimensional register C. Complete positivity gives
$$
 \rho_i^{CB}\ \le\ 2^c\Phi_i(I_A/d_A)\otimes I_B/d_B
 \ \le\ 2^c K\tau,\qquad
 \tau=I_C/K\otimes I_B/d_B .
$$
Bob's arbitrary j-dependent operation on C and B is included in a Hermitian contraction. More generally if $\rho_i\le R\tau$ for common trace-one $\tau$, put $Z_i=\tau^{-1/4}\rho_i\tau^{-1/4}$ on its support. Then $0\le Z_i\le R\tau^{1/2}$, so $\operatorname{Tr}(Z_i^2)\le R\operatorname{Tr}(Z_i\tau^{1/2})=R$. By trace-ideal Hölder, $\|X_j\|_1\le\|\sum_i H_{ij}Z_i\|_F$, since $\|\tau^{1/4}\|_4=1$. Walsh orthogonality now gives average bias $\le\sqrt{R/m}$. Reflecting the cut gives the column bound. A fixed number of clean shared qubits can save only a fixed number of address qubits per side.

For comparison, with arbitrary initially supplied entanglement Bob's marginal $\rho_B$ is common before he receives C. Positivity of block matrices gives $\rho_i^{CB}\le K I_C\otimes\rho_B$: by phase averaging over K basis phases, pinching onto the C-diagonal blocks dominates $\rho_i/K$, and every diagonal block is bounded by $\rho_B$. With $\tau=I_C/K\otimes\rho_B$ the same argument gives $K\ge(1-\epsilon^2/2)\sqrt m$, and likewise for L. For even a this width is achievable exactly with supplied Bell pairs to the central receiver: each side dense-codes its entire address into $a/2$ sent qubits, the receiver decodes, applies the complete table sign and undoes the decode, and the senders undo their encoding. The received Bell halves remain part of the physical table operation. This example does not supply a clean-free native scalar compiler.

## Prior affine layouts, sign corrections and multiple small visits

The quantum proof applies to *any* sign matrix S after replacing the factor $1/\sqrt m$ in its bias upper bound by $\|S\|_{\rm op}/m$. Indeed weighted Hilbert–Schmidt space is a Hilbert space, so $\sum_j\|\sum_i S_{ij}Z_i\|_F^2\le\|S\|_{\rm op}^2\sum_i\|Z_i\|_F^2$. The classical rank proof admits exactly the same substitution. This matters because a native circuit may pay a logical Clifford before choosing its table representation. Let $\mathcal G$ contain fixed pairs of arbitrary cell permutations and fixed cellwise sign corrections. A uniform random table remains uniform under any one such correction. For iid signs the probability that $\|S\|_{\rm op}>C\sqrt m$ is $\exp(-c C^2m)$ for all large fixed C, by taking $1/4$-nets of both unit spheres and applying the scalar Rademacher tail to each bilinear form. Hence $\log|\mathcal G|=O(m)$ allows one random hard table to obey the same norm bound for every corrected layout, with a suitable universal C for a specified size exponent. In particular *all* binary affine permutations on the $2a$ address bits and all Boolean degree-at-most-two signs cost only $O(a^2)$ bits to specify. A table-dependent choice of such a layout cannot remove the linear-in-m alphabet obstruction for almost all targets. Free row and column gauges also preserve the spectral norm.

There is a communication test for adaptive coherent visits. Split the input address between Alice's row and Bob's column. Assume local processing, input-independent preshared entanglement, and a total of Q qubits transmitted in either direction in a fixed schedule. All gates and local representations may depend on the target table. A complete coherent phase of uniform vector error $\epsilon$ implies
$$
1-2\epsilon^2 \ \le\ 2^Q\,\|S\|_{\rm op}/m.
$$
First Alice prepares a superposition of row i and a fixed reference row 0 with a local control. Apply the actual scalar protocol, coherently erase the locally available row labels, and measure the control in the X basis. The ideal X sign is $S_{ij}S_{0j}$; actual probability of the wrong sign is at most $\epsilon^2$, including all workspace leakage. Bob multiplies by his known sign $S_{0j}$. The resulting two local sign outcomes have product bias at least $1-2\epsilon^2$ for each cell.

Here is an elementary quantum communication bound for this sign protocol. Replace every transmitted qubit by uncorrected teleportation with a fresh preshared Bell pair. The parties proceed locally irrespective of the Bell outcomes, marking locally whether all their own sent-qubit outcomes were the no-correction result. On simultaneous success the joint branch is the ideal communication protocol with probability $4^{-Q}$. If Alice and Bob respectively send $Q_A,Q_B$ qubits, the marginal probability that a party marks success is $4^{-Q_A}$ or $4^{-Q_B}$. To see this without assuming independent outcomes on the two parties, examine just that party's reduced no-communication circuit. Each fresh outgoing Bell half is locally maximally mixed and independent of its untouched local systems before its first use. Local Bell measurement then has four equiprobable outcomes for every local previous record. The remote no-communication operations do not change this marginal.

On the initial shared pure state $\Psi$, including local purifications, Alice's signed test on success corresponds to a Hermitian contraction $A_i$, with $A_i^2\le F_i$ for local success effect $F_i$; this follows by taking a Naimark dilation, placing signs $\pm1$ on successful outcomes and zero elsewhere, and compressing the square. Likewise $B_j^2\le G_j$ for Bob. Therefore $x_i=(A_i\otimes I)\Psi$ and $y_j=(I\otimes B_j)\Psi$ have norms at most $2^{-Q_A}$ and $2^{-Q_B}$. Their inner products give the marked signed correlators, each equal to $4^{-Q}$ times the ideal communication correlator. Spectral norm bounds their sum against S by $\|S\|_{\rm op}(\sum_i\|x_i\|^2)^{1/2}(\sum_j\|y_j\|^2)^{1/2}\le\|S\|_{\rm op}m2^{-Q}$. Rearranging gives the stated inequality. A fixed schedule with classical messages can be simulated by sending the same number of qubits. For the Walsh or layout-robust random hard target, the total requires at least $(\log_2m)/2-O_\epsilon(1)$ qubits across this cut for $\epsilon<1/\sqrt2$. Thus q adaptive visits transmitting at most k bits or qubits per visit require $qk=\Omega(\log m)$ at fixed small error. Arbitrary joint native Cliffords can move that much address information with zero T-depth.
