# T gates outside the two widest native layers

Let a clean qubits and any number of dirty qubits be available for a complete circuit with arbitrary Clifford interlayers. Let n be the number of data qubits, h=n+a+1, and N=2^n. For any emitted circuit let t be its T-count. Let s be the total T-count left after deleting its two widest native T layers; delete all layers if there are fewer than two. Chronological positions of the deleted layers are free. Use t and s below for common upper bounds on the individual circuit parameters, with the maximization for the widths done separately in each circuit.

For every complete real-frame compiler with operator error at most 2^{-L}, L≥6, put E=(N−1)(L−log₂6). For a compiler of all scalar signs on n bits to any error below 2 sin(π/16), put E=N−1. Then

    E ≤ O(min{ t(s+h)+h², (s+h)³ }).

More explicitly, for an absolute constant C there is an integer Q≤s/2+Ch such that the second upper bound is 2 binom(Q,3)+O((h+s)²), with Q enlarged monotonically for a family. In particular if h=o(E^{1/3}) even allowing arbitrarily many T gates in those two layers requires s≥(24E)^{1/3}(1−o(1)). At fixed precision, bounded clean supply and total T-count O(√N), the first bound forces Ω(√N) T gates outside every pair of native layers, independent of the number, placement and widths of all other layers. The bounds do not imply growing depth under an unspecified constant in that total budget.

## Why an effective Pauli space of dimension at most s+O(h) suffices

Push all Cliffords to the output, producing chronological T rotations about signed physical Pauli labels. On any given circuit write v for the dimension of their binary span and 2r for its symplectic rank. By the companion full-return stabilizer-transition argument, v≤t/2+O(h), for the scalar theorem even v≤floor(t/2)+n+a. A commuting independent physical T layer is an isotropic subspace of this span, of dimension at most v−r. The widest layer has at least (t−s)/2 elements. For this circuit therefore r≤s/2+O(h), even allowing the other layers to be arbitrarily large. This computation uses its actual t,s before passing to common upper bounds. For zero/one layer the same assertion follows directly since r=0.

Augment the span by input X,Z on all logical and clean wires and output X,Z on the logical wires pulled back through the final Clifford. These are k≤4n+2a boundary labels. Each augmentation can increase symplectic rank by at most two, so the augmented nondegenerate quotient has dimension 2q with q≤r+k. Its radical commutes with the entire input logical/clean Pauli algebra and hence acts only on dirty wires. Freeze any one joint character on that radical and use the normalized projector on its eigenspace as a dirty input. Because the target must work for every dirty input, this is an allowed witness. On that sector each axis or boundary observable is a signed Pauli on q effective qubits, tensored with the multiplicity identity. The boundary labels determine, through polynomial expansions of density matrices and observables and the normalized trace, the reduced logical channel on this witness. The argument is the same as in the anchored repository's research/endpoint/JOINT_NATIVE_WORDS.md §3. A different witness may be used for each circuit. A sign table family has 2^{N−1} separated channels; the first-column sphere patch at fixed precision has at least 2^E separated states as in the companion half-span note.

## Two descriptions of the effective word

For the first bound, record the t chronological signed Pauli labels explicitly on q effective qubits and the k signed boundary labels. Each costs 2q+O(1) bits. The variable lengths and dimension can be encoded in O(t+s+h) bits. This gives O(t(s+h)+h²) bits; here s≤t can be enforced on the upper limits by taking their minimum.

For the second bound, any single large commuting projected layer admits a Clifford word specified as a signed symplectic basis change with O(q²+1) bits which takes its axes to Z parities. On computational basis strings y its phase, up to a global phase, is ω^{P(y)}, ω=exp(iπ/4), where P modulo 8 is a signed sum of affine binary parities. For binary coordinates the parity is the integer multilinear polynomial
    XOR_{j∈A} y_j = Σ_{∅≠S⊆A} (−2)^{|S|−1} ∏_{j∈S} y_j .
An affine offset replaces the parity by one minus itself. All terms of degree at least four vanish modulo eight. A cubic coefficient is zero or four, a quadratic one is any even residue, and each linear coefficient is an arbitrary residue. Thus each large layer costs at most binom(q,3)+2 binom(q,2)+3q+O(q²+1) bits independent of its original length. Encode the other s axes explicitly, then specify the locations of the two complete phase layers by their positions among these s axes costing O(log(s+2)) bits. This works even for separated layers and projected repeated/identity axes. The boundary labels cost O(hq+h). Together this gives 2 binom(q,3)+O((s+h)²) bits, without a single term depending on the number of T gates in either large layer. The description calculates a witness channel. It need not synthesize a replacement native word with the original width/depth.

Using q≤s/2+O(h) and h=o(E^{1/3}) establishes the explicit leading threshold. If s were o(E^{1/3}) the entropy bound already gives a contradiction, so the remainder is o(s³) along any nontrivial subsequence with s=O(E^{1/3}).

## One model test for the cubic dependence

An unrestricted commuting block on q *effective* qubits can have at least 2^{binom(q,3)} distinct phase functions up to phase. Apply the usual seven signed parity identity for 4 x_i x_j x_k for every selected triple, all modulo eight. The resulting Boolean cubic monomials are linearly independent as functions. If physical layer independence is imposed *before* freezing and one requires only a witness sector, each parity axis can also be lifted to an independent commuting physical label by adjoining one private Z on a new wire fixed to + on that sector. This observation concerns a sector description and does not give a full-work-return circuit on arbitrary inputs. It explains why merely replacing each commuting-block descriptor by a quadratic-size string is unjustified. A stronger lower bound needs constraints linking the layers or their actions on multiple dirty-sector witnesses.

Dependencies: full return and the stabilizer-transition proof in hopf_half_span_return.md; the signed-Gram/witness channel and sphere packing therein; the native convention in Hopf-Frame-Compilation commit ae613bf8e8a38f6d0407c25910b83d69f01a2733.

## How strongly return constrains the layer-size profile

Write k_j for the physical sizes of all layers in one word, t=Σ k_j. Up to O(ht+h²) boundary/encoding bits, the logarithm of the number of full logical witness channels with this profile is at most
    3t²/8 − (1/2) Σ_j k_j².
A separate bound in terms of s=t−k_(1)−k_(2) is F(t,s), where
    F(t,s)=st/2+s²/4                        for s≤t/2,
    F(t,s)=3t²/8−(t−s)²/4                    for s≥t/2.
Orders, variable lengths, profiles and ranks are encodable within the O(ht+h²) remainder. Use size-profile-wise maxima when counting a nonuniform family. F is increasing in t and s on the allowed cone, so F can also be applied to common upper bounds (first trim s to t).

Here is a proof of the profile coefficient. Quotient only the T-axis span, giving rank 2r≤v, and let M=max_j k_j. In that quotient a layer of k commuting elements lies in an isotropic s'-space with s'≤min(k,r). Counting choices of the space and the k ordered coordinates within it costs no more than 2rk−g(k,r)+O(k+1) bits, with g(k,r)=k²/2−((k−r)_+)²/2. The quotient tuple spans, so the free symplectic group action removes log₂|Sp(2r,2)|=2r²+r+O(1) bits. Thus the total leading term is 2rt−2r²−Σ_j g(k_j,r). These counting details are in hopf_symplectic_layer_count.md. The return and maximum-layer bounds say r≤min(t/4,t/2−M)+O(h). The radial objective before the O-remainder is nondecreasing for 0≤r≤t/4: its derivative is 2t−4r−Σ(k_j−r)_+, which is nonnegative on [0,t/4]; only [0,t/4+O(h)] is ever used. The corrections for clipping to [0,t/4] cost O(ht+h²). Write Δ=t/4−r. Each (k_j−r)_+≤2Δ+O(h), whence
    (1/2) Σ_j (k_j−r)_+² ≤ (Δ+O(h)) Σ_j(k_j−r)_+ ≤ Δt+O(ht).
Since 3t²/8−(2rt−2r²)=Δt+2Δ², dropping the nonnegative final slack yields the result.

For the sharper F near two concentrated layers, use convexity of g in k to retain at least 2g((t−s)/2,r) total penalty. The leading objective 2rt−2r²−2g((t−s)/2,r) is increasing through r≤t/4, by differentiation on either side of (t−s)/2. If s≤t/2 evaluate at r=s/2 and otherwise at r=t/4, with O(ht+h²) corrections. This gives the displayed two formulas. As a result at a fixed t gate ceiling, a family with s≤t/2 needs s≥sqrt(t²+4E)−t up to lower-order terms.

At count t=(sqrt(8/3)+o(1))sqrt(E) and h=o(t), the existence of such a compiler would force diffuse native layers on worst-case hard targets. More precisely, for any fixed δ>0, sign tables admitting a circuit with this count ceiling and sum of its two largest bandwidths at least δt form at most a 2^{−(δ²/4−o(1))t²} fraction of all projective sign tables. This follows also from Σk_j²≥(k_(1)+k_(2))²/2. It is an almost-all statement about a hypothetical leading coefficient; no compiler is known to attain that coefficient.
