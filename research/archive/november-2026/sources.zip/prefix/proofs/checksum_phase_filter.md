# Amplifying a scalar source with address motion

Let a desired Boolean predicate be h(x). A sufficiently fast compiler for arbitrary scalar signs can supply an actual native word for the scalar t h(x). Sandwich it in Hadamards on t to get Q, an approximate XOR of h into t, with full initialized-operator error δ and c initially zero source wires. An independent p-bit address x and arbitrary source dirty work W may both move during Q. Suppose δ<1/√2. The following condition, which refers only to one compressed measurement, is sufficient for arbitrary accuracy.

Form R₀ = Q† Z_t Q, a physical Hermitian involution, and let A₀ be its compression to t=0 and the c source-clean bits equal to zero. Its matrix entries in the address basis are operators on all the original dirty work. Suppose a known binary s-by-p matrix H has the property
```math
(A_0)_{xy}=0 \quad\text{whenever }h(x)\ne h(y),\ Hx=Hy .
```
The number of check rows s and c may be fixed constants. This condition permits label changes between different addresses with the same answer, arbitrary changes detected by H, and arbitrary physical address motion and source-clean leakage in Q. A sufficient condition is access to the list of K possible nonzero displacements x+y with different Boolean answers and nonzero matrix entry. An s-row H with s=ceil(log₂(K+1)) eliminates all K displacements, by the union bound for a uniformly random binary matrix. A matrix may also be supplied directly. Offline existence of an s-row checksum is decidable from a finite emitted Clifford+T word and the prescribed table. Its matrix coefficients belong to the dyadic eighth-root cyclotomic ring, so every relevant zero test and enumeration of H is finite. This gives termination without a polynomial preprocessing claim.

## Projecting out detected changes

Let U_H XOR Hx into an s-bit checksum register, by at most sp CNOTs. Set R=U_H† R₀ U_H and let P project all the c source bits, t and the s checksum bits onto zero. Its compression A=PRP on the code has entries
```math
A_{xy}=\mathbf1[Hx=Hy](A_0)_{xy}.
```
Thus A is the pinching of A₀ by the checksum projectors. For a normalized code input supported on answer b, the ideal source puts t=b and the actual probability of t≠b is at most δ². The compression of (−1)^b A₀ to that answer sector is bounded below by αI, α=1−2δ². Pinching commutes with the answer projectors and preserves that inequality. Under the stated collision condition A is block diagonal across answers, has absolute eigenvalues at least α and sign(A)=D_h tensored with I_W, including the case of nontrivial operators within each answer block.

## Filtering using few initialized bits

Put S=2P−I and F=RS. Its Hermitian part (RS+SR)/2 is block diagonal for P, with compression exactly A. Consequently its spectral sign on the code is exactly sign(A). Controlled R is implemented by U_H† Q† CZ Q U_H, with the CZ from the external control to t. Controlled S is a returned equality-controlled phase on c+s+1 bits and a one-bit phase on the control for the global minus sign in S. There is no controlled generic native source word.

Choose k≥1 and power-of-two K≥k+1, K≥4, with K=O(k+1). Prepare a clock initially zero in amplitudes
```math
w_j={k\choose j}/\sqrt{{2k\choose k}}\quad(0\le j\le k)
```
and zero elsewhere. Apply controlled F^j and the K-point inverse Fourier transform to the clock. For a walk eigenphase φ and θ_l=2πl/K the frequency probability is
```math
\frac{4^k}{K{2k\choose k}}\left|\cos((\phi-\theta_l)/2)\right|^{2k}.
```
For an eigenphase with |cos φ|≥α, every frequency of the incorrect sign is separated in circular distance by at least γ=arcsin α. Either assignment for cos θ_l=0 works. The total incorrect probability is at most (2k+1) cos(γ/2)^(2k), since the central binomial coefficient is the largest in the row summing to 4^k. Apply the sign of cos θ_l and reverse the entire circuit. The operator error on the code and zero clock is at most 2√(2k+1) cos(γ/2)^k. This is uniform on all code states: sign(Re F) commutes with F, and its spectral portion with |Re F|<α has zero support on P. A state can have components outside P while the walk is running.

Arbitrary-angle clock preparation and Fourier unitaries require synthesis. The clock uses O(log(k+2)) qubits. It can be prepared by a binary tree of O(k) one-qubit rotations controlled on O(log(k+2)) bits, and the Fourier transform uses O(log²(k+2)) Hadamards and controlled phases. Synthesize each rotation to its share of an error η using fixed-precision Clifford+T synthesis, exact controlled decompositions and returned dirty conjunctions. These short operations have count and depth polynomial in k and log(1/η). The clock sign comparison on the middle half of the circle is a Boolean function of O(log(k+2)) bits and has a finite polynomial-cost native synthesis. All adjoints are actual reversed words. The walk powers use O(k) occurrences of controlled R and controlled S. The initialized bits are c+s+1+O(log(k+2)).

To end with a full zero-clean scalar for g(x), apply this construction to h(u,x)=u g(x), satisfying the same source/checksum hypothesis for this h. Conjugate u by Hadamards to give a complete clean-code XOR, use the repository's bounded-clean XOR promotion, then extract the sign on all inputs by the query/Z/actual-unquery/Z echo. The overhead and error multiplier of this promotion are O(2^(c+s)(k+1)) up to constants; extra local zero tests cost poly(c+s+log(k+2)). Choose k=O_δ(c+s+log(1/τ)+1), increasing its constant to absorb the polynomial in k, and choose the short synthesis tolerance correspondingly. Output error is at most τ with O(2^(c+s) poly(k)) multiplicative resource overhead over the original source and polynomial local additions, including O(sp) elementary Cliffords per checksum pass. Only two additional Boolean input bits enter the source arity. At fixed s,c,δ the overhead is polylog(2/τ). The same phase filter may be used directly as an initialized-code result if those qubits are available. For a fixed requested precision, thresholds may depend on δ. The native source count, elementary Clifford count, depth and dirty width orders are all charged separately.

In the iterated scalar-to-frame reduction, a target τ_m proportional at fixed L to (1+log* m)^(−2) now costs poly(log(2+log* m)) per stage. At fixed s,c,δ the resulting general depth upper is
```math
O_L\!\left(N/b^2+\log\log(n+4)+(1+\log^* n)(\log(2+\log^* n))^{O(1)} d(n+O_L(1))\right).
```
Polynomial precision overheads in short local operations sum to O_L(log log(n+4)); polynomial factors of the local height/precision in long volume terms are absorbed by the reserve as in the scalar transfer. An O(sp) Clifford checksum costs O(p) at fixed s and affects no native T-depth. This is a conditional complete-frame theorem. It requires a collision-free checksum for each compiled predicate h at its measured compression.

## Residual collisions and limits of affine checks

Write B=diag(A_{00},A_{11}) for the block diagonal across the two answer values. If the remaining off-diagonal block of A has norm η, then ||sign(A)−D_h||≤η/α. Indeed the two diagonal blocks of B are respectively ≥αI and ≤−αI. For any real z in (−α,α), the positive upper diagonal block of A−zI is invertible and its Schur complement is strictly negative, so A also has gap α. Apply the resolvent identity in the symmetric integral for sign along the imaginary axis; the norm difference is ≤(η/π)∫dt/(t²+α²)=η/α. This initialized-code systematic contribution is also multiplied by the promotion error factor when that wrapper is used.

No bounded number of affine address checks generically removes even a small fixed systematic tilt. For p≥1 choose h equal to the indicator of the zero address. Let a p-bit dirty key r be a computational control and W_r=exp(iθ X^r) on the address. Take Q=W_r Q_h W_r†, acting as a direct sum over the keys. Its full error is at most 2|sin θ|, and its compressed measurement is W_r D_h W_r†. For any H with nontrivial kernel choose a nonzero key r in that kernel. On the address pair 0,r the checksum does not distinguish the two labels, and the compressed sign still differs from D_h by 2|sin θ|. This example is already a legal oracle-level counterexample to generic promotion by affine checks of the address. It can also be approximated arbitrarily well by finite native circuits with bounded source clean work: X^r is the product of the address CNOT translations from r, controlled X^r uses linear many Toffolis, and a clean flag in a Hadamard test records its ±1 eigenspace. Rotate that flag and actually uncompute. A sufficiently accurate emitted one-bit phase retains a fixed positive residual by continuity. The example is limited to the stated affine-check procedure. The point function itself has other direct compilers.

More generally a fixed checksum H enforces the implication for every sufficiently accurate source for h if and only if h is constant on its fibers. Sufficiency is the definition. For necessity one collision x,y with opposite answers supports a two-dimensional rotation of the intended XOR, arbitrarily weak but with a nonzero mixed matrix entry on that same fiber. For a linear checksum this means ker H must lie in the translation-period space T_h={z:h(x+z)=h(x) for every x}. Thus the minimum number of affine check bits for a guarantee uniform over arbitrary sources equals p−dim T_h. Choosing a code only after seeing an actual source can beat that worst-case value. The dirty-key example shows the same lower requirement simultaneously for a single source containing all translations.

[Bounded-clean promotion](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/DIRTY_PROMOTION_OF_CLEAN_QUERIES.md)

## Arbitrary table-independent quantum fingerprints

The affine obstruction has a channel-rank generalization. Before the checksum stage let the wrapper use any fixed, computationally controlled isometries \(V_x:B\to C\), where the entirely arbitrary fingerprint workspace has dimension \(m=\dim B\) and \(\dim C=mK\). Thus \(K\) is the additional initialized dimension. Define \(V=\sum_x |x\rangle\langle x|\otimes V_x\). Compressing an observable \(Y\) on the address gives \(\Phi(Y)=V^\dagger(Y\otimes I_C)V\), with any independent reference allowed. This includes table-independent coherent checks, arbitrary controlled encodings of an unknown fingerprint state, and finite coherent averages of address-dependent tag operations. Write \(M=2^p\), and let \(\Delta\) dephase in the address basis.

The completely bounded operator-norm distance from \(\Phi\) to \(Y\mapsto\Delta(Y)\otimes I_B\) is at least \(2(1-K/M)\) when \(K\le M\). To see this, apply the Schrödinger adjoint channel \(X B\to X\) to half of a normalized maximally entangled input. Its output has rank at most \(mK\), since the environment C of its Stinespring isometry has that dimension. The ideal adjoint (discard B and dephase X) gives the normalized Choi state
\[
 M^{-1}\sum_x |xx\rangle\langle xx|_{X X'}\otimes I_{B'}/m .
\]
This is flat on rank \(mM\). Its probability outside the support of the actual output is at least \(1-K/M\), so their trace-norm distance is at least twice that number. A Hermitian contraction testing that trace distance gives the claimed lower bound on the observable difference, on the independent reference \(X'B'\).

This lower bound produces *an actual scalar accuracy obstruction*, with no promise on the native complexity of the adversarial source. Fix such a testing observable \(Y\), including the reference. For a uniformly random Boolean sign table h let \(E_h\) be its cross-answer part of Y, the sum of the two blocks between opposite answers. Each \(E_h\) is a Hermitian contraction, and \(\mathbb E_h E_h=(Y-\Delta(Y))/2\). Since \(\Phi\) agrees with the ideal map on all address-diagonal observables, some h and \(E=E_h\) have \(\|\Phi(E)\|\ge1-K/M\). The tag commutes with address-diagonal projectors, so \(\Phi(E)\) also lies entirely between opposite answer blocks. Put \(D=D_h\), extended by the identity wherever appropriate. Then \(E D\) is anti-Hermitian. Let \(W=\exp(\theta E D/2)\) with \(0<\theta\le1/8\), and define \(Q'=W Q_h W^\dagger\). This is a valid XOR source to error at most \(\theta\). Its zero-target compressed measurement is \(W D W^\dagger=\exp(\theta E D)D=D+\theta E+O(\theta^2)\), uniformly in dimension. After tagging the compression becomes \(A=D+\theta\Phi(E)+O(\theta^2)\). Since \(D\Phi(E)+\Phi(E)D=0\), one gets \(\|A^2-I\|=O(\theta^2)\) and \(\|\operatorname{sgn} A-A\|\le\|A^2-I\|\). Therefore even infinite-accuracy spectral filtering leaves
\[
 \|\operatorname{sgn} A-D\| \ \ge\ \theta(1-K/M)-O(\theta^2).
\]
For \(K=o(M)\), a linear-in-source-error tilt persists worst case, irrespective of dirty fingerprint dimension. With \(K=M\) the exact address-copy tags realize full dephasing. The claim assumes a single tagging compression fixed independently of the truth table, arbitrary source error and spectral sign readout. A tag chosen using the prescribed table, a source-specific compiler or a circuit interleaving several differently modified sources is outside the lower bound.


## Exact extraction for a finite-order walk

If the measured compression already has a separated Boolean sign and each of its eigenvalues obeys \(\arccos|\lambda|\in(2\pi/k)\mathbb Z\) for a known odd integer k, then the simpler word \(F^k\) acts as \(D_h\) exactly on the code and returns the hash and t. Indeed its two eigenphases over a positive answer give eigenvalue \(+1\) after k powers, while \(\pm(\pi-\arccos|\lambda|)\) give \(-1\). No clock or estimate is needed. A different exact case occurs if every supported walk eigenphase is a multiple of \(\pi/4\) and no cosine is zero. Then exact eight-point phase estimation, the frequency sign and exact reversal suffice. The eight-point Fourier transform uses Hadamards and controlled phases of angles \(\pi/2,\pi/4\), exactly realizable by computing the two-bit conjunction, applying S or T and uncomputing with one extra initialized bit. Bounded-clean promotion can then be exact. These finite-spectrum promises are stricter than the approximate-source contract, but allow exact extraction even if \(Q\) moves logical labels.
