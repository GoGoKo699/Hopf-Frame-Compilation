# Verification guide

Start with Hopf_Scalar_Phase_and_Frame_Depth.md. The repository anchor is ae613bf8e8a38f6d0407c25910b83d69f01a2733.

## Proofs in reading order

1. scalar_frame_transfer.md gives the exact scalar-source hypothesis, the R98 row ledger and the bounded-height terminal. iterated_frame_transfer.md gives background on the precision schedule.
2. single_feedback_pencil.md constructs two structured matrices for every scalar table. It identifies the unpaid native phase.
3. modular_rotation_bank.md gives the unconditional dyadic family and the frame perturbation formula. Its last-one construction uses haar_shortcut.md and the three-basis vote proof in haar_predecessor.md. The exact read-only conjunction is in the anchored repository, docs/DIRTY_SUM_COMPRESSION.md, section 6 (included as dirty_sum_compression.md).
4. half_span_return.md proves the stabilizer transition and Gram description bounds. symplectic_layer_count.md refines the count by physical layer.
5. optimal_reciprocal_basis.md, scalar_alternating_visits.md and calibrated_probe_metric.md treat the reciprocal multiplier, alternating row/column access and the robustness of partial parity information, respectively. Each states its own model.

## Running checks

Use Python 3 and NumPy. From the extracted directory run python run_checks.py. The checks use explicit finite enumerations, matrix comparisons and deterministic seeds. They test the stated identities on sample parameters. The mathematical arguments in the notes establish the asymptotics.

For the companion regression run, from the referenced repository checkout run

    python -m unittest -q tests.test_boolean_query_frame_reduction tests.test_approximate_query_frame_transfer tests.test_joint_native_words tests.test_homogeneous_depth tests.test_causal_compact_coin_depth tests.test_recursive_field_shear_decoder

That command ran 23 tests successfully in this research session.
