# A scalar-phase route to sublogarithmic complete Hopf frames

Research note, 19 November 2026. Repository reference `ae613bf8e8a38f6d0407c25910b83d69f01a2733`. The verification archive includes the derivations and small-instance checks. Here \(n\) is the number of system qubits, \(N=2^n\), \(b\) is the available dirty width, and \(2^{-L}\) is the requested full-frame error. Logarithms are base two. Constants in \(O_L\) may depend on the fixed precision.

**General status.** At \(b=\Theta(\sqrt N)\), the strongest unconditional general upper bound is still R96's \(O_L(\log n)\) native T-depth. The unconditional lower bound on the depth at that resource order remains \(\Omega(1)\). This note gives a sufficient condition on scalar signs alone that would beat the upper bound, an unconditional subfamily that does beat it, and depth-dependent lower bounds on the leading T-count. The target throughout is the complete prescribed frame acting on every input column, including superpositions with an external reference. The return of the clean qubit and the dirty workspace is included in the error.

## 1. A sufficient scalar bound for every frame

For a prescribed Boolean table \(g\) on \(a\) bits, let \(D_g|x\rangle=(-1)^{g(x)}|x\rangle\). Suppose every such sign has an exact native implementation, with returned work, at every dirty allocation \(B\ge C(a+2)\). Assume the following three bounds **simultaneously**, with \(d\ge1\) nondecreasing:

\[
 T_{\rm scalar}=O(2^{a/2}+2^a/B),\qquad
 G_{\rm scalar}=O(2^a),\qquad
 D_{\rm scalar}=O(d(a)+2^a/B^2).
\]

Here \(G\) counts elementary Cliffords. Zero or a fixed number of clean source qubits suffices. Under that hypothesis every real and complex magnitude frame, at the original admissible widths and with one external clean qubit, has

\[
\begin{split}
 T&=O_L(\sqrt N+N/b),\qquad G=O_L(N),\\
 D_T&=O_L\!\left(N/b^2+\log\log(n+4)
       +(1+\log^*(n+2))\,d(n+O_L(1))\right).
\end{split}
\]

In particular a doubly logarithmic scalar depth term would give **\(o(\log n)\) for all frames** at square-root width. A constant scalar term would give \(O_L(\log\log n)\). A bare little-oh assumption on \(d\), without a rate, need not absorb the iterated-logarithm factor. The baseline precision scope is fixed \(L\) in these comparisons.

The reduction uses the identity \(H_Y Q_F H_Y|x,y\rangle=(-1)^{y\cdot F(x)}|x,y\rangle\) for a complete XOR of an output word \(F(x)\). Directly adjoining every physical Fourier bit \(y\) would put too many variables into the scalar truth table. The improvement comes from counting which address bits and which Fourier bits can affect **the same row**. For example, one of the erasure operations reads the low \(k_i\) bits of a block and writes the high \(q_i-k_i\) bits. Its phase reads a total of exactly \(q_i\) long variables. A short, preserved selector places both relevant slices on the same carrier, with the routing and its inverse charged. The fine rectangular rows obey a corresponding combined bound. The argument uses a specified reversible extension on padding and invalid rows.

Repeating the stage down to a height bounded at fixed precision requires \(O(1+\log^*n)\) stages. This matters at the terminal. Reading a \(q\)-bit angle program literally by one generic scalar phase on \(n-m+q\) inputs would cost in proportion to \(2^{n-m+q}\), even though the table itself occupies only \(2^{n-m}q\) bits. A bounded-height terminal keeps \(q=O_L(1)\). A summable allocation of stage errors preserves the original total error and resource bounds. The archive gives the row-by-row ledger and the precision schedule.

A sufficiently accurate fixed-error scalar compiler also suffices for a sublogarithmic transfer when \(d(a)=O(\log\log(a+4))\), **if its completed operation preserves the computational address exactly on every physical sector**. Coherent majority recording followed by the actual reverse circuit amplifies accuracy under that hypothesis. A two-dimensional tilted-eigenbasis example shows why successive votes can share the same systematic error when the hypothesis is dropped.

## 2. Encoding any scalar sign in one feedback edge

For \(p\) input bits split the address into \(u,v\) of nearly equal length. Write \(R=2^{|u|}\), \(S=2^{|v|}\), and \(Q=RS\). Make two binary trees. On the first, \(v\) selects a path from its root to one leaf. On the second, \(u\) selects the one leaf with a path to its root. Insert fixed edges between the two sets of leaves according to the \(Q\) bits of the prescribed truth table. Connect the second root back to the first. The graph contains exactly one directed cycle if \(f(u,v)=1\), and is acyclic otherwise. The cycle, when present, has length \(p+2\).

For the binary adjacency matrix \(G\), the matrix \(I+G\) has nullity exactly \(f(u,v)\). A smaller construction on \(R+S\) coordinates uses the algebraic normal form of \(f\) and a rank-one update of a unitriangular matrix. In either construction the full reversible operation \(w\gets w+(I+G)z\), or its smaller counterpart, is available with zero clean qubits, \(O(\sqrt Q)\) T gates and dirty wires, \(O(Q)\) elementary Cliffords and constant T-depth. The fixed truth table contributes only Cliffords to that operation.

The open step is to emit the coherent scalar \((-1)^{f(u,v)}\) and return every work input. Applying the matrix to an arbitrary vector gives no such phase by itself. A generic quantum matrix-vector oracle needs linearly many calls to distinguish full rank from corank one. Here the compiler knows the two trees, the marked edge and every table bit in advance, so that oracle theorem leaves the structured question open. The next direct target is a native phase for cycle membership of this particular marked edge with the scalar bounds in Section 1. A calculation that assumes an initialized test vector, an inverse of the unitriangular matrix, or a free powering operation must charge for it. [Childs, Hung and Li, Theorem 21](https://doi.org/10.4230/LIPIcs.ICALP.2021.55)

## 3. An unconditional complete-frame improvement

Consider positive real frames with a common angle across each level. The angle can vary independently between levels. If the supplied angles are exact multiples of \(2\pi/2^k\) with \(k=o(\log n)\), then at square-root dirty width
\[
 D_T=O_L(k+\log\log(n+4)),\qquad T=O_L(\sqrt N),\qquad G=O_L(N).
\]
This includes fixed grids and grids that become finer with \(n\). It preserves one clean qubit, the whole operator and all work returns.

In the common eigenbasis of the upper rotation bank, all desired phases are determined by one modular weighted sum. Each required high bit has a Boolean polynomial representation of degree bounded by \(2^k\) before the short selector is included. At this grid resolution its monomials fit in \(2^{o(n)}\) private dirty work and can be evaluated in parallel. Rounding happens once on the eigenphase of the entire bank. Extending the argument by independently rounding arbitrary real angles needs a bound on the resulting complete-frame error. The archive gives a sharp finite-displacement recurrence for that error.

## 4. An unrestricted lower bound on simultaneous count and depth

Let \(t,d\) bound, respectively, the worst-case T-count and number of nonempty native T layers. Let \(a_0\) be the clean count and \(h=n+a_0+1\). For a compiler covering all real complete frames at \(L\ge6\), arbitrary dirty width and arbitrary Clifford interlayers,
\[
 (N-1)(L-\log_2 6)\ \le\ C_d\,t^2+O(ht+h^2),
\quad C_1=C_2=0,\quad C_3=11/72,\quad
 C_d=3/8-1/(2d)\quad(d\ge4).
\]
For all scalar signs on \(p\) inputs, the left side becomes \(2^p-1\) and \(h=p+a_0+1\), at any error below \(2\sin(\pi/16)\). In particular a three-layer scalar compiler with a fixed number of clean qubits needs at least \((\sqrt{72/11}-o(1))2^{p/2}\) T gates in the worst case.

The role of complete return is explicit. Purify the dirty input using Bell pairs. Returning those pairs restricts the number of independent Pauli directions in a word of \(t\) T rotations to \(t/2+O(h)\). Within a native layer the physical axes commute and are independent. Counting the possible pairings layer by layer in the resulting symplectic quotient gives \(C_d\). These are necessary count coefficients. At the original \(O_L(\sqrt N)\) budget its unspecified leading constant can still accommodate a constant-depth compiler.

The verification archive contains the proof appendices, their predecessor lemmas where needed, standalone checks and commands to rerun them. Finite examples check the identities and resource arithmetic. The asymptotic claims rely on the proofs and on the repository constructions at the referenced commit. [Repository frontier](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/OPEN_PROBLEM.md) · [R98 transfer](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/QUERY_DEPTH_FRAME_TRANSFER.md)
