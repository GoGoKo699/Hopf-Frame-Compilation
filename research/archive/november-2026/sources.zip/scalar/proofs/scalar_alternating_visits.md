# Three visits, four visits, and arbitrary scalar table signs

Split the address into $u,v$, each with $a$ bits, put $m=2^a$, and prescribe any sign matrix $M_{uv}\in\{+1,-1\}$. One row visit applies an arbitrary unitary $A_u$ to all common work; a column visit applies an arbitrary $B_v$. Fixed unitaries are absorbed into adjacent visits. The external addresses remain computational controls of the completed visits. Native implementations of those visits can temporarily act on their own controlling address if they restore it at each visit boundary. The comparison in each sector is to $M_{uv}$ times the identity on all common inputs, including the return of any initialized work. The following results price *addressed visits*. They impose no native complexity bound on one visit. A word coupling the two addresses directly is outside the model.

## The exact minimax error for three visits

Allow $c$ clean qubits, an arbitrary number of dirty qubits, and up to three alternating row/column visits. The minimum full-isometry error guaranteed on every sign matrix is exactly
$$
\epsilon_3(m,c)=\sqrt{2-2\min(1,\sqrt{2^c/m})}.
$$
At $c=0$ two visits already attain the upper bound. One clean qubit and any fixed small required error therefore need at least four visits for a worst-case table as $a$ grows.

For the lower bound choose the Walsh matrix $M_{uv}=(-1)^{u\cdot v}$, which has spectral norm $\sqrt m$ and is symmetric. A three-visit word can be written $W_{uv}=A_uB_vC_u$ (or with row and column exchanged). This includes shorter words by taking identity factors. Let $P$ project onto the clean sector, let $D$ be the whole work dimension, and $d=\operatorname{rank}P=D/2^c$. Unitary isometries obey
$$
\|W_{uv}J-M_{uv}J\|\le\epsilon
\quad\Longrightarrow\quad
\operatorname{Re}\big(M_{uv}\operatorname{Tr}(PW_{uv})/d\big)
\ge1-\epsilon^2/2.
$$
By cyclicity this compressed trace divided by $d$ is the Hilbert–Schmidt inner product of $(C_uPA_u)^\dagger/\sqrt d$ and $B_v/\sqrt D$, multiplied by $\sqrt{D/d}$. Each vector has norm one. For any families of unit vectors $x_u,y_v$ in any Hilbert space,
$$
\left|\sum_{uv}M_{uv}\langle x_u,y_v\rangle\right|
\le \|M\|\big(\sum_u\|x_u\|^2\big)^{1/2}
               \big(\sum_v\|y_v\|^2\big)^{1/2}
=m\sqrt m .
$$
The mean signed correlation is therefore at most $\sqrt{2^c/m}$. This is a bound on the full-operator approximation even if the address-specific unitaries move all common work and use arbitrary scalar phases. If the same common phase is allowed as a comparison, absorb it into one fixed factor.

For the matching upper bound let $c'=\min(c,a)$ and partition rows into $2^{c'}$ groups of $\ell=m/2^{c'}$ rows. Write $u=(t,i)$. Use $\ell$ pairwise anticommuting Hermitian unitary Majoranas $\Gamma_i$ on a common arbitrary dirty register. For $\ell=1$ take the identity. The other cases allow the usual Pauli realization by $Z$ strings followed by $X$ or $Y$. The first row visit writes $t$ by XOR into the clean register. The column visit acts there blockwise by
$$
G_{t,v}=\ell^{-1/2}\sum_j M_{(t,j),v}\Gamma_j .
$$
This is a Hermitian unitary since all cross anticommutators vanish. The last row visit applies $\Gamma_i$ and uncomputes $t$ by XOR. Thus the clean bits return exactly, and on the fully arbitrary dirty register the word is $U=\Gamma_iG_{t,v}$. Its Hermitian part is $M_{uv}I/\sqrt\ell$, so
$$
(U-M_{uv}I)^\dagger(U-M_{uv}I)=(2-2/\sqrt\ell)I.
$$
At $c'=a$ the result is exact. This construction prices the number of visits; synthesizing all the $G_{t,v}$ simultaneously could be difficult. In particular the Walsh lower witness on the original two addresses by themselves is a product of CZ gates. It illustrates the distinction between an interface lower bound and a native T-depth lower bound.

## Four visits have a forced scalar commutator on the whole space

With zero clean input, suppose $W_{uv}=A_u B_v C_u D_v$ has full operator error $\epsilon$ from $M_{uv}I$. Fix a reference row and column, both denoted $0$. For each of the four factors $F_j$ form its relative unitary $F_j F_{j,0}^\dagger$, where $F_{j,0}$ is the corresponding reference factor. Conjugate the relative unitary by the product of preceding reference factors. The resulting $A'_u,B'_v,C'_u,D'_v$ each equal identity at reference and satisfy
$$
A'_uB'_vC'_uD'_v=W_{uv}W_{00}^\dagger .
$$
Each sector on the right is within $2\epsilon$ of $m_{uv}I$, $m_{uv}=M_{uv}M_{00}$. Evaluating at $(u,0)$ and $(0,v)$ gives $C'_u$ within $2\epsilon$ of $m_{u0}(A'_u)^\dagger$ and $D'_v$ within $2\epsilon$ of $m_{0v}(B'_v)^\dagger$. Consequently
$$
\|A'_uB'_v(A'_u)^\dagger(B'_v)^\dagger
       -M_{uv}M_{u0}M_{0v}M_{00}I\|\le6\epsilon.
$$
For exact synthesis this characterizes all four-visit words up to one-sided scalar factors and the reference changes of basis. Approximate replacement of these factors on a clean sector alone has a separate domain issue: the interim $D'_v$ may carry the state outside that sector.

Define the binary rectangle matrix $C$ by $(-1)^{C_{uv}}=M_{uv}M_{u0}M_{0v}M_{00}$. The **minimum exact four-visit dirty width** for this table is
$$
w_{\min}=\lceil\operatorname{rank}_{\mathbb F_2} C/2\rceil .
$$
For necessity take $r$ independent rows of $C$. Every ordered product of a subset of the corresponding $A'_u$ is an eigenoperator of conjugation by $B'_v$, with eigenvalue $(-1)^{\sum C_{uv}}$. Distinct subsets have different eigenvalues for at least one $v$. Their $2^r$ unitary products are pairwise orthogonal in Hilbert–Schmidt space, whose dimension is $2^{2w}$. This does not require the row family, column family, or conjugations within either family to commute. Conversely factor $C$ through an $r$-dimensional binary vector space and embed the row and column labels into the binary $2w$-dimensional Pauli symplectic space as paired vectors giving precisely $C$ under symplectic pairing. Their Hermitian Pauli representatives provide the desired commutators. Multiply visits by the one-sided signs $M_{u0}$ and $M_{0v}M_{00}$ to restore the original rectangle. Counting local word synthesis would be an additional cost.

## Recovering the indicator from independently addressed Pauli row programs

Suppose $C$ has full reduced row rank $m-1$. If the actual normalized row family has a complete native selector $P_u$ made of Paulis up to branch phases, the labels for $u\ne0$ are linearly independent from their pairing signs when the column operators are Paulis. The same conclusion holds for arbitrary column unitaries in the exact commutator identity: a binary linear dependence makes the corresponding product of Pauli rows scalar, contradicting its nontrivial sign under one of the columns. The reference branch is identity up to phase. Independence holds even for anticommuting rows. Run the selected row circuit and its gatewise complex conjugate on two separate arbitrary banks. The branch phases cancel in $P_u\otimes P_u^*$. The lifted labels $(a_u,a_u)$ are independent and pairwise commute. Add the arbitrary $m$-wire output bank if needed. A fixed Clifford on the common workspace maps the independent commuting rows to $X_{Y_u}X_{Y_0}$ for all $u\ne0$, with any required fixed sign adjustment by a Pauli. Existence follows by extending an isotropic Pauli basis to a symplectic basis; symplectic Gaussian elimination costs quadratic elementary gates in the total width. Apply this Clifford and its inverse around the pair of calls, then flip $Y_0$. At $u=0$ only $Y_0$ flips. The resulting circuit is the complete zero-clean indicator, on every occupied output and work input. Two sequential calls suffice even if their shared address moves internally. A $\delta$-approximation of the ideal selected row family costs at most $2\delta$ in the two-call circuit. This argument excludes a route-specific shortcut obtained merely by changing the two tables of Pauli labels or using noncommuting row labels. It does not supply the physical simultaneous Clifford change for an arbitrary non-Pauli representation.

## What a non-Pauli column can buy against Pauli rows

Suppose each row is a Hermitian Pauli $P(a_u)$ and each column $B_v$ is any unitary, with full-space commutator error at most $\delta$. Expand $B_v=\sum_z b_z P(z)$ in the orthonormal normalized Hilbert–Schmidt Pauli basis, so $\sum|b_z|^2=1$. For every entry the identity
$$
\|P(a_u) B_v P(a_u)^\dagger -(-1)^{C_{uv}} B_v\|_{\rm normalized\ HS}^2
=4\Pr_{z\sim|b|^2}\big([a_u,z]\ne C_{uv}\big)
$$
implies pointwise parity-prediction error at most $\delta^2/4$. The symplectic pairing becomes an ordinary dot product after fixing coordinates. As a consequence each column has one deterministic approximating parity with at most $m\delta^2/4$ erroneous entries. The approximating matrix has binary rank at most $\dim\operatorname{span}\{a_u\}\le2w$. A worst-case normalized table has rank $\Omega(m)$ even after an arbitrary fixed small positive fraction of entries is changed. Indeed matrices of rank at most $r$ have at most $2^{2mr}$ descriptions by factorization; balls of $\rho m^2$ errors have at most $2^{h_2(\rho)m^2}$ strings, while normalized tables have $(m-1)^2$ free bits. Thus Pauli-row protocols, even with fully quantum columns, need $\Omega(m)$ carrier qubits for sufficiently accurate uniform worst-case approximation. The approximate four-factor extraction above supplies $\delta\le6\epsilon$ when its normalized row operators are Paulis.

Conversely, suppose for some common feature $\lambda(u)\in\mathbb F_2^k$ each column admits a distribution $p_v(j)$ over parities $z_j$, whose worst-case pointwise error is at most $\xi$. Choose $A_u=X^{\lambda(u)}$, and append a fixed set of mutually anticommuting Hermitian Paulis $\Gamma_j$ on a separate register. The choice
$$
B_v=\sum_j\sqrt{p_v(j)}\;\Gamma_j\otimes Z^{z_j}
$$
is a Hermitian unitary. Conjugating the summands by $A_u$ supplies the chosen parity signs. The signed difference from $(-1)^{C_{uv}}B_v$ is twice the sum over erroneous $j$. That sum squares to the total erroneous probability times identity, so the full operator error is **exactly** twice the square root of that probability. This realizes the distributional characterization at four addressed visits, with width for the feature and the extra Majoranas. A common support list of at most $(m+1)m$ entries suffices: for each column its vector of predicted correlations lies in the convex hull of parity-sign columns in $\mathbb R^m$, and convex elimination leaves at most $m+1$ components per column. Pricing the native implementation of $B_v$ remains necessary.

## Two table-specific three-visit characterizations

With zero clean qubits, define the real vector margin
$$
\gamma(M)=\max_{\|x_u\|=\|y_v\|=1}\min_{u,v} M_{uv}\,x_u\cdot y_v.
$$
The best full-operator error for *this particular table* given at most three alternating visits is $\sqrt{2-2\gamma(M)}$, attained with two visits. The compressed-trace proof with $c=0$ shows necessity after taking the realification of the complex Hilbert–Schmidt space. Conversely take $A_u=\sum_i x_{u,i}\Gamma_i$ and $B_v=\sum_i y_{v,i}\Gamma_i$ for any maximizing vectors. Each is Hermitian unitary and the Hermitian part of their product is $(x_u\cdot y_v)I$. The real Gram matrix on the $2m$ vectors is positive semidefinite with unit diagonal, so the maximum exists, a Gram semidefinite program computes it, and a real realizing dimension at most $2m$ suffices. Any matrix other than a product of two one-sided signs contains a $2\times2$ Walsh submatrix up to row/column permutations and sign changes, and so cannot have error below $\sqrt{2-\sqrt2}$ at zero clean qubits in this interface.

In the order $A_u B_v C_u$, let $R$ count distinct row patterns modulo an overall row sign. **Exact implementation is possible with $c$ initialized qubits if and only if $R\le2^c$.** Indeed write $V_u=C_u J$, $Z_u=A_u^\dagger J$ for isometries embedding the $d$-dimensional occupied space in the full $D=2^c d$ dimensional space. Exactness gives $B_v V_u=M_{uv}Z_u$. Therefore $D_v=B_0^\dagger B_v$ agrees with $m_{uv}=M_{u0}M_{uv}$ on the range of $V_u$. Two different normalized patterns are distinguished by opposite eigenvalues of at least one unitary $D_v$, so their code ranges are orthogonal. Conversely store the row class in $c$ initialized bits, apply the prescribed sign on that class under $v$, and undo the class label with the overall row sign. If the opposite ordering is allowed, take the minimum of the row and column pattern counts.

At uniform error $\epsilon$, $\|D_v V_u-m_{uv}V_u\|\le2\epsilon$, with the same bound for $D_v^\dagger V_u-m_{uv}V_u$ by unitarity. For any rows i,j with different patterns pick a distinguishing v; evaluating $V_j^\dagger D_v V_i$ using either row estimate then gives $\|V_j^\dagger V_i\|\le2\epsilon$. Write $P_i=V_iV_i^\dagger$. Their fusion-frame trace bound follows from Hilbert–Schmidt Cauchy–Schwarz,
$$
(Rd)^2/D\le\operatorname{Tr}\left(\sum_i P_i\right)^2
\le Rd+R(R-1)d(2\epsilon)^2.
$$
For $R>1$ this yields $\epsilon\ge\tfrac12\sqrt{\max(0,R/2^c-1)/(R-1)}$. In particular if $\epsilon<2^{-c-1}$ every feasible table already has $R\le2^c$; at this tolerance the exact classification applies unchanged for the given ordering. For one clean qubit the threshold is $1/4$.
