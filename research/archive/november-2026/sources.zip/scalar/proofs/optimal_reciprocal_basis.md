# A minimum-dimensional reciprocal basis, at every binary address length

For each $p\ge0$ there is a field $E$ of binary dimension **exactly** $m=2^p$, an affine address slice $\alpha+U$ for a $p$-dimensional binary subspace $U\subset E$ with $\alpha\notin U$, and a basis
$$
\left\{g_s=(\alpha+s)^{-1}:s\in U\right\}
$$
of $E$ over $\mathbb F_2$. This reaches the dimension lower bound $m$ for $m$ independent translations. It proves the all-size case that the previous $m+p$-dimensional root-count construction left open.

## The quadratic extension

Begin with $F=\mathbb F_2$, $U'=\{0\}$, $\alpha'=1$. Suppose a pair $(U',\alpha')$ in $F$ has been constructed for $p-1$ address bits, with the stated reciprocal basis. Since $\alpha'\notin U'$, some binary functional vanishes on $U'$ and is one at $\alpha'$. By nondegeneracy of the absolute trace pairing on a finite field, choose $\gamma\in F^\times$ for which this functional is $x\mapsto\operatorname{Tr}_{F/2}(\gamma x)$. The binary-linear map $L(x)=x^2+x$ has kernel $\{0,1\}$ and image the trace-zero hyperplane. The latter follows from the trace identity $\operatorname{Tr}(x^2)=\operatorname{Tr}(x)$ and dimensions. The trace pairing itself is nondegenerate because the trace polynomial is nonzero of degree less than $|F|$, so some field element has trace one, and multiplication by any nonzero element is bijective.

Let $E=F[\alpha]$ with $\alpha^2+\alpha=\gamma\alpha'$. The right side has absolute trace one, so the polynomial is irreducible and $[E:F]=2$. The nonidentity relative Galois automorphism sends $\alpha$ to $\alpha+1$. Take
$$
U=L^{-1}(\gamma U')\subset F\subset E.
$$
It has dimension $p$, since $\gamma U'$ lies in the image of $L$. Further $\alpha\notin F$, so all required reciprocals exist. Choose a binary-linear section $s'\mapsto u(s')$ with $L(u(s'))=\gamma s'$. Then every address in $U$ has the unique form $u(s')+b$, $b\in\mathbb F_2$. The two reciprocals for $b=0,1$ are relative conjugates and their sum is
$$
\frac{1}{\alpha+u}+\frac{1}{\alpha+u+1}
  =\frac{1}{\gamma\alpha'+u^2+u}
  =\gamma^{-1}(\alpha'+s')^{-1}.
$$
These relative sums form a basis of $F$. The relative trace map $E\to F$ has kernel $F$, since the extension is quadratic in characteristic two. In the quotient $E/F$, the cosets of one reciprocal from each pair therefore also form a basis, by their independent relative traces. The collection of all $2^p$ reciprocals spans $F$ by its pair sums and spans $E/F$ by its cosets. Its cardinality equals $[E:\mathbb F_2]$, completing the induction.

The induction only requires binary linear systems, arithmetic in the previously presented field, and adjoining the displayed irreducible quadratic. There is no search over exponentially large sets of shifts or subsets.

A canonical normalization uses the actual field tower in the [existing recursive decoder, Section 1](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/RECURSIVE_FIELD_SHEAR_DECODER.md). Start with $\rho_0=1$, $V_0=\{0\}$. Adjoin $\theta_j^2+\theta_j=\rho_{j-1}$, set $\rho_j=\rho_{j-1}\theta_j$ and
$$V_j=\rho_{j-1}\{x\in F_{j-1}:x^2+x\in V_{j-1}\}.$$
Then $\operatorname{Tr}(\rho_j)=1$ by the trace tower, while $V_j\subset F_{j-1}$ lies in the absolute trace-zero hyperplane of $F_j$. On writing $L(x)=v$ the two addresses $\rho_{j-1}x$, $\rho_{j-1}(x+1)$ give a reciprocal pair whose relative trace is $\rho_{j-1}^{-1}(\rho_{j-1}+v)^{-1}$. The same quotient argument proves minimality directly for every $j$. This realization avoids finding the functional $\gamma$ and shares the archived field constants. Its particular address slices are part of the new construction.

## Explicit scalar recursion and its scope

The multiplicative norm of the denominator gives the stronger identity
$$
g_p(s',b)=\gamma^{-1}g_{p-1}(s')\big(\alpha+1+u(s')+b\big).
$$
Thus $g_p$ is the product of $p$ embedded affine field factors and fixed scalars in one tower. The full binary trace function of any fixed $c=c_0+c_1\alpha$ obeys
$$
\operatorname{Tr}_{E/2}(c g_p(s',b))
 =\operatorname{Tr}_{F/2}\!\left(\gamma^{-1}\,[c_0+c_1(u(s')+b)]g_{p-1}(s')\right).
$$
Here the coefficient of $\alpha$ in the product computes the relative trace. Every Boolean truth table on $p$ bits has exactly one such scalar coefficient $c$, by nondegeneracy of the absolute trace and the reciprocal basis.

With no extra carrier wires, a fixed binary coordinate change sends $g_s$ to $e_s$, and is paid by $O(m^2)$ elementary Cliffords. Thus a complete native reciprocal translation is equivalent to the full dirty indicator by one visit, preserving T-count, depth, error, clean count and additional work. The map $M:(s,y)\mapsto(s,(\alpha+s)y)$ has the property $M^\dagger X_1M:(s,y)\mapsto(s,y+g_s)$. The complete *out-of-place* multiplication XOR already has $O(1)$ T-depth, $O(m)$ T and dirty work, $O(m^2)$ elementary Cliffords and no clean work: use a bilinear algorithm of rank $O(m)$ for binary field multiplication (existence follows, for instance, from [Ballet, Curves with Many Points and Multiplication Complexity in Any Extension of Fq](https://doi.org/10.1006/ffta.1999.0255)). For each rank term, a Hadamard on the output bank converts the shear to a product of CCZ phases of three linear forms, with one returned private dirty phase mask per term. Evaluating each form through private-target CNOTs costs $O(m)$ Cliffords. Contributions from the fixed coefficient $\alpha$ are a linear map. Exhaustive search for a bilinear rank decomposition terminates if needed. The out-of-place shear by itself leaves an in-place operation unpaid. The wrapper below pays it from a complete indicator. The degree of the whole inverse translation is $p$: a binary linear combination of its coordinates realizes the point mass at zero, and each coordinate has at most $p$ input variables. Separate exact quadratic-gate synthesis still needs at least $\lceil\log_2p\rceil$ nonlinear layers.

For a particular fixed scalar, the degree can of course be smaller. The recursive trace formula by itself supplies no general native sublogarithmic method, and using it with an unknown running coefficient can reintroduce the original dirty-bank operation.

## In-place multiplication is equivalent at the original linear budget

Let $I$ be a complete dirty indicator for $p$ bits, with forward and actual reversed costs $(T_I,G_I,d_I,w_I)$ and full norm error $\delta$. In the reciprocal coordinates one use implements $T\leftarrow T+a^{-1}$ where $a=\alpha+s$, and one fixed $O(m^2)$ Clifford change of basis on each side pays the identification. To implement $A\leftarrow A+a^{-1}B$ on two other arbitrary $m$-bit banks, use the field-multiplication XOR $A\leftarrow A+T B$ before and after adding $a^{-1}$ to the dirty $T$, then undo that program change. All $T$ terms cancel and $T$ returns. The two source calls add at most $2\delta$ full error. The corresponding shear $B\leftarrow B+aA$ is directly available, since $a$ is affine in the address. Both types of product grid use the same binary bilinear-rank budget above.

Execute $B\leftarrow B+aA$, $A\leftarrow A+a^{-1}B$, $B\leftarrow B+aA$, and swap the two banks. The resulting ideal paired word is $U_a=M_a\otimes M_{a^{-1}}$, since its intermediate first bank is $a^{-1}B_{\rm old}$. It contains just two indicator visits. Frobenius $F:y\mapsto y^2$ on the first bank is a fixed binary linear permutation, hence Clifford. The field identity $F M_a F^{-1}=M_{a^2}$ gives
$$
(F\otimes I)U_a(F^{-1}\otimes I)U_a^\dagger=M_a\otimes I.
$$
In particular the entire second bank returns immediately, for arbitrary joint initial states. The complete operator error is at most $4\delta$ using the actual reverse of $U_a$. Charging all coordinate changes and products gives
$$
D(M)\le4d_I+O(1),\quad T(M)\le4T_I+O(m),\quad
G(M)\le O(G_I+m^2),\quad w(M)\le w_I+O(m).
$$
Conversely, the two-call word $M^\dagger X_1 M$ and the fixed basis changes implement the full dirty indicator to at most twice the multiplier error. The costs in this direction are twice the in-place T-count and depth, its same additional dirty width, and $O(m^2)$ further elementary Cliffords. Both directions tolerate native words that move the address between completed boundaries. These reductions preserve the original linear T and simultaneous dirty width and quadratic Clifford budgets, with no Cartesian splitting. In particular the existing exact logarithmic-depth dirty indicator supplies a complete exact field multiplier satisfying those native bounds. The first unpaid operation for a strict improvement is the same in either representation: an all-input in-place multiplier or a full indicator in $o(\log(p+2))$ depth.

There is also a direct norm descent independent of a supplied indicator. For $a=\alpha+x$ with $x=u(s')+b\in F$ and $c=\gamma\alpha'$, multiplication on the two coordinate halves is
$$M_a(z,w)=\big(xz+cw,\ z+(x+1)w\big).$$
First add $(x+1)w$ into $z$, then multiply $w$ in place by $N(a)=c+x^2+x=\gamma(\alpha'+s')$, then add $xz$ from the new $z$ into $w$ and swap. The norm operation is a fixed multiplication by $\gamma$ around one lower-level multiplier. Both external shears have constant native depth by the bilinear grid. This gives $O(p)$ depth, $O(m)$ T and arbitrary dirty work and $O(m^2)$ elementary Cliffords without a field inverse call or initialized workspace. The exact logarithmic bound above uses the independent established indicator construction.

The same unpairing applies to any table of $k$ nonzero field elements $a_i$ acting on an unrelated field of binary dimension $h$. Use an arbitrary $k$-bit program $T$ in the shearing grid for $(\sum_i T_i a_i)A$. Each of the $O(h)$ multiplication rank terms reads a fixed parity directly from $T$. One indicator toggle and its inverse around the two grids add $a_s A$ into the target and restore $T$. The selected reciprocal shear uses the same construction with $a_i^{-1}$. Three shears and a swap make the paired unitary, and the two paired calls in the Frobenius commutator return the second bank. This gives $D\le12d_I+O(1)$, $T\le12T_I+O(h)$, dirty work $w_I+O(k+h)$ and $O(G_I+hk+h^2)$ elementary Cliffords. Full error is at most $12\delta$. Thus a compiled table of $kh$ bits can drive a returned one-bank scalar action without a separate non-Clifford term per table coefficient. The linear-size multiplication rank and the Clifford-cost allowance are both used.

## The multiplier has a robust linear T-count floor

For $p\ge1$, every zero-clean implementation of this particular $M$ within full operator error $\epsilon<1/\sqrt2$ requires at least $2m+p$ native T or T-dagger gates, at arbitrary dirty width. Up to scalar, the only Pauli labels on the specified $p+m$ wires that $M$ conjugates to a signed Pauli are the $p$ address Z labels. Indeed, a Pauli shift by address $d$ and field word $w$ conjugates to address shift $d$ and a field shift, evaluated on output $(s,y)$, of
$$
\frac{\iota(d)}{a_s}y+(a_s+\iota(d))w,\qquad a_s=\alpha+\iota(s),
$$
where $\iota$ is the injective linear address embedding. If $d\ne0$ this depends on $y$; if $d=0$ and $w\ne0$ it depends on $s$. No choice of Pauli phases repairs a variable shift. With both shifts zero, an input field Z mask can be written as $(-1)^{\operatorname{Tr}(cy)}$. Its output field mask is $c/a_s$, which varies unless $c=0$. All $p$ address Z labels survive and every Pauli on the arbitrary identity helper factor survives.

For every excluded Pauli image and every signed Hermitian Pauli on the full physical register, either some computational column has the wrong destination (column distance $\sqrt2$) or the two diagonal signs differ on a column (distance $2$). A circuit within $\epsilon$ changes a Pauli image in operator norm by at most $2\epsilon$ and thus cannot acquire an exact surviving Pauli outside this subgroup. Each T gate reduces the dimension of the tracked Pauli-label space by at most one, by retaining the codimension-at-most-one subspace commuting with that gate's axis. Cliffords preserve it. On $w$ extra dirty wires the deficit is therefore at least $2(p+m+w)-(p+2w)=2m+p$. This is an exact constant in a necessary count bound, not an optimum leading constant. Compare the independent [indicator Pauli-nullity bound](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/INDICATOR_PAULI_NULLITY.md).
