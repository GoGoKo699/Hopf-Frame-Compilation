# A complete positive Haar frame in doubly logarithmic native T-depth

Let a real Hopf frame have the positive balanced rotation R at every node, with R=(1/√2)[[1,−1],[1,1]]. Put N=2^n. For each fixed L≥6 the complete prescribed real frame has initialized-isometry error at most 2^{-L}, one external clean qubit, and at most b arbitrary dirty qubits. At any b≥17(L+n+7) one circuit satisfies
$$
 T=O_L(\sqrt N+N/b),\qquad G=O_L(N),\qquad D_T=O_L(N/b^2+\log\log(n+4)).
$$
In fact, at any b≥P_L(n), for a fixed polynomial P_L, the circuit uses polynomially many gates and dirty qubits and has depth O_L(log log(n+4)). This improves the previous positive-balanced depth upper at polynomial and square-root width. It is an approximate full-frame result. The existing exact positive or signed balanced upper is still O(log(n+2)) at square-root width. Arbitrary input states, all marker columns and work return are included.

## A complete last-one query with short affine conjunctions

For h input bits X in left-to-right order let t(X) be the one-based position of its rightmost 1, and t(0)=0. Let H be an arbitrary activity bit and u an arbitrary s=ceil(log2(h+1))-bit target. The Fourier phase of u ↦ u XOR Ht(X), on tag character z, has sign given by the binary exponent
$$
 \sum_{j=1}^h H X_j\, (j\mathbin{\cdot}z)\,[X_{j+1:h}=0].
$$
Choose a finite binary field of size q=2^k, and one arbitrary k-bit seed word. For a computational seed a substitute the zero-test of the field polynomial
$$
 F_j(a)=\sum_{l=j+1}^h X_l a^{l-j-1}
$$
for the suffix test. A zero suffix is accepted for every seed. For a given nonzero suffix the false-accept set has size at most h−j−1. Thus, for every fixed H,X,z, the wrong signs occupy at most K=h² seeds, including possible cancellations between terms. This is a per-input bound on the complete single sign.

For each a0 and j, the contribution can be implemented by a sign controlled by H, X_j, the linear form j·z, k seed literals for a=a0, and k affine linear forms for the zero field coordinates of F_j(a0). Every coefficient is precomputed classically. This is a conjunction of at most 2k+3 affine controls. Apply a complete read-only conjunction XOR on a private dirty bit before and after its physical Z to realize that sign via the four-operation echo. Every physical public read of an affine form can be expanded into CNOTs to the same private target, with a private X for its constant. It changes neither the public computational bits nor the native depth. The exact read-only conjunction theorem has depth O(log(k+2)), safe O((k+3)^3) T-count and private dirty wires, and polynomially many Clifford gates even after expanding each form. Give all qh terms distinct private work, align their T layers and serialize their Clifford reads. Thus one seed-dependent phase costs O(log(k+2)) native T-depth and q poly(h+k) gates and dirty wires.

Apply the three-basis dirty-seed phase correction of the accompanying note, then bounded-clean promotion of the corresponding complete XOR. For clarity, the same correction can be implemented by recording the three signs coherently in constant many initially zero vote bits, applying the majority phase and undoing the whole recorder. An external binary probe multiplying the entire phase can be included as one more affine control; Hadamards on that probe then give a Boolean XOR and the zero-clean promotion theorem applies literally. Extract the sign with Z on a borrowed output before and after the query; finally sandwich the Fourier tag sign in Hadamards on its s physical wires. All auxiliary wires may be arbitrary after promotion, even during inactive H sectors. For fixed full error tau, q≥C(h+1)^4/tau² suffices including constant promotion and sign-extraction losses. The resulting complete last-one query and its actual inverse have
$$
 D_T=O(\log(2+\log(h+2)+\log(1/\tau))),\qquad T,G,w= q\,\mathrm{poly}(h+\log q).
$$
Here and below a finite field of suitable size can be constructed by terminating classical search. No efficient preprocessing assumption is used. For a fixed tau the counts and work are polynomial in h. The full operator guarantee also applies in superposition over H, X and z. Only the error contract, not exact return on the inactive sector by the approximate query, is needed in the next hybrid.

## One large protected stage followed by an exact small terminal

For large n use r=ceil(log2(n+1)), h=n−r and s=ceil(log2(h+1))≤r. Partition logical bits as upper X and lower Z of r bits. Compute H=[Z=0] into the external clean bit with the exact returned two-helper conjunction, depth O(log(r+2)). Reserve s original lower logical bits as the tag; they are zero only on the active sector. Use the stage of R80 §5,
$$
 F_H,\quad S_H(T),\quad B^\dagger,\quad F_H,\quad B
$$
in chronological order, followed by the actual inverse of the H computation. Here B=R^{⊗h} and the selected product S_H(T) applies R to each j with H=1 and T≤j. The tag masks have short read-only address (H,T), hence the exact paid native depth is O(log log(h+4)). The two conditioned involutions implementing R and B use fixed-length native words on different physical data targets. More precisely with C=S H_Had and V=C T C† one has (VZV†)Z=R, including its scalar. All control masks and their inverses are charged. [Protected stage and native masks](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/HOMOGENEOUS_MAGNITUDE_DEPTH.md)

With ideal F_H the word is exact on every column. On H=1 the input root and markers carry their rightmost-one index t. After the controlled rotations and B†, the suffix starting at t equals |1 0...0> for a nonzero marker, or the entire word is zero for the root. The rotated prefix does not affect t, so the second tag XOR clears the tag and B restores the selected column. On H=0 both tag operations and the selected product are identities, and the two B factors cancel for every occupied tag. The remaining r lower layers form a complete positive Haar frame on Z independent of X. Replacing both F_H occurrences by their certified complete approximants costs at most 2tau in initialized-isometry norm by a unitary hybrid. This includes leakage and possible failure to clear the temporary tag or H. The exact inverse of the H predicate and later operations preserve this error bound.

Use the previously proved exact positive balanced recursion for the r-bit terminal, or its direct constant-size base at bounded n. The polynomial-work positive branch in R80 §§5–8 costs O(log(r+2)) T-depth, independent of requested precision. Its absolute-width constant is absorbed by the polynomial workspace above. Use tau=2^{-L}/4. One large stage and one exact small terminal suffice; no error is summed over log-star many approximate stages. The result follows at polynomial workspace. When b is smaller than the polynomial required, the previous exact polynomial-count direct fallback with two returned helpers costs O(n log(n+2)) T-depth. For fixed L this is covered by O_L(N/b²) outside finitely many dimensions. Its polynomial gate counts fit the displayed square-root and linear bounds there. Increase constants for the finite small dimensions.

The same polynomial-work proof permits a known homogeneous sequence U_j=(V_j Z V_j†) Z with uniformly bounded native depth, T-count and Clifford count for each supplied one-site V_j, by using the exact R80 generalized-frame tag and masks with these actual words. A bare promise of arbitrary positive one-site angles does not supply such words with the required product error. At growing precision the explicit branch with q=Theta((n+1)^4 4^L) still has depth O(log(2+log(n+2)+L)) if its q poly(n+L) dirty and gate costs fit. The exact existing branch can be used independently at higher precision.

## Why arbitrary node signs are a full lookup problem

For an arbitrary Boolean table f on n−1 bits, change the matrix at each deepest node p from R to (−1)^{f(p)}R. This is a legal balanced pair of signed sine and cosine. All other nodes remain positive balanced. The last layer is therefore (D_f ⊗ I) times the positive last layer, and the entire signed frame equals (D_f ⊗ I) W_+. Thus a signed balanced frame compiler followed on its input side by the actual inverse of the positive Haar circuit supplies an arbitrary lookup sign, including full work return to the sum of the two approximation errors. One may treat the extra unconstrained logical target as borrowed. Conversely R80's diagonal sign gauge writes every signed balanced frame as two arbitrary Boolean signs surrounding the positive frame. Hadamards and an extra target admit conversions to addressed Boolean XOR, for example the sign of g(x,z)=z f(x) on n Boolean inputs. Hence a general signed extension already encompasses arbitrary Boolean-table signs, even when every rotation magnitude is the same. If both supplied gauges are Clifford phases, the positive result applies directly, and known bounded-depth gauges similarly add just their priced depth.

The accompanying check enumerates complete protected-stage matrices including inactive sectors and clean leakage, directly constructs every deepest-sign table through four logical qubits, and tests the finite-field last-one sign selection on all small words. These finite checks supplement the all-size proof.

## Dense, succinct sign tables

There is a broader concrete family of signed balanced frames with the same complete depth improvement. Suppose the two sign-gauge Boolean functions have polynomial-size, fixed-depth circuits over unbounded fan-in AND, OR, parity and NOT, with arbitrary nonuniform wiring (the class usually denoted AC⁰[2]/poly). This promise includes many dense tables. It suffices that the prescribed cosine and sine sign functions at each depth separately have such circuits with common fixed size exponent and depth, since the two gauges can then be formed within the same class.

The classical polynomial approximation is the Razborov–Smolensky method. [Algebraic circuit approximations, Lecture 12](https://www.cs.mcgill.ca/~hatami/comp531-F2022/files/Lectures.pdf)

For the needed pointwise randomized form, let $f$ have $p$ inputs, gate count $S$ and depth $D$ under this promise. For an OR gate with child values $b_i$, choose $r$ independent uniform binary linear forms $L_j$ in its input list and evaluate
$$
 1+\prod_{j=1}^r (1+L_j(b)).
$$
At zero this is exactly zero. At nonzero $b$ it errs with probability $2^{-r}$. Use De Morgan for AND, ordinary addition for parity and $1+b$ for NOT. Substituting these expressions through the circuit gives a distribution on multilinear polynomials over $\mathbb F_2$ of degree at most $\min(p,r^D)$. For each fixed input, union bound the events that any gate estimate on its true children is wrong. If none is wrong, the composed answer is correct by induction on the circuit DAG. Thus the failure probability for each input is at most $\delta$ once $r=\lceil\log_2(2(S+1)/\delta)\rceil$.

Choose a fixed native output tolerance $0<\tau<1/4$. For example let $\delta=c\tau^2/(p+1)$ and let $M$ be the first power of two at least $C(p+1)^2/\tau^2$. For absolute constants take $C=64/c$ and make $c>0$ sufficiently small for the three-basis correction and bounded-clean promotion constants. Independently sampling $M$ polynomials yields expected bad count at most $\delta M$ for each input. The multiplicative upper-tail bound (or its exponential-moment proof) makes the probability that count exceeds $2\delta M$ at most $\exp(-\delta M/3)$. Since $\delta M\ge64(p+1)$, the union over $2^p$ inputs is less than one. Fix one list with this simultaneous guarantee. The size-$M$ selector bad sets then have $K/\sqrt M\le 2\delta\sqrt M\le 2\sqrt{128c}\,\tau$. Exhaustive finite search for such a list is allowed; its evaluations and the true Boolean table are finite. No randomized execution, sampled classical bit, QRAM or supplied seed state appears in the emitted circuit.

For every seed label, expand its Boolean polynomial in squarefree monomials. Attach equality on the $k=\log_2 M$ dirty computational seed bits to each of its monomials. The parity of these conditioned terms is the selected polynomial, exactly. Each term has arity at most $k+\min(p,r^D)$, and the native read-only conjunction and phase echo above permit all of them to run in parallel on separate dirty helpers. The deterministic phase costs
$$
 D_T=O(\log(k+r^D+2)),\qquad
 T,G,w\le M\left(\sum_{i=0}^{\min(p,r^D)}\binom pi\right)\mathrm{poly}(p+k).
$$
The same bounds up to absolute constant factors hold for the corrected full sign, including private work return on every input. A phase probe or a joint XOR output can be included before promotion, as above. For fixed $\tau,D$ and $S=p^{O(1)}$ these estimates give $O(\log\log(p+4))$ T-depth and $\exp(O(\log^{D+1}(p+2)))$ counts and dirty width. This last quantity is $2^{o(p)}$ for the fixed circuit depth. More generally a polynomial-output-length XOR table with succinct bits is handled at once by compiling the parity of the output-character bits times their individual predicates. The Fourier-character trick also accepts an arbitrary occupied output word.

For completeness, let $e_{d,0}(u),e_{d,1}(u)$ give the sign bits on the two edges at each depth-$d$ prefix $u$. For an input leaf $x$, the exponent of the output sign gauge is
$$
 \bigoplus_{d=0}^{n-1}e_{d,x_{d+1}}(x_{1:d}).
$$
For an input marker with last one at $t$, the input sign exponent is the same path parity up to depth $t-2$, followed by $e_{t-1,0}(x_{1:t-1})\oplus e_{t-1,1}(x_{1:t-1})$. It is zero on the zero word. Choose between the $n$ candidate expressions using the exact Boolean tests $x_t\wedge\bigwedge_{k>t}\neg x_k$. Their combination and the output formula above have polynomial size and fixed depth using the allowed gates. Apply both gauge phases around the positive Haar circuit, each approximated to a fixed fraction of $2^{-L}$. For fixed gate exponent, circuit depth and $L$, the large-width compiler has $O(\log\log(n+4))$ T-depth and $2^{\mathrm{polylog}(n)}=2^{o(n)}$ counts and work. Thus it fits the simultaneous $\sqrt N$ T-count and dirty-width envelopes at square-root allocation. It also fits at every $b\ge\sqrt N/n$ after the usual fixed-parameter dimension cutoff. On narrower allocations R80's exact signed balanced bound $O(N/b^2+\log(n+2))$ reduces to $O(N/b^2)$ since there $N/b^2>n^2$. Both branches give the claimed all-width tradeoff with constants also depending on the fixed signed circuit depth and size exponent. The per-node promise concerns Boolean computation of the two signs; no small-support assumption is made.
