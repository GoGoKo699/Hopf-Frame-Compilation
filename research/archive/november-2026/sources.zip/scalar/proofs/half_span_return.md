# Full work return bounds the span of all native T axes

The result applies to unrestricted coherent Clifford+T circuits with arbitrary Clifford interlayers. For a word of $t$ T or T-dagger gates on arbitrary physical wires, move all Cliffords to the output and write the chronological non-Clifford part as rotations $e^{\pm i\pi P_i/8}$ about Hermitian Paulis. Scalars are immaterial below. Write $v$ for the binary dimension of the span of these Pauli labels. For complete $p$-bit Boolean phases with $a$ clean qubits and arbitrary dirty width, full error below $2\sin(\pi/16)$ implies
$$
v\le\lfloor t/2\rfloor+p+a.
$$
For unrestricted complete frames on $n$ qubits at any error $0\le\epsilon\le 1/2$, the corresponding bound is $v\le t/2+O(n+a+1)$. The operator may redistribute information across every wire during the computation.

## One stabilizer-to-stabilizer matrix element

Let $|S\rangle$ be a pure stabilizer state on all physical qubits together with any references, and extend every physical rotation by identity on the references. For each physical Pauli record its binary vector of anticommutations with a full independent generating set of the stabilizer of $|S\rangle$. Denote the rank of the $t$ resulting syndrome columns by $r$. For any pure stabilizer $|B\rangle$ on the same space, set $c=\cos(\pi/8)$. Then
$$
|\langle B|U|S\rangle|\le \min(1,c^{2r-t}).
$$

Conjugate by a Clifford so the input is the all-zero state. The syndrome of a Pauli is now its binary X component. Call index $i$ a pivot if its X component is independent of all previous components. Retain all $r$ pivot rotations. For each of the other $t-r$ rotations use the exact expansion
$$
e^{\pm i\pi P/8}=\frac{I+e^{\pm i\pi P/4}}{2c}.
$$
The two terms are Clifford operators. For each branch push all the chosen Cliffords forward to the output. A previously chosen rotation through angle $\pm\pi/4$ transforms any later Pauli label by adding zero or its own label. Consequently the X component of each later axis changes only by an element of the earlier X span. A transformed nonpivot remains in its original earlier span, and the $r$ chronological pivot images have independent X components on every branch. This argument holds inductively even when several prior labels have been transformed.

Expand the $r$ remaining rotations in Pauli powers. Each binary subset $u$ of the pivot axes reaches its own computational basis vector, by independence. An invertible binary coordinate map sends those images to $|u,0\rangle$. Each Pauli factor contributes a local fourth-root phase; collecting its signed X/Z parts through earlier factors gives a Boolean quadratic sign in $u$. A diagonal Clifford absorbs these phases. The resulting state is therefore Clifford-equivalent to $(c|0\rangle+s|1\rangle)^{\otimes r}$ and stabilizer spectators, with $s=\sin(\pi/8)$.

For clarity, its overlap with any stabilizer is bounded by $c^r$. Projecting spectators onto zero either kills a stabilizer or gives an unnormalized stabilizer on the first $r$ qubits of norm at most one. A normalized stabilizer has constant-magnitude amplitudes on a binary affine subspace $A$ of dimension $k$. Choose $k$ information-set coordinates on $A$. Since $s/c=\sqrt2-1<1$, the magnitude sum is bounded by
$$
2^{-k/2} c^r\sum_{u\in A}(s/c)^{|u|}
\le 2^{-k/2}c^r(1+s/c)^k=c^r.
$$
The triangle inequality over the $t-r$ expanded rotations costs $c^{-(t-r)}$. This proves the matrix-element inequality. The exponent has the right dependence in the two extremal cases: $t=r$ independent X rotations achieve overlap $c^r$ with the all-zero input, and $t=2r$ paired inverse rotations can return exactly.

## A reference that witnesses every dirty direction simultaneously

Set the input to a computational logical basis vector and clean zeros, with each arbitrary dirty qubit in a Bell pair with an external reference. This is a stabilizer state allowed by the contract. The only physical Pauli labels (with identity on the reference) that stabilize it up to sign are Z labels on logical and clean wires; a nonidentity dirty Pauli changes a Bell pair. The syndrome map restricted to the transported T-axis span therefore has nullity at most $p+a$ ($n+a$ for general frames).

For a scalar sign, the ideal output equals the same stabilizer up to phase. Full norm error $\epsilon$ implies overlap magnitude at least $1-\epsilon^2/2$. If $\epsilon<2\sin(\pi/16)$ this exceeds $c$, forcing the integer $2r-t\le0$. For any general frame the ideal output lies in a subspace of dimension $N=2^n$ with orthonormal stabilizer basis $|y,0,\mathrm{Bell}\rangle$. Actual projection success is at least $1-\epsilon^2$, so some such stabilizer has overlap at least $\sqrt{(1-\epsilon^2)/N}$. Thus
$$
2r-t\le\frac{n-\log_2(1-\epsilon^2)}{2\log_2(1/c)}.
$$
This proves both physical-span bounds.

## Counting arbitrary tables and the full frame

The input logical Pauli generators and output Pauli measurements, together with the clean input generators, add $h=O(n+a)$ signed boundary axes to the transported word. They cost $ht+O(h^2+t+1)$ bits beyond the binary Gram of its T axes. The existing radical-freezing and signed Gram argument of [Joint native words, Section 3](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/endpoint/JOINT_NATIVE_WORDS.md) applies. More explicitly, include both input X,Z on the logical and clean wires so the radical of the augmented Pauli span can act only on the dirty wires. Choose one joint character of its commuting Hermitian generators and the normalized mixed dirty state on that sector. After quotienting by that radical, the Gram of all listed axes determines all abstract Pauli labels up to a common symplectic basis change and one sign per label. The chosen witness on the multiplicity factor is maximally mixed and all displayed operations act trivially on that factor. Every logical input density matrix and the clean-zero projector are polynomials in the included generators. The descriptor therefore determines the *entire reduced logical channel* for one allowed dirty witness, as well as its first-column output. It is unnecessary for the witnesses chosen for different circuits to coincide; each circuit must work for all dirty inputs.

Select $v$ independent physical axis labels among the $t$ rotations and encode the remaining labels in these coordinates, costing at most $v(t-v)$ bits. Flag selected indices in $t$ bits. Split the basis axes into the $d$ nonempty native T layers, with counts $v_j$ and $\sum v_j=v$. Only interlayer binary pairings need recording because same-layer axes commute. The layer partition costs at most $t$ bits, and the basis Gram costs at most $(v^2-\sum_j v_j^2)/2$ bits. This works even if the restricted form is degenerate. The T-axis Gram can then be reconstructed. Variable lengths $t'\le t$, signs and the partition cost $O(t+1)$ bits in total. Cauchy–Schwarz and the physical bound give
$$
vt-\frac{1+1/d}{2}v^2\ \le\ \frac{3-1/d}{8}t^2+O((n+a+1)t+(n+a+1)^2).
$$
Indeed for $v\le t/2$ the quadratic is increasing up to $t/2$ for all $d\ge1$. The permitted overshoot beyond $t/2$ is $O(n+a+1)$.

For scalar phases on $p$ inputs, the $2^{2^p-1}$ projective sign tables are pairwise perfectly distinguishable as channels: if the relative sign is nonconstant, take the superposition of two addresses on which it differs. Thus one common descriptor cannot represent two tables at full norm error below $1/2$. With $n=p$, this proves
$$
2^p-1\ \le\ \frac{3-1/d}{8}t^2+O((p+a+1)t+(p+a+1)^2).
$$
In particular the all-depth scalar count lower bound at fixed $a$ and the stated fixed accuracy is $(\sqrt{8/3}-o(1))2^{p/2}$.

For real frames at accuracy $2^{-L}$, $L\ge6$, pack the real sphere patch $\psi(x)=(\sqrt{1-\|x\|^2},x)$ over the $(N-1)$-dimensional ball of radius $1/2$. Its inner products are positive, its pure-state trace distance is at least $\|x-y\|/\sqrt2$, and a maximal $3\epsilon$-separated packing contains at least $(1/(6\epsilon))^{N-1}$ points by volume. All are valid first columns. The complete guarantee ensures first-column trace distance at most $\epsilon$ on the chosen witness, so
$$
 (N-1)(L-\log_2 6)\ \le\ \frac{3-1/d}{8}t^2+O((n+a+1)t+(n+a+1)^2).
$$
The independent combinatorial bound from charging only interlayer entries of the full $t\times t$ Gram gives the alternative coefficient $(1-1/d)/2$; take the minimum. At growing precision and $n+a=o(\sqrt{NL})$, approaching $(\sqrt{8/3}+o(1))\sqrt{NL}$ T gates would require $d\to\infty$. This is an unconditional depth/count tradeoff. At fixed accuracy and unspecified constants in the optimal-order T budget, the general frame depth gap remains open.
