# How native layer depth changes the leading counting bound

Let $t$ be T-count and $d$ the number of nonempty native T layers. The circuit may use any elementary Cliffords and arbitrarily many dirty wires, all subject to the complete-return contract. For $n$ system qubits and $a$ initialized qubits set $h=n+a+1$. Write $N=2^n$. For a worst-case complete real-frame compiler at error $2^{-L}$, $L\ge6$, simultaneous upper bounds $t,d$ imply
$$
(N-1)(L-\log_2 6)\le C_d t^2+O(ht+h^2).
$$
For all prescribed scalar signs on $p$ inputs and fixed error below $2\sin(\pi/16)$ the left side can instead be $2^p-1$, with $h=p+a+1$. In both cases the coefficients are
$$
C_1=C_2=0,\qquad C_3=11/72,\qquad C_d=3/8-1/(2d)\quad(d\ge4).
$$
These are upper bounds on description lengths and hence lower bounds on required resources. Tightness of the circuit tradeoff is open.

## Proof

The companion proof of the stabilizer transition bound gives $v\le t/2+O(h)$ for the dimension of the binary span of all transported physical T axes. The Gram matrix of their symplectic form has even rank $2r\le v$. On the quotient by its radical the axes form a spanning tuple in a nondegenerate $2r$-dimensional symplectic space. The Gram matrix determines this tuple up to symplectic isomorphism. The converse follows by pulling back the symplectic form. Two spanning tuples furnishing the same Gram have the same linear relations, since in a nondegenerate space orthogonality against a spanning set implies zero. The symplectic group acts freely on spanning tuples.

Suppose a layer contains $k$ gates. Its axes commute and are physically independent: before the common change of Clifford frame they are Z axes on distinct wires. They span an isotropic space in the physical span of dimension at most $v-r$ (radical dimension $v-2r$, quotient isotropic dimension at most $r$). Consequently
$$
r\le v-\max_j t_j\le t(1/2-1/d)+O(h).
$$
This remains true if some axes in different layers coincide. It is important to apply independence before passing to the quotient. Their *images* in the quotient need not be independent.

For an isotropic $k$-tuple in the quotient with span dimension $s\le\min(k,r)$, the number of possible containing $s$-spaces is
$$
\prod_{i=0}^{s-1}\frac{2^{2r-i}-2^i}{2^s-2^i}.
$$
Each factor in the numerator counts the next independent orthogonal vector and the denominator removes the number of bases. Multiplying the number of spaces by $2^{ks}$ bounds the choices of their $k$ coordinates. Taking logarithms gives at most $(2r+k)s-3s^2/2+O(s+1)$ bits. The leading quadratic is maximized at $s=\min(k,r)$ on the allowed interval. Thus a layer costs at most $2rk-g(k,r)+O(k+1)$ bits, where
$$
g(k,r)=
\begin{cases}k^2/2,&k\le r,\\rk-r^2/2,&k\ge r.\end{cases}
$$
The summation over possible $s$ adds at most $\log_2(k+1)\le k$ bits. The bound on denominators is uniform because $\prod_{j\ge1}(1-2^{-j})>0$.

Divide the resulting count of spanning tuples by $|\operatorname{Sp}(2r,2)|=2^{r^2}\prod_{j=1}^r(2^{2j}-1)$. This formula also follows by choosing a nonzero vector, a partner having symplectic pairing one, and continuing on their orthogonal complement. The group-order log is $2r^2+r+O(1)$. The total logarithmic Gram count is at most
$$
F(r)=2rt-2r^2-dg(t/d,r)+O(t+1).
$$
Here $g$ is convex in its first argument and the layer partition costs at most $t$ bits. A variable rank and variable word length also fit $O(t+1)$ bits.

For the leading term, $r\le t/4+O(h)$. If $d=2$ the physical independence condition improves this to $O(h)$; for $d=3$ it gives $t/6+O(h)$. The main term in $F$ is nondecreasing up to the indicated boundaries. Where $t/d\ge r$ its derivative is $t+(d-4)r$, and where $t/d\le r$ it is $2t-4r$. Shifting the endpoint by $O(h)$ costs at most $O(ht+h^2)$ in the upper bound (the derivative from above is at most $2t$). For $d=3$ the value at $t/6$ is $11t^2/72$. For $d\ge4$ the value at $t/4$ is $(3/8-1/(2d))t^2$. In one layer the Gram is zero. The coefficients are nondecreasing, so they apply also to all words of depth at most $d$.

The signed boundary axes for input preparation and output measurements add $O(ht+h^2)$ bits independent of dirty width. The reduced logical channel on a valid dirty witness and the packing of complete targets are established in the companion proof. In particular for arbitrary scalar signs the packing contains $2^{2^p-1}$ distinguishable phase channels. The full-frame high-precision consequence is $t\ge(\sqrt{8/3}-o(1))\sqrt{NL}$ if $L\to\infty$ and $h=o(\sqrt{NL})$. A family approaching that leading coefficient must have $d\to\infty$. At fixed precision the scalar bound, for example, requires at least $(\sqrt{72/11}-o(1))2^{p/2}$ gates for a three-layer universal compiler. A strictly growing T-depth lower bound with arbitrary constants in an $O(\sqrt N)$ T-count budget remains open.
