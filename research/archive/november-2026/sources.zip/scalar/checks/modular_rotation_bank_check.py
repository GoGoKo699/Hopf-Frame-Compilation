"""Exact integer fixtures for the dyadic rotation-bank and CRT identities."""
from itertools import product
from math import comb, lcm, prod
from random import Random

def subset_coefficient(bits, weights, bit_number, precision):
    cap = 1 << bit_number
    pol = 1
    mask = (1 << (cap + 1))-1
    for z, w in zip(bits,weights):
        if z:
            # (1+t)^w in the binary coefficient ring.
            for i in range(precision):
                if ((w % (1<<precision))>>i)&1:
                    pol = (pol^(pol<<(1<<i))) & mask
    return (pol>>cap)&1

def check_angles():
    rng=Random(1011)
    checked=0
    for height in range(1,7):
        for k in range(1,6):
            modulus=1<<k
            weights=[rng.randrange(modulus) for j in range(height)]
            for bits in product(range(2),repeat=height):
                for t in range(height+2):
                    active=[j+1>=t for j in range(height)]
                    signed=sum(a*z*(2*x-1) for x,a,z in zip(bits,weights,active))
                    input_bits=active+[(z and x) for x,z in zip(bits,active)]
                    encoded_weights=[-a for a in weights]+[2*a for a in weights]
                    result=sum(subset_coefficient(input_bits,encoded_weights,b,k)<<b for b in range(k))
                    assert result==signed%modulus
                    checked+=1
    return checked

def check_crt():
    rng=Random(12)
    checked=0
    for k in range(2,36):
        q=lcm(*range(1,k+1))
        assert q % comb(k,k//2)==0
        factors=[]
        rest=q
        for p in range(2,k+1):
            power=1
            while rest%p==0:
                power*=p
                rest//=p
            if power>1:
                factors.append(power)
        assert prod(factors)==q
        assert max(factors)<=k
        for _ in range(50):
            bits=[rng.getrandbits(1) for j in range(8)]
            weights=[rng.randrange(-q,q+1) for j in bits]
            exact=sum(x*w for x,w in zip(bits,weights))
            residues=[sum(x*(w%m) for x,w in zip(bits,weights))%m for m in factors]
            crt=sum(r*(q//m)*pow(q//m,-1,m) for r,m in zip(residues,factors))
            assert (crt-exact)%q==0
            checked+=1
    return checked

if __name__=='__main__':
    print(f'{check_angles()} weighted rotation bank words and {check_crt()} complete CRT reconstructions')
