"""Constructive binary tower, inverse basis and trace recursion; stdlib only."""
from random import Random

def solve_image(linear_columns, target):
    pivots={}
    for i, word in enumerate(linear_columns):
        coeff=1<<i
        while word:
            k=word.bit_length()-1
            if k not in pivots:
                pivots[k]=(word,coeff)
                break
            v,c=pivots[k];word^=v;coeff^=c
    coeff=0
    while target:
        k=target.bit_length()-1
        if k not in pivots:
            raise AssertionError('outside required image')
        v,c=pivots[k];target^=v;coeff^=c
    return coeff,len(pivots)

class Tower:
    def __init__(self,small=None,constant=0):
        self.small=small; self.constant=constant
        self.dim=1 if small is None else 2*small.dim
        self.mask=(1<<(self.dim//2))-1
        self.square_basis=None

    def mul(self,x,y):
        if not x or not y: return 0
        if x==1: return y
        if y==1: return x
        f=self.small
        a,b=x&self.mask,x>>f.dim
        c,d=y&self.mask,y>>f.dim
        ac=f.mul(a,c);bd=f.mul(b,d)
        return (ac^f.mul(self.constant,bd)) | ((f.mul(a^b,c^d)^ac)<<f.dim)

    def square(self,x):
        if self.square_basis is None:
            self.square_basis=[self.mul(1<<i,1<<i) for i in range(self.dim)]
        out=0
        while x:
            b=x&-x;out^=self.square_basis[b.bit_length()-1];x^=b
        return out

    def inverse(self,x):
        assert x
        out=1
        for _ in range(self.dim-1):
            out=self.mul(self.square(out),x)
        out=self.square(out)
        assert self.mul(out,x)==1
        return out

    def trace(self,x):
        # In the chosen quadratic basis the relative trace is the high coefficient.
        return (x>>(self.dim-1))&1

def main():
    rng=Random(319)
    f=Tower()
    alpha=1
    basis=[]
    old_g=[1]; old_s=[0]
    branches=0; scalar_cases=0
    for p in range(1,8):
        rows=basis+[alpha]
        gamma_columns=[
            sum(f.trace(f.mul(1<<j,row))<<i for i,row in enumerate(rows))
            for j in range(f.dim)]
        gamma,_=solve_image(gamma_columns,1<<(len(rows)-1))
        igamma=f.inverse(gamma)
        constant=f.mul(gamma,alpha)
        assert f.trace(constant)==1
        ext=Tower(f,constant)
        new_alpha=1<<f.dim
        ls=[f.square(1<<i)^(1<<i) for i in range(f.dim)]
        new_basis=[solve_image(ls,f.mul(gamma,b))[0] for b in basis]+[1]
        new_s=[0]
        for b in new_basis:
            new_s+=[z^b for z in new_s]
        assert len(set(new_s))==1<<p
        new_g=[]
        for i,x in enumerate(new_s):
            idx=i%len(old_s);b=i//len(old_s); u=x^b
            assert f.square(u)^u==f.mul(gamma,old_s[idx])
            v=f.mul(igamma,old_g[idx])
            g=ext.mul(v,new_alpha^1^u^b)
            assert ext.mul(g,x^new_alpha)==1
            for _ in range(2):
                c0=rng.randrange(1<<f.dim);c1=rng.randrange(1<<f.dim)
                lhs=ext.trace(ext.mul(c0|(c1<<f.dim),g))
                rhs=f.trace(f.mul(c0^f.mul(c1,x),v))
                assert lhs==rhs
                scalar_cases+=1
            # Norm descent, the three paired shears with arbitrary program, and
            # conjugation on just one field bank by the squaring Clifford.
            av=new_alpha^x
            z=rng.randrange(1<<ext.dim)
            w=rng.randrange(1<<ext.dim)
            mask=rng.randrange(1<<ext.dim)
            low=z&ext.mask;high=z>>f.dim
            new_low=low^f.mul(x^1,high)
            new_high=f.mul(constant^f.square(x)^x,high)^f.mul(x,new_low)
            assert (new_high|(new_low<<f.dim))==ext.mul(av,z)
            def paired(a,ia,q,b):
                b^=ext.mul(a,q)
                q^=ext.mul(mask,b)
                q^=ext.mul(mask^ia,b)
                b^=ext.mul(a,q)
                return b,q
            assert paired(av,g,z,w)==(ext.mul(av,z),ext.mul(g,w))
            q,b0=paired(g,av,z,w)
            # Reverse Frobenius: use a preimage known by choosing z as a square;
            # here implement directly with dim-1 Frobenius steps.
            for _ in range(ext.dim-1): q=ext.square(q)
            q,b0=paired(av,g,q,b0)
            assert (ext.square(q),b0)==(ext.mul(av,z),w)
            new_g.append(g);branches+=1
        half=len(new_g)//2
        assert all((new_g[i]^new_g[i+half])==f.mul(igamma,old_g[i]) for i in range(half))
        _,rank=solve_image(new_g,0)
        assert rank==1<<p==ext.dim
        f,alpha,basis,old_s,old_g=ext,new_alpha,new_basis,new_s,new_g
    print(f'{branches} optimal-dimension reciprocal branches, 508 scalar trace recurrences, paired/direct standalone multiplier checks and exact full ranks through p=7 verified')
    assert scalar_cases==508
def canonical():
    F=Tower();rho=1;V=[0];pairs=0
    for p in range(1,8):
        assert F.trace(rho)==1 and not any(F.trace(v) for v in V)
        E=Tower(F,rho)
        cols=[F.square(1<<j)^(1<<j) for j in range(F.dim)]
        roots=[solve_image(cols,v)[0] for v in V]
        theta=1<<F.dim
        new_rho=E.mul(rho,theta)
        new_V=[F.mul(rho,x^b) for b in [0,1] for x in roots]
        old=[F.inverse(v^rho) for v in V]
        vals=[E.inverse(new_rho^v) for v in new_V]
        assert solve_image(vals,0)[1]==E.dim==1<<p
        assert all(F.mul(rho,vals[j]^vals[j+len(old)])==g for j,g in enumerate(old))
        pairs+=len(old);F,rho,V=E,new_rho,new_V
        if p<=2:
            bank_bits=F.dim
            words=1<<(p+bank_bits)
            perm=[(i>>bank_bits)<<bank_bits | F.mul(rho^V[i>>bank_bits],i&((1<<bank_bits)-1)) for i in range(words)]
            inv=[perm.index(a) for a in range(words)]
            valid_shifts=[d for d in range(words) if len({perm[inv[i]^d]^i for i in range(words)})==1]
            assert valid_shifts==[0]
            valid_masks=[]
            for c in range(words):
                table=[(c&inv[i]).bit_count()%2 for i in range(words)]
                const=table[0]
                grad=sum((table[1<<j]^const)<<j for j in range(p+bank_bits))
                if all((const^((grad&i).bit_count()%2))==table[i] for i in range(words)):
                    valid_masks.append(c)
            assert valid_masks==[i<<bank_bits for i in range(1<<p)]
    print(f'{pairs} conjugate traces and all reciprocal ranks in the canonical repository tower passed')

if __name__=='__main__':
    main()
    canonical()
