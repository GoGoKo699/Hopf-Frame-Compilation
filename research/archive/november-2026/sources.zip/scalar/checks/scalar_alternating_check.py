"""Small numerical and exact checks for the alternating scalar table interface."""
import itertools
import math
import numpy as np

def rowrank(rows):
    pivots={}
    for row in rows:
        while row:
            i=row.bit_length()-1
            if i in pivots: row ^= pivots[i]
            else:
                pivots[i]=row
                break
    return len(pivots)

def rank_fixture():
    count=0
    for m in range(1,5):
        for code in range(1<<((m-1)**2)):
            rows=[0]+[sum(((code>>((i-1)*(m-1)+j-1))&1)<<j for j in range(1,m)) for i in range(1,m)]
            r=rowrank(rows)
            basis=[]
            for a in rows:
                if rowrank(basis+[a])>len(basis): basis.append(a)
            words={0:0}
            for i,z in enumerate(basis):
                words.update({w^z : b^(1<<i) for w,b in list(words.items())})
            w=(r+1)//2
            for i,j in itertools.product(range(m),repeat=2):
                a=words[rows[i]]
                b=sum(((z>>j)&1)<<t for t,z in enumerate(basis))
                # Encode lower half as X and upper as Z on rows; swap on columns.
                mask=(1<<w)-1
                ax,az=a&mask,a>>w
                bz,bx=b&mask,b>>w
                pairing=((ax&bz)^(az&bx)).bit_count()&1
                assert pairing==(rows[i]>>j)&1
            count+=1
    return count

I=np.eye(2); X=np.array([[0,1],[1,0]]); Y=np.array([[0,-1j],[1j,0]]); Z=np.diag([1,-1])
def kron(items):
    out=np.ones((1,1))
    for item in items: out=np.kron(out,item)
    return out

def majoranas(n):
    if n==1: return [np.ones((1,1))]
    w=(n+1)//2
    return [kron([Z]*(i//2)+[[X,Y][i%2]]+[I]*(w-i//2-1)) for i in range(n)]

def upper_fixture():
    count=0
    for m,codes in [(2,range(16)),(4,[0, 0x2330, 0x6a16, 0xffff]),(8,[0x83fec013eca91d20])]:
        for code in codes:
            for c in range(m.bit_length()):
                size=m//2**c
                gam=majoranas(size)
                eye=np.eye(len(gam[0]))
                expected=math.sqrt(2-2/math.sqrt(size))
                for v in range(m):
                    for u in range(m):
                        first=u//size*size
                        signs=[1-2*((code>>((first+j)*m+v))&1) for j in range(size)]
                        g=sum(a*sign for a,sign in zip(gam,signs))/math.sqrt(size)
                        assert np.allclose(g@g,eye)
                        delta=gam[u%size]@g-signs[u%size]*eye
                        assert np.allclose(delta.conj().T@delta,expected**2*eye)
                        count+=1
    return count

def distribution_fixture():
    rng=np.random.default_rng(348703)
    gam=majoranas(4)
    count=0
    for _ in range(18):
        p=rng.dirichlet(np.ones(4))
        columns=rng.integers(4,size=4)
        b=sum(math.sqrt(w)*np.kron(g,kron([Z if (z>>i)&1 else I for i in range(2)]))
              for w,g,z in zip(p,gam,columns))
        eye=np.eye(b.shape[0]);assert np.allclose(b@b,eye)
        for u in range(4):
            a=np.kron(np.eye(len(gam[0])),kron([X if (u>>i)&1 else I for i in range(2)]))
            for target in (0,1):
                bad=sum(float(w) for w,z in zip(p,columns) if ((u&int(z)).bit_count()&1)!=target)
                delta=a@b@a@b-(1-2*target)*eye
                assert np.allclose(delta.conj().T@delta,4*bad*eye)
                count+=1
    return count

if __name__=='__main__':
    print(f'{rank_fixture()} normalized sign tables with minimal-width Pauli factorizations')
    print(f'{upper_fixture()} sharp full-operator three-visit sector and clean-width cases')
    print(f'{distribution_fixture()} sharp approximate non-Pauli-column parity-distribution tests')
