"""Check the exact complete-frame angle recurrence and the all-angle bound."""
import math
from random import Random
import numpy as np

def rotation_stage(previous, angles):
    c,s=np.diag(np.cos(angles)),np.diag(np.sin(angles))
    return np.block([[c@previous,-s],[s@previous,c]])

def radius(d):
    a=0.
    for delta in d:
        a=(a+math.hypot(a,2*delta))/2
    return a

def check():
    rng=Random(914)
    exact=general=0
    worst=0.
    for n in range(1,7):
        for mode in ('level','arbitrary'):
            for trial in range(24):
                w,wp=np.eye(1),np.eye(1)
                phi=0.
                changes=[]
                for t in range(n):
                    size=2**t
                    angles=np.array([rng.uniform(-4,4) for _ in range(size)])
                    d=rng.choice([0.,.55,math.pi,math.pi/2]) if trial%9==0 else rng.uniform(0,2.5)
                    if mode=='level':
                        perturb=np.array([rng.choice([-d,d]) for _ in range(size)])
                    else:
                        perturb=np.array([rng.uniform(-d,d) for _ in range(size)])
                    w,wp=rotation_stage(w,angles),rotation_stage(wp,angles+perturb)
                    changes.append(max(abs(perturb)))
                    phi=phi/2+math.acos(max(-1,min(1,math.cos(changes[-1])*math.cos(phi/2))))
                dist=np.linalg.norm(w-wp,2)
                assert dist<radius(changes)+1e-10
                assert dist<=2*math.sin(phi/2)+1e-10
                if mode=='level':
                    error=abs(dist-2*math.sin(phi/2))
                    worst=max(worst,error)
                    assert error<1e-9
                    exact+=1
                else:
                    general+=1
    print(f'{exact} exact level-perturbation matrices and {general} arbitrary complete-frame metric bounds, max residual {worst:.2g}')
if __name__=='__main__':
    check()
