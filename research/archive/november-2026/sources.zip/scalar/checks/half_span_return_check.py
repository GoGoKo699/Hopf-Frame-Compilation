"""Finite tests of stabilizer return versus transported Pauli flip rank."""
from itertools import product
from math import cos, sin, pi, sqrt
from random import Random
import numpy as np

C, S = cos(pi/8), sin(pi/8)
rng = Random(20261119)

def rank(labels):
    pivots = {}
    for original in labels:
        v = original
        while v:
            bit = v.bit_length()-1
            if bit not in pivots:
                pivots[bit]=v
                break
            v ^= pivots[bit]
    return len(pivots)

def freeze(vec):
    index = int(np.argmax(np.abs(vec) > 1.e-8))
    state = vec * np.conj(vec[index])/abs(vec[index])
    return tuple((round(float(z.real),8),round(float(z.imag),8)) for z in state)

def stabilizers(n):
    dim=1<<n
    init=np.eye(dim, dtype=complex)[0]
    states, todo={freeze(init):init},[init]
    while todo:
        vec=todo.pop()
        for i in range(n):
            mask=1<<i
            inputs=np.arange(dim)
            bit=(inputs>>i)&1
            h=(vec*(1-2*bit)+vec[inputs^mask])/sqrt(2)
            sg=vec*np.where(bit,1j,1)
            outputs=[h,sg]
            for j in range(n):
                if j!=i:
                    outputs.append(vec[inputs^(bit<<j)])
            for new in outputs:
                key=freeze(new)
                if key not in states:
                    todo.append(new)
                    states[key]=new
    return np.stack(list(states.values()))

def amplitude_test(n, words):
    dim=1<<n
    states=stabilizers(n)
    assert len(states)=={1:6,2:60}[n]
    inputs=np.arange(dim)
    for axes in words:
        vec=np.eye(dim,dtype=complex)[0]
        for x,z,sign in axes:
            phase=(1j)**((x&z).bit_count()) * np.array([(-1)**((z&i).bit_count()) for i in range(dim)])
            vec=C*vec+1j*sign*S*(phase*vec)[inputs^x]
        max_overlap=np.max(np.abs(states.conj()@vec))
        bound=min(1,C**(2*rank([k[0] for k in axes])-len(axes)))
        assert max_overlap<bound+2e-8, (axes,max_overlap,bound)
    return len(words)*len(states)

a=[(x,z,1) for x,z in product(range(2), repeat=2) if (x,z)!=(0,0)]
small=[w for t in range(6) for w in product(a, repeat=t)]
b=[(x,z,sgn) for x,z in product(range(4), repeat=2) for sgn in (1,-1) if (x,z)!=(0,0)]
larger=[tuple(rng.choice(b) for j in range(rng.randrange(1,12))) for i in range(1200)]
larger+=list(product(b,repeat=2))
print(f'{amplitude_test(1,small)+amplitude_test(2,larger):,} stabilizer-transition amplitude bounds verified')

# The syndrome kernel for a physical Pauli on system, clean, dirty, and
# untouched Bell-reference, contains only system and clean Z labels.
for n,a,b in [(1,1,1),(2,0,2),(1,1,2)]:
    phys=n+a+b
    generators=[(0,1<<j) for j in range(n+a)]
    for j in range(b):
        both=(1<<(n+a+j))|(1<<(phys+j))
        generators.extend([(both,0),(0,both)])
    kernel=[]
    for x,z in product(range(1<<phys),repeat=2):
        fail=any(((x&zz).bit_count()+(z&xx).bit_count())&1 for xx,zz in generators)
        if not fail:
            kernel.append((x,z))
    assert kernel==[(0,z) for z in range(1<<(n+a))]
print('3 complete physical Pauli kernels with dirty Bell references verified')
