"""Enumerate finite symplectic tuples independently of the entropy bound."""
from collections import Counter
from fractions import Fraction
from itertools import product

def pair(x,y,r):
    mask=(1<<r)-1
    return (((x>>r)&y&mask)^((y>>r)&x&mask)).bit_count()%2

def rank(xs):
    basis={}
    for row in xs:
        while row and row.bit_length() in basis:
            row ^= basis[row.bit_length()]
        if row:
            basis[row.bit_length()]=row
    return len(basis)

def iso_count(r,k,s):
    value=Fraction(1)
    for i in range(s):
        value *= Fraction(2**(2*r-i)-2**i, 2**s-2**i)
    # onto maps from k coordinates to an s-dimensional space
    for i in range(s):
        value *= 2**k-2**i
    assert value.denominator==1
    return int(value)

def main():
    tested=0
    for r,maximum in ((0,3),(1,6),(2,4)):
        for k in range(1,maximum+1):
            ctr=Counter()
            for xs in product(range(1<<(2*r)),repeat=k):
                if all(pair(a,b,r)==0 for i,a in enumerate(xs) for b in xs[:i]):
                    ctr[rank(xs)]+=1
            assert all(ctr[s]==iso_count(r,k,s) for s in range(min(r,k)+1))
            tested+=(1<<(2*r))**k
    # Distinct full-span tuples realize each Gram equally often, once per Sp element.
    orbits=0
    for r,lengths in ((1,(2,2)),(1,(1,1,1)),(2,(2,2))):
        t=sum(lengths)
        ctr=Counter()
        for xs in product(range(1<<(2*r)),repeat=t):
            if rank(xs)!=2*r:
                continue
            pieces=[]
            start=0
            for length in lengths:
                pieces.append(xs[start:start+length])
                start+=length
            if not all(pair(x,y,r)==0 for block in pieces for j,x in enumerate(block) for y in block[:j]):
                continue
            gram=tuple(pair(x,y,r) for i,x in enumerate(xs) for y in xs[:i])
            ctr[gram]+=1
        group_order=2**(r*r)
        for j in range(1,r+1):
            group_order*=2**(2*j)-1
        assert ctr and all(size==group_order for size in ctr.values())
        orbits+=len(ctr)
    print(f'{tested:,} symplectic tuples checked and {orbits} full-span Gram classes matched exact group orders')
if __name__=='__main__':
    main()
