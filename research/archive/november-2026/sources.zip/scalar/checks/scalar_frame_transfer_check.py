"""Small exact fixtures for dual input/output packing and the terminal dimension bound."""
from itertools import product
from fractions import Fraction

def par(x):
    return x.bit_count() % 2

def make_layout(block_widths,splits):
    """Actual arrays have separate padded low/high banks per block."""
    offset=0
    low=[]
    high=[]
    for width,split in zip(block_widths,splits):
        low.extend(range(offset,offset+split))
        high.extend(range(offset+width,offset+width+width-split))
        offset+=2*width
    return low,high

def gather(x,slots):
    return sum(((x>>slot)&1)<<i for i,slot in enumerate(slots))

def scatter(x,slots):
    return sum(((x>>i)&1)<<slot for i,slot in enumerate(slots))

def table_row(prefix,splits,x,output_width):
    # Include a nonlinear, prefix-sensitive term.
    return ((x*13)^(x*x>>1)^(7*prefix)^(sum(i*k for i,k in enumerate(splits))+1))% (1<<output_width)

def check_dynamic():
    cases=0
    for widths in ((1,),(2,),(1,1),(1,2),(2,2)):
        for splits in product(*[range(q+1) for q in widths]):
            lo,hi = make_layout(widths,splits)
            assert len(lo+hi)==sum(widths) and len(set(lo+hi))==sum(widths)
            for ins,outs in ((lo,hi),(hi,lo)):
                for prefix in (0,1):
                    for public_word in range(1<<(2*sum(widths))):
                        full_output=scatter(table_row(prefix,splits,gather(public_word,ins),len(outs)),outs)
                        packed=gather(public_word,ins+outs)
                        inmask=(1<<len(ins))-1
                        val=table_row(prefix,splits,packed&inmask,len(outs))
                        assert par((packed>>len(ins))&val)==par(full_output&public_word)
                        cases+=1
    return cases

def check_walsh():
    cases=0
    for d in range(1,5):
        for row in range(1<<d):
            for x,y in product(range(1<<d), repeat=2):
                # H D_row H gives a literal permutation on every column.
                amp=sum((-1)**par(w&(row^x^y)) for w in range(1<<d))
                assert amp==(1<<d)*int(y==x^row)
                cases+=1
    return cases

def check_adversarial_record_model():
    # Sequential conditional error probabilities may depend on earlier votes.
    # Test precisely the k-error exponent rather than assume IID votes.
    tested=0
    p=Fraction(1,11)**2
    for k in (1,3,5,7,9):
        for mode in range(5):
            branches={():Fraction(1,1)}
            for i in range(k):
                out={}
                for votes,prob in branches.items():
                    wrong=p if ((sum(votes)+i+mode)%4)!=0 else p/3
                    out[votes+(1,)]=prob*wrong
                    out[votes+(0,)]=prob*(1-wrong)
                branches=out
            total=sum(prob for votes,prob in branches.items() if 2*sum(votes)>k)
            assert total<=2**k*p**((k+1)//2)
            tested+=1
    return tested

def check_oracle_span():
    # A one-visit preencoded response on q bits needs at least 2^q sites
    # for a coherent exact word loader. Walsh tables attain it when R=2^q.
    for k in range(1,7):
        dim=2**k
        rows=[[(-1)**par(v&j) for j in range(dim)] for v in range(dim)]
        for i in range(dim):
            for j in range(dim):
                assert sum(a*b for a,b in zip(rows[i],rows[j]))==dim*int(i==j)
    return 6

if __name__=="__main__":
    print(check_dynamic(),"ragged dual-input shear/erasure cases")
    print(check_walsh(),"literal full-word Fourier columns/entries")
    print(check_adversarial_record_model(),"history-dependent majority bounds")
    print(check_oracle_span(),"finite capacities attained by Walsh coding")
