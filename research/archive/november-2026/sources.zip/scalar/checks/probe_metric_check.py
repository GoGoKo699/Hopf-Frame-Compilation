"""Small Cayley-distance examples, including every tested and untested displacement."""
from collections import deque
from itertools import combinations
import math

def distances(masks, dimension):
    seen = {0: 0}
    queue = deque([0])
    while queue:
        x = queue.popleft()
        for mask in masks:
            y = x ^ mask
            if y not in seen:
                seen[y] = seen[x] + 1
                queue.append(y)
    return seen if len(seen) == 1 << dimension else None

def test():
    cases = 0
    for m in range(1, 5):
        candidates = range(1, 2**m)
        for n in range(m,min(m+2,len(candidates))+1):
            for masks in combinations(candidates,n):
                dist = distances(masks,m)
                if dist is None:
                    continue
                for y,ell in dist.items():
                    if not ell:
                        continue
                    for delta in (0.08,0.7,1.6):
                        step = min(2*math.asin(delta/2),math.pi/ell)
                        def commutator(mask):
                            return max(2*abs(math.sin(step*(dist[x^mask]-distance)/2))
                                       for x,distance in dist.items())
                        target = 2*math.sin(min(math.pi/2,ell*math.asin(delta/2)))
                        assert abs(commutator(y)-target) < 1e-12
                        assert all(commutator(mask) <= delta+1e-12 for mask in masks)
                        cases += 1
    print(f'{cases:,} sharp probe-error examples over all spanning small mask sets checked')
if __name__=='__main__':
    test()
