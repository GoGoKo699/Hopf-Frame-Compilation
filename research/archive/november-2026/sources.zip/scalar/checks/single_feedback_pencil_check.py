"""Exact determinant, nullity and graph checks over GF(2); Python 3.10+."""
from itertools import product
from random import Random
from fractions import Fraction

def mul(cols, word):
    ans=0
    while word:
        bit=word & -word
        ans ^= cols[bit.bit_length()-1]
        word ^= bit
    return ans

def rank(cols):
    piv={}
    for y in cols:
        while y:
            k=y.bit_length()-1
            if k not in piv:
                piv[k]=y
                break
            y ^= piv[k]
    return len(piv)

def anf(table,p):
    values=[(table>>i)&1 for i in range(1<<p)]
    for i in range(p):
        for j in range(1<<p):
            if (j>>i)&1:
                values[j]^=values[j^(1<<i)]
    return values

def compact(c,r,s,u,v):
    R,S=1<<r,1<<s
    cols=[1<<i for i in range(R+S)]
    for a in range(1,R):
        k=a.bit_length()-1
        if (u>>k)&1:
            cols[a] ^= 1<<(a^(1<<k))
    for a in range(1,S):
        k=a.bit_length()-1
        if (v>>k)&1:
            cols[R+(a^(1<<k))] ^= 1<<(R+a)
    for b in range(S):
        cols[R+b] ^= sum(c[a+(b<<r)]<<a for a in range(R))
    cols[0] ^= 1<<R
    return cols

def graph(table,r,s,u,v):
    R,S=1<<r,1<<s
    left=2*R-1
    adj=[0]*(left+2*S-1)
    for i in range(1,left):
        d=(i+1).bit_length()-2
        if ((u>>(r-1-d))&1)==((i+1)&1):
            adj[i] ^= 1<<((i-1)//2)
    for i in range(1,2*S-1):
        d=(i+1).bit_length()-2
        if ((v>>(s-1-d))&1)==((i+1)&1):
            adj[left+(i-1)//2] ^= 1<<(left+i)
    for a,b in product(range(R),range(S)):
        if (table>>(a+(b<<r)))&1:
            adj[left+S-1+b] ^= 1<<(R-1+a)
    adj[0] ^= 1<<left
    return adj

def check_orientation():
    rng = Random(31)
    cases = 0
    for ell in range(2,18):
        for _ in range(5):
            left = [Fraction(rng.randrange(1,6),rng.randrange(1,6)) for i in range(ell)]
            right = [Fraction(rng.randrange(1,6),rng.randrange(1,6)) for i in range(ell)]
            di = [a*b for a,b in zip(left,right)]
            weights = [Fraction(rng.randrange(1,8),rng.randrange(1,8)) for i in range(ell-1)]
            prefix = [Fraction(1)]
            for w in weights:
                prefix.append(prefix[-1]*w)
            product = Fraction(rng.randrange(2,6))
            bound = Fraction(0)
            for i in range(ell):
                for j in range(i):
                    x = prefix[i]/(prefix[j]*right[i]*left[j])
                    y = product/(product-1)*prefix[j]/(prefix[i]*right[j]*left[i])
                    assert x*y>=1/(di[i]*di[j])
                    bound += x+y
            assert max(di)*bound/ell >= ell-1
            cases += 1
    print(f'{cases} exact preconditioned open/closed clock orientation bounds')

def main():
    rng=Random(29); cases=0; truth=0
    for r,s in ((0,0),(0,1),(1,0),(1,1),(1,2),(2,2),(2,3),(3,3)):
        R,S=1<<r,1<<s
        tables=range(1<<(R*S)) if R*S<=8 else [rng.getrandbits(R*S) for _ in range(40)]
        for table in tables:
            c=anf(table,r+s)
            for u,v in product(range(R),range(S)):
                want=(table>>(u+(v<<r)))&1
                K=compact(c,r,s,u,v)
                assert len(K)-rank(K)==want
                adj=graph(table,r,s,u,v)
                K2=[(1<<i)^col for i,col in enumerate(adj)]
                assert len(K2)-rank(K2)==want
                cur=[1<<i for i in range(len(adj))]
                for _ in range(r+s+2):
                    cur=[mul(adj,x) for x in cur]
                assert (cur[2*R-1]>>(2*R-1)) & 1 == want
                squared=[mul(cur,x) for x in cur]
                assert rank(squared) == (r+s+2)*want
                assert [mul(squared,x) for x in squared] == squared
                # Remove the fixed bridge, then count root-to-root walks of length p+1.
                adj[0] ^= 1<<(2*R-1)
                paths=[0]*len(adj);paths[2*R-1]=1
                for _ in range(r+s+1):
                    paths=[sum(count for j,count in enumerate(paths) if (adj[j]>>i)&1)
                           for i in range(len(adj))]
                assert paths[0]==want
                z=rng.randrange(1<<len(K));w=rng.randrange(1<<len(K));delta=mul(K,z)
                assert w==(w^delta)^delta
                truth+=want;cases+=1
    print(f'{cases} paired ANF/directed-graph pencil branches, {truth} unique-cycle branches; exact ranks, actual root paths and XOR return passed')
if __name__=='__main__':
    main()
    check_orientation()
