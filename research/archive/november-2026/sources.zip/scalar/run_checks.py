from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
environment = os.environ.copy()
environment['OPENBLAS_NUM_THREADS'] = '1'
for check in sorted((root / 'checks').glob('*.py')):
    print(check.name, flush=True)
    subprocess.run([sys.executable, str(check)], cwd=root, env=environment, check=True)
