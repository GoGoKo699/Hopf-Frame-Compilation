"""Exact finite checks for the disjoint-triple source and Gaussian-readout bounds."""
from itertools import product
from random import Random


def parity(x):
    return x.bit_count() & 1


def sign(exponent):
    return -1 if exponent & 1 else 1


def check_address_degrees():
    # Three disjoint triples. The phase ratio of a Pauli on a basis input
    # is sufficient since it multiplies that input's original Pauli image.
    groups = [0b111 << (3*j) for j in range(3)]
    n = 9
    count = 0
    checked = set()
    for flip in (0, 1, 3, 6, 9, 11, 17, 69, 73, 153, 325, 511):
        touched = sum(bool(flip & group) for group in groups)
        for y in range(1 << n):
            address = 0
            for j, g in enumerate(groups):
                address |= (((y & g) == g) ^ (((y ^ flip) & g) == g)) << j
            vals = [sign(parity(address & s)) for s in range(8)]
            # Real multilinear integer coefficients.
            for j in range(3):
                for s in range(8):
                    if (s >> j) & 1:
                        vals[s] -= vals[s ^ (1 << j)]
            degree = max(s.bit_count() for s, c in enumerate(vals) if c)
            assert degree <= touched
            checked.add(degree)
            count += 1
    assert checked == {0, 1, 2, 3}
    for mode in range(3):
        assert sum(sign(((y & 7) == 7) ^ (((y ^ (1 << mode)) & 7) == 7))
                   for y in range(8)) == 4
    return count


def axes(rng):
    # A product of rational orthogonal Walsh matrices and integral signed
    # permutations. The result is an 8 by 8 scaled orthogonal matrix.
    matrix = [[int(i == j)*sign(rng.randrange(2)) for j in range(8)] for i in range(8)]
    den = 1
    for _ in range(3):
        rng.shuffle(matrix)
        matrix = [
            [sum(sign(parity(k & i)) * matrix[base + k][j] for k in range(4))
             for j in range(8)]
            for base in (0, 4) for i in range(4)
        ]
        den *= 2
    for i, row in enumerate(matrix):
        for j, other in enumerate(matrix):
            assert sum(a*b for a, b in zip(row, other)) == den**2 * (i == j)
    return matrix, den


def act_gamma(coeff, state):
    out = {}
    for y, amp in state.items():
        for j, a in enumerate(coeff):
            if not a:
                continue
            mode, odd = divmod(j, 2)
            bit = 1 << mode
            factor = sign(parity(y & (bit - 1)))
            if odd:
                factor *= 1j * sign(bool(y & bit))
            x = y ^ bit
            out[x] = out.get(x, 0) + amp * factor * a
    return out


def realify(matrix):
    n = len(matrix)
    return [
        [(int(matrix[i % n][j % n].real) if (i < n) == (j < n)
          else (1 if i >= n else -1) * int(matrix[i % n][j % n].imag))
         for j in range(2*n)]
        for i in range(2*n)
    ]


def determinant(matrix):
    # Bareiss elimination. All divisions are exact.
    rows = [row[:] for row in matrix]
    n = len(rows)
    den = 1
    orientation = 1
    for k in range(n - 1):
        if rows[k][k] == 0:
            j = next((i for i in range(k+1, n) if rows[i][k]), None)
            if j is None:
                return 0
            rows[k], rows[j] = rows[j], rows[k]
            orientation *= -1
        pivot = rows[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                numerator = rows[i][j] * pivot - rows[i][k] * rows[k][j]
                assert numerator % den == 0
                rows[i][j] = numerator // den
        den = pivot
    return orientation * rows[-1][-1]


def check_low_sector_witnesses():
    rng = Random(20261119)
    basis = [y for y in range(16) if y.bit_count() in (0, 2)]
    checks = 0
    for _ in range(16):
        g, den = axes(rng)
        for mode in (1, 2, 3):
            compressed = [[0j] * len(basis) for _ in basis]
            for col, y in enumerate(basis):
                b0 = act_gamma(g[0], act_gamma(g[1], {y: 1}))
                bs = act_gamma(g[2*mode], act_gamma(g[2*mode+1], {y: 1}))
                for row, x in enumerate(basis):
                    compressed[row][col] = 1j * (bs.get(x, 0) - b0.get(x, 0))
            for target in (-2, 2):
                matrix = [[c - (target * den**2 if j == k else 0)
                           for k, c in enumerate(row)] for j, row in enumerate(compressed)]
                assert determinant(realify(matrix)) == 0
                checks += 1
    return checks


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Use Python without -O.")
    print(f"{check_address_degrees()} signed address-degree tests on three private triples")
    print(f"{check_low_sector_witnesses()} exact two-sided extremal eigenvalue tests "
          "in the physical vacuum-plus-pairs sector of paired four-mode frames")
