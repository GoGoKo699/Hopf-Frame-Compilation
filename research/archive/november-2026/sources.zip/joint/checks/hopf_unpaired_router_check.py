"""All-input finite checks of unpaired dirty routing and three involutions over F2."""
from itertools import permutations, product


def apply(columns, word):
    result = 0
    for i, c in enumerate(columns):
        if word & (1 << i):
            result ^= c
    return result


def table(columns):
    return tuple(apply(columns, w) for w in range(1 << len(columns)))


def span_table(columns):
    return {apply(columns, w): w for w in range(1 << len(columns))}


def independent_basis(words):
    cols, span = [], {0}
    for v in words:
        if v not in span:
            cols.append(v)
            span |= {x ^ v for x in span}
    return cols


def projection_and_nilpotent(involution):
    n = len(involution)
    w = n.bit_length() - 1
    N = tuple(involution[x] ^ x for x in range(n))
    assert all(involution[involution[x]] == x for x in range(n))
    kernel = independent_basis(x for x in range(n) if N[x] == 0)
    cols = independent_basis(kernel + [1 << i for i in range(w)])
    assert len(cols) == w and cols[:len(kernel)] == kernel
    coords = span_table(cols)
    E = tuple(apply(cols, coords[x] >> len(kernel) << len(kernel)) for x in range(n))
    assert all(N[E[x]] == N[x] and E[N[x]] == 0 and E[E[x]] == E[x]
               for x in range(n))
    return E, N


def four_shears(E, N, a, b):
    b ^= E[a]
    a ^= N[b]
    b ^= E[a]
    a ^= N[b]
    return a,b


def cycle_reflections(cycles, width):
    r, t = list(range(width)), list(range(width))
    for cycle in cycles:
        for i,x in enumerate(cycle):
            r[x] = cycle[-i % len(cycle)]
            t[x] = cycle[(1-i) % len(cycle)]
    return tuple(1<<i for i in r), tuple(1<<i for i in t)


def permutation_tests():
    total = 0
    for w in range(1,6):
        for perm in permutations(range(w)):
            done, cycles = set(), []
            for i in range(w):
                if i in done:
                    continue
                cycle, current = [], i
                while current not in done:
                    done.add(current)
                    cycle.append(current)
                    current = perm[current]
                cycles.append(cycle)
            matrices = [table(c) for c in cycle_reflections(cycles,w)]
            factors = []
            for matrix in matrices:
                # Use the explicit sparse projection in each two-cycle (i,j).
                swaps = [(i, matrix[1<<i].bit_length()-1) for i in range(w)
                         if matrix[1<<i] > (1<<i)]
                def sparse(x):
                    return sum(((((x>>i)^(x>>j))&1)<<i) for i,j in swaps)
                E = tuple(sparse(x) for x in range(1<<w))
                N = tuple(x^matrix[x] for x in range(1<<w))
                assert all(N[E[x]]==N[x] and E[N[x]]==0 for x in range(1<<w))
                factors.append((E,N))
            ideal = table(tuple(1<<i for i in perm))
            for a,b in product(range(1<<w),repeat=2):
                x,y=a,b
                for E,N in factors:
                    x,y = four_shears(E,N,x,y)
                assert (x,y)==(ideal[a],b)
                total+=1
    return total


def cyclic_decomposition(M):
    """Small exhaustive choice of invariant cyclic summands; proof uses rational form."""
    def search(blocks,used):
        if len(used)==len(M):
            return blocks
        for seed in range(1,len(M)):
            if seed in used: continue
            local, basis = {0:0}, []
            v=seed
            while v not in local:
                basis.append(v)
                local=span_table(basis)
                v=M[v]
            if (set(local)&used)!={0}: continue
            c=local[v]
            assert c&1
            enlarged={x^y for x in local for y in used}
            ans=search(blocks+[(tuple(basis),c)],enlarged)
            if ans is not None: return ans
        return None
    blocks=search([],{0})
    assert blocks is not None
    return blocks


def factored_gl(M):
    blocks=cyclic_decomposition(M)
    basis = tuple(v for block,_ in blocks for v in block)
    coords = span_table(basis)
    width = len(basis)
    trans_cols = [1<<i for i in range(width)]
    cycles, offset=[],0
    for block,c in blocks:
        cycles.append(list(range(offset,offset+len(block))))
        trans_cols[offset]=c<<offset  # e_0 -> e_0+v=c, with c_0=1.
        offset+=len(block)
    r,t=cycle_reflections(cycles,width)
    factors=[]
    for cols in (r,t,tuple(trans_cols)):
        mat=tuple(apply(basis,apply(cols,coords[x])) for x in range(1<<width))
        factors.append(mat)
    assert all(factors[2][factors[1][factors[0][x]]] == M[x] for x in range(len(M)))
    return factors


def linear_tests():
    total, nmat, nblocks = 0,0,0
    for w in range(1,4):
        for columns in product(range(1,1<<w),repeat=w):
            M=table(columns)
            if len(set(M))!=len(M): continue
            mats=factored_gl(M)
            factors=[projection_and_nilpotent(m) for m in mats]
            for a,b in product(range(1<<w),repeat=2):
                x,y=a,b
                for E,N in factors:
                    x,y=four_shears(E,N,x,y)
                assert (x,y)==(M[a],b)
                total+=1
            nmat+=1
            nblocks+=len(mats)
    assert nmat==175 and nblocks==525
    return nmat,total


def selected_shear_tests():
    # Two arbitrary dense selected linear maps. Test actual dirty one-hot echo,
    # including the return of every arbitrary selector-bank content.
    matrices = [table((3,2,7)),table((7,1,5))]
    def grid(a,b,q):
        for i,M in enumerate(matrices):
            if q & 1<<i: b ^= M[a]
        return b
    total=0
    for s,q,a,b in product(range(2),range(4),range(8),range(8)):
        v=grid(a,b,q)
        changed=q^(1<<s)
        v=grid(a,v,changed)
        restored=changed^(1<<s)
        assert (v,restored)==(b^matrices[s][a],q)
        total+=1
    return total


if __name__=="__main__":
    if not __debug__: raise RuntimeError("Enable assertions")
    print(f"{permutation_tests():,} sparse unpaired permutation input/helper cases through 5 wires")
    n,c=linear_tests()
    print(f"all {n} GL maps through 3 wires; {c:,} complete unpaired input/helper cases")
    print(f"{selected_shear_tests():,} dense selected-shear full dirty echo cases")
