"""Exact checks for the two-shear encoder, two-pass identity and certificate bound."""

from itertools import product


def translate(w, a, m):
    return sum(((w >> i) & 1) << (i ^ a) for i in range(m))


def encode(a, b, r, m):
    a ^= translate(b, r, m)
    b ^= translate(a, r, m)
    return b, a


def inverse(x, y, r, m):
    b = x ^ translate(y, r, m)
    a = y ^ translate(b, r, m)
    return a, b


def thin_encoder():
    total = 0
    for p in (1, 2):
        m = 1 << p
        for r, s, a, b in product(range(m), range(m), range(1 << m), range(1 << m)):
            x, y = encode(a, b, r, m)
            assert inverse(x, y, r, m) == (a, b)
            after = encode(*inverse(x, y, r, m), r ^ s, m)
            assert after[0] == translate(x, s, m)
            # Applying the site-zero Pauli now gives the required phase.
            assert (after[0] & 1) == ((x >> s) & 1)
            again = encode(*inverse(*after, r ^ s, m), r, m)
            assert again == (x, y)
            total += 1
    return total


def compose(f, g):
    return tuple(f[i] for i in g)


def inv(f):
    return tuple(f.index(i) for i in range(len(f)))


def two_visit_identity():
    # Two differently conjugated bit-translation representations with
    # noncommuting fixed boundaries. Exact permutations, no floating point.
    aa = (2, 6, 5, 3, 1, 7, 4, 0)
    bb = (1, 3, 0, 2, 7, 4, 6, 5)
    cc = (5, 0, 1, 3, 6, 4, 2, 7)
    perm = (1, 6, 0, 2, 3, 5, 7, 4)
    ds = [tuple(i ^ s for i in range(8)) for s in range(8)]
    es = [compose(perm, compose(d, inv(perm))) for d in ds]
    rows = [compose(aa, compose(d, compose(bb, compose(e, cc)))) for d, e in zip(ds, es)]
    for t, u in product(range(8), repeat=2):
        rt = compose(aa, compose(ds[t], inv(aa)))
        lhs = compose(rt, compose(rows[u], compose(inv(rows[0]), inv(rt))))
        rhs = compose(rows[u ^ t], inv(rows[t]))
        assert lhs == rhs
    return 64


def certificate_check():
    # For fixed data monomial S only functions supported on S can appear.
    # Enumerate all such selector functions and test the degree bound directly.
    total = 0
    for p in (1, 2, 3):
        m = 1 << p
        for S in range(1, 1 << m):
            t = S
            while t:
                coeffs = [(t >> i) & 1 for i in range(m)]
                for j in range(p):
                    for i in range(m):
                        if i & (1 << j):
                            coeffs[i] ^= coeffs[i ^ (1 << j)]
                deg = max(i.bit_count() for i, c in enumerate(coeffs) if c)
                assert deg + S.bit_count() >= p + 1
                total += 1
                t = (t - 1) & S
    return total


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run without -O to enable the exact assertions.")
    print(thin_encoder(), "two-shear encoder and full occupation echoes")
    print(two_visit_identity(), "two-visit derivative identities")
    print(certificate_check(), "enumerated nonzero lookup certificate coefficients")
