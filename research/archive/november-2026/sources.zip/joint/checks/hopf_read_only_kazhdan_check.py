"""Exact finite tests for the read-only zero predicate and simultaneous row filter."""
from collections import Counter, deque
from itertools import permutations, product


def parity(x):
    return x.bit_count() & 1


def mat_vec(columns, x):
    out = 0
    for i, c in enumerate(columns):
        if x >> i & 1:
            out ^= c
    return out


def vec_mat(row, columns):
    return sum(parity(row & c) << i for i, c in enumerate(columns))


def transvections():
    h_group = []
    for columns in permutations(range(1, 8), 3):
        if len({mat_vec(columns, x) for x in range(8)}) == 8:
            h_group.append(columns)
    counts = Counter()
    for columns in h_group:
        inverse = tuple(next(x for x in range(8) if mat_vec(columns, x) == 1 << i)
                        for i in range(3))
        for i, j in permutations(range(3), 2):
            counts[columns[i], vec_mat(1 << j, inverse)] += 1
    assert len(h_group) == 168
    assert len(counts) == 21 and set(counts.values()) == {48}
    assert all(not parity(v & row) for v, row in counts)
    return tuple(counts)


def mod(f, modulus):
    while f.bit_length() >= modulus.bit_length():
        f ^= modulus << (f.bit_length() - modulus.bit_length())
    return f


def times(u, v):
    return mat_vec(tuple(u << i for i in range(v.bit_length())), v)


def times_mod(u, v, f):
    return mod(times(u, v), f)


def evaluate(poly, a, f):
    val = 0
    for i in reversed(range(poly.bit_length())):
        val = times_mod(val, a, f) ^ ((poly >> i) & 1)
    return val


def minimal_poly(a, f):
    h = f.bit_length() - 1
    return next(t for t in range(2, 1 << (h+1)) if evaluate(t, a, f) == 0)


def test_orbit(pairs):
    f, h = 0b1011, 3  # x^3+x+1
    zero = (0, 0, 0)
    for a in (2, 4, 6):
        field_table = tuple(times_mod(a, v, f) for v in range(1 << h))
        reached = {(1, 0, 0)}
        queue = deque(reached)
        while queue:
            values = queue.popleft()
            syndromes = tuple(mat_vec(values, j) for j in range(8))
            for column, row in pairs:
                added = field_table[syndromes[row]]
                image = tuple(v ^ (added if column >> i & 1 else 0)
                              for i, v in enumerate(values))
                if image not in reached:
                    reached.add(image)
                    queue.append(image)
        assert len(reached) == 511 and zero not in reached
    # For every assignment on the remaining seven data bits, |1>|-> gives a
    # difference involving two nonzero words with opposite amplitudes.
    for other in range(128):
        left, right = 4*other+1, 4*other+3
        assert left and right and left != right
        assert (1+(-1)) == 0
    return 3 * 511


def test_chinese_remainder():
    f = 0b100101  # x^5+x^2+1
    h = f.bit_length()-1
    a, b = next((a,b) for a,b in permutations(range(2,1 << h),2)
                if len({minimal_poly(v, f) for v in (a,b,a^b)}) == 3
                and all(minimal_poly(v,f).bit_length() == h+1 for v in (a,b,a^b)))
    samples = (a,b,a^b)
    polys = tuple(minimal_poly(x, f) for x in samples)
    cases = 0
    for i,x in enumerate(samples):
        separator = 0b10  # t imposes kernel at origin
        for j, poly in enumerate(polys):
            if j != i:
                separator = times(separator, poly)
        for desired in range(1 << h):
            q = next(q for q in range(1 << h)
                     if evaluate(times(separator,q), x, f) == desired)
            lift = times(separator,q)
            assert evaluate(lift,0,f) == 0
            assert [evaluate(lift,u,f) for u in samples] == [
                desired if j==i else 0 for j in range(len(samples))]
            cases += 1
    return (a,b), cases


def test_joint_ranks():
    # Diagonal projectors with several local ranks, including zero and full.
    dims = [2, 3, 4, 2]
    assignments = list(product(*(range(d) for d in dims)))
    count = 0
    for ranks in product(*(range(d+1) for d in dims)):
        single_defects = [0]*len(dims)
        for word in assignments:
            failures = [i for i,(u,r) in enumerate(zip(word,ranks)) if u >= r]
            base = not failures
            increments = [all(i==j for i in failures) and not base for j in range(len(dims))]
            assert sum(increments) <= 1
            for j, v in enumerate(increments):
                single_defects[j] += v
        assert sum(single_defects) <= len(assignments)
        count += 1
    return count


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run with Python assertions enabled.")
    axes = transvections()
    orbit_size = test_orbit(axes)
    embedding, lifts = test_chinese_remainder()
    ranks = test_joint_ranks()
    print("168 constant matrices; 1,008 Schreier terms; 21 distinct transvections")
    print(f"{orbit_size:,} nonzero orbit vertices checked across three field parameters")
    print(f"F32 joint embedding {embedding}; {lifts} elementary CRT coefficient lifts checked")
    print(f"{ranks} joint-projector rank profiles verified")
