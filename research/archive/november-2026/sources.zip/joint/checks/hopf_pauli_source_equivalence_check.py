"""Exact checks for Pauli-pulse universality and the indicator-to-encoder echo."""
from itertools import product

def permute(word,shift,m):
    return sum(((word>>i)&1)<<(i^shift) for i in range(m))

def convolution(a, t, m):
    result = 0
    for i in range(m):
        if t & 1<<i:
            result ^= permute(a,i,m)
    return result

def shear(a,b,t,r,m):
    b ^= convolution(a,t,m)
    t ^= 1 << r
    b ^= convolution(a,t,m)
    t ^= 1 << r
    return a,b,t

def encode(a,b,t,r,m):
    a,b,t=shear(a,b,t,r,m)
    b,a,t=shear(b,a,t,r,m)
    a,b,t=shear(a,b,t,r,m)
    return b,a,t

def run():
    p,m=2,4; words=range(1<<m)
    calls=0
    for r,t,a,b in product(range(m), words, words, words):
        ap,bp,tp=encode(a,b,t,r,m)
        assert (ap,bp,tp)==(permute(a,r,m),permute(b,r,m),t)
        assert encode(ap,bp,tp,r,m)==(a,b,t)
        for s in range(m):
            x,y,v=encode(ap,bp,tp,r^s,m)
            assert (x,y,v)==(permute(a,s,m),permute(b,s,m),t)
            assert (x&1)==((a>>s)&1)
            calls+=1
    return calls

def phase_embed():
    tested=0
    for arity in (2,3):
        for s,t0,t1 in product((0,1),repeat=3):
            for vals in product((0,1),repeat=2*arity):
                f0,f1=all(vals[:arity]),all(vals[arity:])
                a,b = t0^f0,t1^f1
                phase=s*(a^b)
                a^=f0; b^=f1
                assert (a,b,phase)==(t0,t1,s*(f0^f1)^s*(t0^t1))
                tested+=1
    return tested

if __name__=="__main__":
    if not __debug__:
        raise RuntimeError("Enable assertions")
    print(f"{run():,} complete two-bit bank-pair transport and occupation fixtures; {phase_embed():,} dirty Pauli-pulse embeddings")
