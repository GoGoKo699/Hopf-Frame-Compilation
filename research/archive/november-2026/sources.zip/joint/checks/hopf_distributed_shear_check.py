"""Exact basis checks for the pivot-free unitriangular occupation encoder.
All clock groups and source coefficient bits are arbitrary. Python 3.10+.
"""
from itertools import product
from random import Random


def submasks(word):
    current = word
    while current:
        yield current
        current = (current - 1) & word


def direct_y(p, z, c, t):
    value = z & 1
    for group in range(1, 1 << p):
        shifted = c[group] ^ (t if (z >> group) & 1 else 0)
        value ^= int(shifted & group == group)
    return value


def translate(p, y, s):
    return sum(((y >> i) & 1) << (i ^ s) for i in range(1 << p))


def phase_anf_transform(p, word):
    for j in range(p):
        for t in range(1 << p):
            if (t >> j) & 1:
                word ^= ((word >> (t ^ (1 << j))) & 1) << t
    return word


def encode(p, z, c, inverse=False):
    # Ascending target grade uses each source coefficient in its original state.
    groups = range(1, 1 << p)
    if inverse:
        z = phase_anf_transform(p, z)
    grades = range(1, p) if not inverse else range(p-1, 0, -1)
    for grade in grades:
        for t in groups:
            if t.bit_count() != grade:
                continue
            for s in groups:
                remainder = s ^ t
                if remainder and t & s == t and (c[s] & remainder) == remainder:
                    z ^= ((z >> s) & 1) << t
    z ^= sum(c[s] & s == s for s in groups) & 1
    return z if inverse else phase_anf_transform(p, z)


def pulse(p, z, c, selector):
    return [initial ^ (selector & group if (z >> group) & 1 else 0)
            for group, initial in enumerate(c)]


def cells(p, clockword):
    out = [0] * (1 << p)
    for s in range(1, 1 << p):
        for j in range(p):
            if (s >> j) & 1:
                out[s] |= (clockword & 1) << j
                clockword >>= 1
    return out


def test_point(p, z, c, selectors):
    y = encode(p, z, c)
    assert encode(p, y, c, inverse=True) == z
    assert y == sum(direct_y(p, z, c, t) << t for t in range(1 << p))
    for s in selectors:
        shifted = pulse(p, z, c, s)
        y1 = encode(p, z, shifted)
        assert y1 == translate(p, y, s)
        # Actual inverse and phase recovery on every spectator.
        assert (y1 & 1) == (y >> s) & 1
        z1 = encode(p, y1, shifted, inverse=True)
        c1 = pulse(p, z1, shifted, s)
        assert encode(p, z1, c1) == y and c1 == c


def main():
    count = 0
    for p in (1, 2):
        m = 1 << p
        for clockword, z in product(range(1 << (p*m//2)), range(1 << m)):
            c = cells(p, clockword)
            test_point(p, z, c, range(m))
            count += m
    print(f"{count:,} exhaustive basis-state/selector cases at one and two bits")
    rng = Random(20261119)
    checks = 0
    for p in range(3, 7):
        m = 1 << p
        for _ in range(24):
            z = rng.getrandbits(m)
            c = [rng.getrandbits(p) & s for s in range(m)]
            selectors = {0, m-1, rng.randrange(m)}
            test_point(p, z, c, selectors)
            checks += len(selectors)
    print(f"{checks:,} full phase-and-return basis cases at three through six bits")

    # All coordinate polynomials, forward and inverse, using exact Mobius
    # transform over every input (p=2 has 8 arbitrary bits).
    for p in (1, 2):
        m = 1 << p
        width = m + p*m//2
        for inverse in (False, True):
            coeffs = [encode(p, raw & ((1 << m)-1), cells(p, raw >> m), inverse)
                      for raw in range(1 << width)]
            for bit in range(width):
                for raw in range(1 << width):
                    if (raw >> bit) & 1:
                        coeffs[raw] ^= coeffs[raw ^ (1 << bit)]
            degree = max(raw.bit_count() for raw, val in enumerate(coeffs) if val)
            assert degree == p
    print("exact forward and inverse logical ANF degree at p=1,2")

    folded_cases = 0
    for p in range(1, 6):
        m, big = 1 << p, 1 << (p+1)
        all_sites = (1 << big)-1
        for s in range(m):
            for dirty_clock in (0, 1):
                t = s | (dirty_clock << p)
                c = [rng.getrandbits(p+1) & k for k in range(big)]
                c[big-1] = (big-1) ^ t
                z = rng.getrandbits(big)
                logical = encode(p+1, z, c)
                after = encode(p+1, encode(p+1, logical, c, inverse=True)
                               ^ (1 << (big-1)), c)
                difference = logical ^ after
                assert difference == ((1 << t) ^ (all_sites if t == 0 else 0))
                target = rng.getrandbits(m)
                before = target ^ ((logical ^ (logical >> m)) & ((1 << m)-1))
                answered = before ^ ((after ^ (after >> m)) & ((1 << m)-1))
                restored = encode(p+1, encode(p+1, after, c, inverse=True)
                                  ^ (1 << (big-1)), c)
                assert restored == logical and answered == target ^ (1 << s)
                folded_cases += 1
    print(f"{folded_cases:,} complete folded-coefficient derivatives at p=1,...,5")


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run without -O to enable checks")
    main()
