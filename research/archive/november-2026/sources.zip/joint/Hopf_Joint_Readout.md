# Two address visits suffice for the complete occupied-bank readout

Hopf Frame Compilation · 19 November 2026 · Research note

A complete dirty indicator and a fixed encoder for **two address-controlled Pauli visits** have the same asymptotic depth question at polynomial discovery cost. This remains true when the original indicator temporarily overwrites its address, and when only a fixed nonzero full-operator accuracy is available. The external address in the new circuit controls only CNOTs. All the hard computation is in an address-independent encoder on arbitrary work. This gives a smaller gate to design and a necessity statement for the indicator route. The unrestricted complete-frame bound is still R96.

Two constructive tests accompany this reduction. An exact change of basis removes the previously exposed first-active-position pivot. Its forward and inverse Boolean degree drops from at least $2^p$ for the old pivot to exactly $p$ here. A second construction implements an approximate zero test in constant native T-depth while every tested address bit stays read-only, even when several tests overlap. Applying a single joint version of that filter produces a provably insufficient change on the full occupied bank. The details below distinguish what each construction buys.

## 1. A fixed encoder with a bare Pauli source

Let $m=2^p$, let $P_r$ translate the indices of an $m$-wire bank by $r\in\mathbb F_2^p$, and let $Z_s$ denote the single-qubit occupation sign at physical site $s$. The desired indicator $I_p$ maps $(s,Y,w)$ to $(s,Y+e_s,w)$ on all inputs. Equivalently, after fixed bank Hadamards its sector at $s$ is $Z_s$ with identity on all other wires. An error below is a full operator-norm error, including arbitrary occupied work and its return. Every implemented inverse is the actual reversed native word.

Allocate an arbitrary $p$-bit work register $r$. The external address visits it by $X_r^s$ using $p$ CNOTs. A fixed work unitary $V$ defines $K_s=V X_r^s V^\dagger$. If $K_s Z_0 K_s^\dagger$ is within $\eta$ of $Z_s$ uniformly, then it is already the desired phase word. It uses two such visits, four occurrences of $V$ or its adjoint and no T gates outside them. The common full error is at most $\eta$ by direct sum. At each requested fixed tolerance, $D_T(V)=o(\log(p+2))$ and $2^{O(p)}$ counts, gates and simultaneous width would give the required discovery-scale indicator.

**Converse.** Suppose an arbitrary indicator circuit on a private address $r$ has depth $d$, T-count $T_I$, elementary Clifford count $G_I$, extra dirty width $w_I$ and full error $\delta$. Borrow two $m$-bit banks $A,B$ and a dirty program bank $T$. The word
$$
 B\gets B+\sum_i T_i P_i A
$$
is a single shared-control bilinear phase grid with at most $m^2$ terms, a constant number of native T layers, and $O(m^2)$ T gates, Cliffords and private dirty bits. Hadamards on $B$ convert this shear to a product of CCZ phases. Private phase masks allow shared operands to be Clifford controls at the same T layer. Execute the grid, $I_p$ on $(r,T)$, the inverse grid and the actual $I_p^\dagger$. At zero error the difference of the two sums gives $B\gets B+P_r A$ while $r,T$ and the grid scratch return. The primitive and its inverse cost two $I_p$ visits. The complete circuit for one shear has error at most $2\delta$. No grid gate is interleaved with the original indicator. [Existing paid grid and paired permutation wrapper](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/PAIRED_PERMUTATION_ROUTING.md)

Use two of these shears, first $A\gets A+P_r B$ and then $B\gets B+P_r A$, followed by a fixed wire swap of the two banks. The result is the reversible basis map
$$
 V_*:(r,A,B)\longmapsto(r,P_r A,A+P_r B).
$$
The first output bank depends only on $A$ and $r$. Shifting $r$ by $s$ inside $V_*X_r^s V_*^\dagger$ always translates that first bank by $s$. Its spectator action consequently cancels in conjugation of $Z_0$. The compiled $V$ uses four indicator visits and has $\|V-V_*\|\le4\delta$, with the ideal extended by identity on program and scratch. Its complete two-visit occupation echo has error at most $16\delta$. Quantitatively,
$$
 D_T(V)\le4d+O(1),\quad T(V)\le4T_I+O(m^2),\quad
 G(V)\le4G_I+O(m^2)
$$
and the extra width is $w_I+O(m^2+p)$. There is no initialized clock or bank. This proves the converse uniformly over fixed requested tolerances and preserves the polynomial discovery budget. The three-shear version in the repository also works and translates both banks exactly. The new observation is the bidirectional depth comparison for the external two-Pauli circuit, including approximate full return. The [existing logarithmic indicator](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/NONUNIFORM_DIRTY_INDICATOR.md) already gives an unconditional $O(\log(p+2))$ native encoder here.

**The equivalence includes the cubic and quartic proposals in the forward direction.** Let $D_r$ be any efficiently implementable representation of $\mathbb F_2^p$ by work unitaries. Use its entire programmed circuit on the dirty clock, $F=\sum_r|r\rangle\langle r|\otimes D_r$. Then
$$
 F X_r^s F^\dagger=X_r^s\otimes D_s .
$$
Indeed the work factor on clock input $r$ is $D_{r+s}D_r^\dagger=D_s$. The spare translation cancels from occupation. Thus a successful fixed encoder fed by the cubic or quartic source yields one fed by bare CNOTs, with only the cost of a fixed programmed source added to the encoder. The physical sector input $s$ never enters this programmed $F$. A uniform full error $\xi$ in $F$ contributes at most $4\xi$ in the final two-visit word. This argument works in one direction without imposing a tensor equivalence between the *undilated* cubic, quartic and Pauli spectra.

**An exact test for a proposed seed.** For this bare Pauli source, an exact encoded site $L_0=V^\dagger Z_0 V$ cannot lie in level $p$ of the Clifford hierarchy (with Paulis at level 1). Exact singleton covariance and the group law give $L_{P_u\lambda}=X_r^u L_\lambda X_r^u$ for all encoded masks. A difference $L_\lambda L_{P_u\lambda}$ is the commutator of a Hermitian encoded mask with a physical Pauli. Such a difference lowers the hierarchy level by at least one, finishing with a scalar on taking a difference of a Pauli. Taking differences of the site mask successively in all $p$ independent directions gives the nonzero all-sites parity, which is traceless. This contradiction excludes level $p$. The bound is sharp for the seed: the explicit $V_*$ has encoded sign $(-1)^{A_r}$, of Boolean degree $p+1$, and a diagonal Boolean sign of degree $k$ belongs to hierarchy level $k$ by the same derivative calculation. A shallow sequence of native T layers with arbitrary Clifford interlayers need not stay in a correspondingly low hierarchy level. This test concerns the encoded observable and exact transport.

## 2. Can an arbitrary middle unitary bypass the encoder?

Suppose the only external selector dependence in a proposed full readout has the form
$$
 W_s=A D_s B E_s C,\qquad \|W_s-Z_s\|\le\epsilon ,
$$
where $D,E$ are exact representations on the work and the three fixed unitaries are unrestricted. Define $R_t=A D_t A^\dagger$. The two group laws give the exact identity
$$
 R_t (W_u W_0^\dagger) R_t^\dagger=W_{t+u}W_t^\dagger .
$$
For example write $W_sW_0^\dagger=R_s S_s$, where $S_s=A B E_s B^\dagger A^\dagger$ is another representation, and expand both sides. Replacing the two endpoints on each side now gives
$$
 \|R_t Z_u Z_0 R_t^\dagger - Z_{u+t} Z_t\|\le4\epsilon .
$$
Choose one address basis vector $u$ and use $t$ in its complementary $(p-1)$-dimensional coordinate space. The pairs $\{t,t+u\}$ are disjoint. Fixed matched CNOTs $M$ identify $Z_t Z_{t+u}$ with the individual occupation $Z_t$ of one output per pair. Hence $MA$ is a fixed weak encoder for the first source restricted to $p-1$ bits, with error at most $4\epsilon$, depth $D_T(A)$ and $O(m)$ extra Cliffords. The other bank wires remain arbitrary. The adjoint word gives the same constraint on the other end. Thus an arbitrary fixed middle operation cannot eliminate the occupation transport obligation in a two-visit word. In particular the previous cubic two-layer obstruction applies to an outside unitary of depth two at $p\ge85$ and $4\epsilon<\sin(\pi/8)/\sqrt2$. The one-layer diagonal-sign obstruction applies at $p\ge4$ and $4\epsilon<1/\sqrt2$. The changed arity does not create a free readout.

One representation visit cannot realize the unrestricted lookup at sufficiently small error. If $W_s=A D_s B$, then $W_{s+t}W_0^\dagger=W_sW_t^\dagger$. For independent $s,t$, $Z_{s+t}Z_0$ and $Z_sZ_t$ differ by two in operator norm. The four replacements give $\epsilon\ge1/2$ for $p\ge2$. These visit counts charge the supplied selector interface. The T-depth of the outside unitaries remains a separate, essential cost.

## 3. A returned single-bank permutation at the same asymptotic depth

There is also an explicit prescribed target for a compiler that prefers a conventional routing problem. The earlier paired permutation returns its auxiliary array after a layout/body/unlayout wrapper. The circuit here returns the auxiliary array immediately after applying any selected permutation on the principal bank.

Let the address select one of $m$ wire permutations on $w$ wires. Factor each permutation into two involutions. On a cycle indexed modulo its length, the two reflections $i\mapsto-i$ and $i\mapsto1-i$ compose to its one-step rotation. Compile the two selected involutions sequentially. For one such involution $J=1+N$ over $\mathbb F_2$, choose $E$ such that $EN=0$ and $NE=N$. For a transposed pair of coordinates choose
$$
 N(a,b)=(a+b,a+b),\qquad E(a,b)=(a+b,0).
$$
Both are zero on every fixed coordinate. With a separate arbitrary $w$-bit word $B$, execute
$$
 B\gets B+EA,\quad A\gets A+NB,\quad
 B\gets B+EA,\quad A\gets A+NB .
$$
After the second gate the principal word is $A+NB+NEA$. Applying $E$ to this gives $EA$ because $EN=0$, so the third gate restores $B$. The last cancels $NB$, leaving $JA$ with all of $B$ restored. Each expression is selected using the indicator/program difference in Section 1. Rows of $E$ and $N$ are sparse. All four shears preserve the address at completed boundaries and use only returned auxiliary work between calls.

For an arbitrary permutation, the resulting bounds are
$$
 D_T\le16d+O(1),\quad T\le16T_I+O(mw),\quad G\le16G_I+O(mw),
 \qquad w_{\rm extra}\le w_I+O(mw+m+w).
$$
The full error is at most $16\delta$. One involution, in particular $P_r$, uses eight indicator visits. With the repository's linear-size logarithmic indicator this is a standalone zero-clean $O(\log(p+2))$-depth selected permutation, including arbitrary dirty return. This improves the return contract of the paired wrapper. The reference preparation, small predicates and finite terminal word in the frame compiler retain their own depth charges. [Earlier paired contract](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/PAIRED_PERMUTATION_ROUTING.md) · [Frame stage and terminal ledger](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/QUERY_DEPTH_FRAME_TRANSFER.md)

The construction extends to table-selected invertible binary matrices on the same bank. For any involution $J=1+N$, $N^2=0$. Choose $E$ to project onto a complement of $\ker N$ along $\ker N$; then $EN=0$ and $NE=N$. Every invertible binary matrix is a product of three involutions. In rational canonical form each companion block is $(I+v e_0^\top)P_{\rm cycle}$ with $v_0=0$, since its nonzero constant coefficient is one. The first factor is an involution and the cycle takes two more. Combine simultaneous blocks, then conjugate all three factors by the fixed basis change for that particular table row. All these matrices are computed by ordinary terminating classical preprocessing. Hence 24 indicator visits suffice. A dense selected shear still needs only one private phase mask per table row and target coordinate because the other control is a fixed linear form in $A$. This gives $O(mw)$ grid T-count and dirty width, and $O(mw^2)$ elementary Cliffords in addition to the indicator costs. [Rational canonical form over a field](https://math.colorado.edu/~mayr/teaching/math6140spring25/PID2.pdf) Uniform full error is at most $24\delta$.

## 4. Removing the pivot and identifying the remaining cost

For each $S\subseteq[p]$ use one occupied coefficient bit $z_S$. For each $j\in S$ use an independent occupied bit $c_{Sj}$. In the Fourier basis on the latter bits the source shear is $c_{Sj}\gets c_{Sj}+s_j z_S$. The coherent source phase $(-1)^{\sum_{S,j\in S}s_j z_Sc_{Sj}}$ costs a constant number of T layers and $O(p2^p)$ gates and width. One can use the private phase grid, or obtain it by visiting the previous disjoint-pair cubic source before and after adding $z_S$ to each private stationary wire and undoing those CNOTs. Define the logical output word by
$$
 Y(t)=z_\varnothing+\sum_{\varnothing\ne S\subseteq[p]}
                   \prod_{j\in S}(c_{Sj}+z_S t_j),\qquad t\in\mathbb F_2^p .
$$
The source translates $Y(t)$ to $Y(t+s)$ identically on every input. At fixed $c$ the coefficients in the Boolean variable $t$ are
$$
 w_\varnothing=z_\varnothing+\sum_{S\ne\varnothing}\prod_{j\in S}c_{Sj},\qquad
 w_T=z_T+\sum_{S\supsetneq T}z_S\prod_{j\in S\setminus T}c_{Sj}\quad(T\ne\varnothing).
$$
Thus $F:(z,c)\mapsto(Y,c)$ is a full basis permutation. Apply the additions in increasing order of the nonempty target's size, with the constant correction computed separately, then use the fixed Boolean evaluation transform. It has a terminating exact circuit with $O(p^23^p)$ gates and $O(p2^p)$ width using returned multi-control scratch. The adjoint is its actual inverse.

Both $F$ and $F^{-1}$ have Boolean degree exactly $p$. Inverting the nonempty triangular system uses a sum over descending inclusion chains. The product on a chain from $S$ to $T$ uses $|S|-|T|$ clock factors; restoring the supplied coefficient adds at most one to the degree. The constant correction attains degree $p$. This is optimal for any complete equivariant basis relabeling of this shear. Choose an input whose output word is $e_0$. Along its orbit the physical input depends affinely on $s$, while its zero-site output is $[s=0]$. A quadratic reversible Boolean circuit for the encoder therefore still needs at least $\lceil\log_2 p\rceil$ nonlinear layers. Removing the old degree-$2^p$ pivot was a genuine gain. It does not give an upper bound below that logarithmic native-depth target.

The unpaid operation can be isolated with no source pulse. Toggling just $z_{[p]}$ displaces the output by $e_{1+c_{[p]}}+[c_{[p]}=1]\,\mathbf1$. This follows by subtracting the two top-cell products. In address length $p+1$, fold the two halves of this displacement onto one $2^p$-bit output using CNOTs. The two constant corrections cancel. Use the $p$ negated address bits and one independent arbitrary extra bit as the top clock, so the remaining displacement folds to exactly $e_s$. Copy before and after the $F X_{\rm top} F^\dagger$ operation, then reverse that operation, to restore every other occupied bit. Thus four uses of a full-norm approximation of $F$ of error $\delta$ would implement the complete dirty indicator to error at most $4\delta$. This gives a direct quantum synthesis target for the joint polynomial readout. A classical synthesis of its individual monomials retains the old scaling.

## 5. A constant-depth filter with a genuinely read-only address

The companion note constructs a zero-clean full-operator XOR test for $[x=0]$ with $O_\tau(1)$ T-depth and $O_\tau(p^3)$ counts and dirty wires at any fixed tolerance $\tau$. Every gate preserves the tested address bits and each T gate acts on private work. Ershov and Jaikin-Zapirain's property-(T) theorem supplies a uniform spectral gap for elementary matrices over $\mathbb F_2[t]$. The circuit evaluates finitely many generators at an address-dependent field element. At zero all generators are identity. At nonzero inputs they generate a transitive action on nonzero field vectors. Two temporarily prepared work bits put the entire remaining dirty state in the complement of the invariants. A fixed-point filter and bounded-clean promotion give a native, returned, read-only circuit. [Property (T) theorem](https://arxiv.org/abs/0809.4095) · [Fixed-point circuit and native rotation accounting](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/EXPANDER_ZERO_REFLECTION.md)

**Positive occupation result.** Suppose the unknown occupied word has weight at most $K$, allowing arbitrary coherent superpositions over all such words and entanglement with a reference. Give row $v$ a private dirty target $t_v$ and an approximate complete comparator $U_v$ for $s=v$. For the row use
$$
 U_v^\dagger CZ(Y_v,t_v) U_v CZ(Y_v,t_v).
$$
At $Y_v=0$ the complete row is identity exactly, even if its comparator has error. At $Y_v=1$ the row has error at most $2\delta$ from the required sign. All comparators are read-only on the same $s$; different row offsets are incorporated as affine constants inside the private shear. All output words $Y$ are preserved. Thus the full error on the whole promised subspace is at most $2K\delta$, including arbitrary dirty return. Taking $\delta=\tau/(2\max(1,K))$ yields **constant native depth at each fixed $K,\tau$**, independently of the address length and the positions of the occupied sites. It costs $O_{K,\tau}(m p^3)$ gates and dirty wires. This is a nontrivial occupied-bank phase on unknown data. Applying Hadamards would change the promise to its Fourier image, so it gives no all-input indicator.

There is also a growing-sparsity bound. Write $L'=1+\log_2(2\max(1,K)/\tau)$ for $0<\tau<1$. The fixed gap needs $O(L')$ visits, and the fixed-dimensional selector phase in each visit costs $O(L')$ T-depth at the necessary accuracy. The number of promoted clean bits is fixed across precisions. Hence the same parallel word gives $D_T=O((L')^2)$, $T,G=O(m(p^3 L'+(L')^2))$, and $O(mp^3)$ dirty wires. This uses the [uniform single-qubit rotation and precision accounting](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/EXPANDER_ZERO_REFLECTION.md#8-uniform-precision-and-complete-indicator-scope) with a different constant-size selector. For fixed $\tau$, $\log(K+2)=o(\sqrt{\log(p+2)})$ suffices for sublogarithmic depth on the promised input. On a general dense bank, per-test error $\delta$ alone only gives a row sum of order $m\delta$.

A fixed encoding into a polynomially enlarged sparse carrier cannot by itself remove this promise. For instance, suppose an occupation string of $m$ independent unbiased bits is encoded in a bank of length $M$ and weight at most $K$, along with spectators. Suppose each bit can be recovered with error probability at most $e<1/2$ from the sparse computational word alone, allowing an arbitrary classical decoder for each address. Measuring the whole word gives a random variable $C$ on at most $\sum_{j\le K}\binom Mj$ values, even if the encoding is quantum. The entropy chain rule and the binary error bound give $H(Y\mid C)\le m h_2(e)$, hence
$$
 \log_2\sum_{j\le K}\binom Mj\ \ge\ (1-h_2(e))m .
$$
For $M=\mathrm{poly}(m)$ and fixed $e<1/2$, this requires $K=\Omega(m/\log(m+2))$. This argument assumes that the decoder sees only the measured sparse carrier. Joint interference with the spectators is a different operation.

We also constructed a *single* common walk that has a size-independent gap for all $m$ rows together. It implements, to constant full accuracy, the reflection about
$$
 P_s=\prod_{v\ne s}J_v
$$
for commuting row-invariant projectors $J_v$. Write $P_*=\prod_v J_v$. The differences $P_s-P_*$ are mutually orthogonal projectors. Thus replacing this reflection by the address-independent one changes normalized rank by at most $1/m$ on the full address/work space. After $q$ ideal visits with address-independent work gates, the normalized Hilbert–Schmidt distance to the erased word $I_{\rm addr}\otimes W$ is at most $2\sqrt{q/m}$. This follows by telescoping ranks and bounding the norm of the final unitary difference by two.

For the desired occupation word the erased baseline is necessarily far away. Distinct physical $Z_s$ are orthogonal in normalized Hilbert–Schmidt inner product, so for any fixed unitary $W$ the mean squared distance is at least $2-2/\sqrt m$. Consequently
$$
 q\ \ge\ \frac{m}{4}\left(\max\{0,\sqrt{2-2/\sqrt m}-\epsilon\}\right)^2
$$
if the joint word has full error $\epsilon$. For approximated visits include their total replacement error on the left of the distance comparison, i.e. replace $\epsilon$ on the right by $\epsilon+\sum_j\delta_j$. This is a bound for circuits whose only selector access is through these joint product-projector reflections. A fixed number of bounded-clean code qubits changes the Hilbert–Schmidt comparison by at most a fixed dimension factor. The obstruction is quantitative even for an ideal filter with infinite precision.

An elementary check also rules out trying to make each low-degree generator literally trivial on all inputs with one value of the desired bit. If a nonzero Boolean polynomial $g(s,Y)$ is supported on $Y_s=1$, write it as $\sum_S g_S(s)Y^S$. At fixed $s$ every surviving monomial must contain $Y_s$, so $g_\varnothing=0$ and $\mathrm{supp}(g_S)\subseteq S$ (identifying $S$ with bank indices). A nonzero degree-$k$ polynomial on $p$ bits has weight at least $2^{p-k}$, by inducting on a top-monomial variable. Thus
$$
 \deg g\ \ge\ |S|+p-\lfloor\log_2|S|\rfloor\ \ge\ p+1
$$
for any nonzero coefficient. This is sharp via $[s=0]Y_0$. Complementing the bank gives the other bit value. This test concerns low-degree Boolean generator defects; other quantum subspaces and nontrivial dynamics on both bit values remain available.

One other joint architecture does have a scaling-level obstruction. Interleave $r$ visits to the original quartic source (disjoint work triples per visit, activated by individual address bits) with arbitrary fixed fermionic Gaussian or Pin unitaries. Following one physical Majorana at site zero, a visit takes grade $k$ to grade at most $5k$ and raises the real selector degree of each coefficient by at most $k$. Indeed each Majorana in a triple acquires a factor $1-2n_b n_c$; a grade-$k$ monomial sees at most $k$ distinct triples. Gaussian unitaries preserve grade. Thus the coefficient of the initial Majorana after the word has real polynomial degree at most $(5^r-1)/4$. Its ideal sign is negative only at address zero. Full error $\epsilon<1/\sqrt2$ gives a fixed gap between its value at zero and every nonzero address. Symmetrization and Markov's polynomial inequality give degree $\Omega_\epsilon(\sqrt p)$, hence $r=\Omega_\epsilon(\log p)$. The verification packet gives the constants and derivation. This excludes sublogarithmically many serial quartic visits even if dense Gaussian mixing is free. An unrestricted fixed Clifford can send a Majorana to a product of many Majoranas and leaves this model. [Polynomial inequality](https://www.cse.iitk.ac.in/users/rmittal/reports/5_approx.pdf)

## 6. Consequence for the final bound

With $N=2^n$, fixed frame accuracy $2^{-L}$ and $b=\Theta(\sqrt N)$ dirty wires, one external clean qubit gives the unconditional R96 bound $D_T=O_L(\log(n+2))$, with $T=O_L(\sqrt N)$ and $G=O_L(N)$. The general depth lower bound there is $\Omega(1)$. The conditional R98 transfer gives
$$
 D_T=O_L\big(N/b^2+d(2n+10)+\log\log(n+4)\big)
$$
for an eligible complete query envelope $d$. At each fixed requested error, fixed-exponent polynomial overhead in $2^p$ can be normalized by a constant balanced Cartesian split of the address, with the leaf tolerance reduced by a fixed factor. As usual, an approximate family needs a size exponent uniform across the precision rescalings used in that split or an explicitly compatible choice of split and precision. The equivalence in Section 1 preserves such a family, since it only changes the requested error by an absolute constant factor and adds $O(m^2)$ costs. The explicit current exact circuits meet the logarithmic benchmark. [R96](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/ALL_PRECISION_LINEAR_DEPTH.md) · [R98](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/QUERY_DEPTH_FRAME_TRANSFER.md) · [Approximate full-error transfer](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/APPROXIMATE_QUERY_FRAME_TRANSFER.md)

The next constructive question is whether a bank-moving, fixed quantum word can perform the top-column displacement of Section 4 jointly in $o(\log(p+2))$ native T-depth on every occupied input, or whether the regular-clock encoder of Section 1 can attain this depth. The latter target is logically equivalent to a faster full dirty indicator at the stated discovery cost. The two questions have different gate-level designs. A shallow synthesis of the displayed in-place triangular $F$ is sufficient. A useful first test for a joint spectral construction is whether its address-dependent part has substantial normalized Hilbert–Schmidt weight at fixed accuracy. The product of row-invariant projectors fails this test. Depth $O(\log\log(p+4))$ for the complete indicator would give $O_L(\log\log(n+4))$ for the complete frame at square-root width. No current construction in this note attains that bound.
