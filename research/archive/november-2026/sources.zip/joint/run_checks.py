from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for path in sorted((root / 'checks').glob('*.py')):
    print(f'Running {path.name}', flush=True)
    subprocess.run([sys.executable, '-B', '-S', str(path)], cwd=root, check=True)
