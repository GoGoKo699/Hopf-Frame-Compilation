# Hopf joint readout verification

Run `python run_checks.py` from the extracted directory using Python 3.10 or later. The six finite fixtures use the standard library. They check exact finite instances. The uniform spectral gap, work-return argument, depth bounds, and all-size obstructions use the proofs in the notes.

The two top-level notes give the main reduction, circuit resources, full operator contracts and dense-bank limitations. The appendices give details of the pivot-free evaluator and the fermionic restriction. The repository baseline is commit ae613bf8e8a38f6d0407c25910b83d69f01a2733.
