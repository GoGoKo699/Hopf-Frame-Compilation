#!/usr/bin/env python3
"""Small exact fixtures for the two-layer occupation obstruction. Standard library only.

Every Clifford matrix is recorded by its computational support and entry phases
in units of pi/4, modulo one common scalar. All its nonzero entries have one
magnitude. Native Clifford generators use exact root-of-unity arithmetic.
"""
from collections import deque
from itertools import combinations, product

N = 4                     # Two-qubit Hilbert dimension
ABSENT = -1
SITES = (0, 1)


def parity(word):
    return word.bit_count() & 1


def canonical(entries):
    shift = next(v for v in entries if v != ABSENT)
    return tuple((v - shift) % 8 if v != ABSENT else ABSENT for v in entries)


def plus_phase(a, b):
    """Return (phase, squared magnitude) for a sum of two equal-norm roots."""
    if a == ABSENT:
        return b, int(b != ABSENT)
    if b == ABSENT:
        return a, 1
    d = (b - a) % 8
    if d == 0:
        return a, 4
    if d == 4:
        return ABSENT, 0
    if d in (2, 6):
        return (a + (1 if d == 2 else -1)) % 8, 2
    raise AssertionError("Non-Clifford phase difference inside the Clifford BFS")


def after_clifford_gate(matrix, op):
    name, bit = op
    flag = 1 << bit
    if name == "H":
        entries, magnitudes = [], set()
        for y, x in product(range(N), repeat=2):
            a, b = matrix[(y & ~flag) * N + x], matrix[(y | flag) * N + x]
            if y & flag and b != ABSENT:
                b = (b + 4) % 8
            phase, magnitude = plus_phase(a, b)
            entries.append(phase)
            if magnitude:
                magnitudes.add(magnitude)
        assert len(magnitudes) == 1
        return canonical(entries)
    if name == "S":
        return canonical([ABSENT if m == ABSENT else (m + 2*bool((i//N) & flag)) % 8
                          for i, m in enumerate(matrix)])
    assert name == "CX"
    target = 1 << (1-bit)
    return canonical([matrix[(y ^ (target if y & flag else 0))*N+x]
                      for y, x in product(range(N), repeat=2)])


def after_pauli_gate(pauli, op):
    x, z, phase = pauli
    name, bit = op
    f = 1 << bit
    if name == "H":
        if x & z & f:
            phase = (phase + 2) % 4
        if bool(x & f) != bool(z & f):
            x, z = x ^ f, z ^ f
    elif name == "S":
        if x & f:
            z ^= f
            phase = (phase + 1) % 4
    else:
        tf = 1 << (1-bit)
        x ^= tf if x & f else 0
        z ^= f if z & tf else 0
    return x, z, phase


def all_two_qubit_cliffords():
    identity = tuple(0 if x == y else ABSENT for y, x in product(range(N), repeat=2))
    paulis = ((1,0,0), (2,0,0), (0,1,0), (0,2,0))
    table = {identity: paulis}
    queue = deque([identity])
    gates = [(name, bit) for name in ("H", "S", "CX") for bit in SITES]
    while queue:
        matrix = queue.popleft()
        tableau = table[matrix]
        for gate in gates:
            step = after_clifford_gate(matrix, gate)
            image = tuple(after_pauli_gate(p, gate) for p in tableau)
            if step in table:
                assert table[step] == image
            else:
                table[step] = image
                queue.append(step)
    assert len(table) == len(set(table.values())) == 11520
    return table


def conjugate_diagonal(matrix, phases):
    return canonical([ABSENT if matrix[y*N+x] == ABSENT else
                      (matrix[y*N+x] + phases[y] - phases[x]) % 8
                      for y, x in product(range(N), repeat=2)])


def axes_and_corrections(tableau, directions):
    changed = {}
    for i, sigma in enumerate(directions):
        if sigma == 0:
            continue
        x, z, phase = tableau[2+i]  # g Z_i g^-1
        if x or z not in (1, 2):
            return None
        j = z.bit_length() - 1
        if directions[j] == 0:
            return None
        assert phase in (0, 2)
        changed[j] = (sigma * (-1 if phase else 1) != directions[j])
    return changed


def test_two_qubit_axis_test():
    table = all_two_qubit_cliffords()
    total, positive = 0, 0
    for directions in product((-1, 0, 1), repeat=2):
        phases = [sum(sigma*((x>>i)&1) for i, sigma in enumerate(directions))
                  for x in range(N)]
        for matrix, tableau in table.items():
            conjugate = conjugate_diagonal(matrix, phases)
            changed = axes_and_corrections(tableau, directions)
            assert (conjugate in table) == (changed is not None)
            if changed is not None:
                correction = [2*sum(directions[j]*int(flag)*((y>>j)&1)
                                    for j, flag in changed.items()) for y in range(N)]
                predicted = canonical([ABSENT if val == ABSENT else
                                       (val + correction[i//N]) % 8
                                       for i, val in enumerate(matrix)])
                assert conjugate == predicted
                positive += 1
            total += 1
    print("Two-qubit projective Clifford group: 11,520 distinct exact phase matrices and tableaux")
    print(f"T-axis criterion: {total:,} Clifford/direction arrays; "
          f"{positive:,} exact quarter-turn corrections")


def anf_degree(table):
    coeffs = list(table)
    bit = 1
    while bit < len(coeffs):
        for k in range(len(coeffs)):
            if k & bit:
                coeffs[k] ^= coeffs[k ^ bit]
        bit <<= 1
    return max((i.bit_count() for i, coeff in enumerate(coeffs) if coeff), default=-1)


def features(w, high, n):
    # All features are packed into one Python integer. Its bit positions are
    # constant, w_i, all distinct pairs, and the high phase bit.
    r = 1 | (w << 1)
    i = n+1
    for j, k in combinations(range(n), 2):
        r |= (((w>>j)&(w>>k)) & 1) << i
        i += 1
    return r | (high << i)


def test_selector_lift():
    bits, wires = 4, 8
    width = 2*wires+1
    seeds = [0] + [1<<i for i in range(width)]
    seeds += [(1<<i)|(1<<j) for i, j in combinations(range(width), 2)]
    evaluation = [(v,0) for v in seeds] + [(0,1)]
    worst = 0
    word = (1<<wires)-1
    for w, high in evaluation:
        out = []
        for b in range(1<<bits):
            x, z, a0 = w & word, (w>>wires) & word, w>>(2*wires)
            phase = high
            for j in range(bits):
                if (b>>j)&1:
                    i,k = 2*j,2*j+1
                    phase ^= ((x>>i)&(x>>k)) & 1
                    z ^= (((x>>i)&1)<<k) | (((x>>k)&1)<<i)
            out.append(features(x|(z<<wires)|(a0<<(2*wires)), phase, width))
        # Möbius transform works componentwise on packed bit vectors.
        worst = max(worst, anf_degree(out))
    assert worst == 2
    print(f"Four independent CZ selectors: signed-Pauli lift has degree {worst} "
          f"on {len(evaluation):,} independent input feature points")


def test_diagonal_tail():
    # In the shear frame, I_i can contain X on its first native CZ endpoint
    # and Z on the other. The common commuting characters can be read at a
    # jointly arbitrary, fixed syndrome. Fixed affine re-encoding is allowed.
    p = 6
    examples = 0
    for syndrome in range(1<<(2*p)):
        out = []
        first, second = syndrome & 63, syndrome>>6
        for s in range(1<<p):
            moved = first ^ (s & second)
            value = parity(moved & 0b110101)
            value ^= parity(moved & 0b011101)*parity(moved & 0b101010)
            out.append(value)
        assert anf_degree(out) <= 4
        examples += 1
    print(f"Terminal diagonal-sign fixtures: {examples:,} fixed invariant syndromes")


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions to run these checks.")
    test_two_qubit_axis_test()
    test_selector_lift()
    test_diagonal_tail()
    print("All wall algebra checks passed.")


if __name__ == "__main__":
    main()
