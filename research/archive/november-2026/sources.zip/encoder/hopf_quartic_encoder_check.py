"""Exact checks for the quartic source and its polynomial-size weak encoder.

Place hopf_weak_encoder_check.py beside this file. Both use the standard
library. A physical cell has three bits in each of a, b, c. Hadamards on c
turn the selected quartic phase into c <- c + s*(a AND b) in each cell.
All cell coordinates and the parent encoder's spectator wires are occupied.
"""
from random import Random

from hopf_weak_encoder_check import check_two_bits_exhaustively, encode, translate


def parity(x):
    return x.bit_count() & 1


def cell_tables():
    # Sort the 27 stationary words with a&b=0 first. The high bit of the
    # rank is balanced and is zero on all 27 of those words.
    ordered = sorted(range(64), key=lambda v: bool((v & 7) & (v >> 3)))
    rank = {word: i for i, word in enumerate(ordered)}
    assert sum(not ((w & 7) & (w >> 3)) for w in ordered) == 27

    forward = [0] * 512
    for raw in range(512):
        station, c = raw & 63, raw >> 6
        a, b = station & 7, station >> 3
        step = a & b
        t = rank[station] >> 5
        # Complete the nonzero row l with l dot step=t to an invertible
        # linear change of c, retaining all three output bits.
        first = next(v for v in range(1, 8) if parity(v & step) == t)
        second = next(v for v in range(1, 8) if v != first)
        third = next(v for v in range(1, 8)
                     if v not in (first, second, first ^ second))
        ctrl = sum(parity(row & c) << j for j, row in enumerate((first, second, third)))
        # Distinguished pair (t,r) in the low two bits, 7 spectators above.
        forward[raw] = (t | ((ctrl & 1) << 1)
                        | ((rank[station] & 31) << 2) | ((ctrl >> 1) << 7))
    assert sorted(forward) == list(range(512))
    inverse = [0] * 512
    for raw, coded in enumerate(forward):
        inverse[coded] = raw
    return tuple(forward), tuple(inverse)


FORWARD, INVERSE = cell_tables()


def cell_shear(raw):
    return raw ^ (((raw & 7) & ((raw >> 3) & 7)) << 6)


def check_cells():
    count = 0
    for raw in range(512):
        coded = FORWARD[raw]
        t, r = coded & 1, (coded >> 1) & 1
        assert INVERSE[coded] == raw
        for s in (0, 1):
            moved = cell_shear(raw) if s else raw
            actual = FORWARD[moved]
            assert (actual & 3) == (t | ((r ^ (s * t)) << 1))
            assert INVERSE[actual] == moved
            assert (cell_shear(moved) if s else moved) == raw
            count += 1
    return count


def recode(rows, *, inverse=False):
    """Recode every nine-bit cell, frame the two principal bits, undo in reverse."""
    p = len(rows)
    new_rows = [list(row) for row in rows]
    if not inverse:
        new_rows = [[FORWARD[x] for x in row] for row in new_rows]
    first = tuple(sum((x & 1) << k for k, x in enumerate(row)) for row in new_rows)
    second = tuple(sum(((x >> 1) & 1) << k for k, x in enumerate(row)) for row in new_rows)
    first, second = encode(first, second, inverse=inverse)
    for j in range(p):
        for k, x in enumerate(new_rows[j]):
            value = (x & ~3) | ((first[j] >> k) & 1) | (((second[j] >> k) & 1) << 1)
            new_rows[j][k] = INVERSE[value] if inverse else value
    return tuple(tuple(row) for row in new_rows)


def occupation(rows):
    offset = (len(rows) - 1).bit_length()
    return sum((x & 1) << k for k, x in enumerate(rows[0][offset:]))


def physical_shear(rows, address):
    return tuple(tuple(cell_shear(x) if address & (1 << j) else x for x in row)
                 for j, row in enumerate(rows))


def check_echoes():
    rng = Random(744306)
    cases = 0
    for p in range(1, 8):
        m = 1 << p
        h = m + (p - 1).bit_length()
        for trial in range(40):
            rows = tuple(tuple(rng.randrange(512) for _ in range(h)) for _ in range(p))
            if trial % 4 == 0:
                # Force one entire principal a word to zero without fixing its
                # moving or spectator inputs, even for the widest instances.
                j = rng.randrange(p)
                masked = tuple(INVERSE[FORWARD[x] & ~1] for x in rows[j])
                rows = rows[:j] + (masked,) + rows[j+1:]
            original = recode(rows)
            assert recode(original, inverse=True) == rows
            y = occupation(original)
            for address in {0, m - 1, rng.randrange(m)}:
                moved = recode(physical_shear(rows, address))
                assert occupation(moved) == translate(y, address, m)
                # Apply a physical Z on the logical site's root wire.
                sign = occupation(moved) & 1
                returned = recode(physical_shear(recode(moved, inverse=True), address))
                assert returned == original and sign == ((y >> address) & 1)
                cases += 1
    return cases


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run without -O to enable exact assertions.")
    print(check_cells(), "local input/control cases, 512-column cell bijection and actual inverse")
    print(check_two_bits_exhaustively(), "two-bit input/address cases, all 20 principal bits; cell test covers arbitrary local spectators")
    print(check_echoes(), "complete nine-wire-cell native-target sign and return checks through p=7")
