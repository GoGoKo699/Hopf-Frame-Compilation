#!/usr/bin/env python3
"""Exact two-qubit sign-coset gap and monomial-face examples, standard library."""
from itertools import combinations, permutations, product

D = 4
SPACE = range(D)
ROOTS = (1, 1j, -1, -1j)


def pauli(x, z):
    phase = ROOTS[(x & z).bit_count() % 4]
    return tuple(tuple(phase * (-1)**((z & v).bit_count()) if w == v ^ x else 0
                       for v in SPACE) for w in SPACE)


def addterms(terms):
    return tuple(tuple(sum(c * t[w][v] for c, t in terms) for v in SPACE) for w in SPACE)


def multiply(a, b):
    return tuple(tuple(sum(a[w][k] * b[k][v] for k in SPACE) for v in SPACE) for w in SPACE)


def sign(a):
    return -1 if a else 1


def matrix_positive(a):
    # All entries and determinants are exactly representable Gaussian integers.
    if any(a[k][k].real <= 0 for k in SPACE):
        return False
    for size in (2, 3, 4):
        det = 0
        for perm in permutations(range(size)):
            term = sign(sum(perm[i] > perm[j] for i, j in combinations(range(size), 2)) % 2)
            for i in range(size):
                term *= a[i][perm[i]]
            det += term
        assert det.imag == 0
        if det.real <= 0:
            return False
    return True


def gap():
    # Set the first Pauli basis to computational Z by Clifford invariance,
    # absorb the initial Pauli into the second, and enumerate all relative
    # Pauli labels and quarter scalars. Each basis sign is fixed to + on
    # its first character; the relative scalar includes independent signs.
    ps = [pauli(n & 3, n >> 2) for n in range(16)]
    ident = ps[0]
    lagrangians = set()
    for a, b in combinations(range(1, 16), 2):
        def sp(l, r):
            return (((l & 3) & (r >> 2)).bit_count() + ((l >> 2) & (r & 3)).bit_count()) % 2
        if sp(a, b) == 0:
            lagrangians.add(tuple(sorted((a, b, a ^ b))))
    assert len(lagrangians) == 15
    total = equal = at_gap = 0
    for a, b, _ in lagrangians:
        A, B = ps[a], ps[b]
        AB = multiply(A, B)
        # Four times each joint-stabilizer eigenspace projector.
        proj = [addterms(((1, ident), (sign(u), A), (sign(v), B), (sign(u ^ v), AB)))
                for u, v in product((0, 1), repeat=2)]
        for h in range(0, 16, 2):
            H = addterms([(sign((h >> j) & 1), proj[j]) for j in SPACE])
            for P in ps:
                PH = multiply(P, H)
                for scalar in ROOTS:
                    M = tuple(tuple(scalar * val for val in row) for row in PH)
                    for f in range(0, 16, 2):
                        signs = [sign((f >> j) & 1) for j in SPACE]
                        # M=4B and F is diagonal. 4(F B+B† F)>0 iff ||F-B||<sqrt(2).
                        K = [[signs[w]*M[w][v]+signs[v]*M[v][w].conjugate()
                              for v in SPACE] for w in SPACE]
                        same = all(M[w][v] == (4*signs[w] if w == v else 0)
                                   for w, v in product(SPACE, repeat=2))
                        assert matrix_positive(K) == same
                        equal += same
                        at_gap += all(K[i][j] == 0 for i, j in product(SPACE, repeat=2))
                        total += 1
    assert at_gap
    print(f"Pauli times sign-algebra gap: {total:,} exact comparisons, {equal:,} equal, "
          f"{at_gap:,} with distance exactly sqrt(2) by vanishing anticommutator.")


def monomial_faces():
    total = 0
    for perm in permutations(SPACE):
        if any(perm[perm[v]] != v for v in SPACE):
            continue
        for phase in product(range(4), repeat=D):
            if any((phase[v] + phase[perm[v]]) % 4 for v in SPACE):
                continue
            # Arbitrary Hermitian monomial with quarter phases. Check every
            # independent pair of unconstrained diagonal signs (including repeats).
            for q, r in product(range(16), repeat=2):
                for start in SPACE:
                    v, t = start, 0
                    for h in (0, q, r, q ^ r):
                        out = perm[v]
                        t += phase[v] + 2*(((h >> v) ^ (h >> out)) & 1)
                        v = out
                    assert v == start and t % 4 == 0
                total += 1
    print(f"Four translates of a monomial involution: {total:,} exact two-qubit fixtures.")


if __name__ == '__main__':
    gap()
    monomial_faces()
