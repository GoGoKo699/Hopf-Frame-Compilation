# A two-T-layer obstruction for the cubic occupation source

Ruge Lin's Hopf Frame Compilation project · Research note · 19 November 2026

For the commuting cubic source defined below, any address-independent encoder with at most two native T layers has worst-address operator error at least $\sin(\pi/8)/\sqrt2$ once $p\ge84$. This holds for arbitrary circuit width, any number of T gates per layer, arbitrary intervening Cliffords and just **one** tested physical occupation. The proof uses the full dirty Hilbert space. The number 84 is a sufficient threshold from the proof.

A second result applies to every representation by diagonal signs, including frozen non-Clifford sources. At three or more address bits, an encoder of at most one native T layer has error at least $1/\sqrt2$. There is also a zero-clean exact encoder of polynomial size in the bank length for each of two explicit sources, with suitable multiplicities. Their shared pivot computation incurs a large depth cost. These results distinguish the resource that still needs a better construction. The strongest unconditional general frame depth continues to be R96.

## 1. Source, accuracy and the connection to frame depth

Let $m=2^p$. Index the $m$ physical bank qubits by $t\in\mathbb F_2^p$ and write $P_s e_t=e_{s+t}$ for translation of masks. The physical source on arbitrary work is
$$
 Q_s=\prod_{j=1}^p\left(\prod_\ell CZ_{a_{j\ell},b_{j\ell}}\right)^{s_j}.
$$
Identity spectators are allowed. For each frozen $s$, this is a Clifford. In the quantum circuit the selector is coherent. $Q_s$ is a literal representation, so $Q_sQ_t=Q_{s+t}=Q_tQ_s$ and $Q_s^2=I$. The argument also allows fixed changes of Clifford coordinates. The active multiplicities can vary with $p$.

For a fixed encoder $V$ put $L_\lambda=V^\dagger Z^\lambda V$, where $Z^\lambda$ acts only on the physical bank. The weak occupation requirement measures
$$
 \epsilon=\max_s \|Q_s L_{e_0} Q_s^\dagger-L_{e_s}\|_{\rm op}.
$$
Indeed, take $K_s=VQ_sV^\dagger$ and conjugate the physical $Z_0$ by $K_s$. On an exact implementation the answer is $Z_s$ on the bank tensored with identity on every other wire. Conjugating by bank-wide Hadamards gives the complete indicator $Y\mapsto Y+e_s$ with literal work return. On approximate implementations this word has the same full operator error. The source has an exact three-T-layer implementation. For a common control $c$ and private pair $u,v$, the modulo-eight identity for $4cuv$ uses the seven parity phases on $c,u,v,c+u,u+v,c+v,c+u+v$ with signs $+,+,+,-,-,-,+$. The three pairs $(u,v),(c+u,u+v),(c+v,c+u+v)$ each form reversible coordinates for fixed $c$. Combine all common-control phases on $c$. The masks for different private pairs are computed and undone by Cliffords. The full indicator therefore takes at most $4D_T(V)+6$ T layers, and uses the actual adjoints throughout.

**Theorem.** If $p\ge84$ and $V$ is a unitary zero-clean, at-most-two-T-layer circuit, then $\epsilon\ge\rho=\sin(\pi/8)/\sqrt2\simeq0.270598$. The theorem permits arbitrary input states on every work wire. It concerns the displayed source and conjugation interface. A third layer, a different source, and a direct indicator circuit all remain possible.

## 2. What exact transport forces on the inner T layer

Use the [R75 operator gap](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/FOUR_LAYER_OPERATOR_RIGIDITY.md). On the same full physical space two Hermitian Pauli images of depth at most two either agree or are separated in operator norm by at least $\rho$. For fixed $s$ both sides of the occupation test are such images. Thus $\epsilon<\rho$ gives exact transport at every site. By the group law, conjugating the site at $t$ gives the site at $s+t$. Multiplying these literal identities gives
$$
 Q_s L_\lambda Q_s^\dagger=L_{P_s\lambda}
 \qquad\text{for every mask }\lambda.
$$
This is where a single-site error bound buys an exact test of arbitrarily many occupied sites. Every nonzero mask gives a traceless Hermitian involution.

Factor $V=F E$, taking $E$ to be a Clifford conjugate of its source-facing T layer. Fixed boundary Cliffords are absorbed into $F$ or the choice of axes for $E$. $F$ has at most one T layer, so $C_\lambda=F^\dagger Z^\lambda F$ is a Hermitian Clifford for every mask. Indeed, a physical T layer sends a Pauli to a tensor product of one-qubit Cliffords. Thus $L_\lambda=E^\dagger C_\lambda E$. The $L_\lambda$ form a commuting group of involutions.

Write $B$ for the binary isotropic span of the independent active Pauli axes of $E$. Write $S_s$ for the binary symplectic action of $Q_s$, and define
$$
 I=\bigcap_s S_s B,\qquad U=I^\perp=\sum_s S_s(B^\perp).
$$
Here orthogonality uses the Pauli commutation pairing. Both $I$ and $U$ are invariant under $S_s$. For $v\in B^\perp$, the Pauli $P_v$ commutes with $E$. Then $L_\lambda P_v L_\lambda^\dagger$ is a one-layer conjugate of a Pauli and hence a Clifford. Conjugate this fact by each $Q_s$ and use the mask transport identity. It holds for every $v\in S_s(B^\perp)$ and thus, by Pauli multiplication, for every $v\in U$.

Let $G$ be the projective group generated by the Cliffords $L_\lambda P_v L_\lambda^\dagger$, with $v\in U$ and all masks $\lambda$. Projective means that only the global scalar on a Clifford is discarded. $G$ contains every projective $P_v$ for $v\in U$ by taking $\lambda=0$. Each $L_\lambda$ normalizes $G$ by mask addition, and each $Q_s$ normalizes it by transport and invariance of $U$.

We need a stronger property of $G$. Every member permutes the **individual** active axes of $E$ up to signs. Here is the axis argument. If two bands of signed eighth-turn Pauli rotations about independent commuting axes have Clifford product, their unsigned axis sets coincide. Choose a Pauli that anticommutes with one chosen axis of the first-applied band and commutes with its other axes. Its conjugate by this band is a Clifford whose symplectic deviation from identity has image exactly the line of the chosen axis. Via the Clifford endpoint this same conjugate is the inverse second band's conjugate of another Pauli. That deviation has image the span of all its active anticommuting axes. Indeed it is a product of their symplectic transvections, whose cross terms vanish by isotropy and whose pivot functionals are independent. Hence the chosen axis occurs in the second band. Apply the argument to the inverse product for the reverse inclusion.

For a generator of $G$ write $g=E^\dagger C'E$ with $C'=C_\lambda(EP_vE^\dagger)C_\lambda^\dagger$ Clifford. Since $g$ is Clifford, $gC'^\dagger$ is a Clifford product of the bands $E^\dagger$ and $C'EC'^\dagger$. The axis argument shows that $C'$ permutes the axes. Both $E$ and $E^\dagger$ commute with the axes themselves, so $g$ acts on them just as $C'$ does. This proves the property on the generators and hence on $G$.

## 3. Tracking the group with a degree bound independent of width

Use binary normal-Pauli coordinates $i^{t_0+2t_1}X^xZ^z$, allowing all four Pauli phases so the phase bits are independent of the labels. On the feature vector consisting of $1$, the entries of $(x,z,t_0)$, their pair products and $t_1$, each Clifford $g$ acts by a binary matrix $\Psi(g)$. It is a faithful representation modulo the scalar of $g$. For completeness, a Clifford sends labels linearly. Its normal-phase increment modulo four is a sum of linear terms plus twice a quadratic form in the input labels. The low bit is linear and the high bit is quadratic, including the carry with $t_0$. Pair products of label features consequently transform linearly on the enlarged feature list. These distinct Boolean monomials are independent, and fixing all their evaluations fixes all signed Paulis. [Detailed phase lift and cube-product identity](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/CLIFFORD_ORBIT_QUERY_RANK.md)

For this source the entries of $\Psi(Q_s)$ have Boolean degree at most two in $s$. In its original coordinates $Q_s$ adds an affine-in-$s$ shear to the Pauli Z label and adds twice the frozen quadratic form evaluated at the X label to the phase. Products of two label entries cost at most degree two. A fixed Clifford change of coordinates multiplies by fixed matrices and preserves this bound. $S_s$ itself is affine in $s$.

Use the entries of the pair $y(g)=(\Psi(g),\Psi(g^{-1}))$ as coordinates. Conjugating $g$ by a fixed Clifford acts linearly on these coordinates. Conjugating by $Q_s$ also acts linearly, with coefficients of degree at most four in $s$, since it multiplies each matrix on both sides.

Choose a fixed Clifford frame in which $E$ is a product of positive $T$ rotations about the individual $Z_j$ for active $j$. A fixed Pauli can flip any needed axis orientations. For an axis-permuting Clifford $g$, write
$$
 g^{-1} Z_j g=(-1)^{f_j}Z_{i(j)}.
$$
For fixed $j$, $f_j$ is one linear evaluation of the high phase bit in $\Psi(g^{-1})$. In this frame $E g E^\dagger$ equals $(\prod_j S_j^{f_j})g$ up to scalar. For $E^\dagger g E$ the same relation uses $S_j^{-f_j}$. A product of these commuting quarter turns has a lift of degree at most two in the flags $f$. On an input Pauli its binary label shear has coefficients linear in $f$, and its phase adds $\pm\sum_j f_j x_j$ modulo four. The carry involves only pairs. The product with $\Psi(g)$ costs one further degree. Apply the same argument to $g^{-1}$ for the inverse coordinates. Thus conjugation through either direction of $E$ has degree at most **three** in $y(g)$ on the axis-permuting Clifford domain.

For each $\lambda$, all entries of $y(L_\lambda g L_\lambda^\dagger)$ on $G$ are therefore polynomials of degree at most **nine** in $y(g)$. Conjugate first through $E$, then the fixed Clifford $C_\lambda$, then $E^\dagger$. The domain condition on the last application is essential. Its input $g'$ is a Clifford, its output is in $G$, and $g'=E( L_\lambda g L_\lambda^\dagger)E^\dagger$ permutes the axes because its output in parentheses permutes them and $E$ commutes with each of them. The intermediate fixed Clifford need not preserve the axes on arbitrary inputs.

Consider the finite space of binary functions on $G$ spanned by the individual entries
$$
 h_{\lambda,i}(g)=y(L_\lambda g L_\lambda^\dagger)_i .
$$
It contains the raw coordinates at $\lambda=0$ and hence separates the points of $G$. Pullback by conjugation with $L_{e_s}$ is an involution $A(s)$ of this function space. It maps the displayed functions to the same functions indexed by $\lambda+e_s$. All $A(s)$ commute.

In a fixed basis of this space, the entries of $A(s)$ have degree at most **40** in $s$. To see the bound without charging anything for the number of functions, select the basis from the displayed functions. Select as many fixed evaluation points in $G$ as basis functions so the evaluation matrix is invertible. This is possible by linear independence on a finite set. Basis coefficients of any translated function are fixed linear combinations of its values at these points. At a fixed $g$, commuting the two logical masks lets us evaluate its translated value by taking the $i$th coordinate of
$$
 L_{e_s}\, g'\, L_{e_s}^\dagger,\qquad g'=L_\lambda g L_\lambda^\dagger\in G
$$
with $g'$ fixed. Substitute $L_{e_s}=Q_s L_{e_0}Q_s^\dagger$. Conjugation of $g'$ by $Q_s^\dagger$ costs degree four in $s$, conjugation by $L_{e_0}$ substitutes these bits into degree-nine polynomials, and the outside $Q_s$ adds at most four by matrix multiplication. The total is $4\cdot9+4=40$.

## 4. A nonzero mask would have to be scalar

For commuting involutive binary matrices $A(s)$ of entrywise degree $r$, the product on any coordinate face of dimension $>2r$ is identity. To verify this, expand $A(s)-1=\sum_j f_j(s) N_j$ in a basis of the linear span of its values, chosen from those values. The $N_j$ commute and square to zero, while the $f_j$ have degree at most $r$. For commuting square-zero $x_j=f_jN_j$,
$$
 1+\sum_j x_j=\prod_j(1+x_j)\prod_{i<j}(1+x_i x_j).
$$
The coefficient of a squarefree monomial on $h$ labels counts partitions of those labels into singletons and pairs. This is even for $h\ge2$ by the involution-count recurrence. In the product over the face each factor occurs evenly, since both $f_j$ and $f_i f_j$ have degree below the face dimension.

Take $\eta$ to be the nonzero wire mask of an 81-dimensional coordinate subspace. The corresponding product of the $A(s)$ is identity by the degree-40 bound. Since our functions separate $G$, the operator $L_\eta$ centralizes $G$ projectively. In particular its conjugation sends $P_v$ to $\pm P_v$ for all $v\in U$. These signs form a linear character of $U$ and extend to the commutation signs of a single physical Pauli $P_a$ by nondegeneracy of the symplectic form. Hence $L_\eta=P_aD$ with $D$ commuting with all $P_v$, $v\in U$. The Pauli expansion of $D$ is supported inside $U^\perp=I\subset B$. Consequently $D$ commutes with $E$. We already know both $EL_\eta E^\dagger=C_\eta$ and $EP_aE^\dagger$ are Cliffords. Cancelling the latter proves that $D$ and $L_\eta$ are Cliffords, up to an irrelevant scalar.

It remains to eliminate this Clifford mask. Since $D$ commutes with the Paulis on $U$, the symplectic action of $L_\eta=P_aD$ fixes $U$ pointwise. Its deviation from identity has image in $U^\perp=I$ by symplectic duality. Both statements persist for its translated Cliffords $C(s)=Q_s L_\eta Q_s^\dagger$, since $S_s$ preserves $I$ and $U$. As $I\subset U$, their deviations $N_s=S(C(s))-1$ satisfy $N_s N_t=0$ for all $s,t$.

**Three-direction cancellation.** Suppose $C(s)=D_s C(0)D_s$ are commuting Hermitian Clifford involutions for an arbitrary computational diagonal sign representation $D_s$, and their symplectic deviations have the pairwise-zero-product property above. The product of the eight operators on three independent selector directions is identity. For each physical computational $Z_i$,
$$
 C(s)Z_i C(s)^\dagger=D_s\big(C(0) Z_i C(0)^\dagger\big)D_s .
$$
Both tested operators are Paulis, and diagonal conjugation preserves their computational shift, i.e. the X label. Thus the upper-right (Z input to X output) symplectic block of $C(s)$ is the same for every $s$, in the source's computational coordinates. For a first direction $u$, put $W=C(0)C(u)$. Its symplectic action is $1+N_0+N_u$, whose upper-right block vanishes. Hence $W$ normalizes the computational Z algebra. It is monomial, acting as $|v\rangle\mapsto\phi(v)|\sigma(v)\rangle$, and $\sigma^2=1$ since $W^2=1$.

Write $D_t|v\rangle=(-1)^{q_t(v)}|v\rangle$. Then $D_t W D_t=W H_t$ with diagonal sign $H_t(v)=(-1)^{q_t(v)+q_t(\sigma(v))}$. These signs commute with $W$ because they are invariant under $\sigma$. They form a representation in $t$. Consequently the four conjugates of $W$ over the two remaining selector directions multiply to $W^4=1$. By the group law each conjugate is the corresponding pair of $C(s)$, giving the asserted eightfold product.

Apply this to $C(s)=Q_s L_\eta Q_s^\dagger$ on three directions outside the original 81. By exact mask covariance the combined product is the encoded characteristic function of an 84-dimensional coordinate subspace. Its encoded operator has trace zero and cannot be identity. This proves the theorem.

## 5. An exact encoder of polynomial size on occupied banks

This construction uses the freedom to choose the pulse multiplicity. Let $h=m+\lceil\log_2p\rceil$ and take $h$ private pairs per address bit. Hadamards on each second rail turn $Q_s$ into the classical shear $(a_j,b_j)\mapsto(a_j,b_j+s_j a_j)$ on $h$-bit words. We build a fixed basis permutation $M$ with a designated $m$-bit output $Y$ satisfying $Y(S_s x)=P_sY(x)$ on every input, where $S_s$ here denotes the basis shear. Then $V=M H_b$ transports the observable exactly. The spectators may depend on the input and cancel in the complete conjugation.

1. For each nonzero $a_j$, swap the zeroth bit of $b_j$ with the bit at the least set position of $a_j$. Do nothing if $a_j=0$. The resulting designated bit $r_j$ toggles by $s_j$ when $a_j\ne0$.
2. Reversibly combine the $a_j$ in a balanced tree. To combine two $k$-bit words $u,v$, replace $v$ with $w=u+v$. For $w\ne0$ apply to $u$ an invertible linear map $L_w$ sending $w$ to $e_0$. At $w=0$ take the identity. Keep every wire, and pass the $k-1$ nonpivot bits of $L_wu$ up the tree. When either input word vanishes, $u\in\{0,w\}$, so all the passed bits vanish. At an unpaired word set one bit aside for that level. The root holds $m$ bits $T$ unaffected by the shear. The whole root vanishes whenever any of the original $a_j$ vanishes.
3. Output $Y=P_rT$, retaining all other wires. If all $a_j\ne0$, $r$ changes by $s$ so $Y$ translates by $s$. Otherwise $Y$ is zero and still obeys the same relation. Every step is reversible, so the logical bits jointly with all spectator bits range over the entire physical space. No input distribution or initialized register is assumed.

One can clear $w$ to $e_0$ using its least set coordinate, additions controlled by the remaining bits, and a final pivot swap. The fixed circuit enumerates candidate pivots. Each merge uses $O(k^2)$ multi-controlled bit gates with $O(k)$ controls. A $k$-controlled X costs $O(k^2)$ native gates and $O(\log(k+2))$ returned dirty bits. For example, split its controls into sets $A,B$, toggle a dirty flag by the AND on $A$, and apply the target toggle controlled by that flag and $B$ both before and after the flag toggle. Undo the flag toggle. The four calls recurse on nearly equal effective sizes, down to Toffolis. Negative controls and controlled swaps have fixed Clifford/Toffoli implementations. The orientation and the last $p$ controlled matchings also fit the budget. Hence $O(ph^4)$ T and elementary Clifford gates and $2ph+O(\log(h+2))$ wires suffice, including the principal bank. The counts are singly exponential in $p$, so a fixed number of balanced address splits can normalize them using the [exact Cartesian merge](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/COMPLETE_BANK_DIFFERENCE.md).

This implementation exposes the bit $r_j$ as an output wire. Its difference on the two inputs $x,S_{e_j}x$ equals $\mathrm{OR}(a_j)$, of Boolean degree $h$. The shear is affine in the input, so $r_j$ itself has degree at least $h$. With quadratic reversible Boolean layers and affine interlayers, the degree after $d$ layers is at most $2^d$. Thus this way of computing the pivot takes at least $\lceil\log_2 h\rceil\ge p$ such layers. The argument is about explicit classical reversible layers. The native T-depth of a quantum implementation that only needs the final observable is open.

## 6. Changing the source while keeping the complete indicator

Change the elementary frozen-sector phase from CZ to CCZ. Write $D_s|w\rangle=(-1)^{q_s(w)}|w\rangle$ with
$$
 q_s(w)=\sum_{j,\ell}s_j a_{j\ell}d_{j\ell}c_{j\ell}.
$$
An actual coherent visit acts on four bits per term, one of which is the address. It has native T-depth at most **12**. For each term borrow a private dirty bit $t$. Apply $CCZ(s_j,c,t)$, toggle $t$ by $ad$, repeat the phase, and undo the toggle. The two signs multiply to $(-1)^{s_jcad}$, independent of the initial $t$. The two shared-control phase batches cost three layers each by Section 1, and each private Toffoli batch costs three layers by the same CCZ decomposition and fixed Hadamards. Counts and dirty width are linear in the number of terms. A nonempty block at a single active address bit is non-Clifford since it sends a single-site X to X times CZ.

**Full-input construction.** Three private triples suffice to encode one effective pair of Section 5. Within a cell, write $a,d,c$ for three-bit words, and $k=a\mathbin{\&}d$. After Hadamards on $c$, the moving word undergoes $c\mapsto c+s_j k$. Of the 64 stationary $(a,d)$, exactly 27 have $k=0$. Choose a fixed bijection of the 64 words so one output bit $u$ is zero on all 27. This is possible since there are 32 zero-bit slots. For each stationary input choose a nonzero binary row $\ell$ satisfying $\ell k=u$. If $k\ne0$, either value has a nonzero solution in three dimensions, and if $k=0$ the chosen $u$ is zero. Complete that row to an invertible $3\times3$ map on $c$ and use $v=\ell c$ as its first output. These constant-size, reversibly recoded cells satisfy
$$
 (u,v)\longmapsto (u,v+s_ju)
$$
on every basis input. The other seven output bits are retained. They can move, but the displayed pair's action is independent of them. All maps in the rest of the encoder are basis permutations and its tested occupation is diagonal after the input-side Hadamards. It follows by evaluating basis states that spectator motion cancels coherently in the completed observable. No decoupled tensor-factor assumption about the whole source unitary is needed.

Use $h$ cells per selector bit, followed by the encoder permutation in Section 5 on their effective pairs. This quartic source now has $9ph$ input wires and a complete exact polynomial-size encoder, including its inverse. To synthesize a fixed nine-bit cell one may use basis transpositions and borrowed-bit multi-controlled gates. All cells then cost $O(ph)$ gates and at most $O(ph)$ returned extra wires, with the same overall singly exponential budget. The source needed by a single-site indicator has two visits, giving the paid bound $4D_T(V)+24$ for this variant. An encoder with depth $O(\log\log(p+4))$ and the same type of gate and width budgets would suffice for the fixed-precision frame bound discussed below.

### A one-layer encoder fails for every diagonal sign representation

For $p\ge3$, every address-independent at-most-one-T-layer encoder has uniform singleton error at least $1/\sqrt2$ for **any** representation $D_s=\prod_j D_j^{s_j}$ by computational diagonal signs $D_j$. There is no degree or locality assumption on the work sign of a frozen generator. This includes the quartic pulse.

First we need an operator gap. Let $A=P_a F_I$ and $B=P_b H_J$, where $P_a,P_b$ are Paulis and $F_I,H_J$ have signs $\pm1$ in respective maximal commuting Pauli bases $I,J$. Here the bases are specified by their Lagrangian label spaces. Then $A=B$ or $\|A-B\|\ge\sqrt2$, allowing the ordinary Pauli scalar phases. If the support cosets $a+I,b+J$ are disjoint, the normalized Hilbert–Schmidt distance already gives $\sqrt2$. If they meet at $d$, multiply both operators on the left by a Pauli on $d$. Absorb the resulting Paulis in $I,J$ into their diagonal signs. Up to a common phase we compare signs $F'_I$ and $\omega H'_J$ for $\omega\in\{1,-1,i,-i\}$. An imaginary $\omega$ gives distance at least $\sqrt2$ by testing an eigenvector of $F'_I$. For a real $\omega$ absorb it into $H'_J$. In each joint eigenspace of $I\cap J$, every vector of the complete $I$ stabilizer basis has the same expectation $\mu$ of $H'_J$. In its Pauli expansion only labels in $I\cap J$ contribute, since the other labels exchange orthogonal $I$ eigenstates. If the distance is below $\sqrt2$, an $I$ eigenvector with $F'_I$ eigenvalue $f$ has squared error $2-2f\mu$. Thus $f$ has the same sign as $\mu$ throughout that syndrome. Consequently $F'_I$ is scalar on each common eigenspace and commutes with $H'_J$. Distinct commuting signs have distance two.

Write $C=L_{e_0}$ and $C_s=L_{e_s}$. These are Hermitian Cliffords. If $D_s C D_s$ is within $\epsilon$ of $C_s$, test on an arbitrary physical Hermitian Pauli $P$ and strip the outside $D_s$. This puts $C(D_s P D_s)C^\dagger$ within $2\epsilon$ of $D_s(C_s P C_s^\dagger)D_s$. Each operator is a Pauli times signs diagonal in a maximal commuting Pauli basis. Indeed a diagonal sign sends a Pauli with X label $x$ to itself times the diagonal sign given by the Boolean difference in direction $x$. Clifford conjugation takes one such basis to another. The gap gives equality for every probe when $\epsilon<1/\sqrt2$. The full signed Pauli action determines its conjugating unitary up to scalar. Both $D_s C D_s$ and $C_s$ are Hermitian, and their initial distance excludes an opposite sign. Thus the site orbit is exact and again yields all-mask covariance.

All the $C_s$ are images of bank Paulis under one common T layer and fixed Clifford boundaries. Their symplectic deviations $S(C_s)-1$ are sums of transvection deviations on a single fixed isotropic axis space. Each maps into that space and vanishes on it, so products of two deviations vanish. The three-direction cancellation in Section 4 now applies directly. Exact covariance identifies its eightfold product with the encoded nonempty three-dimensional bank mask. That operator is traceless, giving the contradiction. This proof also identifies why changing the work degree of the sign pulse cannot rescue a one-layer encoder.

## 7. The decision in terms of final scaling

Let $n$ be the number of logical qubits in the frame, $N=2^n$, $b$ the dirty allocation, and $2^{-L}$ the required full initialized-isometry error. With one external clean qubit the strongest unconditional general upper bound is
$$
 D_T=O\big(NL/b^2+L+\log(n+2)\big),\quad
 T=O\big(\sqrt{NL}+L+NL/b\big),\quad G=O(NL).
$$
It applies for $L\ge6$, at $b\ge17(L+n+7)$ for the complete real frame and $b\ge17(L+n+8)$ for the prescribed complex magnitude frame. At fixed $L$ and $b=\Theta(\sqrt N)$, the depth interval is still $\Omega(1)$ to $O_L(\log n)$. [R96 and the general frontier](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/OPEN_PROBLEM.md#large-width-t-depth)

For this interface the next construction should implement the conjugated physical occupation with sublogarithmic native depth and full return. A concrete first target is $O(\log\log(p+4))$ on the quartic pulse, with singly exponential discovery costs. The cell construction provides an exact reference observable on every occupation word. The first expensive operation is the coherent selection of an active coordinate across a growing block. A quantum implementation could compute the needed phase jointly across the cells and its inverse, without emitting all the pivot bits. A shortcut using one coherent prefix test already encounters a quantitative obstacle. Restrict one block to a one-hot active word at unknown position $k\in\{0,\ldots,h-1\}$ and fix the second word to $b_i=i\bmod2$. Its selected orientation phase is $(-1)^k$. Grant a perfect indexed prefix phase $O_k|j\rangle=(-1)^{[j\le k]}|j\rangle$ and suppose $k$ enters only through a single parallel batch of $q$ such calls. On a fixed pre-query input the outputs for $k,k+1$ have distance at most $2\sqrt{p_{k+1}}$, where $p_i$ is the probability that at least one query index equals $i$. The target literal signs differ by two, so uniform error $\epsilon<1$ requires $p_{k+1}\ge(1-\epsilon)^2$. Since $\sum_i p_i\le q$, this requires $q\ge(h-1)(1-\epsilon)^2$. Polynomial width could accommodate that many calls. The [existing zero-reflection circuit](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/EXPANDER_ZERO_REFLECTION.md) moves its tested register and supplies no shared-prefix parallel implementation. A construction using the actual occupied word jointly with its return can bypass the oracle restriction.

After normalizing an exact $2^{O(p)}$ size precursor by a fixed balanced Cartesian split, the project transfer at fixed $L$ gives
$$
 D_T=O_L\big(N/b^2+d(2n+10)+\log\log(n+4)\big)
$$
for an eligible query with depth envelope $d$. The target above would give $O_L(\log\log(n+4))$ at square-root dirty width with $T=O_L(\sqrt N)$ and $G=O_L(N)$. A uniform $o(\log(p+2))$ envelope already gives a strict asymptotic improvement there. A depth of three for the original encoder, or two for the quartic source, remains an admissible possibility. Proving another constant lower bound alone would leave the logarithmic upper bound intact. [R98](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/QUERY_DEPTH_FRAME_TRANSFER.md) · [Fixed-accuracy approximate transfer and its full error contract](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/APPROXIMATE_QUERY_FRAME_TRANSFER.md)


## Verification

The companion archive runs with Python 3.10 or later using only the standard library. The exact finite checks include all 11,520 projective two-qubit Cliffords in the axis argument, 61,440 comparisons for the operator gap, all $2^{20}$ basis inputs and all four addresses of the two-bit cubic encoder, and all 512 words of the quartic recoding cell. Additional tests apply the encoders and their actual inverses on larger occupied inputs through $p=7$. The shared-control phase test checks the three-layer parity frames and the literal dirty return in the 12-layer quartic visit. The size-independent statements follow from the proofs above. The two repository modules for R75 and the Clifford phase lift also passed all 12 of their tests at commit `ae613bf8e8a38f6d0407c25910b83d69f01a2733`.
