"""Exact shared-control phase and work-return checks. Run with Python 3.10+."""

from itertools import product


def triple_batch(s, pairs):
    # Each tuple gives the two private-wire coordinates for one T layer.
    exponent = s * len(pairs)
    for u, v in pairs:
        exponent += u + v
        exponent -= (s ^ u) + (u ^ v)
        exponent += -(s ^ v) + (s ^ u ^ v)
    return exponent % 8


def toffoli_batch(first, second, work):
    # H, literal diagonal batch, H on each target. The 0/4 phase difference
    # implies the exact indicated output with coefficient +1.
    result = []
    for a, d, t in zip(first, second, work):
        e0 = triple_batch(a, [(d, 0)])
        e1 = triple_batch(a, [(d, 1)])
        assert e0 == 0 and e1 in (0, 4)
        result.append(t ^ (e1 // 4))
    return tuple(result)


def main():
    tests = 0
    for s in (0, 1):
        frames = (
            [(u, v) for u, v in product((0, 1), repeat=2)],
            [(s ^ u, u ^ v) for u, v in product((0, 1), repeat=2)],
            [(s ^ v, s ^ u ^ v) for u, v in product((0, 1), repeat=2)],
        )
        assert all(len(set(layer)) == 4 for layer in frames)
        for bits in product((0, 1), repeat=8):
            a, d, c, dirty = bits[:2], bits[2:4], bits[4:6], bits[6:]
            first = triple_batch(s, list(zip(c, dirty)))
            updated = toffoli_batch(a, d, dirty)
            second = triple_batch(s, list(zip(c, updated)))
            returned = toffoli_batch(a, d, updated)
            assert returned == dirty
            assert (first + second) % 8 == (4*s*sum(
                x*y*z for x, y, z in zip(a, d, c))) % 8
            tests += 1
    print(f"{tests:,} exact shared-selector two-term quartic phases and dirty returns")


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run without -O to enable exact assertions.")
    main()
