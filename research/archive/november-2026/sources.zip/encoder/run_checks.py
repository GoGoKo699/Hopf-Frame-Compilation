"""Run the exact checks from a freshly extracted archive (Python 3.10+)."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
files = (
    "hopf_wall_algebra_check.py",
    "hopf_monomial_gap_check.py",
    "hopf_shared_pulse_check.py",
    "hopf_weak_encoder_check.py",
    "hopf_quartic_encoder_check.py",
)
for name in files:
    subprocess.run([sys.executable, "-B", "-S", str(root / name)], check=True)
