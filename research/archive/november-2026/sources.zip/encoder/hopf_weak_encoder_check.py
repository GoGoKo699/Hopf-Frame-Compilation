"""Exact checks for the oriented-clock, occupied-bank encoder; standard library only."""
from itertools import product
from random import Random


def swap_bit_zero(word, k):
    if (word ^ (word >> k)) & 1:
        return word ^ (1 | (1 << k)) if k else word
    return word


def pivot(w):
    return (w & -w).bit_length() - 1 if w else 0


def row_reduce(w, u, inverse=False):
    """Binary change of coordinates with L_w w=e_0 when w is nonzero."""
    if not w:
        return u
    k = pivot(w)
    if inverse:
        u = swap_bit_zero(u, k)
    if (u >> k) & 1:
        u ^= w ^ (1 << k)
    return u if inverse else swap_bit_zero(u, k)


def translate(word, r, m):
    return sum(((word >> i) & 1) << (i ^ r) for i in range(m))


def tree_layers(p):
    active = list(range(p))
    result = []
    while len(active) > 1:
        result.append(list(zip(active[::2], active[1::2])))
        active = active[::2]
    return result


def tree(a, p, *, inverse=False):
    layers = tree_layers(p)
    levels = reversed(range(len(layers))) if inverse else range(len(layers))
    for ell in levels:
        low = (1 << ell) - 1
        for i, j in layers[ell]:
            u, v = a[i] >> ell, a[j] >> ell
            if inverse:
                w = v
                u = row_reduce(w, u, inverse=True)
                v = w ^ u
            else:
                v ^= u
                u = row_reduce(v, u)
            a[i] = (a[i] & low) | (u << ell)
            a[j] = (a[j] & low) | (v << ell)


def encode(a, b, *, inverse=False):
    a, b = list(a), list(b)
    p = len(a)
    root_offset = (p - 1).bit_length()
    m = 1 << p
    if not inverse:
        b = [swap_bit_zero(x, pivot(y)) for x, y in zip(b, a)]
        tree(a, p)
    clk = sum((v & 1) << j for j, v in enumerate(b))
    root = translate(a[0] >> root_offset, clk, m)
    a[0] = (a[0] & ((1 << root_offset) - 1)) | (root << root_offset)
    if inverse:
        tree(a, p, inverse=True)
        b = [swap_bit_zero(x, pivot(y)) for x, y in zip(b, a)]
    return tuple(a), tuple(b)


def shear(a, b, s):
    return tuple(x ^ (y if (s >> j) & 1 else 0) for j, (x, y) in enumerate(zip(b, a)))


def check_compressor():
    checked = 0
    for n in range(1, 7):
        for u, v in product(range(1 << n), repeat=2):
            w = u ^ v
            out = row_reduce(w, u)
            assert u and v or out >> 1 == 0
            recovered_u = row_reduce(w, out, inverse=True)
            assert (recovered_u, recovered_u ^ w) == (u, v)
            checked += 1
    return checked


def check_two_bits_exhaustively():
    # Two address bits, four logical sites, n=5, 20 physical binary coordinates.
    # Cache the small elementary tables so all 2^20 basis inputs are feasible.
    p, m, h, n = 2, 4, 1, 5
    words = range(1 << n)
    translation = [[translate(y, r, m) for y in range(1 << m)] for r in range(m)]
    orientations = [[swap_bit_zero(b, pivot(a)) for b in words] for a in words]
    seen = bytearray(1 << (2*p*n))
    tests = 0
    for a0, a1 in product(words, repeat=2):
        w = a0 ^ a1
        first = row_reduce(w, a0)
        t, saved = first >> h, first & 1
        assert a0 and a1 or t == 0
        for b0, b1 in product(words, repeat=2):
            b0prime, b1prime = orientations[a0][b0], orientations[a1][b1]
            r = (b0prime & 1) | ((b1prime & 1) << 1)
            y = translation[r][t]
            output = saved | (y << h) | (w << n) | (b0prime << (2*n)) | (b1prime << (3*n))
            assert not seen[output]
            seen[output] = 1
            for s in range(4):
                new0 = orientations[a0][b0 ^ (a0 if s & 1 else 0)] & 1
                new1 = orientations[a1][b1 ^ (a1 if s & 2 else 0)] & 1
                after = translation[new0 | (new1 << 1)][t]
                assert after == translation[s][y]
                tests += 1
    assert all(seen)
    return tests


def check_full_echoes():
    rng = Random(20261119)
    tests = 0
    for p in range(1, 8):
        m = 1 << p
        h = (p - 1).bit_length()
        n = m + h
        for _ in range(85):
            a = tuple(rng.getrandbits(n) if rng.randrange(3) else 0 for _ in range(p))
            b = tuple(rng.getrandbits(n) for _ in range(p))
            programmed = encode(a, b)
            assert encode(*programmed, inverse=True) == (a, b)
            y = programmed[0][0] >> h
            if not all(a):
                assert y == 0
            for s in {0, m-1, rng.randrange(m)}:
                transported = encode(a, shear(a, b, s))
                assert transported[0][0] >> h == translate(y, s, m)
                # Z_root,0 contributes its literal sign here.
                phase = (transported[0][0] >> h) & 1
                a1, b1 = encode(*transported, inverse=True)
                returned = encode(a1, shear(a1, b1, s))
                assert returned == programmed and phase == ((y >> s) & 1)
                tests += 1
    return tests


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run without -O to enable exact assertions.")
    print(check_compressor(), "reversible zero-compressor cases")
    print(check_two_bits_exhaustively(), "two-bit occupied input/address cases; encoder bijective on all 2^20 states")
    print(check_full_echoes(), "complete literal phase and work-return echoes through p=7")
