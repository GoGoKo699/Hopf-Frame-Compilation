## A sharp cost for reading an arbitrary bank from two scalar fingerprints

Take an address-only unit vector $u_s$ and a bank-only unit vector $v_Y$ in any real Hilbert space, with arbitrary encoding functions and unlimited dimension. For $m$ physical sites, let $s$ range over the sites and let $Y$ range over all $2^m$ occupied bit strings. Suppose a bounded real polynomial $f$, of degree $d$ and with $|f(z)|\le1$ on $[-1,1]$, obeys
$$
 |f(\langle u_s,v_Y\rangle)-(-1)^{Y_s}|\le\epsilon
$$
for every address and bank, with $\epsilon<1$. Then $d=\Omega((1-\epsilon)\sqrt m)$. There exist vectors and a bounded polynomial of degree $O(\sqrt m)$ that give equality to the desired signs on every input. This is a statement about a full arbitrary bank; it permits arbitrary classical costs for both separate encodings.

Here is a width-independent proof which permits nonmonotone filters and arbitrary promises on the realized overlaps. For a random Gaussian direction $G$, the unit vectors $\Phi(u):G\mapsto\operatorname{sgn}\langle G,u\rangle$ in $L^2$ obey
$$
 \langle\Phi(u),\Phi(v)\rangle
 =1-2\arccos(\langle u,v\rangle)/\pi.
$$
Only the finite span of the chosen vectors matters. Rotational symmetry in their two-dimensional plane gives the displayed identity. Thus $\langle u,v\rangle=\sin((\pi/2)\langle\Phi(u),\Phi(v)\rangle)$. Set $F(t)=f(\sin(\pi t/2))$. This function is Lipschitz with constant at most $e\pi d/2$. Indeed $Q(w)=w^df((w+w^{-1})/2)$ is a polynomial of degree at most $2d$ bounded by one on the unit circle. Applying the maximum principle to $Q$ and its reversed polynomial gives $|f(\cos(\theta+it))|\le e^{d|t|}$. Cauchy's derivative bound on a radius $1/d$ circle gives the claimed constant after the affine change of angle. The sharper constant $\pi d/2$ follows directly from trigonometric Bernstein.

For uniform independent signs $t_1,\ldots,t_m$, the matching bank vector gives
$$
 (1-\epsilon)m\le
 \mathbb E_t\sup_{\|w\|\le1}\sum_s t_sF(\langle\Phi(u_s),w\rangle)
 \le \operatorname{Lip}(F)\mathbb E_t\left\|\sum_s t_s\Phi(u_s)\right\|
 \le \operatorname{Lip}(F)\sqrt m .
$$
For the middle inequality, average each sign in turn. With all other signed terms denoted $A(w)$, the average over the last sign is half the supremum over $w,w'$ of $A(w)+A(w')+F(x_w)-F(x_{w'})$. Replace the last difference by $L|x_w-x_{w'}|$ and exchange $w,w'$ as necessary. This gives exactly the corresponding expression with $F(x)$ replaced by $Lx$. Iterate over signs. The final inequality is the second-moment bound. Conversely take $u_s$ orthonormal and $v_Y=m^{-1/2}\sum_s(-1)^{Y_s}u_s$. Choose an odd $d$ just above $\pi/(2\arcsin(1/\sqrt m))$ and $\lambda=\sqrt m\sin(\pi/(2d))\le1$. The odd polynomial $f(z)=\sin(d\arcsin(\lambda z))$ has magnitude at most one on the entire interval and equals exactly $\pm1$ on $\pm1/\sqrt m$.

This reads as a query bound for a specific coherent circuit. Suppose the only two input-dependent reflections on a common carrier are $A_s=\sum_i u_{s,i}\gamma_i$ and $B_Y=\sum_i v_{Y,i}\gamma_i$ with anticommuting traceless Hermitian Pauli axes. Permit arbitrary auxiliary-only unitaries, coherent auxiliary control of either reflection, and their actual adjoints. For a fixed auxiliary input/output, the normalized carrier trace of the completed matrix element is a polynomial in $c=\langle u_s,v_Y\rangle$ of degree at most the number of reflection occurrences. Indeed each control expands linearly into fixed auxiliary factors times words in $A_s,B_Y$. Since $A_s^2=B_Y^2=I$ and $A_sB_Y+B_YA_s=2c I$, cancel repeated letters. By cyclicity an odd alternating word has trace zero. An even alternating word gives the trace of $(A_sB_Y)^j$ or its inverse, namely $T_j(c)$ by the quadratic equation of the product and $\operatorname{tr}(A_sB_Y)=c$. The polynomial has magnitude at most one on $[-1,1]$, as witnessed for every $c$ by testing the same program with the Hermitian pair $Z,cZ+\sqrt{1-c^2}X$. Take the real part if the trace is complex. Uniformly returning a scalar lookup phase implies the scalar test above. Consequently this circuit family requires $\Omega(\sqrt m)$ visits even if both reflection calls themselves are free of synthesis error and given unit cost. Input-dependent changes of carrier basis or direct readout of a bank-dependent operator can escape the reduction. The proof gives no unrestricted native T-depth lower bound.

There is also a matching upper bound inside the ideal two-reflection query model, on every carrier state. Keep the orthonormal $u_s=e_s$, take $\mu=\sin(\pi/(2d))$, and set $v_Y=\mu\sum_s(-1)^{Y_s}e_s+\sqrt{1-m\mu^2}\,e_*$ with one extra orthogonal axis. The two eigenangles of $A_sB_Y$ are $\pm(\pi/2-(-1)^{Y_s}\pi/(2d))$. Hence $(A_sB_Y)^d=(-1)^{(d-1)/2+Y_s}I$ exactly, with a known fixed scalar. The circuit has $2d$ ideal reflection visits. Their native synthesis is an additional cost.
