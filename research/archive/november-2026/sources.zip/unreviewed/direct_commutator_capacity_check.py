"""Exhaustive small source factorizations and approximate-reflection identities."""
from itertools import product, combinations
from math import cos,pi,sin,acos
from random import Random

def factor(rows,columns):
    # Basis of rows and their binary coefficients.
    basis=[]
    idx={0:0}
    for value in rows:
        if value in idx:
            continue
        bit=1<<len(basis)
        old=list(idx.items())
        idx.update({value^v:coef|bit for v,coef in old})
        basis.append(value)
    return ([idx[v] for v in rows],
            [sum(((v>>j)&1)<<i for i,v in enumerate(basis)) for j in range(columns)],
            len(basis))

def check():
    matrices=0
    for m,n in ((1,3),(2,3),(3,2),(3,3)):
        for rows in product(range(1<<n),repeat=m):
            left,right,r=factor(rows,n)
            k=(r+1)//2
            mask=(1<<k)-1
            for i,j in product(range(m),range(n)):
                la=left[i]
                rb=right[j]
                lb=((rb & mask)<<k) | (rb>>k)
                sign=((la & mask) & (lb>>k)).bit_count() + ((la>>k) & (lb & mask)).bit_count()
                assert sign%2==(rows[i]>>j)&1
            matrices+=1
    print(f'{matrices} exact rectangular commutator factorizations on minimal carriers')
    rng=Random(17)
    checks=0
    for k in range(1,11):
        for _ in range(60):
            c=sum(rng.choice((-1,1)) for j in range(1<<k))/(1<<k)
            val=complex(c,(max(0,1-c*c))**.5)
            assert abs(abs(val*val+1)-2*abs(c))<1e-12
            checks+=1
    print(f'{checks} full conjugate-eigenphase checks for compressed full-rank probes')
    for m in range(2,100):
        th=pi/(2*m)
        assert abs(2*sin(m*th)-2)<1e-13
    print('98 accumulated singleton-error witnesses checked')

if __name__=='__main__':
    check()
