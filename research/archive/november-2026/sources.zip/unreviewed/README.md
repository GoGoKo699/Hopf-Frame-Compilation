# Exploratory working notes

These notes retain research leads beyond the published packets. They have not undergone the six closeout reviews as independent theorems. A checker beside a note is the original finite fixture and lies outside the verified replay. The main mask and frame theorems use the proof packages in archives/. The two low-rank trace sketches and the switched-diagonal argument are historical alternatives.

| Working note | Scope | Companion |
|---|---|---|
| [certified_mask_displacement.md](certified_mask_displacement.md) | Quantum proposals on nonpivot rows; displacement certification. | [certified_mask_displacement_check.py](certified_mask_displacement_check.py) |
| [coherent_branching_entropy.md](coherent_branching_entropy.md) | Entropy of group-walk branches on a prescribed frame family. | [coherent_branching_entropy_check.py](coherent_branching_entropy_check.py) |
| [constant_fraction_mask_rank.md](constant_fraction_mask_rank.md) | Independent treatment of shrinking rank fractions and one high-degree Boolean source. | [constant_fraction_mask_rank_check.py](constant_fraction_mask_rank_check.py) |
| [conjugation_shear_rank.md](conjugation_shear_rank.md) | Extensions beyond the published affine-Clifford section, including clustered rank growth. | Already in Hopf_Mask_Proofs_and_Checks.zip / conjugation_shear_rank_check.py |
| [direct_commutator_capacity.md](direct_commutator_capacity.md) | Carrier dimension for a table-dependent commutator and exact-probe compression. | [direct_commutator_capacity_check.py](direct_commutator_capacity_check.py) |
| [hidden_clifford_characters.md](hidden_clifford_characters.md) | Character constraints on masks from commuting Clifford actions. | [hidden_clifford_characters_check.py](hidden_clifford_characters_check.py) |
| [lowrank_trace_appendix.md](lowrank_trace_appendix.md) | Probabilistic degree of normalized traces through bounded Gaussian rounds. | [lowrank_trace_appendix_check.py](lowrank_trace_appendix_check.py) |
| [lowrank_transvection_alternative.md](lowrank_transvection_alternative.md) | Alternative transvection estimator for normalized Clifford traces. | — |
| [monomial_band_parity.md](monomial_band_parity.md) | Parity constraints on physical bands near a returned basis permutation. | [monomial_band_parity_check.py](monomial_band_parity_check.py) |
| [one_diagonal_encoder_note.md](one_diagonal_encoder_note.md) | Minimum diagonal-stage count for a regular-clock encoder. | [one_diagonal_encoder_note_check.py](one_diagonal_encoder_note_check.py) |
| [order_three_spin_lift.md](order_three_spin_lift.md) | High-degree sign from cubing a prescribed spin lift. | [order_three_spin_lift_check.py](order_three_spin_lift_check.py) |
| [parallel_geometric_reference.md](parallel_geometric_reference.md) | Conditional parallel reduction for a geometric reference. | — |
| [prescribed_reflection_margin.md](prescribed_reflection_margin.md) | Margin bound for two vector fingerprints and a reflection. | [prescribed_reflection_margin_check.py](prescribed_reflection_margin_check.py) |
| [reciprocal_correlation.md](reciprocal_correlation.md) | Higher finite differences of a trace-inverse predicate on a hyperplane. | — |
| [return_amplitude_quadratics.md](return_amplitude_quadratics.md) | Scalar-return amplitudes expanded in diagonal Clifford phase functions. | [return_amplitude_quadratics_check.py](return_amplitude_quadratics_check.py) |
| [scalar_clifford_correlation.md](scalar_clifford_correlation.md) | Circuit-dependent correlation test for a prescribed scalar phase. | [scalar_clifford_correlation_check.py](scalar_clifford_correlation_check.py) |
| [schur_mask_lift.md](schur_mask_lift.md) | Polynomial features of a returned translation, including quantum proposals. | Already in Hopf_Mask_Proofs_and_Checks.zip / schur_mask_lift_check.py |
| [switched_diagonal_degree.md](switched_diagonal_degree.md) | Work degree for one-layer switched diagonal pulses, historical restricted model. | — |
| [two_fingerprint_readout.md](two_fingerprint_readout.md) | Sharp degree required by a bounded polynomial of separate address and arbitrary-bank fingerprints. | — |
| [uniform_shear_pivot.md](uniform_shear_pivot.md) | Exact width for one fixed quantum change of basis valid in all nonzero shear directions. | [uniform_shear_pivot_check.py](uniform_shear_pivot_check.py) |
| [joint_monomial_tradeoff.md](joint_monomial_tradeoff.md) | Quantum-width tradeoff for low-degree classical motion in a two-visit occupation readout. | [joint_monomial_tradeoff_check.py](joint_monomial_tradeoff_check.py) |
| [trace_inverse_frame_rank.md](trace_inverse_frame_rank.md) | Single trace-inverse bit substituted into the all-depth calibrated mixing argument; the archived proof supplies the shared prefix. | — |
| [minimal_period_space.md](minimal_period_space.md) | Minimal period-space normalization in the older rare four-band analysis; the later four-band gap supersedes the proposed search. | — |
| [graph_reflection_visit_bound.md](graph_reflection_visit_bound.md) | Contrast the query cost of a rank-one candidate graph reflection with a full field multiplier. | — |
