# How many diagonal stages does a regular-clock encoder need?

Use the full-space model of the joint readout note. Let the bank have one physical Z at every index in the p-bit Boolean cube, let a private p-bit clock receive the external XOR, and permit any number of arbitrary extra wires. For an address-independent encoder V write K_s=V X_clock^s V†. The error is the maximum over s of the operator distance of K_s Z_0 K_s† to Z_s. This note measures the number of work-diagonal unitaries between arbitrary Clifford frames. Every operation inside a computational-basis-diagonal unitary is free for this particular measure. This is a structural measure, distinct from native T-depth.

For p≥3 one diagonal stage has optimal full error exactly √2, even with unbounded width. Two stages suffice exactly. For p=2 the same arguments below give the one-stage lower bound 1. The one-stage √2 example is native and uses only a cubic diagonal.

## The obstruction on four vertices

Assume V=C D C' with D any computational-basis diagonal. In C's basis write Q_s=C† Z_s C and T_s=C' X_clock^s C'†. The T_s are a Pauli representation. Their computational permutations are translations by b_s, linear in s. The intermediate conjugators D T_s D† are arbitrary diagonal phases times those same translations. Conjugating any Pauli by such a monomial always leaves its computational XOR permutation unchanged. If the full error is below √2, applying the candidates to a computational basis vector shows that all Q_s have the same XOR permutation a, because distinct permutations have orthogonal outputs. The operators χ_s=Q_0 Q_s, s≠0, are therefore diagonal Pauli signs. These m−1 characters have independent linear parts. Indeed each nonempty product is Clifford-conjugate to a nonidentity product of independent bank Z operators, including where a factor of Z_0 cancels. Consequently all assignments of the m−1 signs occur for some computational word x.

Write D† Q_0 D |x⟩=λ(x)|x+a⟩, |λ(x)|=1. Since D commutes with χ_s, conjugating the occupation criterion back by D gives
$$
   |\beta_s\lambda(x+b_s)-\chi_s(x)\lambda(x)|\le\epsilon
$$
for every x, where β_s∈{1,−1} is independent of x. It is the commutation sign of the Z component of T_s against the fixed displacement a. In particular b_s cannot vanish for nonzero s when ε<√2, since χ_s takes both signs. Set T={0,e₁,e₂,e₃}. For every one of its six unordered edges choose an orientation (t,u) and put s=t+u. These six nonzero s are distinct. Independence of the characters permits a single choice of x₀ with β_sχ_s(x₀+b_t)=−1 on all six edges; the fixed shift b_t contributes just a fixed sign. Put z_t=λ(x₀+b_t). Now |z_t+z_u|≤ε on all six edges. Four unit complex numbers have two with angular distance at most π/2. For those two |z_t+z_u|≥√2, a contradiction. For p=2 take just three affinely independent vertices. The same circle argument gives 2cos(π/3)=1.

## A matching native construction for p≥3

Put C equal to the Hadamard on every bank bit and take C'=I. Then Q_s=X_s and T_s=X_clock^s. For each u≠0 select one j(u) with u_j=1. In computational bank and clock variables w,r, use the native cubic phase
$$
 D(r,w)=(-1)^{w_0\sum_{u\ne0} r_{j(u)} w_u}.
$$
Conjugation of X_0 by D T_s D† gives X_0 times the product of Z_u on u≠0 where s_{j(u)}=1. At zero this is X_0. At nonzero s it anticommutes with the desired X_s. Anticommuting Hermitian unitaries differ by operator norm √2. The phase is an exact product of shared-control CCZ operations, implementable at constant native depth using private returned phase masks.

## Two identical diagonal stages and the cyclic correlation phase

On two computational m-wire banks A,B define the one prescribed diagonal
$$
 D_{\rm corr}(r,A,B)=(-1)^{\sum_i A_i B_{i+r}}
$$
with sums modulo two, where r is the private clock. Fourier conjugation (Hadamards) on either bank turns it into a selected XOR shear on that bank. The two shears A←A+P_r B and B←B+P_r A, then a fixed swap, map (r,A,B) to (r,P_r A,A+P_r B). Shifting r by s in these encoded coordinates translates its first bank by s on arbitrary A,B and private clock, so this is an exact encoder. It uses precisely two occurrences of the same diagonal and fixed Cliffords. Thus two unrestricted diagonal stages are sufficient and one stage cannot beat √2 error for p≥3.

This phase is itself depth-equivalent to the full native dirty indicator at polynomial discovery cost. Replace B by B+e₀ using a fixed X and use D_corr before and after. The product is the sign (−1)^{A_r} and the entire auxiliary bank B can start arbitrary. Two approximate occurrences, using the actual adjoint for the second, incur at most twice their full error. Conversely, let a dirty program T be toggled by e_r with the full indicator. The phase (−1)^{∑_t T_t ∑_i A_i B_{i+t}} applied before and after this toggle, followed by the actual inverse indicator, returns T and gives D_corr. It is a shared-control cubic grid costing O(m²) T, elementary Cliffords and private dirty wires at O(1) T-depth, plus two indicator occurrences. No gates move the address during this grid. An unrestricted fast native synthesis of D_corr would therefore change the final scaling through R98. Its degree p+2 is a classical-function property and does not lower-bound native T-depth.
