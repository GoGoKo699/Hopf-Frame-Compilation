"""Check the exact rectangular table word in its two-generator subalgebra."""
import itertools
import math
import numpy as np

def check():
    count=0
    for m,n in ((1,1),(1,5),(2,3),(3,2),(3,3),(4,2)):
        short=min(m,n)
        d=1
        while d<math.pi/(2*math.asin(1/math.sqrt(short))):
            d+=2
        lam=math.sin(math.pi/(2*d))
        base=np.diag([1.,-1.])
        for switches in itertools.product((-1,1),repeat=m*n):
            for sign in switches:
                c=lam*sign
                other=np.array([[c,math.sqrt(max(0,1-c*c))],
                                [math.sqrt(max(0,1-c*c)),-c]])
                result=(-1)**((d-1)//2)*np.linalg.matrix_power(base @ other,d)
                assert np.allclose(result,sign*np.eye(2),atol=1e-12)
                count+=1
    print(f'{count} carrier-block entries of table-specific exact return checked')
if __name__=='__main__':
    check()
