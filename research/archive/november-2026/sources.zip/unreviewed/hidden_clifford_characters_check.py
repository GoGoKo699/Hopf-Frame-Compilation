"""Binary group/Clifford character invariant."""
from itertools import product
from random import Random

def mul(x,y,n):
    out=0
    for a in range(n):
        if x>>a&1:
            for b in range(n):
                if y>>b&1 and not a&b:
                    out ^= 1<<(a|b)
    return out

rng=Random(13244)
cases=0
for r in range(1,5):
    n=1<<r
    for _ in range(300):
        f,a,b,c=[rng.randrange(1<<(n-1))<<1 for _ in range(4)]
        z=1
        for s,t,u in product(range(2),repeat=3):
            z=mul(z,1^f^(s*a)^(t*b)^(u*c),n)
        assert z==1
        cases+=1
print(f'{cases} vanishing third group differences in arbitrary square-zero algebras of up to 16 bits')
cases=0
for s,t,x in product(range(2),range(2),range(16)):
    multiplier=1^(s<<1)^(t<<2)
    out=mul(multiplier,x,4)
    assert mul(multiplier,out,4)==x
    if x&1:
        def phase(z):
            return (z>>3&1)^((z>>1&1)&(z>>2&1))
        assert phase(out)^phase(x)==s*t
    cases+=1
print(f'{cases} native Clifford permutation columns with sharp quadratic characters')
# Independent random real/complex Clifford tableaus. Use dense matrices at two qubits.
import numpy as np
from functools import reduce
import operator
I=np.eye(2,dtype=complex); X=np.array([[0,1],[1,0]],complex); Z=np.diag([1,-1])
H=(X+Z)/np.sqrt(2); S=np.diag([1,1j]); SW=np.eye(4)[:,[0,2,1,3]]
CNOT=np.eye(4)[:,[0,1,3,2]]
gates=[np.kron(H,I),np.kron(I,H),np.kron(S,I),np.kron(I,S),SW,CNOT]
def pauli(v):
    xx=[X if v>>i&1 else I for i in range(2)]
    zz=[Z if v>>(i+2)&1 else I for i in range(2)]
    return np.kron(xx[0]@zz[0],xx[1]@zz[1])
ps=[pauli(i) for i in range(16)]
def label(mat):
    cands=[np.trace(p.conj().T@mat)/4 for p in ps]
    w=int(np.argmax(np.abs(cands)));c=int(np.argmin([abs(v-cands[w]) for v in [1,1j,-1,-1j]]))
    assert np.allclose(mat,(1j**c)*ps[w])
    return w,c
nchecks=0
for _ in range(25):
    U=np.eye(4)
    for _ in range(18):
        U=rng.choice(gates)@U
    cols=[label(U@ps[1<<i]@U.conj().T) for i in range(4)]
    for v,c in product(range(16),range(4)):
        selected=[(s,d) for i,(s,d) in enumerate(cols) if v>>i&1]
        v2=reduce(operator.xor,(s for s,d in selected),0)
        c2=c+sum(d for _,d in selected)+2*sum(((s>>2)&t).bit_count() for j,(s,_) in enumerate(selected)
                                                   for t,_ in selected[j+1:])
        assert label(U@(1j**c*ps[v])@U.conj().T)==(v2,c2%4)
        nchecks+=1
print(f'{nchecks} complex Clifford ordered-phase lifted-coordinate checks')
