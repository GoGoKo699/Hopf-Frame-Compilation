"""Finite exact checks for the one-stage sign geometry and the correlation target."""
from itertools import combinations, product

def routing(x, s):
    return sum(((x >> (i ^ s)) & 1) << i for i in range(1 << p))

for p in range(3, 9):
    simplex = [0, 1, 2, 4]
    assert len({t ^ u for t, u in combinations(simplex, 2)}) == 6
    for s in range(1, 1 << p):
        select = lambda u: (u & -u).bit_length() - 1
        active = sum(((s >> select(u)) & 1) << u for u in range(1, 1 << p))
        assert active >> s & 1
print('6 Sidon edges and 498 nonzero-sector anticommuting cubic examples (p=3,...,8)')
cases = 0
for p in range(1, 3):
    m = 1 << p
    for r, a, b in product(range(m), range(1 << m), range(1 << m)):
        parity = lambda x: x.bit_count() % 2
        corr = lambda z: parity(a & routing(z, r))
        assert corr(b) ^ corr(b ^ 1) == (a >> r) & 1
        a1 = a ^ routing(b, r)
        b1 = b ^ routing(a1, r)
        assert (b1,a1)==(routing(a,r), a ^ routing(b,r))
        cases += 1
print(f'{cases:,} complete correlation derivatives and two-stage encoder cases')
