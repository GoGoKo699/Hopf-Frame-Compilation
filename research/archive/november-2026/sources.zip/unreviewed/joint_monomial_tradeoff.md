# Classical motion and quantum width in a two-visit occupation readout

Use $m=2^p$, translation $P_s e_i=e_{i+s}$, and a full-input site echo $K_s Z_0 K_s^\dagger\simeq Z_s$. Here $K_s$ is an exact unitary representation of $\mathbb F_2^p$. The site approximation is required on all inputs and has operator error $\epsilon$. All statements hold in arbitrary fixed Clifford coordinates, where the bank operators become independent commuting Hermitian Paulis $P_i$.

## Reduction of a general two-visit word

Let $W_s=A D_s B E_s C$ approximate the literal site phase $Z_s$ with error $\delta$. The work-only fixed gates can be arbitrary and $D,E$ can be different representations. Put $R_s=A D_s A^\dagger$, $F_s=W_sW_0^\dagger$. Then $F_s=R_s S_s$ for a second representation $S$, and
$$
R_t F_u R_t^\dagger=F_{t+u}F_t^\dagger=W_{t+u}W_t^\dagger .
$$
Consequently $R_t(Z_u Z_0)R_t^\dagger$ is within $4\delta$ of $Z_{u+t}Z_t$. Take $u$ one fixed nonzero coordinate direction and $t$ in its complementary $(p-1)$-space. A layer of disjoint, fixed CNOTs identifies each pair parity $Z_{u+t}Z_t$ with an independent physical bank $Z_t$. Thus the *outside gate* $A$ already gives an occupation encoder on $p-1$ address bits, at the same native depth. Apply the same argument to the adjoint word for the obligation on $C^\dagger$. In the other direction the encoder echo supplies a two-visit solution on all $p$ bits.

Any diagonal pulse with phase $(-1)^{s\cdot f(y)}$ can be enlarged by $p$ arbitrary spectator bits $r$ bearing $Z_r^s$, preserving any existing occupation encoder by extension with identity. The fixed XOR $r\gets r+f(y)$ then recodes the enlarged pulse to $Z_r^s$ alone. For private cubic or quartic pulses the fixed XOR is respectively a shared-control three- or twelve-T-layer native implementation by the paid phase gadgets and surrounding $H_r$, of singly exponential size. Thus a low-depth solution on either original pulse would yield one for bare Pauli visits. An undoped nonzero-trace generator cannot itself be unitarily recoded to one with a traceless independent Pauli factor.

## Model and exact tradeoff

In the fixed Clifford coordinates suppose
$$
 K_s|y,\psi\rangle=|\sigma_s(y)\rangle U_{s,y}|\psi\rangle ,
$$
where the fully quantum word has $k$ qubits and the classical-coordinate permutation and quantum gates are otherwise arbitrary. For each fixed $y$ let every individual bit of $\sigma_s(y)$ have Boolean degree at most $d$ in the selector $s$. Write $B(a,d)=\sum_{j=0}^{\min(a,d)}\binom{a}{j}$. At exact error,
$$
 k\ \ge\ \max\{0,2^p-2 B(p,d)\}.
$$
This bound is attained by an exact regular-clock representation in suitable Clifford coordinates.

Indeed, let $M=\mathbb F_2[\mathbb F_2^p]$, the regular module for bank masks $\lambda$. In binary Pauli coordinates let $x(\lambda),z(\lambda)$ be the classical X/Z labels and let $q(\lambda)$ be the $2k$-bit quantum Pauli label. Tracking only classical displacements gives
$$
 \sigma_s(y+x_i)=\sigma_s(y)+x_{i+s},\qquad x_i=x(e_i).
$$
This relation still holds for $2\epsilon<\sqrt2$ because exact representation and singleton transport imply all-site transport to error $2\epsilon$, and distinct output basis words give distance $\sqrt2$ on an input. Iterating the relation gives a common linear action of $\sigma_s$ along every coset of $X=\operatorname{span}\{x_i\}$. In particular $x(P_s\lambda)=\sigma_s(x(\lambda))+\sigma_s(0)$.

Put $K=\ker x$ and $H=\ker x\cap\ker q$. Both are invariant at exact transport. On $H$ the bank operator is purely diagonal on the classical word. It therefore transforms as
$$
 z(P_s\lambda)_j=z(\lambda)\cdot[\sigma_s^{-1}(e_j)+\sigma_s^{-1}(0)].
$$
The inverse permutation is $\sigma_s$ by involutivity. Differences of order $d+1$ vanish in both expressions. Let $J$ be the augmentation ideal in $M=\mathbb F_2[t_1,\dots,t_p]/(t_i^2)$, with $t_i=1+g_i$ acting as a first selector difference. Then $J^{d+1}M\subset K$ and $J^{d+1}H=0$. The annihilator of $J^{d+1}$ is $J^{p-d}$ (for $d<p$), seen by multiplying squarefree monomials by complementary supports. Commuting bank Paulis in $K$ have commuting quantum components since their classical X labels vanish, so $\dim K/H\le k$. Taking dimensions proves the bound.

For sharpness take the exact regular-clock representation $|r,Y\rangle\mapsto|r+s,P_sY\rangle$ obtained by the fixed controlled permutation $Y\mapsto P_rY$ before and after $r\mapsto r+s$. For $d<p/2$ the invariant commuting label space on the bank
$$
 L=Z(J^{p-d})\oplus X((J^{d+1})^\perp)
$$
is isotropic since $J^{p-d}\subset J^{d+1}$. Its dimension is $2B(p,d)$. In a Clifford basis putting $L$ in the classical Z generators, $K_s$ is block monomial and its classical motion has degree $\le d$. On the two summands the action is that on $J^{p-d}$ and the dual of $M/J^{d+1}$, respectively. Both are annihilated by $J^{d+1}$, so their matrix entries are degree $\le d$. Use pure Z and pure X basis generators, so products and their image signs do not introduce carries or offsets. Put the regular clock into the Fourier basis if $d=0$. The remaining bank wires give $k=m-2B(p,d)$. For $d\ge\lfloor p/2\rfloor$ use the maximal isotropic $Z(J^j)\oplus X((J^j)^\perp)$ with $j=\lceil p/2\rceil$; the degrees of its two summands are $p-j$ and $j-1$. When $p$ is even use this cut at $d=p/2$ where the preceding strict formula does not apply. The use of a high-depth fixed controlled permutation in this witness only demonstrates tightness of the representation tradeoff.

## Purely monomial motion at constant error

If $k=0$ and $\epsilon<\sin(\pi/8)$, still $d\ge\lfloor p/2\rfloor$, with arbitrary complex phases. It suffices to recover the purely diagonal kernel identity on $K$. Fix $s$ and write the unit-modulus phase on input $y$ as $F(y)$. Every site transport implies
$$
 F(y+x_i)/F(y)\ \simeq\ \alpha_i(-1)^{z_i\cdot y+z_{i+s}\cdot\sigma_s(y)}
$$
with angle error at most $\kappa=2\arcsin\epsilon$. For arbitrary $w$, take ratios at $y+w,y$. On a fixed coset of $X$ the difference $b=\sigma_s(y+w)+\sigma_s(y)$ is constant. Thus the unit-circle function $H_w(y)=F(y+w)/F(y)$ satisfies $H_w(y+x_i)/H_w(y)\simeq (-1)^{z_i\cdot w+z_{i+s}\cdot b}$ at angle $2\kappa<\pi/2$.

Any such approximate translation signs in fact form a character of $X$. Choose a basis from the $x_i$ and divide out the character fixed by the signs on that basis. The short oriented edge angles on this cube have zero winding on every square because their magnitudes are strictly below $\pi/2$. Backtracking edges cancel, so they integrate to a single real-valued lift $h$ on the cube. If a remaining vector $v$ is assigned minus, $h(y+v)-h(y)$ lies in an interval about an odd multiple of $\pi$, of half-width $<\pi/2$. As $y$ moves by a basis edge, this difference changes by less than $\pi$, smaller than the gap between consecutive such intervals. It can never leave its initial interval, whereas $y\mapsto y+v$ negates the difference, a contradiction. Thus for every $\lambda\in K$, $z(\lambda)\cdot w=z(P_s\lambda)\cdot b$ for all $y,w$. Substituting preimages of $0,e_j$ gives the exact kernel identity above. The dimension bound with $k=0$ follows.

## Constant-error tradeoff with quantum work

At any fixed $\epsilon<1/(2\sqrt2)$ and all $a,b\ge0$ with $a+b=p$,
$$
 1-h_2(4\epsilon^2)\ \le\ \frac{B(b,d)}{2^b}+\frac{B(a,d)+k}{2^a}.
$$
For $d=o(p)$ it follows that $k\ge\Omega_\epsilon(2^{p-O_\epsilon(d+1)})$. In particular at $d=O(1)$ almost-classical readouts still require an extensive number of fully quantum wires. This concerns representation of the complete readout in a common frame; a dirty width allowance of order $2^p$ can accommodate it.

To see the inequality, take any truth table $v(i)$, choose a physical Pauli $R$ with commutation signs $(-1)^{v(i)}$ against the independent $P_i$, and write $w$ for its classical X label. Put $W_s=K_s R K_s^\dagger$. Since $K_s^\dagger=K_s$, its commutator against $P_i$ has the target sign $(-1)^{v(i+s)}$ at operator error $\le4\epsilon$ by the all-site bound. Restrict $W_s$ to input columns with classical word in the affine subspace $\sigma_s(0)+X$. Every such column has fixed displacement $b_s=\sigma_s(w)+\sigma_s(0)$, by the classical displacement identity. The restriction is invariant under conjugating its input domain by each $P_i$. In normalized Hilbert–Schmidt norm the restricted, renormalized operator has unit norm and its signed conjugation errors are at most $4\epsilon$.

An orthogonal operator basis on that restricted coset/displacement consists of Fourier characters $\ell$ on $X$ multiplying the shift by $b_s$, tensored with all quantum Paulis labeled $\alpha$. Under $\mathrm{Ad}_{P_i}$ its eigenbit is
$$
 z_i\cdot b_s+\ell(x_i)+\omega(q_i,\alpha).
$$
The normalized squared coefficient mass in the wrong eigenspace is at most $4\epsilon^2$ for each $i$. For any subgroup $A$ on $a$ coordinate directions there exists a single component whose wrong fraction among all $i\in A$ is at most $4\epsilon^2$. Each column correction $i\mapsto\ell(x_i)+\omega(q_i,\alpha)$ is drawn from a fixed binary code of dimension at most $B(a,d)+k$. In fact its dimension is the joint rank of the restricted $x_i,q_i$ columns. Each classical X coordinate is degree $\le d$ in $i$, and quantum components of $x$-null masks are isotropic. The term $z_i\cdot b_s$ has degree at most $d$ in $s$ for each row $i$.

Take $s$ in the complementary $b$-dimensional subgroup. The array $v(i+s)$ ranges over every $2^a\times2^b$ binary matrix. Each array is within normalized Hamming distance $4\epsilon^2$ of the sum of a matrix with rows in the degree-$d$ Reed--Muller code on $b$ variables and a matrix with columns in that fixed correction code. Counting the dimension of this linear sum from above and applying the binary Hamming-ball volume bound proves the inequality. To obtain the asymptotic consequence, choose $b=C_\epsilon(d+1)$ large enough to make $B(b,d)/2^b$ smaller than half $1-h_2(4\epsilon^2)$, while $B(a,d)/2^a=o(1)$.
