# All-depth rank for a candidate trace-inverse bit

This is the original working suffix to fixed_accuracy/quartic_frame_rank.md in the published Hopf_Zero_Test_and_Precision_Proofs.zip. The earlier frame path expansion is kept in that archive.

## The proposed single trace bit

For the earlier local candidate let F have q=2^{k+1} elements, let c,d be nonzero, let H={x:Tr(cx)=0}, with |H|=2^k, and put χ(x)=(−1)^{Tr(d inv₀(x))} for x∈H. A complete XOR word for this bit is tested on the target state |−⟩ and all work fixed to zero, producing exactly the same scalar-amplitude comparison as above. Uniform homomorphism H→F₂^k in any binary basis preserves the uniformity norm.

Four uniform directions h₁,…,h₄ of H are dependent with probability at most 15/2^k. Otherwise their span S has 16 points, and off these points the fourth cube derivative on H equals the canonical field additive character of R(x)=dΣ_{s∈S}1/(x+s). Introduce the indicator of H in F as the half sum of 1 and the field character of cx. The two complete sums then have rational functions R(X) and R(X)+cX. Each has 16 distinct simple finite poles, so neither is an Artin–Schreier difference h²−h+constant, even over the algebraic closure. The rational additive Weil estimate is O(√q) with an absolute constant in both cases, since pole numbers and their orders are bounded. The convention at the 16 poles costs at most 16 in the sum over H. This gives
$$
 \|\chi\|_{U^4(H)}^{16}=O(2^{-k/2}) .
$$
Consequently an implementation of this **particular** inverse trace XOR at fixed uniform full-return error ε<√2 needs H_min≥k/16−O_ε(1) and Γ_all≥k/32−O_ε(1). This remains a linear-rank requirement compatible with the polynomial local resource budget and with shallow wide bands. A sufficient reference for the rational additive character bound and its hypotheses is [Cochrane and Pinner, Theorem 1.1](https://www.math.ksu.edu/~cochrane/research/stepmix.pdf).
