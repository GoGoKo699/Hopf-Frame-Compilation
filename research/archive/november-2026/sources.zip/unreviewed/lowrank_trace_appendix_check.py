"""Finite independent check of Clifford low-rank closure and literal trace expansion."""
from itertools import product
from random import Random
import math
import numpy as np


def parity(x):
    return x.bit_count() & 1


def symp(a,b,n):
    mask=(1<<n)-1
    return parity(((a&mask)&(b>>n))^((a>>n)&(b&mask)))


def image(cols,x):
    ans=0
    for j,col in enumerate(cols):
        if x>>j&1: ans ^= col
    return ans


def span_basis(vectors):
    out={}
    for v in vectors:
        for bit in sorted(out,reverse=True):
            if v>>bit&1: v ^= out[bit]
        if v: out[v.bit_length()-1]=v
    return list(out.values())


def span(basis):
    return [image(basis,x) for x in range(1<<len(basis))]


def transvect(a,v,n):
    return v^(a if symp(a,v,n) else 0)


def find_nondegenerate_container(K,n):
    pairs=[]
    rad=list(K)
    while True:
        pair=next(((a,b) for a in rad for b in rad if symp(a,b,n)),None)
        if pair is None: break
        a,b=pair
        rad=span_basis(v^(a if symp(v,b,n) else 0)^(b if symp(v,a,n) else 0) for v in rad)
        pairs.append(pair)
    while rad:
        a=rad.pop()
        b=next(w for w in range(1<<(2*n)) if symp(a,w,n) and all(not symp(w,v,n) for v in rad) and all(not symp(w,z,n) for pair in pairs for z in pair))
        pairs.append((a,b))
    return pairs


def correction(cols,n):
    cols=list(cols)
    identity=[1<<j for j in range(2*n)]
    K=span_basis(x^y for x,y in zip(cols,identity))
    pairs=find_nondegenerate_container(K,n)
    basis=[x for pair in pairs for x in pair]
    assert len(basis)<=2*len(K)
    vectors=span(basis)
    out=[]
    for j,w in enumerate(basis):
        v=image(cols,w)
        if v==w: continue
        if symp(v,w,n):
            path=[v^w]
        else:
            u=next(t for t in vectors if symp(v,t,n) and symp(w,t,n) and all(not symp(v^t,b,n) for b in basis[:j]))
            path=[v^u,u^w]
        for axis in path:
            assert all(not symp(axis,b,n) for b in basis[:j]); cols=[transvect(axis,vv,n) for vv in cols]; out.append(axis)
    assert cols==identity
    return out,len(K)


def pauli(v,n):
    d=1<<n; x=v&(d-1); z=v>>n
    mat=np.zeros((d,d),dtype=complex)
    for j in range(d): mat[j^x,j]=(1j**((x&z).bit_count()))*(-1 if parity(j&z) else 1)
    return mat


def pauli_product(v,w,n):
    mask=(1<<n)-1; x=v&mask; z=v>>n; y=w&mask; t=w>>n
    exponent=((x&z).bit_count()+(y&t).bit_count()+2*parity(z&y)-((x^y)&(z^t)).bit_count())%4
    return (v^w,1j**exponent)


def test():
    rng=Random(20261119)
    cases=0; largest=0
    for n in (2,3,4,5):
        n2=1<<n; eye=np.eye(n2,dtype=complex); P=[pauli(v,n) for v in range(1<<(2*n))]
        for trial in range(70):
            target_r=rng.randrange(0,min(4,2*n)+1)
            original=[1<<j for j in range(2*n)]
            axes=rng.sample(range(1,1<<(2*n)),target_r)
            j=rng.randrange(8); y=rng.randrange(1<<(2*n)); U=np.exp(1j*j*math.pi/4)*P[y]
            for v in axes:
                original=[transvect(v,col,n) for col in original]
                U=(eye+1j*P[v])@U/math.sqrt(2)
            closure,r=correction(original,n)
            largest=max(largest,len(closure)); fixed=U.copy()
            for v in closure: fixed=(eye+1j*P[v])@fixed/math.sqrt(2)
            # The Pauli action on generators determines the two halves of a.
            a=0
            for i in range(2*n):
                sign=np.trace(fixed@P[1<<i]@fixed.conj().T@P[1<<i]).real/n2
                assert abs(abs(sign)-1)<1e-9
                if sign<0: a|=1<<((i+n)%(2*n))
            gamma=np.trace(fixed@P[a]).item()/n2
            assert abs(abs(gamma)-1)<1e-9 and abs(gamma**8-1)<1e-8
            # Undo all closure rotations around the Pauli left in fixed.
            terms={a:gamma}
            for v in reversed(closure):
                update={}
                for w,c in terms.items():
                    u,f=pauli_product(v,w,n)
                    update[w]=update.get(w,0)+c/math.sqrt(2)
                    update[u]=update.get(u,0)-1j*c*f/math.sqrt(2)
                terms=update
            actual=np.trace(U)/n2
            assert abs(actual-terms.get(0,0))<1e-9
            assert abs(actual)<=2**(-r/2)+1e-9
            cases+=1
    print(f'{cases} literal complex Clifford traces checked, n=2..5, rank 0..4; max closure rotations {largest}.')
if __name__=='__main__': test()
