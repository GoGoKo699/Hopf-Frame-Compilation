# A circuit-level Clifford-correlation test for an arbitrary scalar phase

Write $F(x)=(-1)^{f(x)}$ on $p$ address bits. The following directly tests a candidate prescribed-phase word, including its inverse and dirty return when these are part of the word. Form its ordered native Pauli T axes by moving each Clifford to the output. Take the stabilizer input $|x,0,\Phi\rangle$ with the clean wires zero and an external Bell reference for every dirty wire. Let $r$ be the binary rank of the syndromes of all the T axes against the stabilizer generators of this state. This rank is independent of $x$. Equivalently it is the rank of their span modulo the subspace of physical logical/clean Z labels. Put $c=\cos(\pi/8)$, and let $t$ count all T or T-dagger gates.

For the actual returned diagonal amplitude
$$
A(x)=\langle x,0,\Phi|U|x,0,\Phi\rangle
$$
there exists a probability distribution on functions $\gamma q(x)$, where $|\gamma|=1$ and $q$ is a diagonal Clifford phase in the original computational address, such that
$$
A(x)=c^{2r-t}\,\mathbb E[\gamma q(x)]\qquad\text{for every }x .
$$
The *same* distribution works on every address. It is a mathematical representation of the emitted circuit. The sampled Clifford phases need not synthesize the original operator.

## Proof

Use the chronological pivot decomposition in the companion half-span note, always using the same pivots for every $x$. Replace each of the $t-r$ other T rotations by the uniform average of its identity and Clifford terms, times $1/c$. In every fixed branch the remaining T axes have independent flip syndromes. A fixed input Clifford puts $|0,0,\Phi\rangle$ at the all-zero state, with the family $|x,0,\Phi\rangle$ now computational translates $|q_x\rangle$ times a diagonal Clifford phase of $x$; $q_x$ is affine in $x$.

In one such branch write $M$ for the matrix of the $r$ independent pivot flips, and $Z$ for the matrix of their Z components. On input $q_x$ the amplitude for subset $u$ of the pivots is its value at zero multiplied by $(-1)^{u^\top Z^\top q_x}$, reaching $q_x+Mu$. A linear-in-$x$ Pauli mask realizes this factor on those positions because $M^\top$ is onto. Thus the branch's output is a Pauli-affine translate of its zero-input state, up to a diagonal Clifford phase in $x$. That state is a fixed Clifford applied to $|H\rangle^{\otimes r}|0\rangle$, where $|H\rangle=c|0\rangle+s|1\rangle$ and $s=\sin(\pi/8)$. Moving the branch's final Clifford, Pauli translates and pivot basis change into the bra reduces the diagonal matrix element to the overlap of this product with a Pauli-affine translate of one stabilizer.

Each such bra has a common affine support direction of dimension $k$ and literal amplitudes of the form $2^{-k/2}\gamma q(x,u)$ on the translated support. Here $q$ is a diagonal Clifford phase jointly in the translated physical coordinates $u$ and $x$. This follows either from the stabilizer normal form (constant-amplitude affine support with mod-four linear and binary quadratic phases), or by lifting the commuting input Pauli generators and keeping their pair commutations. The products of affine Pauli families add at most a binary quadratic sign and a mod-four linear phase. Restriction to the affine support and affine coordinate changes preserve the diagonal Clifford form, since a binary parity viewed modulo four has even quadratic coefficients and no cubic terms.

Impose zero on all spectator coordinates of the magic product. The set of $x$ with a surviving bra support is an affine subspace. On it, the resulting affine supports on the first $r$ coordinates have the same direction and the same dimension $k'\le k$. Choose one common information set of $k'$ of these $r$ coordinates. Use its actual bits $w$ as free variables. Every other coordinate $u_{\mathrm{rem}}$ is an affine function of $(x,w)$, with an arbitrary affine extension off the valid addresses. Thus, after division by $c^r$, the overlap on valid inputs is exactly a common unit phase times
$$
2^{-(k-k')/2}\,\mathbb E_w\left[q'(x,w)(s/c)^{|u_{\mathrm{rem}}(x,w)|}\right],
$$
where the $w$ bits are independent with $\Pr[w_i=1]=(s/c)/(1+s/c)$ and $1+s/c=\sqrt 2$. For fixed $w$, $q'(x,w)$ is again a diagonal Clifford phase in $x$.

The attenuation factor is an expectation of $(-1)^{b\cdot u_{\mathrm{rem}}}$ with independent $b_i$ satisfying $\mathbb E(-1)^{b_i}=s/c$. The affine guard $[Lx=d]$ is an expectation of $(-1)^{z\cdot(Lx+d)}$ for uniform $z$. The constant attenuation $2^{-(k-k')/2}$ is an expectation of a random global sign; an empty support is handled similarly with mean-zero sign. Hence the whole branch overlap divided by $c^r$ is an average of unit-modulus Clifford phases on $x$. Restoring $c^{-(t-r)}$ from the nonpivot expansion proves the claim. All inputs and references are retained; the proof estimates an actually returned matrix element rather than supplying an amplitude oracle.

## Consequences

Define $C(F)=\max_q|2^{-p}\sum_x F(x)q(x)|$ over diagonal Clifford phases. From full error at most $\epsilon$, pointwise $\Re(F(x)A(x))\ge1-\epsilon^2/2$. A common global phase can be absorbed in the estimator. Necessarily
$$
t-2r\ \ge\ \frac{\log_2((1-\epsilon^2/2)/C(F))}{\log_2(1/c)}.
$$
Thus a readout with many linearly independent flips must also generate a surplus of T rotations when the desired phase correlates weakly with every quadratic Clifford phase. In the exact extremal case $t=2r$, a full phase must itself be a diagonal Clifford up to a scalar: an average of unit complex numbers can have modulus one only if all positive-weight summands agree at that point, and there are only finitely many addresses.

There are at most $4^p 2^{p(p-1)/2}$ distinct diagonal Clifford phases up to a common scalar. A uniformly random sign table has $C(F)=O((p+1)2^{-p/2})$ with probability tending to one by Hoeffding's bound on the real and imaginary parts and a union bound. Therefore some prescribed phases require
$$
t-2r\ge\frac{p/2-O(\log(p+2))}{\log_2(1/c)}
$$
at fixed error. The leading coefficient is approximately $4.38p$. This does not give a growing native T-depth bound at a fixed unspecified constant in the square-root T-count budget.

An explicit family is the parity of $k$ disjoint triple-ANDs, on $3k$ bits. Its correlation with every diagonal Clifford phase is at most $(11/32)^{k/8}$. Repeated Cauchy–Schwarz bounds correlation against every degree-two multiplicative phase by the normalized third Gowers norm. A mod-four linear times quadratic binary Clifford phase has third multiplicative derivative one. For one triple the third derivative of the cubic exponent is the determinant of three independent uniform binary three-vectors. An invertible matrix occurs with probability $(7/8)(6/8)(4/8)=21/64$, giving mean sign $11/32$. Independent blocks multiply. This establishes a linear-in-$k$ lower bound on the excess $t-2r$ for an explicit table.

The half-span counting and the correlation argument are logically independent of any special cut or particular Hadamard normal form. The former gives a leading T-count/T-depth tradeoff for the full family; the latter furnishes a directly computable diagnostic for a proposed scalar circuit.

## A robust test on any nonquadratic sign, and an explicit product bound

A nonquadratic Boolean function has a three-variable coordinate subcube on which its sign equals $(-1)^{x_1x_2x_3}$ times a quadratic sign: take three directions in a nonzero monomial whose third derivative is nonzero at some fixing of the other bits. Restricting a diagonal Clifford phase to that cube keeps it diagonal Clifford. The maximal normalized correlation of the cubic sign with a diagonal Clifford on three bits is $3/4$. In detail, parameterize every Clifford by $i^{a\cdot x}(-1)^{b_1x_1x_2+b_2x_1x_3+b_3x_2x_3}$ with $a\in\mathbb Z_4^3$ and $b\in\mathbb F_2^3$. The squared magnitudes of the unnormalized eight-term sums have values $4,20,36$ with multiplicities $392,112,8$. The fixture computes all with Gaussian integers. The same circuit rank $r$ applies to all addresses on the cube. Consequently **every nonquadratic sign requires $t\ge2r+4$ whenever $\epsilon\le1/4$.**

For the parity of $k$ disjoint cubic terms, the exact correlation with any diagonal Clifford is $(3/4)^k$. Indeed a three-qubit stabilizer with support having at most four computational points has overlap with the normalized CCZ sign state at most $1/\sqrt2$. On full support the 512 phases give maximum $3/4$. Bravyi et al. prove that all three-qubit states are stabilizer aligned and that stabilizer fidelity multiplies on their tensor products (Theorem 5 and Corollaries 1, 3). Thus the maximal absolute stabilizer overlap of the $k$-block sign state is $(3/4)^k$, attained by the all-plus stabilizer. Diagonal Clifford phases give a subset of these stabilizers and include that attaining state. This improves the elementary $U^3$ estimate to
$$
t-2r\ \ge\ \frac{k\log_2(4/3)+\log_2(1-\epsilon^2/2)}{\log_2(1/c)} .
$$
At fixed precision it has leading coefficient about $3.63k$. [Bravyi et al., *Simulation of quantum circuits by low-rank stabilizer decompositions*, Section 6](https://eprints.whiterose.ac.uk/id/eprint/150621/1/q-2019-09-02-181.pdf).

The magnitude of this test has a useful ceiling. Walsh characters are diagonal Clifford phases. Parseval and Cauchy–Schwarz give $\sum_u|\widehat F(u)|\le2^{p/2}$ for every sign table. Hence the absolute-convex Clifford norm of every unscaled sign is at most $2^{p/2}$. For a typical sign the preceding correlation witness gives at least $2^{p/2}/O(p)$ for the same norm. The logarithmic deficit obstruction for a typical table is therefore sharp to additive $O(\log p)$ *as an atomic-norm test*. Converting one of these mathematical expansions to a native returned phase would be a separate constructive problem.
