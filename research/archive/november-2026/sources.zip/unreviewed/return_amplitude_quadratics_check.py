from itertools import combinations, product
from math import cos, pi, sin
from random import Random
import numpy as np

rng = Random(72011)
c = cos(pi / 8)
s = sin(pi / 8)


def rank(vectors):
    pivots = {}
    for v in vectors:
        while v:
            b = v.bit_length() - 1
            if b not in pivots:
                pivots[b] = v
                break
            v ^= pivots[b]
    return len(pivots)


def dictionary(n):
    xs = np.array([[(x >> i) & 1 for i in range(n)] for x in range(1 << n)])
    pairs = list(combinations(range(n), 2))
    monomials = np.array([xs[:, i] * xs[:, j] for i, j in pairs])
    out = []
    for lin in product(range(4), repeat=n):
        phase = xs @ lin
        for quad in product(range(2), repeat=len(pairs)):
            term = np.asarray(quad) @ monomials if pairs else 0
            out.append((1j) ** ((phase + 2 * term) % 4))
    return np.asarray(out)


def clifford(matrix, q):
    N = 1 << q
    for _ in range(4 * q):
        i = rng.randrange(q)
        j = rng.randrange(q)
        kind = rng.randrange(3)
        old = matrix.copy()
        for x in range(N):
            bit = (x >> i) & 1
            if kind == 0:
                matrix[x] = ((-1) ** bit * old[x] + old[x ^ (1 << i)]) / np.sqrt(2)
            elif kind == 1:
                matrix[x] = 1j ** bit * old[x]
            elif i != j:
                matrix[x] = old[x ^ (bit << j)]
    return matrix


def amplitude(n, a, w, X, Z, signs):
    q = n + a + w
    N = 1 << q
    circ = np.eye(N, dtype=complex)
    labels = np.arange(N)
    for x, z, sign in zip(X, Z, signs):
        phases = np.array([(-1) ** ((int(y) & z).bit_count() % 2) for y in labels])
        phases = (1j) ** ((z & x).bit_count() % 4) * phases
        rot = (phases[:, None] * circ)[labels ^ x]
        circ = c * circ + sign * 1j * s * rot
    circ = clifford(circ, q)
    diag = np.diag(circ)
    return sum(diag[:(1 << n)] if not k else
               diag[(k << (n + a)):(k << (n + a)) + (1 << n)] for k in range(1 << w)) / (1 << w)


duals_tested = 0
for n in (1, 2, 3):
    D = dictionary(n)
    words = 1 << n
    duals = [[(-1) ** ((mask >> i) & 1) for i in range(words)] for mask in range(1 << (words - 1))]
    duals += [[complex(rng.uniform(-1, 1), rng.uniform(-1, 1)) for _ in range(words)] for _ in range(45)]
    duals = np.asarray(duals)
    caps = np.max(abs(duals @ D.T), axis=1)
    if n == 3:
        ccz = np.ones(words); ccz[-1] = -1
        assert abs(np.max(abs(D @ ccz)) / words - 3/4) < 1e-12
        for row in duals[:1 << (words - 1)]:
            if np.prod(row.real) < 0:
                assert np.max(abs(D @ row)) <= 6.000001
    for _ in range(350):
        a = rng.randrange(2); w = rng.randrange(2); q = n + a + w
        t = rng.randrange(13)
        axes = [rng.randrange(1, 1 << (2 * q)) for _ in range(t)]
        X = [label % (1 << q) for label in axes]
        Z = [label >> q for label in axes]
        signs = [rng.choice([-1, 1]) for _ in axes]
        synd = [x ^ ((z >> (n + a)) << q) for x, z in zip(X, Z)]
        r = rank(synd)
        amp = amplitude(n, a, w, X, Z, signs)
        assert np.max(abs(duals @ amp) - caps * c ** (2 * r - t)) < 2e-11
        duals_tested += len(duals)
print(f'{duals_tested:,} quadratic-correlation bounds from complete native return amplitudes')


def multiply(x, y, poly):
    m = poly.bit_length() - 1
    out = 0
    while y:
        if y & 1:
            out ^= x
        y >>= 1
        x <<= 1
        if x & (1 << m):
            x ^= poly
    return out


def power(x, exponent, poly):
    y = 1
    while exponent:
        if exponent & 1:
            y = multiply(y, x, poly)
        x = multiply(x, x, poly)
        exponent >>= 1
    return y


field_branches = 0
for n, poly in [(3, 0b1011), (4, 0b10011), (5, 0b100101), (6, 0b1000011),
                (7, 0b10000011), (8, 0x11b)]:
    size = 1 << n
    fs = []
    for x in range(size):
        z = power(x, 7, poly)
        trace = 0
        for _ in range(n):
            trace ^= z
            z = multiply(z, z, poly)
        assert trace in (0, 1)
        fs.append(trace)
    for h in range(1, size):
        ds = [fs[x] ^ fs[x ^ h] for x in range(size)]
        rows = [sum((ds[0] ^ ds[1 << i] ^ ds[1 << j] ^ ds[(1 << i) ^ (1 << j)]) << j
                    for j in range(n)) for i in range(n)]
        r = rank(rows)
        radical_count = 0
        for x in range(size):
            h2, h8, h16 = (power(h, j, poly) for j in (2, 8, 16))
            x2, x8, x16 = (power(x, j, poly) for j in (2, 8, 16))
            R = (multiply(h8, x16, poly) ^ multiply(h2 ^ h16, x8, poly)
                 ^ multiply(h ^ h8, x2, poly) ^ multiply(h2, x, poly))
            assert (R == 0) == all((x & row).bit_count() % 2 == 0 for row in rows)
            radical_count += R == 0
        assert radical_count <= 16 and r >= n - 4
        field_branches += 1
print(f'{field_branches:,} complete nonzero-derivative radical identities through GF(256)')
