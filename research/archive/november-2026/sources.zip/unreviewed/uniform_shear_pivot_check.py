"""Exact label, group-algebra and small matrix tests for a universal shear pivot."""
from itertools import combinations, product


def pair(u,v):
    x,z=u
    y,w=v
    return ((x&w).bit_count()+(z&y).bit_count())%2


def plus(u,v):
    return u[0]^v[0],u[1]^v[1]


def majoranas(n):
    out=[]
    for i in range(n):
        out.extend([(1<<i,(1<<i)-1),(1<<i,(1<<(i+1))-1)])
    return out


def summed(vs):
    out=0,0
    for v in vs:
        out=plus(out,v)
    return out


def sharp(h):
    m=1<<h
    w=(m-2)//2
    axes=majoranas(w)
    axes.append(summed(axes))
    z=[summed(v for j,v in enumerate(axes,1) if j&(1<<k)) for k in range(h)]
    assert all(pair(u,v)==1 for u,v in combinations(axes,2))
    assert all(not pair(u,v) for u,v in combinations(z,2))
    for d,v in enumerate(axes,1):
        assert sum(pair(s,v)<<j for j,s in enumerate(z))==d
    return axes,z


def apply_pauli(v, column):
    x,z=v
    phase=(1j**((x&z).bit_count()%4))*(-1)**((column&z).bit_count()%2)
    return column^x,phase


def mat(n, fun):
    return tuple(tuple(fun(col).get(row,0) for col in range(n)) for row in range(n))


def dagger(a):
    return tuple(tuple(ascol.conjugate() for ascol in col) for col in zip(*a))


def mult(a,b):
    return tuple(tuple(sum(x*y for x,y in zip(row,col)) for col in zip(*b)) for row in a)


def mulm(a,t):
    return tuple(tuple(t*x for x in row) for row in a)


def add(a,b):
    return tuple(tuple(x+y for x,y in zip(r,s)) for r,s in zip(a,b))


def eye(n):
    return mat(n,lambda i:{i:1})


def lit(n,axis):
    def col(i):
        j,p=apply_pauli(axis,i)
        return {j:p}
    return mat(n,col)


def sharp_matrix():
    axes,z=sharp(3)
    m=8
    H=eye(m)
    for v in axes:
        H=add(H,mulm(lit(m,v),1j))
    assert mult(H,dagger(H))==mulm(eye(m),m)
    for a in range(1,m):
        S=lit(m,summed(x for k,x in enumerate(z) if a&(1<<k)))
        R=mult(H,mult(S,dagger(H)))
        assert mult(S,mult(R,S))==mulm(R,-1)
    return m-1


def biased_matrix():
    h=2
    masks=[0,1,2,0]  # repeated masks allow unequal sizes / nonzero bias.
    M=len(masks)
    axes=[(x<<h,(z<<h)^u) for (x,z),u in zip(majoranas(M//2),masks)]
    n=1<<(h+M//2)
    H=mulm(eye(n),0)
    for g in axes:
        H=add(H,lit(n,g))
    assert mult(H,H)==mulm(eye(n),M)
    for a in range(1<<h):
        S=lit(n,(a,0))
        R=mult(H,mult(S,H))
        char=sum((-1)**((a&u).bit_count()%2) for u in masks)
        assert add(mult(S,R),mult(R,S))==mulm(eye(n),2*char)
    return 1<<h


if __name__=='__main__':
    if not __debug__:
        raise RuntimeError('Enable assertions')
    for h in range(3,9):
        sharp(h)
        print('address word',h,'exact minimum total pivot qubits',((1<<h)-2)//2)
    print('full-matrix sharp nonzero directions:',sharp_matrix())
    print('full-matrix biased directions:',biased_matrix())
