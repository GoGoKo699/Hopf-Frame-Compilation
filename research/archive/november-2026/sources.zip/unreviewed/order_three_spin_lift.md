# The cube of a prescribed spin lift reads a high-degree Boolean phase

Let x have k bits. On the m=4^k labels z=(z₁,…,z_k) of k binary two-bit registers let C be the permutation fixing 0 and cycling 1,2,3. Define π_x(z)_i=C^{x_i}z_i. This is a product of commuting order-three coordinate permutations. It is physically inexpensive on the *binary label register*: independent constant-size controlled Cliffords run in parallel on disjoint coordinate/target pairs. The following identity concerns instead the associated spin action on m Majorana modes, with a prescribed scalar convention. It identifies why that scalar matters.

For a directed three-cycle a→b→c→a, define
$$
 R_{abc}=-(\gamma_a-\gamma_b)(\gamma_b-\gamma_c)/2 ,
$$
where distinct Hermitian Majoranas anticommute and square to I. Each factor (γ_a−γ_b)/√2 is a Hermitian unitary and a Pin lift of an adjacent transposition, up to the conventional sign in the vector action. Their product implements the cycle in the even spin action. The scalar part of R is +1/2, the choice obtained from the shortest rotation in its two-dimensional cyclic plane; multiplication by −1 selects the other lift. Direct expansion gives R+R†=I, hence R²−R+I=0 and R³=−I. This lift is unchanged by cyclic permutation of a,b,c, as may be checked in the expanded bivector expression. Disjoint cycles have commuting even lifts. Each named factor is an exact Clifford circuit: a normalized difference of anticommuting Paulis equals a Pauli times a π/2 Pauli rotation, with a fixed correcting phase. Use R=I on fixed points.

There are 4^{k−|x|} fixed labels and (4^k−4^{k−|x|})/3 nontrivial cycles. Thus the product R_x of the prescribed lifts over one representative per cycle satisfies
$$
 R_x^3=(-1)^{(4^k-4^{k-|x|})/3}I=(-1)^{x_1\cdots x_k}I .
$$
Already R_x is an accurately specified target. There is an equivalent word with no need to choose cycle representatives: visiting every label and applying R_{z,π_x z,π_x² z} on nontrivial triples applies each such cyclic lift three times. The entire product gives the desired sign directly. More simply, [γ_z,γ_{π_x z}] equals +I when z is fixed and −I when it is moved, so the product of these pair commutators over all z gives the same answer.

These identities do not by themselves compile the conditional Majorana signs or their data-dependent locations. For each fixed z the binary coordinates of π_x z are affine in x, but selecting the corresponding physical Majorana is an additional native word. The literal fixed-label commutator detects that every x_i with z_i≠0 is zero. The terms capable of supplying full degree still refer to all k controlling bits. Executing fixed representative-free factors at unpriced variable labels would conceal precisely that cost.

There is also a sharp obstruction to factorizing the proposed lift along coordinates. Let g_i be any choice of spin lift of the fixed coordinate permutation π_{e_i}. The lifts commute: their commutators are central signs, and g_i³ is central since π_{e_i} has order three; for a central commutator [g_i,g_j]³=[g_i³,g_j]=1, forcing its sign to be +1. Consequently (Π_i g_i^{x_i})³ is a product of fixed linear scalar signs. For k≥2 this cannot equal the desired nonlinear sign. In the canonical scalar convention each individual coordinate permutation at k≥2 already has an even number of cycles and its cube is +I. The native question is therefore a globally signed, jointly priced construction of R_x on the physical modes. Purported solutions using only commuting coordinate lifts fail even if these coordinate lifts were free. This is a complete scalar-phase target, not yet a read-only bit-XOR unless controlled access is supplied (or derivative/extra-bit conversion at the appropriate arity).
