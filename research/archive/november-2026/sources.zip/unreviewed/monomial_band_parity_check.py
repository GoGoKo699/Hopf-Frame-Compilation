"""Numerical Heisenberg witnesses and exact cycle arithmetic for the layer-parity test."""
from collections import Counter
from functools import reduce
from itertools import product
from math import gcd, pi, sqrt, sin
from operator import xor
from random import Random

import numpy as np


def pairing(a, b, n):
    return (((a >> n) & b).bit_count() + ((b >> n) & a).bit_count()) & 1


def pmat(a, n):
    base = (np.eye(2), np.array([[0, 1], [1, 0]]), np.diag([1, -1]),
            np.array([[0, -1j], [1j, 0]]))
    result = np.ones((1, 1))
    for j in range(n):
        code = ((a >> j) & 1) + 2 * ((a >> (n + j)) & 1)
        result = np.kron(base[code], result)
    return result


def rank(rows):
    basis = {}
    for row in rows:
        while row:
            piv = row.bit_length()
            if piv not in basis:
                basis[piv] = row
                break
            row ^= basis[piv]
    return len(basis)


def gates(n, rng):
    rows = []
    for _ in range(rng.randrange(1, n+1)):
        eligible = [z for z in range(1, 1 << (2*n))
                    if all(not pairing(z, p, n) for p in rows) and rank(rows + [z]) > len(rows)]
        rows.append(rng.choice(eligible))
    return [(z, rng.choice((-1, 1))) for z in rows]


def check_native():
    rng = Random(3248)
    cases = Counter()
    for n in (2, 3):
        ps = [pmat(p, n) for p in range(1 << (2*n))]
        dim = 1 << n
        eye = np.eye(dim)
        h2 = np.array([[1, 1], [1, -1]]) / sqrt(2)
        cliff = np.kron(np.eye(dim // 2), h2)
        for _ in range(36):
            bands = [gates(n, rng) for _ in range(rng.randrange(1, 5))]
            u = cliff.astype(complex)
            for band in bands:
                for p, sign in band:
                    u = (np.cos(pi/8)*eye+1j*sign*np.sin(pi/8)*ps[p]) @ u
            for j, band in enumerate(bands):
                outside = [p for i, other in enumerate(bands) if i != j for p, _ in other]
                odd = reduce(xor, (p for p, _ in band), 0)
                obstructed = rank(outside+[odd]) > rank(outside)
                found = False
                for h in range(1, 1 << (2*n)):
                    if any(pairing(h,p,n) for p in outside):
                        continue
                    v = sum(pairing(h,p,n) for p, _ in band)
                    if not v:
                        continue
                    found |= bool(v % 2)
                    work = ps[h] @ u @ cliff.conj().T @ ps[h] @ cliff @ u.conj().T
                    np.testing.assert_allclose(np.linalg.matrix_power(work, 4), (-1)**v * eye, atol=1e-12)
                    np.testing.assert_allclose(np.trace(work)/dim, 2**(-v/2), atol=1e-12)
                    ar = np.angle(np.linalg.eigvals(work))
                    counts = Counter(round(t/(pi/4)) % 8 for t in ar)
                    if v % 2:
                        assert any(counts[k]!=counts[(k+4)%8] for k in (1, 3, 5, 7))
                    else:
                        assert counts[0]+counts[4] == counts[2]+counts[6] == dim//2
                        assert len(counts) >= 3
                    if not v % 2:
                        cases['even-rotation spectra'] += 1
                        continue
                    cases['matrix witnesses'] += 1
                assert found == obstructed
                cases['binary layer tests'] += 1
    return cases


def check_cycles():
    checks = 0
    for length in range(1, 71):
        for fourth_index in range(4):
            roots = {(fourth_index+4*k) % (4*length) for k in range(length)}
            if length % 2:
                assert any(j * length in roots for j in range(4))
            else:
                assert {(v+2*length) % (4*length) for v in roots} == roots
            checks += 1
    np.testing.assert_allclose(abs(np.exp(1j*pi/8)-1),2*sin(pi/16),atol=1e-15)
    return checks


if __name__ == "__main__":
    print(dict(check_native()))
    print(check_cycles(), "fourth-root cycle spectra and one sharp projective threshold")
