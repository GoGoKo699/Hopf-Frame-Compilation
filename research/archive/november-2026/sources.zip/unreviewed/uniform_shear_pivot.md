## A fixed quantum change of basis for every nonzero shear direction

Let $h$ be the length of a moving word, let $S_a=X^a$ for $a\in\mathbb F_2^h$, and include $k$ arbitrary helper qubits. Consider a fixed unitary $H$ independent of $a$ on all $h+k$ qubits. A way to expose a binary orientation without computing a first-set position is to use $R_a=H S_a H^\dagger$ as the second logical Pauli. The error criterion for this construction is
$$
\max_{a\ne0}\|S_a R_a S_a+R_a\|\le\epsilon .
$$
A fixed $a$ is a mathematical fiber of a coherent stationary word. The seed may move all physical moving and helper qubits. Independence from $a$ is the substantive restriction on this particular change of basis.

**Exact width.** For $h\ge3$, the exact minimum total number of qubits is $w=(2^h-2)/2$. This minimum also lower-bounds all at-most-two-T-layer seeds at $\epsilon<\sin(\pi/8)/\sqrt2$. In contrast, at arbitrary synthesis depth and every $0<\epsilon<1$, $h+O(h/\epsilon^2)$ qubits suffice.

For the lower bound, Fourier-transform the moving word so that every $S_a$ has diagonal characters $(-1)^{a\cdot z}$. Put $m=2^h$ and let $H_{zy}$ denote the resulting square helper blocks. The $(z,z')$ block of $R_a$ is
$$
\sum_y(-1)^{a\cdot y}H_{zy}H_{z'y}^\dagger.
$$
For $z=z'$ this vanishes for every nonzero $a$ by exact anticommutation, and equals identity at $a=0$. Fourier inversion gives $H_{zy}H_{zy}^\dagger=I/m$ entrywise, so all $\sqrt m H_{zy}$ are unitaries. For $z\ne z'$ set $t=z+z'$. All the Fourier coefficients with $a\cdot t=0$ vanish, including $a=0$ by unitarity. Hence
$$
H_{zy}H_{z'y}^\dagger=-H_{z,y+t}H_{z',y+t}^\dagger
$$
at every $y$. For each $d$ form a unitary $M_d$ supported on $z+y=d$ with helper blocks $\sqrt m H_{zy}$. The preceding equation is $M_dM_e^\dagger=-M_eM_d^\dagger$ whenever $d\ne e$. Right-multiply all of them by $M_0^\dagger$. Apart from identity, these are $m-1$ skew-Hermitian unitaries which anticommute pairwise. Equivalently, after multiplication by $i$, they are pairwise anticommuting Hermitian involutions. For $2r$ such generators, the $r$ commuting products $iA_{2j-1}A_{2j}$ have all $2^r$ joint sign patterns, since $A_{2j-1}$ switches only the $j$th sign. Thus the total space has dimension at least $2^{\lfloor(m-1)/2\rfloor}$. At T-depth at most two and error below the stated constant, [R75](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/FOUR_LAYER_OPERATOR_RIGIDITY.md) first gives the exact requirement, since at fixed $a\ne0$ both $S_aR_aS_a$ and $-R_a$ are Hermitian Pauli images under at most two native layers.

For sharpness on $w=(m-2)/2$ qubits choose $m-1=2w+1$ anticommuting Hermitian Paulis $\Gamma_d$, indexed by nonzero $d$. The $2w$ standard Majoranas and their Hermitian parity product give such a set; their binary labels $v_d$ have just one relation, the sum of all labels. Form $z_j=\sum_{d:d_j=1}v_d$. The symplectic pairing obeys $\langle z_j,v_e\rangle=e_j$ since $2^{h-1}$ is even. The $z_j$ are independent and isotropic, since the pairwise counts $2^{h-2}$ on distinct indices are also even. Choose a fixed Clifford frame which makes them computational $Z$ operators on the $h$ moving coordinates. Put $M_0=I$ and $M_d=i\Gamma_d$ otherwise. They satisfy $M_dM_e^\dagger+M_eM_d^\dagger=0$ for distinct indices and $S_a M_d S_a=(-1)^{a\cdot d}M_d$ in the Fourier frame. Therefore $H=m^{-1/2}\sum_d M_d$ is unitary. The direct character identity is
$$
 S_a H S_a H^\dagger+H S_a H^\dagger S_a
 =2m^{-1}\sum_d(-1)^{a\cdot d} I.
$$
It equals zero for each nonzero $a$.

The sharp example has a native implementation up to a common phase, which cancels in all uses. Starting with the coefficient vector at $M_0$, expand into the $m$ uniform coordinates in $h$ balanced stages. At each stage pair occupied coefficients with unused ones so the maps act on disjoint pairs. A pair $(i,j)$ of nonzero labels can be rotated by conjugating the operator under construction by an eighth-turn about the signed Hermitian Pauli $i\Gamma_i\Gamma_j$. The pair $(0,j)$ is rotated by multiplying on both left and right with $\exp(i\pi\Gamma_j/8)$. It fixes all other $i\Gamma_e$ because they anticommute with $\Gamma_j$. The axes within a stage commute, and their only possible linear relation is the sum of the axes when they collectively cover every nonzero index. Thus at most two actual T layers per side implement a stage with fixed Clifford basis changes, for total T-depth at most $4h$.

**Polynomial-width approximate construction.** Choose $M=2^{\lceil\log_2(C h/\delta^2)\rceil}$ covectors $\ell_i$ whose character averages are bounded by $\delta$ on nonzero $a$. The finite random sampling bound plus a union bound gives this for an absolute $C$, and an exhaustive search terminates. Use $M/2$ private wires for $M$ independent Majoranas $\gamma_i$. In the original moving basis let $\Gamma_i=Z_b^{\ell_i}\gamma_i$, and take $H=M^{-1/2}\sum_i\Gamma_i$. These are anticommuting Hermitian Paulis, so $H$ is a Hermitian unitary. Expanding the anticommutator gives
$$
 \{S_a,H S_a H\}=2c(a) I,\qquad c(a)=M^{-1}\sum_i(-1)^{\ell_i\cdot a}.
$$
Here the equation follows directly by cancellation of unequal-index terms in $(S_a H S_a)H+H(S_a H S_a)$. For $a\ne0$, put $R'_a=(R_a-c(a)S_a)/\sqrt{1-c(a)^2}$. This is an exactly anticommuting Hermitian involution with $\|R_a-R'_a\|\le2\delta$. On a fresh *dirty* bit $q$ the three CNOTs for swapping the logical pair $(S_a,R'_a)$ with the physical pair $(X_q,Z_q)$ are controlled-$S_a$, $H_q$ controlled-$R'_a$ $H_q$, controlled-$S_a$, with $q$ controlling the indicated unitary. Instead implement the middle controlled-$R_a$ by $H\,\mathrm{ctrl}_q(S_a)\,H$. At $a=0$ all three logical CNOTs act identically. The actual dressing is within $2\delta$ of the ideal on all other sectors, so conjugating a selected shear $S_a^s$ outputs $X_q^{s[a\ne0]}$ with full error at most $4\delta$ on arbitrary moving, helper and reference states. The pivot has no requested action on $q$ at $a=0$. The native switch $\mathrm{ctrl}_q(S_a)$ consists of shared-control Toffolis on the $h$ pairs. The exact dense $H$ can be implemented in $O(\log M)$ T layers by balanced conjugations between anticommuting axes. A direct implementation of the new quantum pivot costs $O(\log(h/\delta))$ T layers, whereas a genuinely shallow synthesis of the dense change of basis is still missing. For $h\asymp2^p$, choosing $\delta=1/\operatorname{poly}(2^p)$ keeps width and gate costs singly exponential in $p$ and can absorb any fixed polynomial number of uses. A completed bank readout would also need to handle the inactive sectors and all occupation bits together.
