"""Finite fixtures for the coherent-branch proof and optimal shared-seed guess."""
from itertools import combinations, product
from math import comb, sqrt


def bit_parity(x):
    return x.bit_count() % 2


def information_set(p, d):
    m = 1 << p
    monomials = [s for s in range(m) if s.bit_count() <= d]
    coefficients = {}
    for s in sorted(monomials, key=int.bit_count):
        acc = 1 << s
        for t, coefficient in coefficients.items():
            if t & s == t:
                acc ^= coefficient
        coefficients[s] = acc

    def evaluate(x):
        answer = 0
        for subset, coefficient in coefficients.items():
            if subset & x == subset:
                answer ^= coefficient
        return answer

    scores = []
    for x in range(m):
        success = sum(evaluate(x ^ shift) == 1 << (x ^ shift) for shift in range(m))
        scores.append(success)
    expected = sum(comb(p, j) for j in range(d + 1))
    assert scores == [expected] * m
    return m


def elementary_path_check(mixed, address):
    # A 3-bit address x, a two-bit work, and the address's two low bits
    # controlling classical nonlinear data updates that can move work into coin.
    # The checks use an asymmetric complex coin with data-dependent gate inputs.
    root2 = 1 / sqrt(2)
    #  H S, entries indexed by (out, in)
    mat = ((root2, 1j * root2), (root2, -1j * root2))

    def update(state, step):
        c, w, t = state
        x = (address >> (step % 3)) & 1
        y = (address >> ((step + 1) % 3)) & 1
        c ^= t & x
        w ^= c & y
        t ^= w & (1 ^ y)
        return (c, w, t), (-1 if c & x & w else 1)

    amp = {(0, 0, 0): 1}
    for step, target in enumerate(mixed):
        after = {}
        for state, a in amp.items():
            moved, sign = update(state, step)
            for out in (0, 1):
                revised = list(moved)
                revised[target] = out
                dst = tuple(revised)
                after[dst] = after.get(dst, 0) + a * sign * mat[out][moved[target]]
        amp = after
    expression = 0
    for matrix_units in product(tuple(product((0, 1), repeat=2)), repeat=len(mixed)):
        value, allowed = 1, True
        state = (0, 0, 0)
        for step, (target, (out, inp)) in enumerate(zip(mixed, matrix_units)):
            state, sign = update(state, step)
            allowed &= state[target] == inp
            changed = list(state)
            changed[target] = out
            state = tuple(changed)
            value *= sign * mat[out][inp]
        if allowed and state == (0, 0, 0):
            expression += value
    assert abs(expression - amp.get((0, 0, 0), 0)) < 1e-10


def verify():
    translated = sum(information_set(p, d) for p in range(1, 7) for d in range(p + 1))
    amplitudes = 0
    for addresses in range(8):
        for mixed in product(range(3), repeat=3):
            elementary_path_check(mixed, addresses)
            amplitudes += 1
    count = 0
    for p in range(1, 5):
        m = 1 << p
        # Exactly half of binary linear hashes accept any nonzero guard vector.
        for guard in range(1, m):
            assert sum(bit_parity(mask & guard) == 0 for mask in range(m)) == m // 2
            count += 1
    print(f"{translated} translated information-set success counts, {amplitudes} matrix-unit return amplitudes, {count} guard hashes")


if __name__ == "__main__":
    verify()
