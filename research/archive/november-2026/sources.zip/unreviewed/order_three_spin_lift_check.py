from itertools import permutations
import numpy as np
X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1,-1]);I=np.eye(2)
gamma=[np.kron(X,I),np.kron(Y,I),np.kron(Z,X),np.kron(Z,Y)]
Id=np.eye(4);tests=0
def lift(a,b,c):
    return -(gamma[a]-gamma[b])@(gamma[b]-gamma[c])/2
for a,b,c in permutations(range(4),3):
    R=lift(a,b,c)
    assert np.allclose(R@R@R,-Id) and np.allclose(R,lift(b,c,a))
    assert np.allclose(R+R.conj().T,Id)
    labels=[int(np.argmax([abs(np.trace(v.conj().T@R@gamma[j]@R.conj().T)) for v in gamma]))
            for j in range(4)]
    assert (labels[a],labels[b],labels[c]) in ((b,c,a),(c,a,b))
    tests+=1
print(f'{tests} oriented three-cycle spin lifts on exact binary quarter-amplitude matrices')
n=0
for k in range(1,7):
    m=4**k
    for x in range(1<<k):
        def move(z):
            out=0
            for i in range(k):
                v=(z>>(2*i))&3
                if (x>>i)&1 and v:v=v%3+1
                out|=v<<(2*i)
            return out
        count=sum(move(z)!=z for z in range(m))
        assert count%3==0 and (count//3)%2==int(x+1==1<<k)
        n+=1
print(f'{n} full label-register permutations through 4^6 labels')
