"""Exact fixtures for classical motion degree and the hybrid quantum-width bound."""
from itertools import combinations, product
from math import comb


def low_deg_count(p, d):
    return sum(comb(p, i) for i in range(min(p, d) + 1))


def indices(mask):
    while mask:
        key = mask & -mask
        yield key.bit_length() - 1
        mask ^= key


def cosets_in(mask):
    sub = mask
    while True:
        yield sub
        if not sub:
            break
        sub = (sub - 1) & mask


def mobius_table(values):
    values = list(values)
    i = 1
    while i < len(values):
        for v in range(len(values)):
            if v & i:
                values[v] ^= values[v ^ i]
        i *= 2
    return values


def motion_polarizations():
    frames = checks = 0
    for p in range(1, 8):
        m = 1 << p
        R = range(m)
        t = [sum(1 << x for x in cosets_in(a)) for a in R]
        dual = [sum(1 << x for x in R if a & x == a) for a in R]
        assert all(((t[a] & dual[b]).bit_count() & 1) == (a == b) for a in R for b in R)
        for d in range(p + 1):
            # High and low degree parts are complementary in the maximal case.
            low = min(d, (p - 1) // 2)
            high = (p - d) if 2 * d < p else low + 1
            Z = [a for a in R if a.bit_count() >= high]
            X = [a for a in R if a.bit_count() <= low]
            assert not set(X) & set(Z)
            assert m - len(Z) - len(X) == max(0, m - 2 * low_deg_count(p, d))
            for labels, words, extract in ((Z, t, dual), (X, dual, t)):
                for a in labels:
                    coefficients = []
                    for s in R:
                        moved = sum(1 << (u ^ s) for u in indices(words[a]))
                        coeff = sum(((moved & extract[j]).bit_count() & 1) << j for j in labels)
                        recovered = 0
                        for j in indices(coeff):
                            recovered ^= words[j]
                        assert recovered == moved
                        coefficients.append(coeff)
                        checks += 1
                    assert all(not val or s.bit_count() <= d
                               for s, val in enumerate(mobius_table(coefficients)))
            frames += 1
    return frames, checks


def phase_consistency():
    # Octant angles. Strictly below pi/2 amounts to being 0,1,7 away from a sign.
    examples = redundant = 0
    for rest in product(range(8), repeat=3):
        h = (0,) + rest
        signs = {}
        for x in range(4):
            for bit in (0, 1):
                if all((h[y ^ x] - h[y] - 4 * bit) % 8 in (0, 1, 7) for y in range(4)):
                    signs[x] = bit
        allowed = [v for v in range(4)
                   if all(((v & x).bit_count() & 1) == b for x, b in signs.items())]
        assert allowed
        redundant += len(signs) == 4
        examples += 1
    return examples, redundant


def restricted_basis():
    # Three classical coordinates, one quantum qubit. Domain y=odd or high coset
    # of the two low coordinate directions. All exponents are integer signs.
    cases = 0
    for origin, b, ell, alpha, zi, xi, qi in product(
        (0, 4), range(8), range(4), range(4), range(8), range(4), range(4)
    ):
        # A label 0..3 packs its X in bit 0 and Z in bit 1.
        ax, az = alpha & 1, alpha >> 1
        qx, qz = qi & 1, qi >> 1
        predicted = ((zi & b).bit_count() + (ell & xi).bit_count() + qx*az + qz*ax) % 2
        for x, q in product(range(4), (0, 1)):
            y = origin ^ x
            # P_i W and W P_i at the same input, omitting identical Pauli global phases.
            pw = (ell & x).bit_count() + az*q + (zi & (y ^ b)).bit_count() + qz*(q ^ ax)
            wp = (zi & y).bit_count() + qz*q + (ell & (x ^ xi)).bit_count() + az*(q ^ qx)
            assert (pw - wp) % 2 == predicted
        cases += 1
    return cases


if __name__ == "__main__":
    assert __debug__
    print("sharp CSS choices and exact translated generators", motion_polarizations())
    print("octant-valued square functions and full-direction cases", phase_consistency())
    print("restricted-coset Fourier/quantum-Pauli label combinations", restricted_basis())
