"""Test the Clifford-correlation inequality for many exact native sign words."""
from itertools import product, combinations
from math import cos,pi
from random import Random
import numpy as np

def rank(labels):
    pivots={}
    for value in labels:
        while value:
            col=value.bit_length()-1
            if col not in pivots:
                pivots[col]=value
                break
            value^=pivots[col]
    return len(pivots)

def clifford_amplitudes(p):
    data=[]
    for lin in product(range(4),repeat=p):
        for q in product(range(2),repeat=p*(p-1)//2):
            row=[]
            for x in range(1<<p):
                val=sum(v*((x>>i)&1) for i,v in enumerate(lin))
                for flag,(i,j) in zip(q,combinations(range(p),2)):
                    val+=2*flag*((x>>i)&1)*((x>>j)&1)
                row.append((1j)**val)
            data.append(row)
    return np.array(data)

def native_words(p, samples=400):
    d=1<<p
    phases=clifford_amplitudes(p)
    addresses=np.arange(d)
    c=cos(pi/8)
    sn=np.sin(pi/8)
    rng=Random(20001+p)
    # For Boolean F, |mean F(x)A(x)| is bounded by c^{2r-t} C(F).
    cnt=0
    for _ in range(samples):
        word=np.eye(d,dtype=complex)
        xs=[]
        for __ in range(rng.randrange(1,2*p+5)):
            xx=rng.randrange(d); zz=rng.randrange(d)
            if xx==zz==0:
                zz=1
            sign=rng.choice((-1,1))
            pp=1j**((xx&zz).bit_count())*np.array([(-1)**((zz&i).bit_count()) for i in range(d)])
            word=c*word+1j*sign*sn*(pp[:,None]*word)[addresses^xx]
            xs.append(xx)
        # A nontrivial terminal unrestricted Clifford.
        for __ in range(2*p+2):
            gate=rng.choice('hst' if p>1 else 'hs')
            i=rng.randrange(p)
            bit=(addresses>>i)&1
            if gate=='h':
                word=((1-2*bit)[:,None]*word+word[addresses^(1<<i)])/np.sqrt(2)
            elif gate=='s':
                word=np.where(bit,1j,1)[:,None]*word
            else:
                j=(i+1)%p
                word=word[addresses^(bit<<j)]
        amp=word.diagonal()
        for f in [np.array([rng.choice((-1,1)) for i in range(d)]) for j in range(10)]:
            assert abs(f@amp)/d<=c**(2*rank(xs)-len(xs))*np.max(np.abs(phases@f))/d+1e-10
            cnt+=1
    return cnt

for p in (1,2,3):
    print(f'{native_words(p)} native diagonal amplitude/correlation checks at p={p}')
def det(a,b,c):
    return rank((a,b,c))==3
mean=sum((-1)**det(*v) for v in product(range(8),repeat=3))/512
assert mean==11/32
print('All 512 third-derivative determinant triples give 11/32')
counts={}
for lin in product(range(4),repeat=3):
    for q in product(range(2),repeat=3):
        total=0j
        for x in product(range(2),repeat=3):
            i,j,k=x
            total+=1j**sum(a*b for a,b in zip(lin,x))*(-1)**(q[0]*i*j+q[1]*i*k+q[2]*j*k+i*j*k)
        squared=int(total.real)**2+int(total.imag)**2
        counts[squared]=counts.get(squared,0)+1
assert counts=={4:392,20:112,36:8}
print('All 512 full-support three-bit Clifford correlations give maximum 3/4')
