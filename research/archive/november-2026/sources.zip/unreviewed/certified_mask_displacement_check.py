"""Full-matrix traces of compatible temporal feature readout, plus its robust predicate."""
from itertools import product
import numpy as np

def parity(x): return x.bit_count()%2

def cnot_feature_source(d):
    c=np.zeros((2*d,2*d),complex)
    for i,b in product(range(d),range(2)):
        c[2*i+(b^((i>>1)&1)),2*i+b]=1
    return c

rng=np.random.default_rng(48003)
cases=0
for _ in range(120):
    d=8
    perm=rng.permutation(d).tolist()
    phase=np.exp(2j*np.pi*rng.random(d))
    E=np.zeros((d,d),complex)
    for i,j in enumerate(perm):E[j,i]=phase[i]
    C=cnot_feature_source(d)
    lifted=np.kron(E,np.eye(2))
    got=lifted.conj().T @ C @ lifted @ C
    expect=np.zeros_like(got)
    for i,b in product(range(d),range(2)):
        bit=((i>>1)^(perm[i]>>1))&1
        expect[2*i+(b^bit),2*i+b]=1
    assert np.max(np.abs(got-expect))<1e-10
    cases+=1
print(cases,'fully monomial displacement words, including moving addresses and native phases')

k=3;m=1<<k
checks=0
for u,v in product(range(m),range(1<<m)):
    for y in (0,1,56,112,255):
        for s in (0,2,7):
            y_shift=sum(((y>>(i^s))&1)<<i for i in range(m))
            parameter=(1^parity(v)) | ((1^parity(v&y_shift))<<1)
            for i in range(m):
                if (v>>i)&1: parameter|=(u^i)<<(2+i*k)
            assert (not parameter)==(v==1<<u and ((y>>(u^s))&1))
            checks+=1
print(checks,'complete exact singleton-and-forecast certificates')

def cycle(points,n=5):
    p=list(range(n))
    for i,j in zip(points,points[1:]+points[:1]):p[i]=j
    return np.eye(n)[:,p]

def comm(a,b):return a@b@a.conj().T@b.conj().T
A=cycle([0,1,2,3,4]);B=cycle([0,1,3,4,2]);C=comm(A,B)
E=np.eye(5)
for j in range(1,5):assert not np.allclose(np.linalg.matrix_power(C,j),E)
assert np.allclose(np.linalg.matrix_power(C,5),E)
trials=0
for _ in range(120):
    big=rng.normal(size=(10,10))+1j*rng.normal(size=(10,10))
    U,_=np.linalg.qr(big)
    I=np.eye(10)
    assert np.allclose(comm(U,I),I) and np.allclose(comm(I,U),I)
    aa,bb=np.kron(A,np.eye(2)),np.kron(B,np.eye(2))
    assert np.allclose(comm(aa,bb),np.kron(C,np.eye(2)))
    trials+=1
print(trials,'full unitary commutator annihilations for arbitrary noncommuting work')
