"""Exact finite arithmetic and seeded-vote operator checks; NumPy only."""
from fractions import Fraction as Fr
from itertools import product
from math import sqrt
from random import Random
import numpy as np

rng=Random(193711)
def parity(x):
    return x.bit_count()&1

def moment(mask, piv, k):
    answer=0
    for i,label in enumerate(piv):
        if mask>>i&1:
            answer^=(1<<k)+label
    return answer

rows=0
for k in range(1,4):
    m=2**k
    for r in range(1,min(5,m)+1):
        piv=rng.sample(range(m),r)
        for x in range(m):
            for mask in range(1<<r):
                for sb,b in [(1,1),(1,3),(2,2)]:
                    s=Fr(1,1<<sb); e=Fr(1,1<<b)
                    ap=(1<<k)+x
                    delta=moment(mask,piv,k)^ap
                    exact_mom=Fr(sum(not parity(j&delta) for j in range(2*m)),2*m)**b
                    exact=Fr()
                    for active in range(1<<r):
                        mass=s**active.bit_count()*(1-s)**(r-active.bit_count())
                        off=mask&~active
                        survive=Fr(sum(not parity(j&off) for j in range(1<<r)),1<<r)**b
                        exact+=mass*survive*exact_mom
                    w=mask.bit_count()
                    forecast=(s**w+(1-s**w)*e)*(e if delta else 1)
                    assert exact==forecast
                    if x in piv and mask==1<<piv.index(x):
                        assert exact>=s
                    elif w<2:
                        assert exact<=e
                    else:
                        assert exact<=s*s+e
                    rows+=1
print(f'{rows:,} exact pivot, zero, alias and dense-row erasure probabilities')

words=0
for m in range(1,7):
    for _ in range(50):
        w=m+2
        maps=[rng.randrange(1<<w) for _ in range(m)]
        shift=rng.randrange(1<<w)
        def lin(value):
            return sum(parity(value&row)<<i for i,row in enumerate(maps))
        for _ in range(50):
            z=rng.randrange(1<<w); b=rng.randrange(1<<m); y=rng.randrange(1<<m)
            t=rng.randrange(2); phase=0
            z0,b0=z,b
            for j in range(2):
                b^=lin(z)
                phase^=t*parity(b&y)
                b^=lin(z)
                phase^=t*parity(b&y)
                z^=shift
            assert (phase,b,z)==(t*parity(lin(shift)&y),b0,z0)
            words+=1
print(f'{words:,} dirty-bilinear returned phase probes')
def tensor_basis(one,h):
    a=np.ones((1,1),complex)
    for _ in range(h):
        a=np.kron(a,one)
    return a

def norm(x):
    return np.linalg.norm(x,ord=2)

checks=0
for h in (2,3,4,5):
    n=1<<h
    H=np.array([[1,1],[1,-1]])/sqrt(2)
    bases=[np.eye(n),tensor_basis(H,h),tensor_basis(np.diag([1,1j])@H,h)]
    for _ in range(70):
        sets=[rng.sample(range(n),rng.randrange(n//4+1)) for i in range(3)]
        wrong_sets=[[j for j in s if rng.randrange(2)] for s in sets]
        def proj(b,s):return b[:,s]@b[:,s].conj().T
        bad=[proj(b,s) for b,s in zip(bases,sets)]
        wrong=[proj(b,s) for b,s in zip(bases,wrong_sets)]
        mu=max(norm(bad[i]@bad[j]) for i,j in ((0,1),(0,2),(1,2)))
        all_branches=[]; wrong_branches=[]
        for votes in product([0,1],repeat=3):
            a=np.eye(n)
            for p,bit in zip(wrong,votes):
                a=(p if bit else np.eye(n)-p)@a
            all_branches.append(a)
            if sum(votes)>=2:wrong_branches.append(a)
        cont=np.concatenate(wrong_branches)
        stacked=np.concatenate(all_branches)
        assert np.allclose(stacked.conj().T@stacked,np.eye(n))
        assert norm(cont)<=2*(mu+mu**2)+1e-10
        checks+=1
print(f'{checks} three independent flat-basis vote records, wrong-set containment and complete isometries')

def perm_comp(a,b):
    return tuple(a[x] for x in b)
def inv(a):
    return tuple(a.index(i) for i in range(len(a)))
def cycled(sequence):
    return tuple(sequence[(sequence.index(i)+1)%len(sequence)] for i in range(len(sequence)))
A=cycled((0,1,2,3,4)); B=cycled((0,2,1,4,3)); identity=tuple(range(5))
for x,y in product([0,1],repeat=2):
    u=A if x else identity; v=B if y else identity
    c=perm_comp(perm_comp(perm_comp(u,v),inv(u)),inv(v))
    out={0}; point=0
    for _ in range(5):
        point=c[point];out.add(point)
    assert len(out)==(5 if x*y else 1)

virtual=0
# A Clifford boundary block differs by an input-only phase, which cancels in a Z echo.
for n in (1,2,3):
    P=1<<n
    W=np.diag([1,-1]*(P//2))
    for _ in range(32):
        L=[rng.randrange(P) for _ in range(n)]
        M=[rng.randrange(P) for _ in range(n)]
        def app(cols,x):
            return sum(parity(col&x)<<j for j,col in enumerate(cols))
        for f in range(P):
            X=np.eye(P)[:,np.arange(P)^app(L,f)]
            Z=np.diag([(-1)**parity(i&app(M,f)) for i in range(P)])
            C0=np.eye(P)[:,list(reversed(range(P)))]
            phase=(1j)**rng.randrange(4)
            C=phase*X@Z@C0
            for d in range(P):
                xz=app(L,d)^app(L,d^f)
                zz=app(M,d)^app(M,d^f)
                sim=np.eye(P)[:,np.arange(P)^xz]@np.diag([(-1)**parity(i&zz) for i in range(P)])@C0
                assert np.allclose(C.conj().T@W@C,sim.conj().T@W@sim)
                virtual+=1
print(f'{virtual:,} virtual XOR/Clifford-boundary substitutions and S5 AND truth table')

convolutions=0
for k in range(1,8):
    n=1<<k
    for _ in range(80):
        f=[rng.randrange(2) for _ in range(n-1)]
        f+=[1^(sum(f)&1)]
        C=np.array([[f[u^a] for a in range(n)] for u in range(n)],dtype=np.uint8)
        assert np.array_equal((C@C)%2,np.eye(n,dtype=np.uint8))
        convolutions+=1
print(f'{convolutions} odd-weight truth-table convolution inversions over F2')

from itertools import permutations
group_checks=0
for i,j,l in permutations(range(3)):
    for a,b in product(range(2),repeat=2):
        A=np.eye(3,dtype=np.uint8); A[i,j]=a
        B=np.eye(3,dtype=np.uint8); B[j,l]=b
        G=A@B@A@B%2
        expected=np.eye(3,dtype=np.uint8); expected[i,l]=a*b
        assert np.array_equal(G,expected)
        for v in product(range(2),repeat=3):
            v=np.array(v,dtype=np.uint8); flip=np.eye(3,dtype=np.uint8)[l]
            out=(G@((G@(v^flip)%2)^flip))%2
            assert np.array_equal(out,v^(a*b*np.eye(3,dtype=np.uint8)[i]))
            group_checks+=1
print(f'{group_checks} GL(3,2) product shears and arbitrary-lane output translations')
