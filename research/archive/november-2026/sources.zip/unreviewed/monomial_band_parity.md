# An odd isolated subset of a native T layer excludes a returned permutation

Let \(U=B_D\cdots B_1 C\) be a Clifford+T circuit on its entire physical space, with the free Clifford intervals pulled into the terminal Clifford \(C\) and the Pauli axes of each native rotation layer \(B_j\). Multiplying by a global unit scalar is immaterial. The axes within a layer commute and have independent binary Pauli labels, since they come from distinct physical T sites through one common Clifford.

For layer \(j\) let \(G_j\) be the binary sum of **all** its axes and \(S_j\) the binary span of the axes in all other layers. If \(U\) is within operator error strictly smaller than
\[
 \eta_*=2\sin(\pi/16)
\]
of a computational basis permutation whose matrix entries are fourth roots of unity up to a common unit scalar, then every layer satisfies \(G_j\in S_j\). The assertion permits arbitrary movement of the address and all dirty helpers. Its comparison is on the whole physical space. A code-space promise on initialized qubits makes a different claim.

In particular a single nonempty native T layer fails this test, and every individual T axis in a qualifying circuit must belong to the binary span of the remaining axes. The second conclusion alone is weaker than the first. The test applies directly to complete Boolean XOR words and to arbitrary signed permutations. It does not give a logarithmic bound on T-depth.

## A spectral certificate

If \(G_j\notin S_j\), symplectic nondegeneracy supplies a Hermitian Pauli \(H\) that commutes with all axes outside layer \(j\), and anticommutes with an odd number \(v\) of axes in that layer. Form
\[
 W(U)=H\,U\,C^\dagger H C\,U^\dagger .
\]
The common Clifford disappears. Because \(H\) commutes with both outer stretches, \(W(U)\) is unitarily conjugate to \(H B_j H B_j^\dagger\). Flipping a \(\pm\pi/8\) Pauli rotation contributes a \(\mp\pi/4\) Pauli rotation; untouched factors cancel. The surviving \(v\) signed axes commute and are independent. All \(2^v\) sign tuples thus have equal multiplicity in their joint spectra. Every eigenvalue of \(W(U)\) is an odd eighth root, and its normalized trace equals \((\cos(\pi/4))^v>0\). No independence across different layers is assumed.

For any fourth-root-phased computational monomial \(M\), \(W(M)\) is a monomial with fourth-root entries because \(C^\dagger H C\) is also a Hermitian Pauli, and global phases cancel. Every odd-length permutation cycle of \(W(M)\) has at least one fourth-root eigenvalue. Indeed its eigenvalues are the solutions to \(z^l=b\) with \(b\) a fourth root and odd \(l\) invertible on the fourth roots. Every even-length cycle has a spectrum symmetric under multiplication by \(-1\).

If \(U\) is closer to \(M\) than the threshold, after removing any common scalar there is a unitary path from \(U\) to \(M\) of operator-norm generator length \(\theta<\pi/8\). For example use the spectral logarithm of \(U^\dagger M\), whose operator norm equals \(2\arcsin(\|U-M\|/2)\). Applying \(W\) along the path gives a path of length at most \(2\theta<\pi/4\). Every point on this new path has operator distance strictly below \(2\sin(\pi/8)\) from \(W(U)\). One elementary proof of the chord bound is to transport each unit vector along the path in the unit sphere with the real part of the inner product, bound its great-circle angle by the integrated operator-norm speed, and take the supremum over initial vectors. The spectrum of a unitary within this distance of \(W(U)\) contains no fourth root: a resolvent bound for the normal \(W(U)\) gives the least possible distance \(2\sin(\pi/8)\) for an eigenvalue at a fourth root. Eigenvalue counts in the four open quadrants are consequently constant throughout the path.

In particular \(W(M)\) has no odd permutation cycles. All its cycles are even, so its quadrant counts are equal in opposite quadrants. The same must then hold for \(W(U)\). The latter has precisely one possible eighth-root phase per open quadrant, so this symmetry forces its trace to be zero. This contradicts the positive trace. The numerical constant is sharp in projective norm for the broad monomial exclusion, since a single T gate has projective distance \(2\sin(\pi/16)\) from the identity.

The complete XOR verifier can form this criterion from the physical gate list by Gaussian elimination on binary Pauli labels. A failure gives an explicit boundary Pauli \(H\) and a uniform lower bound on the complete physical approximation. The condition can be met by trivial inverse pairs, so an affirmative test alone gives no depth improvement.

## Every returned dirty Pauli gives a linear constraint

Let \(A_j\) be the span of the individual axes in band \(j\), and let \(I\) be any subspace of physical Pauli labels that commute with the ideal target \(M\) (commuting up to scalar also suffices if the scalar is a fourth root). If the full physical error is below \(2\sin(\pi/16)\) in the ordinary commuting case, then
\[
 A_j\subseteq S_j+I^\perp,\qquad A_j\subseteq S_j+C I^\perp C^\dagger .
\]
Indeed if \(H\) belongs to \(S_j^\perp\cap I\), then \(W(M)\) is unitarily conjugate to \(H(C^\dagger H C)\), a Pauli with fourth-root phase. If instead \(C^\dagger H C\) commutes with \(M\), the same product is \(W(M)\) itself. For any nonzero isolated subset of the band that \(H\) flips, \(W(U)\) cannot have this spectrum: for an odd subset all its eigenvalues are at chordal distance at least \(2\sin(\pi/8)\) from the physical Pauli eigenvalues; for a positive even subset it has at least three distinct fourth-root eigenvalues, whereas a phased Pauli has at most two. Spectral inclusion for normal matrices in both directions, or the preceding unitary path, excludes either case. Taking symplectic orthogonals yields both inclusions. For a single controlled bit XOR on \(k\) address bits with all work returned, \(I\) includes all address Z's, the output X and the complete Pauli space on every additional dirty wire. Its perpendicular has dimension \(k+1\), regardless of physical width.

## Sparse targets force complete reuse of every band's axis span

Use the Hilbert–Schmidt norm normalized by the square root of the physical Hilbert dimension, written \(d_2(U,V)\) and minimized over scalar phases where stated. Suppose \(U\) is at operator error \(\epsilon\) from a target \(M\), and \(d_2(M,K)\le \eta\) up to a scalar for some Clifford \(K\) on all physical wires. If \(2(\epsilon+\eta)<2\sin(\pi/8)\), then deleting *any* one of its native T layers preserves the full global binary span of its T rotation axes:
\[
 A_j\subseteq S_j\quad\text{for every }j .
\]
For a Pauli \(H\) isolating \(v\ge1\) axes of one band, \(W(U)\) has normalized Hilbert–Schmidt distance at least \(2\sin(\pi/8)\) from the phased Pauli \(W(K)\). For odd \(v\) every eigenvalue of \(W(U)\) is an odd eighth root, separated from each fourth root by that chord. For even \(v\) half the spectral weight of \(W(U)\) lies in each of \(\{\pm1\}\) and \(\{\pm i\}\), using independence of its active signs, while a single phased Pauli lies wholly in one of those two sets. Thus the distance in the even case is at least \(1\). For completeness, for eigenbases \(e_l,f_j\) of the two unitaries the normalized squared distance is the mean of the corresponding squared eigenvalue distances weighted by \(|\langle e_l,f_j\rangle|^2\). This gives both assertions without any assumption of commuting endpoints. On the other hand \(d_2(W(U),W(K))\le 2d_2(U,K)\le 2(\epsilon+\eta)\), since the two appearances in \(W\) cancel any scalar. This excludes every \(H\in S_j^\perp\) flipping even one axis of the band. It follows that the global axis rank is at most total T-count minus the width of the widest native T layer.

For a controlled XOR testing the single all-zero \(k\)-bit input, \(\eta=d_2(M,I)=2^{(1-k)/2}\), unaffected by arbitrary returned dirty wires. Hence this conclusion applies to the exact high-arity multiple-control gates obtained from the three-call reciprocal trace identity. For any two-layer word in the stated regime one has \(A_1=A_2\), so every T-rotation axis commutes globally. Their rotations can be placed inside one fixed Clifford-diagonal frame, giving a third-hierarchy operation up to a boundary Clifford. No asymptotic logarithmic lower bound follows merely from the span condition.

## Three native layers have a uniform gap around Cliffords

A complementary lemma excludes three layers for a sufficiently sparse non-Clifford exact target. Write \(\kappa=2\sin(\pi/8)\). If \(U\) has three or fewer native T layers and \(d_2(U,K)<\kappa/4\) up to a common phase for some Clifford \(K\), then \(U\) equals \(K\) projectively on the entire physical space. This is an exact conclusion in normalized Hilbert–Schmidt distance and makes no gate count or dirty width assumptions.

Distinct projective Cliffords have \(d_2\)-separation at least \(\kappa=\sqrt{2-\sqrt2}\). One elementary proof uses their normalized Choi states, which are stabilizer states; distinct stabilizer states have overlap magnitude at most \(1/\sqrt2\), by expanding their projectors as uniform stabilizer sums. Consequently two projective third-hierarchy gates closer than \(\kappa/2\) coincide projectively: compare their conjugations of every Pauli generator. These are Hermitian Cliffords at distance less than \(\kappa\), hence projectively identical. Opposite signs would have distance \(2\) and are excluded by the same actual comparison. Equality of conjugations on all Paulis gives projective equality of the unitaries.

Write \(U=ABC'\) with each factor in the third Clifford hierarchy, absorbing fixed Clifford intervals into those factors. W.l.o.g. choose phases so \(d_2(U,K)<\kappa/4\). For every Pauli \(P\), the Hermitian unitaries \(E=A^\dagger K P K^\dagger A\) and \(F=C' P (C')^\dagger\) are Cliffords. Here \(A^\dagger\) is explicitly a native one-band rotation with Clifford boundaries. Then \(d_2(EB,BF)<\kappa/2\) by pulling the two endpoint comparisons through \(U\). Both \(EB\) and \(BF\) are third-hierarchy gates, since fixed left or right Clifford multiplication preserves the hierarchy level. The separation result forces projective equality. The relative phase is a sign by Hermiticity of \(E,F\), and the small physical distance forces the positive sign. Thus \(U P U^\dagger=KPK^\dagger\) for every Pauli, proving the lemma.

For \(k\ge6\), the exact \(k\)-control NOT has \(d_2(M,I)=2^{(1-k)/2}<\kappa/4\); being nonscalar, it therefore requires at least four native T layers. Likewise sufficiently accurate full-operator approximation to these gates requires four layers: if \(\epsilon+2^{(1-k)/2}<\kappa/4\), the emitted three-layer unitary would be a scalar, which is projectively at operator distance \(\sqrt2\) from the target. This excludes fixed finite shallow architectures and leaves growing sublogarithmic depth open.
