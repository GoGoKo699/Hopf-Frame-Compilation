# Correlation with a trace inverse forces logarithmic Boolean degree

Put \(F=\mathbb F_{2^s}\), \(H=\ker\mathrm{Tr}\), \(q=2^s\), \(d\ne0\), and \(g(x)=\mathrm{Tr}(d\,\mathrm{inv}_0(x))\) on \(H\). If a Boolean polynomial \(P\) on the \(s-1\) binary coordinates of \(H\) has degree less than \(r\), then for \(1\le r\le s-1\),
\[
 \left|\mathbb E_{x\in H}(-1)^{g(x)+P(x)}\right|^{2^r}
 \le C 2^{r-s/2}
\]
for an absolute constant \(C\). In particular any fixed nonvanishing correlation forces degree at least \(\log_2 s-O(1)\), with the additive constant depending on the correlation. This statement is an estimate on the truth table of an exactly emitted Boolean predicate. It does not convert a measurement prediction guarantee to a returned circuit.

Iterated Cauchy–Schwarz bounds the left side by the Gowers differencing average on \(r\) uniform directions in \(H\). Independent directions occur except with probability at most \((2^r-1)/|H|\), by exposing one direction at a time. In the independent case the \(r\)-fold finite difference of \(P\) vanishes, and away from its \(2^r\) poles the difference of \(g\) equals the trace of the rational function
\[
 R(X)=\sum_{a\in A}\frac{d}{X+a},
\]
where \(A\) is the span of the directions. The indicator of \(H\) is \((1+(-1)^{\mathrm{Tr}(x)})/2\). Both of the resulting full-field additive character sums, with functions \(R(X)\) and \(R(X)+X\), have absolute value at most \(C_0\,2^r\sqrt q\) after omitting the poles. For example use the standard Weil bound for an additive character of a rational function with that many simple poles; the additional polynomial \(X\) creates at most one more pole at infinity. Neither rational function is Artin–Schreier degenerate, since it has a simple pole while every pole of \(h^2-h+\mathrm{const}\) has even order. Restoring the omitted points and dividing by \(|H|=q/2\) gives the result.

For constant correlation \(\beta>0\), taking logarithms yields \(2^r\log_2(1/\beta)\ge s/2-r-\log_2 C\). If \(r\ge s/4\) the logarithmic consequence is automatic, and otherwise one obtains the displayed degree consequence (using \(r=\deg P+1\)). The bound is useful at \(r<\log_2 s-O(1)\). It does not give a polynomial-in-\(s\) degree estimate at constant correlation.

If an exactly returned physically read-only predicate with such correlation has polynomial size and native depth \(o(\log\log s)\) at sufficiently frequent field degrees \(s\), choose \(s=2^{\Theta(k)}\) large enough for its certified degree to be at least \(k\). Fix all coordinates outside a nonzero \(k\)-fold derivative to an assignment giving odd weight on the remaining \(k\)-dimensional section. All translated copies can run in parallel, with a fixed binary convolution decoding their outputs. The cost \(2^{O(k)}\) and depth \(o(\log k)\) can be used in a constant-block Cartesian construction, taking smaller linear-size blocks to normalize the exponential factor in the full indicator. This conditional trade accepts classically imperfect agreement with the specified trace and requires a stronger depth bound than the exact polynomial-size degree-\(s-1\) source.

[Cochrane and Pinner, “Using Stepanov’s method for exponential sums involving rational functions” (Journal of Number Theory 116, 2006)](https://www.math.ksu.edu/~cochrane/research/stepmix.pdf)
