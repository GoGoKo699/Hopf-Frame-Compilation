# The two parity tests in the four-call dirty convolution

Let the address have $k$ bits and $m=2^k$. The four-call dirty convolution uses two arbitrary $m$-bit banks $A,B$, an arbitrary output bank, and arbitrarily many dirty inputs. In the output Fourier sector $y$ its convolution gate has phase $(-1)^{\langle y,A\star B\rangle}$. Denote that involution by $C_y$. Fix the logical output address $x=0$, so the two source calls $J,K$ in the two banks use the same borrowed reference address. Their native inverses are used in the complete operator
$$
 E_y=K^\dagger C_yJ^\dagger C_y K C_yJ C_y .
$$
The only port assumptions here are that $J$ does not touch bank $B$, that the source calls do not use $y$, and that access to the logical $x=0$ sector has the stated form. All helper and reference-address motion within the word is allowed. Every norm is the full operator norm on the remaining registers. The ideal indicator at $x=0$ has $E_{\mathbf 0}=I$ and $E_{\mathbf 1}=-I$.

## A necessary parity flip on all helper inputs

Write $Z_A,Z_B$ for the full computational parity observables on the respective banks, and $P_+,P_-$ for the $Z_B$ eigenspace projectors. At $y=\mathbf1$ the convolution phase is just $C=P_++P_- Z_A$, since the parity of a binary convolution is the product of the two input parities.

**Proposition.** Suppose $\|E_{\mathbf0}-I\|\le\tau_0,\ \|E_{\mathbf1}+I\|\le\tau_1$ with $v=\tau_0+\tau_1<2$. Then
$$
 \|J^\dagger Z_A J+Z_A\|\le v .
$$
If $J,K$ commute, $\tau_1$ alone can be used. Only the two Fourier slices are required.

Indeed $E_{\mathbf0}=K^\dagger J^\dagger KJ$, so $\|J^\dagger KJ-K\|\le\tau_0$. Put $W=J^\dagger Z_A J Z_A$ and $D=P_++P_-W$. Since $J$ leaves the entire physical $B$ bank untouched, $CJC=JD$. Thus $\|K^\dagger D^\dagger K D+I\|\le v$, or equivalently $\|DK+KD\|\le v$. On the range of $K P_+$ the operator $D+I$ consequently has norm at most $v$. This range has half the full dimension. By the min-max principle at least half the singular values of $D+I$ are at most $v$. Its entire $P_+$ block has singular value 2. Its $P_-$ block has exactly half the full dimension, so **all** the singular values of $W+I$ are at most $v$. Multiplication by $Z_A$ proves the estimate. Finite dimensions and arbitrary dirty inputs are essential for the dimension step. The conclusion permits arbitrary shared helper actions.

## Rigidity for independent local cells

Now let each source on its bank be a tensor of single-target programs $U_z$, one for each translated address $z$, with independent, arbitrary private work per cell and separate work on $A,B$. On a fixed reference address the full bank program $J$ is the product, with a permutation of factors. Programs on the two banks commute. We assume a well-defined fixed reference-address sector for this local specialization. No individual accuracy or correctness of a proposed truth table is assumed. If the complete four-call operator has error $\tau\le1/2$, then **there exists an odd-weight Boolean function** $b$ such that
$$
 \sum_z \arcsin(e_z)\ \le\ \arcsin(\tau/2),\qquad
 e_z=\max_{t\in\{0,1\}}\left\|P_{t+b(z)+1} U_z P_t\right\|.
$$
Here the $P_t$ are the computational-bit projectors tensored with identity on the local dirty work, subscripts are binary, and $e_z$ is an amplitude. Thus the *average* intrinsic wrong-output amplitude has to be $O(\tau/2^k)$, even for sparse ideal tables. The result includes arbitrary local phases, local non-Clifford actions, data-dependent private garbage and nonuniform errors.

To see this, set $W_z=U_z^\dagger Z_z U_z Z_z$. The global parity estimate gives $\|\bigotimes_z W_z+I\|\le\tau$. Each $W_z$ has conjugate-symmetric unitary spectrum since $W_z^\dagger=Z_z W_z Z_z$. Put $\gamma=2\arcsin(\tau/2)<\pi/4$. Every product of one eigenvalue per cell must lie in the closed angular interval of radius $\gamma$ centered at $-1$. Fix all but one factor. A conjugate pair $e^{it},e^{-it}$ in the remaining cell has distance at most $2\gamma$ around the unit circle, so $t$ is within $\gamma$ of a multiple of $\pi$. All eigenvalues of a given cell use the **same sign**. Different signs would place two allowed alternatives at distance at least $\pi-2\gamma>2\gamma$. Write the sign as $(-1)^{b(z)}$, and let $\alpha_z$ be the largest angular deviation from it.

The relative phases $e^{\pm i\alpha_z}$ are both attained and can be selected independently across cells. Begin with all minus signs and flip one at a time. Each lifted angular increment is $2\alpha_z\le2\gamma$. The forbidden gap between allowed intervals has length $2\pi-2\gamma>2\gamma$, so the whole lifted path stays in a single interval of length $2\gamma$. Its total increment is $2\sum_z\alpha_z$. Consequently $\sum_z\alpha_z\le\gamma$, and the midway lifted phase is the product of the cell signs. It lies in the allowed interval around $-1$, forcing odd parity. Finally $\|W_z-(-1)^{b(z)}I\|=2\sin(\alpha_z/2)$. The commutator or anticommutator of $U_z$ and $Z_z$ has precisely the two wrong output blocks with coefficients of magnitude 2 and orthogonal domains and ranges, so its norm is $2e_z$. This proves the inequality. The same proof applies to disjoint multi-target blocks with their local parity observable in place of $Z_z$, with $e_z$ now counting incorrect *block parity*.

The local criterion is also sufficient up to a numerical constant for a translationally uniform program, meaning that the cell indexed by $a$ at query $q$ uses the identical local program $U_{q+a}$ on its own target and private inputs. From each $U_z$ discard its two wrong blocks after fixing $b(z)$, then take the polar factors of the two correct blocks. If $e_z<1$, the result is a unitary $V_z$ with deterministic output bit $t+b(z)$ and arbitrary target-dependent private action. The norm change is at most $e_z+1-\sqrt{1-e_z^2}\le2e_z$. The omitted wrong blocks' norm is $e_z$, and unitarity bounds the squared singular values of each right block below by $1-e_z^2$. The $A,B$ programs built from the $V_z$ act on disjoint private work. Convolution uses their computational bits only as controls. The phases and private actions all unwind under their actual inverses, leaving the ideal four-corner difference $(\tau_r b)\star(\tau_{r+x} b)=e_x$ on every reference address $r$. Telescoping four product calls gives full error at most $8\sum_z e_z$. A known or unknown scalar phase or an arbitrarily large private motion receives zero penalty whenever the bank bit is correct.

This is an end-to-end obstruction for this four-call, tensor-product architecture. It explains why passing to a common calibration in two banks does not make constant-error *independent* local predictions sufficient. The parity proposition alone does not require independent cells; its tensor-sum refinement does. In particular, a shared work sector can carry a collectively odd mask whose individual bits vary by order one between sectors. Its physical batched construction remains a separate question. A different complete-frame circuit can bypass this four-call experiment altogether.

## Fixed global Clifford frames around one parallel bank

There is a version for a single parallel native bank with global Clifford basis changes at its two ends. Write its action in a fixed address sector as $J=C_{\rm out}(\bigotimes_i U_i)C_{\rm in}$, where $C_{\rm in},C_{\rm out}$ can mix the bank and its private work. Absorb the two overall Pauli signs into fixed factors and factor
$$
 C_{\rm out}^\dagger Z_A C_{\rm out}=\bigotimes_i P_i,\qquad
 C_{\rm in} Z_A C_{\rm in}^\dagger=\bigotimes_i Q_i .
$$
These are physical Hermitian Paulis including allowed identity factors. Then $\|J^\dagger Z_A J+Z_A\|$ equals $\|\bigotimes_i (U_i^\dagger P_i U_i Q_i)+I\|$. Each local spectrum is conjugate-symmetric by conjugation with $Q_i$. The same tensor argument therefore gives a product of signs equal to $-1$, and
$$
 \sum_i \arcsin\!\left(\tfrac12\|U_i^\dagger P_i U_i-(-1)^{b_i}Q_i\|\right)
 \ \le\ \arcsin(v/2)
$$
whenever the applicable parity error $v\le1/2$. If one factor of the two transported parities is a scalar and the other is a nonscalar Pauli, the test already fails at that accuracy. The charges in this conclusion refer to transporting the specified physical Pauli on each block; an arbitrary Clifford crossing does not change precision into a free native resource. Multiple interleaved non-Clifford banks fall outside this factorization.

## Closed Pauli paths in a shareable local source

Assume the same local source $U_z$ comes from a joint read-only Clifford+T word on $k\ge2$ computational address bits and the local work. All Clifford intervals fix the address bits as observables, and all native T gates target the private side. Write $Z$ for the local output bit's Pauli and $f(z)=2^{-w}\operatorname{Tr}(U_z^\dagger Z U_z Z)$, with $w$ the local work-qubit count including the target. In the independent four-call bank setting the preceding odd table obeys
$$
 \sum_z |f(z)-(-1)^{b(z)}|\le2\sum_z e_z^2\le2\arcsin^2(\tau/2)<1.
$$
Indeed the normalized trace is the sign correlation of the input and output bits on a uniformly mixed work basis. Each wrong-bit probability is at most $e_z^2$. Every unnormalized binary Fourier coefficient of an odd-weight sign table on $k\ge2$ is $2\bmod 4$: for a nonzero linear character, the all-positive sign contributes zero, and subtracting twice an odd number of signed units gives the claim. For the trivial character $2^k$ is divisible by four. Hence *every one* of the $2^k$ Fourier coefficients of $f$ is nonzero under this end-to-end approximation contract.

At fixed address, a Clifford interval fixing every computational address bit acts on work as a fixed Clifford multiplied by a Pauli with affine address-dependent labels, up to a scalar. One way to verify the statement is to conjugate each canonical work Pauli by the joint Clifford: the result must commute with the address Z operators, so its address letters are only Z. Its sector sign is an affine linear character while its work Pauli is fixed. Consequently moving all Clifford intervals through the T gates assigns to T gate $j$ a fixed binary work Pauli $p_j$, with sign given by an affine linear address exponent with linear part $\lambda_j$. The starting Heisenberg Pauli likewise has a fixed work label and an affine sign. Let the matrices $P,\Lambda$ have columns $p_j,\lambda_j$. Each Pauli path is uniquely identified by its binary emission vector $e$: an anticommuting T gate either keeps its label or emits $p_j$, with amplitudes of magnitude $2^{-1/2}$. Only the emitted alternative uses the affine rotation sign. The work trace requires $Pe$ to equal one fixed offset. Its Fourier index is one fixed vector plus $\Lambda e$. Thus full Fourier support requires
$$
 \Lambda(\ker P)=\mathbb F_2^k .
$$

There must also be histories that collide after retaining both the work endpoint and its entire Fourier label. Write $c=\dim(\ker P\cap\ker\Lambda)$. Each permitted emission has magnitude equal to the square root of its probability under the dephased path experiment which tosses a fair coin at each anticommuting T rotation. By Cauchy–Schwarz in each Fourier fiber of size at most $2^c$, followed by Parseval,
$$
 \mathbb E_z f(z)^2\le 2^c\,\Pr[\text{the dephased path has the required terminal work label}].
$$
If $a$ axes anticommute with the starting work Pauli in its first effective native band, the path distribution becomes uniform on $2^a$ different labels. The axes within that band are independent before the common Clifford transport, and their work labels remain independent because the quotient action of a read-only Clifford on work Pauli labels is symplectic. Every later dephased rotation is a doubly stochastic update on the work labels. Its highest point probability cannot increase. Thus the right-hand side is at most $2^{c-a}$. On the other hand, the displayed approximation to a Boolean sign gives $\mathbb E f^2\ge1-2\mathbb E|f-(-1)^b|>1/2$ for $k\ge2$. A word with no effective bands would have a scalar sign character and could not pass the full-support test. Consequently $c\ge a$. The reversed Heisenberg experiment gives the same return probability by transpose symmetry of each dephased band; its first effective band provides another lower bound on $c$. In particular a word of $t$ T gates must satisfy
$$
 t-\operatorname{rank}P\ \ge\ k+\max(a_{\rm forward},a_{\rm reverse}).
$$
This is a necessary property of the transported native axes and their address controls. It permits a polynomial-size, sublogarithmic-depth source containing the requisite dependencies. It is not a depth lower bound for all native local XORs.
