"""Independent finite algebra checks for prime-order catalytic charge transfer."""
from itertools import product

import numpy as np


def all_homogeneous_rules(prime):
    # Every homogeneous two-input law f corresponds uniquely to h(b/a).
    n = prime - 1
    indices = [[((b * pow(a, -1, prime)) % prime) - 1
                for b in range(1, prime)] for a in range(1, prime)]
    linear = set()
    primitive = set()
    count = 0
    for h in product(range(prime), repeat=n):
        count += 1
        if not all((a * h[indices[a-1][b-1]] - a * h[indices[a-1][0]] -
                    h[b-1] + h[0]) % prime == 0
                   for a in range(2, prime) for b in range(2, prime)):
            continue
        linear.add(h)
        if all(h):
            primitive.add(h)
    expected = {tuple((u + v * b) % prime for b in range(1, prime))
                for u in range(prime) for v in range(prime)}
    assert linear == expected
    assert len(primitive) == 2 * (prime-1)
    return count, len(linear), len(primitive)


def ternary_eigenvectors():
    i = 1j
    one = np.eye(2)
    x = np.array([[0, 1], [1, 0]])
    y = np.array([[0, -i], [i, 0]])
    z = np.diag([1, -1])
    c = (-one + i * (x + y + z)) / 2
    w = np.exp(2j*np.pi/3)
    delta = w - np.conj(w)
    assert np.allclose(c@c + c + one, 0)
    assert np.allclose(c.conj().T@c, one)
    basis = np.array([1, 0])
    v = [(c-np.conj(w)*one)@basis, (c-w*one)@basis]
    assert np.allclose(v[0]-v[1], delta*basis)
    for u, val in zip(v, (w, np.conj(w))):
        assert np.allclose(c@u, val*u)
    # Native Clifford-Pauli readout of the orientation switch.
    response=[]
    for rotation in (c, c.conj().T):
        p = rotation@x@rotation.conj().T
        comm = z@p@z@p
        sign = round(np.trace(comm).real/2)
        assert np.allclose(comm, sign*one)
        response.append(sign)
    assert set(response)=={-1,1}
    orientation=(x+y+z)/np.sqrt(3)
    for p, q in product((x,y,z), repeat=2):
        assert abs(np.trace(np.kron(p,q)@np.kron(orientation,orientation))/4-1/3) < 1e-12
    return len(v), len(response), 9


def cycle_witnesses():
    # Mod p unnormalized cyclotomic Fourier coefficients all specialize to 1.
    # Companion powers at the prime test the required nonzero column in every n.
    witnesses=0
    for p in (3,5,7,11,13):
        n=p-1
        c=np.zeros((n,n),dtype=object)
        for i in range(n-1):
            c[i+1,i]=1
        c[:,-1]=-1
        nil=c-np.eye(n,dtype=object)
        residue=np.linalg.matrix_power(nil,p-2)%p
        assert np.any(residue)
        assert np.all(np.linalg.matrix_power(nil,p-1)%p==0)
        choices=[i for i in range(n) if np.any(residue[:,i])]
        e=np.eye(n)[:,choices[0]]
        zeta=np.exp(2j*np.pi/p)
        cn=np.array(c,dtype=complex)
        for a in range(1,p):
            v=e.astype(complex)
            for b in range(1,p):
                if a!=b:
                    v=(cn-zeta**b*np.eye(n))@v
            assert np.max(np.abs(v))>0.01
            assert np.allclose(cn@v,zeta**a*v,atol=1e-8)
            witnesses+=1
    return witnesses


if __name__ == '__main__':
    for p in (3,5,7):
        total, affine, portable=all_homogeneous_rules(p)
        print(f'p={p}: {total} homogeneous laws, {affine} linear laws, {portable} nonvanishing selectors')
    print('Validated eigencolumns for primitive companion matrices:', cycle_witnesses())
    print('One-qubit charges, native orientation switch cases and denominator-three Pauli coefficients:',
          ternary_eigenvectors())
