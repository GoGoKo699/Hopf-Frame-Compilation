"""Finite tests for the complete convolution parity obstruction (requires NumPy)."""
import itertools
import math
import os

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np

RNG = np.random.default_rng(27658)
I2 = np.eye(2)
X = np.array([[0., 1.], [1., 0.]])


def norm(a):
    return np.linalg.svd(a, compute_uv=False)[0]


def kron(xs):
    acc = np.ones((1, 1))
    for x in xs:
        acc = np.kron(acc, x)
    return acc


def haar(n):
    m = RNG.normal(size=(n, n)) + 1j * RNG.normal(size=(n, n))
    q, r = np.linalg.qr(m)
    p = np.diag(r)
    return q * (p / abs(p))


def blockdiag(a, b):
    zero = np.zeros_like(a)
    return np.block([[a, zero], [zero, b]])


def make_cell(bit, deviations):
    b = len(deviations)
    theta = (np.pi / 2 - deviations) if bit else deviations
    c = np.diag(np.cos(theta))
    s = np.diag(np.sin(theta))
    return (blockdiag(haar(b), haar(b)) @ np.block([[c, -s], [s, c]])
            @ blockdiag(haar(b), haar(b)))


def sign_matrices(m, d, y):
    labels = [int(i >= d // 2) for i in range(d)]
    b = [sum(labels[ii] << j for j, ii in enumerate(v))
         for v in itertools.product(range(d), repeat=m)]
    val = []
    for a, bword in itertools.product(b, repeat=2):
        parity = sum((a >> i & 1) * (bword >> j & 1) * (y >> (i ^ j) & 1)
                     for i in range(m) for j in range(m)) % 2
        val.append(1 - 2 * parity)
    return np.diag(val)


def bank_test():
    counted = 0
    # Every raw cell may produce target-dependent, fully quantum private garbage.
    for m, private, reps in [(2, 2, 5), (2, 1, 14), (4, 1, 4)]:
        for trial in range(reps):
            truth = RNG.integers(0, 2, size=m)
            truth[0] ^= (sum(truth) + 1) % 2
            deviations = [RNG.uniform(0.0001, 0.009, size=private) for _ in range(m)]
            cells = [make_cell(b, v) for b, v in zip(truth, deviations)]
            h = kron(cells)
            bdim = h.shape[0]
            ident = np.eye(bdim * bdim)
            j = np.kron(h, np.eye(bdim))
            all_ones = 2 ** m - 1
            for addr in [0, m - 1]:
                k = np.kron(np.eye(bdim), kron([cells[z ^ addr] for z in range(m)]))
                for y in sorted({0,1,all_ones}):
                    c = sign_matrices(m, 2 * private, y)
                    # C is diagonal, so form C J C without two dense products.
                    signs = c.diagonal()
                    cj = signs[:, None] * j * signs[None, :]
                    out = k.conj().T @ cj.conj().T @ k @ cj
                    tau = norm(out - (1 - 2 * (y >> addr & 1)) * ident)
                    dosage = sum(max(delta) for delta in deviations)
                    assert tau <= 8 * dosage + 1e-9
                    if y == all_ones:
                        assert dosage <= math.asin(tau/2) + 1e-9
                    counted += 1
    return counted


def embed(a, positions, n):
    result = np.zeros((2 ** n, 2 ** n), complex)
    for i in range(2 ** n):
        inp = sum(((i>>v)&1) << j for j, v in enumerate(positions))
        unused = i ^ sum(((i >> v) & 1) << v for v in positions)
        for j in range(2**len(positions)):
            out = unused + sum(((j >> t) & 1) << v for t, v in enumerate(positions))
            result[out, i] = a[j, inp]
    return result


def small_noise(n, scale):
    q = haar(n)
    return (q * np.exp(1j * RNG.uniform(-scale, scale, size=n))) @ q.conj().T


def shared_test():
    tested = 0
    for scale in [0.005, 0.05, 0.15, 0.35]:
        for _ in range(8):
            # Separate bank bits with an overlapping helper, genuinely noncommuting calls.
            j = embed(small_noise(4, scale) @ np.kron(I2, X), [0, 2], 3)
            k = embed(small_noise(4, scale) @ np.kron(I2, X), [1, 2], 3)
            z_a = np.diag([1 - 2*(i&1) for i in range(8)])
            c = np.diag([1 - 2*((i&3) == 3) for i in range(8)])
            ja = c @ j @ c
            tau_0 = norm(k.conj().T @ j.conj().T @ k @ j - np.eye(8))
            tau_1 = norm(k.conj().T @ ja.conj().T @ k @ ja + np.eye(8))
            p_error = norm(j.conj().T @ z_a @ j + z_a)
            assert tau_0 > 1e-6 and tau_0 + tau_1 < 2.
            assert p_error <= tau_0 + tau_1 + 1e-12
            tested += 1
    return tested


def tensor_test():
    total = 0
    for blocks in range(1, 7):
        for _ in range(25):
            truth = RNG.integers(0,2,size=blocks)
            truth[0] ^= (sum(truth)+1) % 2
            angles = [RNG.uniform(0, 0.025, size=2) for _ in range(blocks)]
            spectra = [[(-1)**int(b) * np.exp(1j * s * 2 * d)
                        for d in a for s in [-1,1]] for b,a in zip(truth,angles)]
            tau = max(abs(np.prod(vals)+1) for vals in itertools.product(*spectra))
            assert tau < .5
            assert abs(sum(max(a) for a in angles) - math.asin(tau/2)) <= 1e-12
            total += 1
    return total


if __name__ == "__main__":
    print(bank_test(), "complete matrix slices on translated local programs with target-dependent phases and garbage")
    print(shared_test(), "noncommuting shared-helper parity obstructions")
    print(tensor_test(), "tensor spectral angular-dosage checks")

def native_path_tests():
    paulis = [np.eye(2),X,np.diag([1,-1]),np.array([[0,-1j],[1j,0]])]
    def pauli(v,n):
        return kron(paulis[((v>>i)&1)+2*((v>>(i+n))&1)] for i in range(n))
    def sp(a,b,n):
        mask=(1<<n)-1
        return (((a&mask)&(b>>n)).bit_count()+((b&mask)&(a>>n)).bit_count())%2
    def one(n,k,p,axes,chars,sign):
        t=len(axes)
        candidates={}
        for e in range(1<<t):
            q,label=0,0
            for j in range(t):
                if (e>>j)&1:
                    q^=axes[j]; label^=chars[j]
            if q==0:
                candidates[label] = candidates.get(label,0)+1
        multiplicity=max(candidates.values())
        v=pauli(p,n)
        mats=[pauli(g,n) for g in axes]
        I=np.eye(2**n)
        f=[]
        for z in range(1<<k):
            u=I
            for mat,ell,s in zip(mats,chars,sign):
                eps=s*(-1)**((ell&z).bit_count()%2)
                u=u@(np.cos(np.pi/8)*I+1j*eps*np.sin(np.pi/8)*mat)
            val=np.trace(v@u.conj().T@v@u).real/len(v)
            f.append(val)
        fourier=[sum(v*(-1)**((z&ell).bit_count()%2) for z,v in enumerate(f))/len(f)
                 for ell in range(len(f))]
        assert all(ell in candidates for ell,c in enumerate(fourier) if abs(c)>1e-9)
        paths={p:1.}
        for g in axes:
            q={}
            for h,wt in paths.items():
                if sp(h,g,n):
                    q[h]=q.get(h,0.)+wt/2
                    q[h^g]=q.get(h^g,0.)+wt/2
                else:
                    q[h]=q.get(h,0.)+wt
            paths=q
        assert np.mean(np.array(f)**2)<= multiplicity*paths.get(p,0)+1e-12
        return f
    for _ in range(160):
        n=int(RNG.integers(1,4)); k=int(RNG.integers(2,5)); t=int(RNG.integers(1,11))
        axes=RNG.integers(1,2**(2*n),size=t).tolist()
        chars=RNG.integers(0,2**k,size=t).tolist()
        s=RNG.choice([-1,1],size=t).tolist()
        one(n,k,1,axes,chars,s)
    # An exact odd k=2 mask saturates t−rank(P)=k+1 in the Pauli-rotation ledger.
    f=one(1,2,1,[2]*4,[0,1,2,3],[1,-1,-1,1])
    np.testing.assert_allclose(f,[1,1,1,-1],atol=1e-12)
    return 161


if __name__ == "__main__":
    print(native_path_tests(), "native signed-T Fourier support and path-return bounds, including a tight two-address circuit")
