# A visitation bound for the exact side of a finite-field walk predicate

The read-only finite-field zero test in the earlier notes uses a bounded list of elementary matrices and fixed conjugates. At a nonzero tested address it acts by controlled linear permutations on vectors $v\in F^3$, $F=\mathbb F_{2^h}$. At the zero address all those generators act as identity. Two special work bits, one initialized to 1 and a different one to minus, keep the nonzero branch away from its invariant subspace. Its fixed-precision gap filter approximates equality in constant native depth when both address classes may incur error. Could a different short filter yield **exactly zero false-positive amplitude** on every nonzero address, while retaining constant true-positive amplitude at zero?

Allow $D$ controlled generator or adjoint visits, with a fixed alphabet of $B\ge2$ possible group operations per visit including identity. Controller-only gates between them may be arbitrary. They may use any number of ancillary controller wires, including clock and signal. At each address choose the same controller operations; all address dependence is through the group generator specializations. Target readout belongs to the controller, and the group-data input has the two-bit initialization described above. This is a restricted circuit class. A readout acting directly on the data or a second programmable data-dependent operation requires a different argument.

Fix a pure permissible controller input. Project the terminal controller onto its marked target-bit outcome. Expanding the $D$ SELECTs gives the resulting marked isometry column, as a function of an arbitrary data input $\psi$,
$$
 K_a|\psi\rangle=\sum_{j=1}^t c_j\otimes L_{a,j}|\psi\rangle,\qquad t\le B^D .
$$
Here $c_j$ can be complex vectors in the entire residual controller space. They are address independent. The $L_{a,j}$ are the actual products of linear permutations and at $a=0$ are all identity. Thus the marked-hit amplitude at zero is $s=\|\sum_j c_j\|$ for every unit data vector.

Choose a fixed nonzero address $a$. Put $u\ne0$ equal to the computational bit direction occupied by the minus code bit. The code contains every $\psi_v=(|v\rangle-|v+u\rangle)/\sqrt2$ whose base $v$ has the first reserved bit 1 and its minus bit 0, giving $|F|^3/4$ permissible choices. For any ordered word pair $j,l$,
$$
 L_{a,j}v=L_{a,l}(v+u)\quad\Longleftrightarrow\quad
 (L_{a,l}^{-1}L_{a,j}-I)v=u .
$$
The coefficient matrix is either zero, giving no solutions, or has rank at least one over $F$, giving at most $|F|^2$ solutions. Thus a fraction at least $1-4t^2/|F|$ of the permissible $v$ have disjoint computational neighborhoods $\{L_{a,j}v\}_j$ and $\{L_{a,j}(v+u)\}_j$.

For either component $w=v$ or $v+u$, sum the marked controller amplitude vectors over its at most $t$ occupied output basis labels. The sum is always $\sum_j c_j$, irrespective of duplicates. Cauchy gives $\|K_a|w\rangle\|\ge s/\sqrt t$. On a pair with disjoint neighborhoods the two output states are orthogonal and cannot cancel. Consequently
$$
 \|K_a|\psi_v\rangle\|\ge s/\sqrt t\ge s B^{-D/2}
$$
on at least the stated fraction of code words. In particular, exact absence of false positives on all nonzero inputs and a nonzero hit $s>0$ force $B^{2D}\ge|F|/4$. More generally, uniform false amplitude at most $\epsilon$ and hit $s$ require
$$
 D\ge \min\!\left\{\tfrac12\log_B(|F|/4),\;2\log_B(s/\epsilon)\right\}.
$$
The square of the amplitude bound, weighted by $1-4t^2/|F|$, lower-bounds the average false probability on the paired computational code whenever that fraction is positive.

For the specified finite-field test, $h=\Theta(k)$ and $B$ is independent of $k$. The direct walk-filter construction therefore needs order $k$ sequential visits to supply an exact off-zero side, or to make a constant zero-hit amplitude coexist with $2^{-\Omega(k)}$ uniform off-zero amplitude. This statement counts visits to the given generators. It does not preclude regrouping into a new native operation, using a shared self-calibrating bank, or synthesizing an entirely different one-sided predicate.
