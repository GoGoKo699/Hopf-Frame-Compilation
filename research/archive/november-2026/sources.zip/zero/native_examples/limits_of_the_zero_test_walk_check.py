"""Finite orbit and marked amplitude checks on three field data registers."""
from itertools import product
import numpy as np


def run():
    rng = np.random.default_rng(8171)
    total=good=0
    # Multiplication by the field element t modulo X^h+X+1 (h=4)
    # or X^h+X^2+1 (h=5).
    for q,poly in [(16,19),(32,37)]:
        def times_t(x):
            y=x<<1
            return (y^poly) if y>=q else y
        def left(w):
            return (w[0]^times_t(w[1]),w[1],w[2])
        def right(w):
            return (w[0],w[1]^times_t(w[2]),w[2])
        words=[lambda v:v,left,right,lambda w:left(right(w))]
        for t in [2,3,4]:
            coeff=rng.normal(size=(t,2))+1j*rng.normal(size=(t,2))
            # Exact nonzero success amplitude of the sum at the zero address.
            c=np.linalg.norm(sum(coeff))
            def marked(v):
                table={}
                for i,word in enumerate(words[:t]):
                    w=word(v)
                    table[w]=table.get(w,0.)+coeff[i]
                return table
            isolated=0
            for a,b,c3 in product(range(1,q,2), range(0,q,2), range(q)):
                v=(a,b,c3)
                w=(a,b^1,c3)
                left_bucket=marked(v); right_bucket=marked(w)
                if left_bucket.keys().isdisjoint(right_bucket.keys()):
                    isolated+=1
                    measured=(sum(np.vdot(j,j).real for j in left_bucket.values())+
                              sum(np.vdot(j,j).real for j in right_bucket.values()))/2
                    assert measured+1e-10 >= c*c/t
                total+=1
            assert isolated >= q**3/4*(1-4*t*t/q)
            good+=isolated
    return total,good


if __name__=="__main__":
    total,good=run()
    print(total,"coded field-vector inputs;",good,"disjoint-neighborhood marked-amplitude bounds")
