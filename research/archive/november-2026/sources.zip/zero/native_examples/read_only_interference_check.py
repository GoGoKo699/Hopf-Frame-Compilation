"""Exact cyclotomic path and interference checks, plus a native cubic XOR example."""
from functools import reduce
from itertools import product
from operator import xor
from random import Random

ZERO = (0, 0, 0, 0)
ONE = (1, 0, 0, 0)


def plus(a, b):
    return tuple(x + y for x, y in zip(a, b))


def minus(a, b):
    return tuple(x - y for x, y in zip(a, b))


def phase(a, e):
    out = [0] * 4
    for i, v in enumerate(a):
        residue = (i + e) % 8
        out[residue % 4] += v * (1 if residue < 4 else -1)
    return tuple(out)


def mul(a, b):
    return tuple(sum(b[j] * phase(a, j)[i] for j in range(4)) for i in range(4))


def automorphism(a, g):
    out = ZERO
    for i, c in enumerate(a):
        out = plus(out, phase((c, 0, 0, 0), g * i))
    return out


def valuation(a):
    # Units are read modulo 1−omega. Valuation normalized by v(1−omega)=1.
    if a == ZERO:
        return 10 ** 9
    answer = 0
    while sum(a) % 2 == 0:
        b0 = (a[0] - sum(a[1:])) // 2
        a = (b0, b0 + a[1], b0 + a[1] + a[2], b0 + sum(a[1:]))
        answer += 1
    return answer


def rank(values):
    pivots = {}
    for x in values:
        while x:
            j = x.bit_length() - 1
            if j in pivots:
                x ^= pivots[j]
            else:
                pivots[j] = x
                break
    return len(pivots)


def parity(x):
    return x.bit_count() % 2


def gauss_sums():
    rng = Random(1709)
    cases = 0
    for k in range(1, 9):
        for _ in range(40):
            terms = [(rng.randrange(1 << k), rng.choice([-1, 1])) for _ in range(k * 2)]
            values = [sum(s * parity(a & x) for a, s in terms) % 4 for x in range(1 << k)]
            result = reduce(plus, (phase(ONE, 2 * e) for e in values), ZERO)
            polar = [sum(((((values[(1 << i) ^ (1 << j)] - values[1 << i] - values[1 << j]) % 4) // 2) << j)
                         for j in range(k)) for i in range(k)]
            if result != ZERO:
                assert valuation(result) == 2 * (2 * k - rank(polar))
            cases += 1
    return cases


def transform(vector, flipped):
    for qubit in range(flipped.bit_length()):
        if flipped >> qubit & 1:
            mask = 1 << qubit
            for z in range(len(vector)):
                if z & mask == 0:
                    a, b = vector[z], vector[z | mask]
                    vector[z], vector[z | mask] = plus(a, b), minus(a, b)


def path_sums():
    rng = Random(1207)
    cases = 0
    for q, k in [(1, 4), (2, 4), (2, 6), (3, 5)]:
        for _ in range(12):
            d = 3
            bases = [rng.randrange(1 << q) for _ in range(d)]
            H = sum((a ^ b).bit_count() for a, b in zip(bases, bases[1:]))
            bands = [[(rng.randrange(1 << q), rng.randrange(4), rng.randrange(1 << k),
                       rng.choice([-1, 1])) for _ in range(5)] for _ in range(d)]
            sectors = [rng.randrange(4), rng.randrange(4)]
            tip = rng.randrange(1 << q)
            initial, final = rng.randrange(1 << q), rng.randrange(1 << q)
            samples = []
            for x in range(1 << k):
                vec = [ZERO] * (1 << q)
                vec[initial] = ONE
                for leg in range(2):
                    for j in (range(d) if leg == 0 else reversed(range(d))):
                        for z in range(1 << q):
                            e = sum(s * (1 - 2 * parity(a & x)) * (parity(c & sectors[leg]) ^ parity(p & z))
                                    for p, c, a, s in bands[j])
                            vec[z] = phase(vec[z], e if leg == 0 else -e)
                        nxt = j + 1 if leg == 0 else j - 1
                        if 0 <= nxt < d:
                            transform(vec, bases[j] ^ bases[nxt])
                    if leg == 0:
                        vec = [vec[z ^ tip] for z in range(1 << q)]
                samples.append(vec[final])
            # Each sample has denominator 2^H; therefore the summed numerators
            # must have v_(1−omega)≥2k after any one- or two-image path expansion.
            for g in [1, 3, 5, 7]:
                assert valuation(reduce(plus, (automorphism(s, g) for s in samples), ZERO)) >= 2 * k
                assert valuation(reduce(plus, (mul(s, automorphism(s, g)) for s in samples), ZERO)) >= 2*k
                cases += 2
            assert H >= 0
    return cases


def native_cubic():
    # Four work qubits. A Pauli label uses low nibble for X and high nibble for Z.
    # CCX is the full seven native parity rotations around Z,Z,X axes.
    def ccx(w, j, i):
        generators = (1 << (w + 4), 1 << (j + 4), 1 << i)
        return [('T', reduce(xor, (g for a, g in enumerate(generators) if 1 << a & subset), 0),
                 1 if parity(subset) else -1) for subset in range(1,8)]

    def transvection(a, i, j):
        toggle = [('P', 1 << 3, 1 << a)]
        update = ccx(3,j,i)
        return toggle + update + toggle + update

    A, B = transvection(0,0,1), transvection(1,1,2)
    pair = A + B + A + B
    flip = [('P',1 << 2,4)]
    word = pair + flip + pair + flip
    axes, signs, cumulative = [], [], [0] * 3
    def anti(a,b):
        return parity(((a & 15) & (b >> 4)) ^ ((b & 15) & (a >> 4)))
    for ty, p, val in word:
        if ty == 'P':
            for i in range(3):
                if (val >> i) & 1:
                    cumulative[i] ^= p
        else:
            axes.append(p)
            signs.append(sum(anti(p,c) << i for i,c in enumerate(cumulative)))
    assert rank(cumulative)==0
    unseen=set(range(len(axes)))
    components=[]
    while unseen:
        seed=unseen.pop()
        seen={seed}
        queue=[seed]
        while queue:
            j=queue.pop()
            adj={i for i in unseen if anti(axes[j],axes[i])}
            queue.extend(adj)
            seen.update(adj)
            unseen-=adj
        components.append(sorted(seen))
    # Address gauge rank is joint labelled rank minus work rank after quotienting
    # shared work space; dim J = rank C + rank rest − rank all.
    max_s=0
    for C in components:
        others=[axes[i] for i in range(len(axes)) if i not in set(C)]
        rhs=[p << 3 for p in others]
        s=rank(rhs+[(axes[i] << 3) | signs[i] for i in C])-rank(others+[axes[i] for i in C])
        max_s=max(max_s,s)
    assert max_s>=1
    import numpy as np
    I=np.eye(16,dtype=complex)
    cache={}
    for p in set(axes):
        X, Z=p&15,p>>4
        assert X & Z == 0
        P=np.zeros_like(I)
        for y in range(16):
            P[y ^ X,y]=(-1)**parity(y&Z)
        for s in (1,-1):
            cache['T',p,s]=(I+P)/2+np.exp(1j*np.pi*s/4)*(I-P)/2
    for x in range(8):
        mat=I.copy()
        for ty,p,val in word:
            if ty=='P':
                if parity(val & x):
                    mat=mat[[i^p for i in range(16)],:]
            else:
                mat=cache[ty,p,val] @ mat
        expected=I[[i^int(x==7) for i in range(16)],:]
        np.testing.assert_allclose(mat,expected,atol=3e-13)
    return len(axes),len(components),max_s


if __name__=='__main__':
    assert valuation(phase(ONE,7))==0 and valuation((2,0,0,0))==4
    print(gauss_sums(),'exact quadratic Gauss valuations')
    print(path_sums(),'exact Galois/bilinear path-sum divisibility checks')
    print('Complete cubical native XOR (rotations, components, max address-constraint rank):',native_cubic())
