from itertools import product, permutations
import numpy as np
from math import pi
X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1,-1]);I=np.eye(2)
H=(X+Z)/np.sqrt(2);S=np.diag([1,1j]);U=-np.exp(1j*pi/4)*H@S
assert np.allclose(U@U+U+I,0)
front=[I];seen=set();G=None
for step in range(10):
    nxt=[]
    for v in front:
        if np.allclose(v@U@v.conj().T,U.conj().T):G=v;break
        for g in (H,S):
            q=g@v;flat=q.ravel();q=q/(next(z for z in flat if abs(z)>1e-6));key=np.round(q,7).tobytes()
            if key not in seen:seen.add(key);nxt.append(g@v)
    if G is not None:break
    front=nxt
assert G is not None
checked=0
for k in range(1,10):
    m=1<<k
    plus=[(k+x.bit_count())%3!=2 for x in range(m)]
    for signs in range(m):
        row=[((k-2*signs.bit_count()+x.bit_count()-2*(x&signs).bit_count())%3!=2) for x in range(m)]
        assert sum(row)%2==1 and all(val==plus[x^signs] for x,val in enumerate(row))
        checked+=1
print(f'{checked} odd-weight ± spin sectors with complete shift identity through k=9')
w=np.exp(2j*pi/3);maxerr=0.
for b in (4,6,8):
    D=1<<b;js=np.arange(D)
    for r in range(3):
        amp=np.fft.fft(np.power(w,r*js))/D
        est=np.argmin(abs(np.exp(2j*pi*js[:,None]/D)-w**np.arange(3)[None,:]),axis=1)
        err=sum(np.abs(amp[(est!=2)!=(r!=2)])**2)
        assert err<=4/D and np.allclose(np.linalg.norm(amp),1.)
        maxerr=max(maxerr,err)
print('Exact order-three Clifford reversal and nine Fourier-clock misclassification bounds checked.')
heralds=0
for k in range(1,9):
    m=1<<k
    for signs in range(m):
        for tau in (-1,1):
            row=[((tau+k-2*signs.bit_count()+x.bit_count()-2*(x&signs).bit_count())%3!=0)
                 for x in range(m)]
            assert sum(row)%2==1
            for r in range(3):
                spect=w**r
                amp=(-1+2*spect+2*spect.conj())/8
                assert np.allclose(amp,(3/8)*(1 if r==0 else -1))
            heralds+=1
print(f'{heralds} exact successful-branch XORs across both reference charges and all event types.')
