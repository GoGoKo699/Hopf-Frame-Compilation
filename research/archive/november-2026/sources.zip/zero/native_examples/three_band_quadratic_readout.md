# The signed displacement of one observed dirty bit in three read-only native layers

The repository's READ_ONLY_THREE_LAYER_RIGIDITY.md proves stronger bounds when the entire zero-clean XOR unitary is prescribed. Here only the displacement of a single observed bit is specified. Other output wires may carry arbitrary garbage. The read-only physical hypothesis remains essential.

Let $x$ be a stable binary address throughout the Clifford boundaries, with all native T gates on the private work. Use no initialized work. The word has at most three T bands. Given boundary work Paulis $P,Q$, suppose that for every $x$,
$$
 R_x^\dagger Q R_x=(-1)^{f(x)}P.
$$
For $P=Z_\mathrm{in}$, $Q=Z_\mathrm{out}$, this is precisely that the observed output bit equals the input bit XOR $f(x)$ on every computational work input; everything outside the one output bit can move arbitrarily, and arbitrary scalar phases are allowed. Then $f$ has binary algebraic degree at most two, regardless of the number of dirty wires. By the repository's three-band Pauli gap (CLEAN_AWARE_DEPTH_OBSTRUCTION.md §4.1), the same conclusion follows if the desired bit relation on each address has mean disagreement strictly below $(1-1/\sqrt2)/4$ over uniformly random work basis columns. If this per-address promise holds only on some good subset, the proof yields a degree-two global polynomial agreeing there.

By the read-only Clifford normal form, each intervening Clifford block on address $x$ is a scalar times a Pauli with affine binary labels times one fixed work Clifford. Put $R_x=A_x B C_x$, with $B$ the literal tensor of fixed physical T/T-dagger rotations forming the middle band and one physical band in each outer factor. For a fixed $Q$, its transport by the left Pauli of $A_x$ incurs only an affine sign. The transport through the fixed one-band word gives one fixed Hermitian Clifford. Conjugation by the address-dependent Pauli on the other side merely changes its Pauli frame. The final fixed Clifford can be pulled through that Pauli, changing its binary labels by a fixed linear map and producing an immaterial conjugator phase. The same argument applies at $C_x$. Thus
$$
 E_x=A_x^\dagger Q A_x=(-1)^{e(x)} P_E(x)^\dagger E_0 P_E(x),
 \qquad
 F_x=C_x P C_x^\dagger=(-1)^{j(x)}P_F(x)^\dagger F_0 P_F(x)
$$
for fixed Hermitian Cliffords $E_0,F_0$, affine signs $e,j$, and projective Paulis with affine bit and phase labels. Here subscripts zero are choices of reference fixed Cliffords and can be taken to refer to $x=0$ by absorbing constant offsets into the labels. Changing $\dagger$ placement in a Pauli conjugation does not matter. The desired sign relation is $E_x=(-1)^{f(x)}B F_x B^\dagger$.

For a work Pauli with bit displacement $a$ and phase label $z$, conjugation shifts a matrix entry $(u,v)$ to $(u+a,v+a)$ and multiplies it by $(-1)^{z\cdot(u+v)}$. Choose any nonzero matrix entry $(u_0,v_0)$ of $F_0$. For every address evaluate at
$$
 u(x)=u_0+a_F(x),\qquad v(x)=v_0+a_F(x),
$$
so $u+v=u_0+v_0$ is fixed. The entry of $F_x$ has a fixed nonzero amplitude up to an affine sign. The entry of $E_x$ is another affine sign times the evaluation of the stabilizer Choi state $E_0$ at the affine map
$(u_0+a_F(x)+a_E(x),v_0+a_F(x)+a_E(x))$.
This lies in its fixed affine support wherever the desired bit relation holds. In any independent binary coordinates on that support, the stabilizer phase has the form $i^{\sum_j c_j y_j}(-1)^{q(y)}$ times a constant, with $q$ binary quadratic. The affine inverse coordinates on the support extend to affine functions on the entire ambient space, so the phase formula extends even if only some addresses are promised.

Let $p_B(w)=\sum_i b_i w_i\bmod 8$ be the exponent of the middle tensor T word. The difference $p_B(u)-p_B(v)$ is a constant plus twice a sum of affine parities of $x$: on coordinates where $u_0\ne v_0$ the difference is $\pm(1-2a_{F,i}(x))$, and the other coordinates cancel. Twice an affine XOR expanded as an integer modulo eight has ordinary degree at most two, since every degree-three coefficient in a parity is divisible by four. The same is true of the evaluated stabilizer phase exponent $2\sum c_j y_j+4q(y)$. All additional affine signs are multiplied by four. Consequently the pointwise phase relation gives $4f(x)=p(x)\bmod8$ on all promised addresses for a globally defined integer multilinear polynomial $p$ of degree at most two, with its linear coefficients even and its quadratic coefficients divisible by four. On the full address cube, Möbius inversion now gives Boolean degree at most two.

For the partial-set extension use the higher bit of $p(x)$: write $p(x)=c+2\sum_i d_i x_i+4\sum_{i<j}e_{ij}x_ix_j$. If there is a promised point then $c$ is even. The high bit of this exponent is the sum of the quadratic part, the high bits of all linear coefficients, the linear carries from the constant, and all pairwise products of the low-bit linear terms. Its binary degree is at most two and at every promised point it equals $f(x)$. The same argument covers fixed affine addresses of any arity and all permitted computational work inputs.

## Two layers and a matching three-layer construction

With only two native T layers the same decomposition has $B=I$. If the promise holds on the whole cube, $E_0,F_0$ are the same Clifford $K$ up to sign. The reference-frame relation asks that the Pauli with affine binary label $p_E(x)+p_F(x)$ conjugate $K$ to a scalar sign times itself. Such labels form a binary subspace, and their conjugation signs give an additive binary character there: any projective phase in the product of two Paulis cancels in the adjoint action. Including the endpoint affine signs proves $f$ is affine. The same holds on a subset containing a good basepoint after translation. Affine functions have exact Clifford XORs.

To attain degree two in three layers, use three private physical bits, written in order from least to most significant. For a mask $s$, put $\ell_s(z)=s\cdot z\bmod2$ with values in $\{0,1\}$. For a list $S$ write $D_S|z\rangle=\omega^{\sum_{s\in S}\ell_s(z)}|z\rangle$. Define sets $S_E=\{1,4,7\}$, $S_F=\{2,4,7\}$. Each set is a binary basis, so its diagonal uses a single literal physical T layer after an invertible CNOT change of wire coordinates. Let $D_E=D_{S_E}$, $D_F=D_{S_F}$, $B=T_1T_2^\dagger$, where positions 1,2 are the two low bits. Then $BD_F=D_E$ exactly. All masks in either basis have odd weight. Thus $P=X^{111}$ flips all three $\ell_s$ of either basis.

For address bits $a,b$ define binary vectors $e=(3a)\mathbin{\mathrm{XOR}}(6b)$, $v=(7a)\mathbin{\mathrm{XOR}}(5b)$ and the physical three-band word, in matrix product order,
$$
 R_{a,b}=D_E^\dagger X^e B X^v D_F .
$$
Write $L_E(z)=\sum_{s\in S_E}\ell_s(z)$ over the integers; define $L_F$ similarly. The diagonal of the actual ratio between $X^e D_EP D_E^\dagger X^e$ and $B X^v D_F P D_F^\dagger X^v B^\dagger$ has exponent
$$
 -2[(L_E(z+e)-L_E(z))-(L_F(z+v)-L_F(z))]\pmod8 .
$$
The $z$-dependent terms cancel because $\bigoplus_{s\in S_E:\ell_s(e)=1}s=\bigoplus_{s\in S_F:\ell_s(v)=1}s$ in each address case. The remaining exponent divided by four modulo two is $a+ab$.

| $a$ | $b$ | $e$ | $v$ | Remaining sign bit |
|---|---|---|---|---|
| 0 | 0 | 0 | 0 | 0 |
| 1 | 0 | 3 | 7 | 1 |
| 0 | 1 | 6 | 5 | 0 |
| 1 | 1 | 5 | 2 | 0 |

Therefore $R_{a,b}^\dagger P R_{a,b}=(-1)^{a+ab}P$. A fixed Clifford frame converts a single observed computational $Z$ to $P$; for example apply H on its wire followed by the two outgoing CNOTs. A final address-$a$-controlled X on that bit supplies the linear correction $a$. All native Clifford reads of $a,b$ are stable address controls into private work. The bit displacement is exactly $ab$ on every private input, so the arbitrary dirty-bit version of this task requires exactly three native T layers. This word may alter the other physical outputs. The repository's full-return AND is a different, four-layer operation.

For any prescribed Boolean quadratic, realize its quadratic monomials on private disjoint triples and align their three T bands, sharing only the original read-only address. The product of the observed Paulis acquires the sum of their sign bits under this tensor word. One fixed initial/final Clifford frame therefore realizes the phase test as the displacement of a single observed computational bit in the full register. Add the total linear correction, its prescribed linear part, and its constant by free Clifford gates. Only $O(k^2)$ T gates, dirty qubits and elementary Clifford gates are needed. This proves exact characterization by the Reed–Muller class of order two for this raw three-layer interface.
