"""Finite tests for the exact power-mixture herald and the sector Clifford test."""
from fractions import Fraction
from math import comb
from random import Random
import numpy as np


def convolution(left, right):
    res = [0] * (len(left) + len(right) - 1)
    for i, u in enumerate(left):
        for j, v in enumerate(right):
            res[i+j] += u*v
    return res


def dyadic_filter(a):
    A = 2**a
    n = max(2, A)
    coeff = convolution([comb(n-2, j) for j in range(n-1)], [A, 4-2*A, A])
    assert sum(coeff) == 2**n
    for i, w in enumerate(coeff):
        assert w >= 0 and Fraction(w, comb(n, i)) == Fraction(
            (A-1)*(n-2*i)**2+n*(n-A), n*(n-1))
    return coeff


def power_eval(poly, mat):
    term = np.eye(len(mat), dtype=complex)
    res = np.zeros_like(term)
    norm = sum(poly)
    for c in poly:
        res += (c/norm) * term
        term = term @ mat
    return res


def exact_roots():
    tests = 0
    for a in range(10):
        A = 2**a
        poly = dyadic_filter(a)
        # Reduce by z²−2(1−2/A)z+1 over exact rationals.
        q = [Fraction(x) for x in poly]
        coef = Fraction(2)*(1-Fraction(2,A))
        while len(q)>2:
            v = q.pop()
            q[-1] += coef*v
            q[-2] -= v
        assert q == [0,0]
        tests += len(poly)
    return tests


def mixed_herald():
    rng = np.random.default_rng(24417)
    checks = 0
    for a in range(5):
        ps = [2**(-j) for j in range(a+1)]
        F = [1]
        for j in range(a+1):
            F = convolution(F, dyadic_filter(j))
        for _ in range(12):
            ev = rng.choice([0.] + ps, size=4)
            clean_work = np.diag(np.sqrt(1-ev))
            other = np.diag(np.sqrt(ev))
            V, _ = np.linalg.qr(rng.normal(size=(4,4)) + 1j*rng.normal(size=(4,4)))
            change = np.kron(np.eye(2), V)
            raw = change.conj().T @ np.block([[clean_work,-other], [other,clean_work]]) @ change
            refl = np.kron(np.diag([1,-1]), np.eye(4))
            W = refl @ raw.conj().T @ refl @ raw
            A = power_eval(F, W)
            assert np.linalg.norm(A[:4,:4] - V.conj().T@np.diag(ev==0)@V) < 1e-10
            assert np.linalg.norm(A[4:,:4]) < 1e-10
            checks += 4
    return checks


def clifford_filter():
    rng = Random(318)
    eye = np.eye(2,dtype=complex)
    X = np.array([[0,1],[1,0]], dtype=complex)
    Z = np.diag([1,-1]).astype(complex)
    Y = 1j * X @ Z
    H = (X + Z) / np.sqrt(2)
    S = np.diag([1, 1j]).astype(complex)
    P1 = (eye-Z)/2
    P0 = (eye+Z)/2
    one = (eye, X, Y, Z)
    n = 3
    def tensor(parts):
        a = np.array([[1]], dtype=complex)
        for v in parts:
            a = np.kron(a,v)
        return a
    def place(g, i):
        return tensor([g if j==i else eye for j in range(n)])
    def cx(i,j):
        return place(P0,i)+place(P1,i)@place(X,j)
    catalog = [tensor([one[a],one[b],one[c]]) for a in range(4) for b in range(4) for c in range(4)]
    results = [0,0,0]
    for trial in range(200):
        U = np.eye(2**n,dtype=complex)
        for _ in range(12):
            i,j = rng.sample(range(n),2)
            gate = rng.choice([place(H,i),place(S,i),place(X,i),cx(i,j)])
            U = gate @ U
        prods = [np.eye(2**n, dtype=complex)]
        for i in rng.sample(range(n),rng.randint(1,n)):
            p = rng.choice([-1,1])*place(Z,i)
            prods += [u@p for u in prods]
        survivors = []
        compressed = np.zeros((4,4),dtype=complex)
        for q in prods:
            P = U.conj().T@q@U
            cut = P[:4,:4]
            compressed += cut/len(prods)
            if np.linalg.norm(cut)>1e-8:
                co = [np.vdot(c,P).real/8 for c in catalog]
                idx = int(np.argmax(np.abs(co)))
                assert abs(abs(co[idx])-1)<1e-8
                survivors.append(co[idx]>0)
        eig = np.linalg.eigvalsh(compressed)
        if eig[-1] < 1e-8:
            assert not all(survivors)
            results[0]+=1
        elif eig[0] > 1e-8:
            assert all(survivors)
            assert eig[-1] - eig[0] < 1e-8
            results[1]+=1
        else:
            results[2]+=1
    assert min(results)>0
    return results


if __name__=='__main__':
    print('Exact nonnegative coefficients and rational phase roots:',exact_roots())
    print('Rotated dirty-sector spectral-filter checks:',mixed_herald())
    print('Random commuting-readout Clifford cases (zero, positive, singular):',clifford_filter())


def shorter_filter():
    count = 0
    for a in range(11):
        A = 2**a
        t = 1
        while t*t < 3*A:
            t *= 2
        interval = [1]*t
        q = convolution(interval,interval)
        g = convolution(q,q)
        poly = convolution([A,4-2*A,A],g)
        assert min(poly)>=0 and sum(poly)==4*t**4 and len(poly)<=4*t+1
        count += len(poly)
    return count


def one_clean_joint_walk():
    rng = np.random.default_rng(25593)
    X = np.array([[0.,1.],[1.,0.]])
    Z = np.diag([1.,-1.])
    checks=0
    for theta in (np.pi/10,np.pi/4,np.pi/3,np.pi/2):
        # Π=|1><1|, false raw is phase diagonal, true primitive a rotation.
        c,s=np.cos(theta),np.sin(theta)
        true=np.array([[c,-s],[s,c]])
        for x in range(4):
            local=[]
            for a in range(4):
                U = true if a==x else np.diag(np.exp(1j*rng.uniform(size=2)))
                local.append(Z @ U.conj().T @ Z @ U)
            for y in range(16):
                W=np.array([[1.]])
                for a in range(4):
                    W=np.kron(W,local[a] if (y>>a)&1 else np.eye(2))
                if (y>>x)&1:
                    distances=np.abs(np.linalg.eigvals(W)-1)
                    assert max(abs(distances-2*s))<1e-10
                else:
                    assert np.linalg.norm(W-np.eye(16))<1e-10
                checks+=1
    return checks


if __name__=='__main__':
    print('Quartic interval coefficients checked:',shorter_filter())
    print('Shared-clock, all-dirty spectral sectors:',one_clean_joint_walk())


def sparse_restrictions():
    from itertools import combinations
    from fractions import Fraction
    tested=0
    for h,k in ((3,1),(3,2),(4,2),(5,2)):
        all_dirs = set()
        for basis in combinations(range(1,1<<h),k):
            flat = {0}
            for b in basis:
                flat |= {u^b for u in list(flat)}
            if len(flat)==1<<k:
                all_dirs.add(tuple(sorted(flat)))
        for b in range(1,1<<h):
            assert Fraction(sum(b in flat for flat in all_dirs),len(all_dirs)) == Fraction(2**k-1,2**h-1)
            tested+=1
    return tested


if __name__=='__main__':
    print('Sparse affine-flat incidence counts:',sparse_restrictions())
