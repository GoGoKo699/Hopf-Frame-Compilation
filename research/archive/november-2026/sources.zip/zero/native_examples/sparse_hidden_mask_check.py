"""Finite checks for affine-bin isolation, masking across selectors and low-degree backgrounds."""
from itertools import combinations, product
from random import Random

def parity(x):
    return x.bit_count() & 1

def shifted(h,x,m):
    return sum(((h>>(a^x))&1)<<a for a in range(m))

def conv(h,g,m):
    out=0
    for i in range(m):
        if h>>i&1: out^=shifted(g,i,m)
    return out

def on_bin(z,rows,c):
    return all(parity(z&r)==(c>>i&1) for i,r in enumerate(rows))

def bin_vector(m,rows,c):
    return sum(on_bin(z,rows,c)<<z for z in range(m))

rng=Random(135795)
checked=0
for k in range(1,4):
    m=1<<k
    for n in range(1,min(3,m)+1):
        j=(2*n-1).bit_length()
        if (m**j)*(1<<j)>40000: continue
        collections=[bin_vector(m,rows,c) for rows in product(range(m),repeat=j) for c in range(1<<j)]
        for sites in combinations(range(m),n):
            h=sum(1<<a for a in sites)
            success=sum((h&g).bit_count()==1 for g in collections)
            assert 8*success >= len(collections)
            checked+=1
print(f'{checked} exact affine-hash singleton probabilities')

checked=origins=0
for k in range(2,6):
    m=1<<k
    lanes=[]
    for _ in range(96):
        j=rng.randint(1,min(k,4))
        rows=[rng.randrange(m) for _ in range(j)]
        lanes.append((bin_vector(m,rows,rng.randrange(1<<j)),j))
    for t in (1,2,3):
        for _ in range(24):
            sx=sum(1<<i for i in rng.sample(range(m),t))
            jmax=min(k,4)
            if k>jmax:
                coeff=[rng.getrandbits(1) if i.bit_count()<k-jmax else 0 for i in range(m)]
                bg=sum((sum(c for i,c in enumerate(coeff) if z&i==i)&1)<<z for z in range(m))
            else:
                bg=0
            masked=sx^bg
            assert any(parity(sx&g) for g,_ in lanes)
            for g,j in lanes:
                assert parity(masked&g)==parity(sx&g)
                h=masked&g
                r=rng.randrange(m);x=rng.randrange(m);a=rng.getrandbits(m);b=rng.getrandbits(m)
                f=shifted(h,r,m);togg=shifted(h,r^x,m)
                # four-corner convolution in explicit unknown origins
                if checked%23==0:
                    got=conv(a,b,m)^conv(a^f,b,m)^conv(a^f,b^togg,m)^conv(a,b^togg,m)
                    assert got==(parity(h)<<x)
                    origins+=1
                assert conv(f,togg,m)==parity(h)<<x
                checked+=1
print(f'{checked} parallel masked syndrome lanes, {origins} unknown-origin four-corner echoes')
