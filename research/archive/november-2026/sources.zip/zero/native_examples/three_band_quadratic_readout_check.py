"""Exact phase/coset checks and a full Hilbert-space raw AND synthesis."""
from functools import reduce
from itertools import product
from operator import xor
from random import Random

import numpy as np

SE, SF = (1, 4, 7), (2, 4, 7)
def value(s, x):
    return (s & x).bit_count() % 2

def weight(S, x):
    return sum(value(s,x) for s in S)

def matrix(S):
    return np.diag([np.exp(1j*np.pi*weight(S,z)/4) for z in range(8)])

def bits(a,b):
    return (3*a) ^ (6*b), (7*a) ^ (5*b)

def exact_phase():
    count = 0
    for a,b in product(range(2),repeat=2):
        e,v=bits(a,b)
        assert reduce(xor,(s for s in SE if value(s,e)),0)==reduce(xor,(s for s in SF if value(s,v)),0)
        for z in range(8):
            phase=-2*(weight(SE,z^e)-weight(SE,z)-weight(SF,z^v)+weight(SF,z))
            assert phase%8==4*(a^(a*b))
            count+=1
    return count

def xgate(mask):
    return np.eye(8)[[z^mask for z in range(8)]]

def matrix_test():
    eye=np.eye(8)
    h1=np.kron(np.eye(4),np.array([[1,1],[1,-1]])/np.sqrt(2))
    fan=eye[[z^((6 if z&1 else 0)) for z in range(8)]]
    frame=fan@h1
    p=xgate(7)
    q=np.diag([1-2*(z&1) for z in range(8)])
    d,e=matrix(SF),matrix(SE)
    b=np.diag([np.exp(1j*np.pi*((z&1)-((z>>1)&1))/4) for z in range(8)])
    np.testing.assert_allclose(frame@q@frame.conj().T,p,atol=1e-12)
    np.testing.assert_allclose(b@d,e,atol=1e-12)
    count=0
    for a,adr in product(range(2),repeat=2):
        v,w=bits(a,adr)
        raw=e.conj().T @ xgate(v) @ b @ xgate(w) @ d
        np.testing.assert_allclose(raw.conj().T @ p @ raw,(-1)**(a^(a*adr))*p,atol=1e-12)
        physical=xgate(a) @ frame.conj().T @ raw @ frame
        np.testing.assert_allclose(physical.conj().T @ q @ physical, (-1)**(a*adr)*q,atol=1e-12)
        for z in range(8):
            assert sum(abs(physical[y,z])**2 for y in range(8) if (y^z)&1 != a*adr)<1e-12
            count+=1
    return count

def bit_high():
    rng=Random(442)
    count=0
    for k in range(1,8):
        for _ in range(20):
            c=2*rng.randrange(4)
            forms=[(rng.randrange(8),rng.randrange(1<<k),rng.randrange(1<<k)) for _ in range(6)]
            vals=[((c+sum(2*v*value(p,x)+4*value(p,x)*value(q,x) for v,p,q in forms))//4)%2
                  for x in range(1<<k)]
            coeff=vals[:]
            for i in range(k):
                for x in range(1<<k):
                    if (x>>i)&1: coeff[x]^=coeff[x^(1<<i)]
            assert all(not a or m.bit_count()<=2 for m,a in enumerate(coeff))
            count+=1
    return count
if __name__=='__main__':
    print(exact_phase(),'exact phase cases,',matrix_test(),'full native dirty AND columns')
    print(bit_high(),'partial-domain high-bit degree checks')
