"""Check the spin alignment argument at characteristic three and at the pair threshold."""
from itertools import product
from functools import reduce
import numpy as np

def mod3_null(a):
    a=np.array(a,dtype=int)%3
    r=0;piv=[]
    for c in range(a.shape[1]):
        nz=np.flatnonzero(a[r:,c])
        if not len(nz):continue
        h=r+nz[0]
        a[[h,r]]=a[[r,h]]
        a[r]=a[r]*int(a[r,c])%3
        for i in range(len(a)):
            if i!=r:a[i]=(a[i]-a[i,c]*a[r])%3
        piv.append(c);r+=1
    free=[c for c in range(a.shape[1]) if c not in piv]
    n=np.zeros((len(free),a.shape[1]),int)
    for j,c in enumerate(free):
        n[j,c]=1
        for i,ci in enumerate(piv):n[j,ci]=-a[i,c]%3
    return n

nil=[]
for entries in product(range(3),repeat=4):
    n=np.array(entries).reshape((2,2))
    if np.any(n) and not np.any(n@n%3):nil.append(n)
assert len(nil)==8
rng=np.random.default_rng(35)
identity=np.eye(2,dtype=int)
counts={}
for s in range(2,7):
    for _ in range(7):
        local=[nil[i] for i in rng.integers(0,len(nil),s)]
        ops=[reduce(np.kron,[n if j==i else identity for j in range(s)]) for i,n in enumerate(local)]
        diffs=[u-ops[0] for u in ops[1:]]
        rr=mod3_null(np.vstack(diffs));ll=mod3_null(np.vstack([d.T for d in diffs]))
        # All right/left kernels have two aligned basis vectors at every multiplicity-free size.
        assert len(rr)==2==len(ll)
        pairing=ll@rr.T%3
        assert (not np.any(pairing)) == (s>=3)
        counts[s]=counts.get(s,0)+1
print(f'{sum(counts.values())} characteristic-three alignment spaces at two through six sites')
I=np.eye(2);X=np.array([[0,1],[1,0]]);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1])
U=-(I+1j*(X+Y+Z))/2
assert np.allclose(U@U+U+I,0) and np.allclose(U@U.conj().T,I)
bell=np.array([1,0,0,1])/np.sqrt(2)
assert np.allclose(np.kron(U,I)@bell,np.kron(I,U.T)@bell)
print('Native spin order-three polynomial and normalized two-site Bell calibration checked.')
