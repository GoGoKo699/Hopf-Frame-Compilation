# Verification and proof guide

Read Hopf_Trace_Inversion_and_the_Zero_Test.md for the resource statements. The unrestricted general frame upper at fixed precision is R96. The zero-test construction is conditional. The linear rank–precision obstruction is a lower bound on the resources required by actual finite-depth circuits.

| Directory | Contents |
|---|---|
| fixed_accuracy | All-depth basis-change lower bound for an explicit complete sign frame, a worst-case sign table, and a constant-depth implementation of the explicit quartic example. |
| precision | Proof improving the fixed-clean R74 witness from square-root to linear crossing rank in the precision exponent, exact cyclotomic checks, and an extension to additional layers. |
| zero_test | Reciprocal partial fractions, complete implementation using private moving addresses, the existing sharp three-band gap applied to a sparse target, two complementary four-band necessary conditions, and the exact one-spin search. |
| native_examples | Actual small native circuits and restricted results on dirty predicates, precision, and exact charge comparisons. The local herald does not implement a full bank on a common hidden sector. |

Each Markdown note has a same-stem Python checker. Run \`python run_checks.py\` from the extracted package with Python 3.11+, NumPy and SciPy available. TEST_RESULTS.txt records the observed finite checks. They supplement the all-size proofs. Tests of exponent and rank conditions do not amount to an implementation of a sublogarithmic scalar source.

Repository baseline: ae613bf8e8a38f6d0407c25910b83d69f01a2733. The authoritative baseline, R74, R75 and R98 are linked in the report. The repository files were kept read-only.
