"""Finite rank and single-active-sector spectral checks used after R75."""
from itertools import product
import numpy as np


def check():
    phase_words=0
    maximal=0
    for r in range(1,5):
        for extra in (0,1,2):
            sector=2**extra
            for active in range(1,1<<min(2**r, 8)):
                support=active.bit_count()
                phases=[(-1 if active>>i&1 else 1) for i in range(2**r)]
                # Exact diagonal entries keep the rank test in integer arithmetic.
                rank=sum(q!=1 for q in phases)*sector
                assert rank==support*sector
                for k in range(1,7):
                    if 0<rank<=(2**r)*sector/(2**k):
                        assert r>=k
                        if r==k:
                            assert support==1
                            maximal+=1
                phase_words+=1
    for phase in np.exp(1j*np.pi*np.arange(1,8)/4):
        # For a single nontrivial value, closure of a product-of-involutions'
        # spectrum under complex conjugation forces the value -1.
        closed=abs(phase-phase.conjugate())<1e-12
        assert closed==(abs(phase+1)<1e-12)
    print('Equal-sector diagonal rank cases:',phase_words)
    print('Rank-saturated exact flips:',maximal)
    print('Eighth-root singleton spectra:',7)


if __name__=='__main__':
    check()
