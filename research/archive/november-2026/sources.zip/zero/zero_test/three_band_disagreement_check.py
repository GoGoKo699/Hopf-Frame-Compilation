"""Exact exponent checks and a physical matrix calculation for the sharp raw-readout gap."""
from itertools import product
from math import sqrt, pi
from random import Random

import numpy as np

def weight_trial():
    rng = Random(1143)
    for n in range(1, 9):
        for it in range(40):
            masks = rng.choices(range(1 << n), k=8)
            vals = [rng.choice((-1,1))*((1 << (it%3))) for _ in masks]
            exponents = [(sum(a*((x&m).bit_count()%2) for m,a in zip(masks,vals)))%8 for x in range(1<<n)]
            re = sum(np.cos(pi*p/4) for p in exponents)/len(exponents)
            assert max(exponents)==0 or re <= (1+1/sqrt(2))/2+1e-12
    return 320

def saturation():
    root = np.exp(1j*pi/4)
    parities = lambda x: ((x^(x>>2))&1, ((x>>1)^(x>>2))&1, x.bit_count()%2)
    exp = []
    for x in range(8):
        a,b,c=parities(x)
        exp.append(a+b-c)
    for x in range(8):
        assert (exp[x^4]-exp[x])%8 == (1-2*(x>>2)+4*((x&1)*((x>>1)&1)))%8
    had=np.array([[1,1],[1,-1]])/sqrt(2)
    h2=np.kron(np.kron(np.eye(2),had),np.eye(2))
    h3=np.kron(had,np.eye(4))
    v=h2 @ np.diag(root**np.array(exp)) @ h2
    t2=np.diag([root**((x>>1)&1) for x in range(8)])
    z3=np.diag([(-1)**(x>>2) for x in range(8)])
    u=h3 @ v.conj().T @ t2 @ v @ h3
    corr=np.trace(z3 @ u @ z3 @ u.conj().T)/8
    e=sum(abs(u[y,x])**2 for x,y in product(range(8),repeat=2) if (x^y)&4)/8
    np.testing.assert_allclose(corr,(1+1/sqrt(2))/2,atol=1e-12)
    np.testing.assert_allclose(e,(1-1/sqrt(2))/4,atol=1e-12)
    return e
if __name__=='__main__':
    print(weight_trial(), "weighted-degree phase averages")
    print("Saturating three-qubit circuit, mean bit discrepancy",saturation())
