"""Check the reciprocal trace projection, six-edge cancellation and binary reconstruction."""
from itertools import combinations
from functools import reduce
from operator import xor
from random import Random

POLY = {2: 0x7, 3: 0xb, 4: 0x13, 5: 0x25, 6: 0x43, 7: 0x83, 8: 0x11b}


class Field:
    def __init__(self, n):
        self.n = n
        self.size = 1 << n
        self.modulus = POLY[n]
        self.mult = [[self.multiply(i, j) for j in range(self.size)] for i in range(self.size)]
        self.inv = [0] + [self.mult[i].index(1) for i in range(1, self.size)]
        self.tr = [reduce(xor, self.frobenius(i)) for i in range(self.size)]
        assert set(self.tr) == {0, 1}

    def multiply(self, x, y):
        acc = 0
        while y:
            if y & 1:
                acc ^= x
            x <<= 1
            if x & self.size:
                x ^= self.modulus
            y >>= 1
        return acc

    def frobenius(self, x):
        powers = []
        for _ in range(self.n):
            powers.append(x)
            x = self.mult[x][x]
        return powers

    def g(self, d, u):
        assert self.tr[u] == 0
        return self.tr[self.mult[d][self.inv[u]]]


def linear_rank(vectors):
    pivots = {}
    for vec in vectors:
        while vec:
            pos = vec.bit_length()
            if pos not in pivots:
                pivots[pos] = vec
                break
            vec ^= pivots[pos]
    return len(pivots)


def check(dimension, rng):
    f = Field(dimension)
    elems = range(f.size)
    ds = [d for d in elems if f.tr[d]]
    identity_checks = 0
    plane_checks = 0
    recon_checks = 0
    and_checks = 0
    short_checks = 0
    subfield_checks = 0
    for d in (ds if dimension <= 4 else rng.sample(ds, min(3, len(ds)))):
        shifts = ([(a, b) for a, b in combinations(elems, 2)] if dimension <= 4
                  else [tuple(rng.sample(elems, 2)) for _ in range(10)])
        for b, c in shifts:
            t = b ^ c
            for x in elems:
                y = f.mult[x ^ b][f.inv[t]]
                q = f.g(d, y ^ f.mult[y][y])
                check = f.tr[f.mult[d][f.mult[t][f.inv[x ^ b] ^ f.inv[x ^ c]]]]
                assert q == check ^ (x == b) ^ (x == c)
                identity_checks += 1
        for _ in range(5):
            u, v = rng.sample(range(1, f.size), 2)
            origin = rng.randrange(f.size)
            plane = (origin, origin ^ u, origin ^ v, origin ^ u ^ v)
            for x in elems:
                bits = []
                for b, c in combinations(plane, 2):
                    y = f.mult[x ^ b][f.inv[b ^ c]]
                    bits.append(f.g(d, y ^ f.mult[y][y]))
                assert reduce(xor, bits) == (x in plane)
                plane_checks += 1
        # Choose <1,2> as the plane; high binary polynomial-basis bits are its complement.
        for x in range(0, f.size, 4):
            bits = []
            for b, c in combinations(range(4), 2):
                y = f.mult[x ^ b][f.inv[b ^ c]]
                bits.append(f.g(d, y ^ f.mult[y][y]))
            assert reduce(xor, bits) == (x == 0)
            and_checks += 1
        a = 1 if dimension % 2 == 0 else next(z for z in elems if not f.tr[z] and f.g(d,z))
        for x in elems:
            tx = x ^ f.mult[f.mult[x][x]][f.inv[a]]
            if f.tr[x] or f.tr[tx]:
                continue
            assert f.g(d, x) ^ f.g(d, x ^ a) ^ f.g(d, tx) == (x in (0, a))
            short_checks += 1
        if dimension % 2 == 0:
            subfield = {z for z in elems if f.frobenius(z)[dimension // 2] == z}
            d_subfield = {f.mult[d][z] for z in subfield}
            w = [x for x in elems if not f.tr[x] and (x ^ f.mult[x][x]) in d_subfield]
            assert len(w) >= 2 ** (dimension // 2 - 1)
            for x in w:
                assert f.g(d, x) ^ f.g(d, x ^ 1) == (x in (0, 1))
                subfield_checks += 1
        if dimension & (dimension - 1) == 0:
            assert linear_rank(f.frobenius(d)) == dimension
            def trace_key(w):
                return tuple(f.tr[f.mult[d][a]] for a in f.frobenius(w))
            decode = {trace_key(w): w for w in elems}
            assert len(decode) == f.size
            for x in elems:
                candidates = []
                for t in (1, 2):
                    y = f.mult[x][f.inv[t]]
                    z = f.mult[y][y] ^ y
                    measured = tuple(f.g(d, zz) for zz in f.frobenius(z))
                    recovered = decode[measured]
                    assert recovered == f.inv[z]
                    candidate = f.mult[f.inv[t]][f.mult[y ^ 1][recovered]]
                    assert candidate == (0 if x == t else f.inv[x])
                    candidates.append(candidate)
                assert candidates[x & 1] == f.inv[x]
                recon_checks += 1
    return identity_checks, plane_checks, and_checks, recon_checks, short_checks, subfield_checks


if __name__ == "__main__":
    rng = Random(302)
    counts = [check(n, rng) for n in POLY]
    print('Field degrees 2..8')
    for name, total in zip(('two-pole identities', 'four-point membership checks',
                            'restricted exact AND cases', 'Frobenius and two-chart inversions',
                            'three-query identities', 'two-query subfield restrictions'),
                           map(sum, zip(*counts))):
        print(f'{total} {name}')
