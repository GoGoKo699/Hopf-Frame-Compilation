# A sparse four-band response needs linearly many crossing directions

Let A=E_A K_A E_A† and B=E_B K_B E_B† be the two midpoint Hermitian Pauli transports from a four-band native readout. The E are single transported T bands, and the K are the Hermitian Clifford endpoints. Let L_A,L_B be their axis spans, I their intersection, r=dim I, and s the rank of their binary symplectic pairing. Assume the R75 near-one conclusion W=BA ∈ span(P_a : a∈I); here P_a denotes a work Pauli. This yields a scalar λ(z) on every I-coordinate sector. Each λ is an eighth root of unity. All these properties are justified in R75 §7 in the near-one region; one may instead assume them as explicit input to this proof.

Suppose W differs from I on a positive fraction γ≤2^{-k} of its equal-dimensional sectors, for k≥5. Then
$$
 s\ge k/2-1.
$$
More precisely s≥k/2−v(1−λ(z₀)) at every exceptional sector z₀, where v is the valuation of Q(ζ₈) above two normalized by v(2)=1. The possible subtracted amounts are 1, 1/2 and 1/4 for roots of order 2, 4 and 8 respectively. For a four-band readout exactly silent outside one k-bit address and active somewhere on it, k≥6 yields the requisite normalized near-one region by the companion R75 commutant argument. Its rank bound gives γ≤2^{-k} and r≥k. Every such circuit therefore needs r≥k and s≥ceil(k/2−1). Since I is contained in the kernel of the pairing on each side, each middle band contains at least k+ceil(k/2−1) independent physical axes. The bound permits arbitrary other gates, arbitrary dirty width and unrestricted completed address motion. Its linear required middle width still fits a polynomial local budget.

## An affine section in the two adapted bases

The radical of L_A+L_B contains I and the crossing-null directions on both sides. Choose common Pauli coordinates in which it is diagonal and in which the remaining s independent directions of L_A are Z-core coordinates and those of L_B are X-core coordinates. This follows by choosing dual bases for the nondegenerate crossing pairing, completing the joint radical and these symplectic pairs to a full symplectic basis. A work wire not used by the spans can be kept in one fixed computational basis. The two physical measurement bases differ only by H on s core coordinates, with fixed Pauli signs absorbed into phase tables. In both bases, I has the same computational joint-sector label.

In the A-adapted basis the support of the entries A_{u,v} equals the affine support of K_A. Its nonzero entries all have magnitude 2^{-h_A/2} where h_A is the usual parity-rank parameter of a Clifford matrix. For a one-band diagonality table E_A, the phases of A_{u,v} further include the difference of the signed sums of affine parities at u,v, evaluated modulo eight. The stabilizer K_A contributes an eighth-root prefactor times i to an integer linear form and minus one to a binary quadratic on an affine parametrization of the support. The same statements hold for B,K_B,E_B in their B-adapted basis with h_B. K_A and K_B are actual native Hermitian Clifford endpoints, with their global phases fixed to eighth roots as in R75. Orientation can be chosen so h_A≥h_B. Switching A and B replaces W by W† and preserves I, s, γ and the valuation v(1−λ).

In the A-adapted basis pick, for every central label z, a pair of input/output strings v(z),u(z) with A_{u(z),v(z)} nonzero, and with input in sector z. They may both be chosen affine in z: the support is an affine relation whose projection on the input I coordinates is surjective by unitarity. A surjective affine map between binary affine spaces has an affine section. Let a(z) denote the unit-modulus phase of that selected entry. From B=A W†, the ratio B_{u(z),v(z)}/A_{u(z),v(z)} equals the conjugate of λ(z). We continue writing λ for that ratio; all comparisons also apply to its conjugate.

Write the selected entries of B in the A frame by the two Hadamard basis changes on the core. A term is indexed by the two old s-bit core labels, so its basis-change magnitude is 2^{-s}. All nonzero terms come from the Clifford support of K_B. The permissible pairs of core labels and central z form an affine relation, and for every z at least one term exists since the exact ratio is a unit. Choose an affine right inverse for this relation and parametrize every nonzero term by
$$
 (z,t)\longmapsto (z,b_0+Bz+C t)
$$
with t ranging over a fixed binary space. The dimension of t need not be estimated. The Hadamard signs are binary quadratics in the joint affine labels. Dividing by the selected A entry gives
$$
 \lambda(z)=2^{-b}\sum_t\Phi_t(z),\qquad b=s+(h_B-h_A)/2\le s .
$$
Each Φ_t is an eighth root given by a fixed prefactor, the native signed sum of affine parities, and the signed Clifford/Hadamard phase factors just described. Every native affine argument depends jointly affinely on z,t. This common parametrization is essential when z varies and t is changed.

## Two divisibility estimates

Let Q be any affine k-cube of central labels. Take Φ₀ as the phase of the free path t=0. For each permitted t, the ratio Φ_t(z)/Φ₀(z) is i to a quadratic polynomial modulo four with all mixed quadratic coefficients even. Indeed changing t only flips constants in all native affine parities. For an affine bit ℓ(z), replacing it by its complement changes the exponent by 1−2ℓ(z). Thus its relative phase is a fixed eighth root times i^{±ℓ(z)}. Ratios of the quadratic Hadamard or Clifford signs give affine signs, since the two arguments differ by a constant; even an uncancelled quadratic sign would still be of the required Z₄ form. Individual terms may retain constant eighth-root factors; these have valuation zero. Affine restriction to Q preserves the form.

For such a Z₄ quadratic, the sum of its i-valued phases over Q either vanishes or has valuation at least k/2. To prove this, square the complex magnitude and sum over the difference variable. Inner character sums vanish except on the radical of its binary polar. The remaining phase on that radical is a character, so the squared magnitude is zero or 2^{k+dim rad}. Complex conjugation preserves the unique two-adic valuation in the eighth cyclotomic field. The triangle inequality for that valuation gives
$$
 v\left(\sum_{z\in Q}\lambda(z)/\Phi_0(z)\right)\ge k/2-b\ge k/2-s .
$$

In contrast Φ₀^{-1} may contain genuine eighth-root linear parity phases. Its sum nevertheless has valuation at least k/4, with **no path denominator**. Expand each factor ω^{cℓ} as 1+(ω^c−1)ℓ. A nontrivial coefficient costs valuation at least 1/4 per binary affine constraint. A quadratic stabilizer sign gives the factor 1−2ℓ₁ℓ₂ and costs valuation 1 for at most two constraints. The sum of a product of constraints over a k-cube is zero or 2^{k−rank}. A term with n constraints contributes valuation at least n/4+max(k−n,0)≥k/4. Constants have zero valuation. This proves the second estimate for the actual native/stabilizer phase tables.

## Isolating one exceptional sector

Let S be the nonempty set of exceptional sectors. Since |S|≤2^{r−k}, necessarily r≥k. For any z₀ in S choose a random affine k-plane through z₀ uniformly in F₂^r. Its expected number of *other* exceptional points is
$$
 (2^k-1)(|S|-1)/(2^r-1)<1.
$$
Therefore there exists a k-cube meeting S precisely at z₀. On this cube the sums of Φ₀^{-1} and λ/Φ₀ differ by one term, of valuation v(1−λ(z₀))≤1. For k≥5 the first sum has valuation k/4>1 or greater. Hence the second sum must have exactly that exceptional valuation. Comparing with k/2−b proves the bound, in fact with b on the left. This uses neither an upper bound on the size of the central space nor a bound on the degree of the original Boolean readout. The rank of crossing directions, as opposed to the dimension of the whole supplemental span, is the quantity charged.

A corollary for general normalized four-band overlaps is available once R75 centralizes W. If unequal A,B have crossing rank s, their central exceptional mass is strictly greater than 2^{-max(5,2s+3)}; otherwise choose the integer k=max(5,2s+3) in the proved statement. Thus the real normalized overlap has loss at least the smaller of δ/4 and (1−1/√2)2^{-max(5,2s+3)}, where δ=(1−1/√2)/2 is R75's one-phase gap. The first branch covers spectra outside R75's near-one region. This is a zero-clean crossing-rank-dependent estimate, not a width-independent four-band scalar gap.

## Another reduction when the exceptional pattern has no translation period

Assume that e is below δ/32, which holds at k≥8 for a single marked input address. For every Hermitian Pauli H, the two new Hermitian involutions A_H=AHA and B_H=BHB again have the form E_A C_A E_A† and E_B C_B E_B† with Hermitian Clifford cores. Indeed E_A† H E_A is Clifford, and conjugating it by K_A remains Clifford. Also ||A_H−B_H||₂≤2||A−B||₂, so their normalized overlap exceeds 1−δ/4. The proof of the R75 commutant reduction applies to arbitrary Hermitian Clifford cores in this form. It gives
$$
 B_H A_H=B (HWH W^*) B\ \in\ \operatorname{span}\{P_b:b\in I\}.
$$
All central eigensector translations are realized by Paulis H. Consequently conjugation by B sends every function z ↦ λ(z+t)/λ(z) into the diagonal I algebra, for all t. If two labels z,z′ have identical values for all these functions, λ(u+z+z′)=cλ(u) at every u. Since λ is one on more than half the labels, c=1. Thus when λ has no nonzero ordinary translation period, these derivative functions separate all sector labels and generate the full diagonal I algebra. Conjugation by B maps that algebra onto itself, and so does A=B W. The middle phase layers commute with all I Paulis, so their fixed Clifford cores K_A,K_B likewise normalize precisely this algebra. Each therefore acts on its eigensector labels by an affine binary permutation, and the two permutations agree. In particular this reduction holds whenever r=k gives one exceptional sector. It does not by itself eliminate that case.
