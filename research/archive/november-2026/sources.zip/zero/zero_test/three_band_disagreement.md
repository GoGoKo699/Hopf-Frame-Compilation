# A sharp error gap for reading one bit through three native T layers

Let $R$ be a zero-clean native Clifford+T word with at most three T layers and arbitrary Clifford intervals. All additional work inputs may have any dimension. Let $P,Q$ be Hermitian Pauli observables at the input and output, respectively, and put
$$
 e=\tfrac12\left(1-\operatorname{Tr}(QRP R^\dagger)/D\right),
$$
where $D$ is the physical Hilbert dimension. The coefficient is real. For computational bit observables, $e$ equals the uniform-input mean probability that the output bit disagrees with the input bit, with the other output wires left unrestricted. The input may be an affine parity tested by a Pauli with sign, and the output may be another. The following alternative is sharp:
$$
 QR=RP\qquad\text{or}\qquad e\ge\frac{1-1/\sqrt2}{4}=0.0732233047\ldots .
$$
Consequently a word that leaves an arbitrary computational bit correctly untouched outside a single $k$-bit address cannot flip it with even positive amplitude on that address when $k\ge4$. This permits arbitrary coherent garbage and arbitrary final address motion. Constant uniform initialization would change the measured fraction of the physical Hilbert space and requires its own argument. If disagreement on the other addresses is only approximately zero, the same gap still applies to their contribution to the displayed uniform average.

Split $R=ABC$ into three one-band words with Clifford boundaries. Then $E=A^\dagger Q A$ and $F=C P C^\dagger$ are Hermitian Cliffords. Strip the two boundary Cliffords from the middle $B$ into $E,F$ so its remaining action is a literal tensor product of T, S, their inverses, and identities; its S factors can likewise be absorbed into the Cliffords. The target correlation equals
$$
 \operatorname{Tr}(E B F B^\dagger)/D
  =\langle\!\langle E|(B\otimes\overline B)|F\rangle\!\rangle ,
$$
using normalized vectorizations in a conventional ordering of the two physical copies. Both vectors are stabilizer states, with affine computational supports and flat magnitudes there. Their global phases are the physical phases of Hermitian Pauli transports. They can be chosen as eighth-root phases multiplying the usual fourth-root stabilizer amplitudes: on each native one-band Pauli transport a T-conjugated single Pauli is an eighth-root scalar times a native Clifford. Conjugation by the other fixed Clifford frames preserves this property.

If the two affine supports are distinct, the normalized size of their intersection is at most $1/\sqrt2$. The middle operation is diagonal, so this bounds the whole correlation. If the supports agree, use affine binary parameters $w$ for their common sites. The correlation is a uniform mean of $e^{\pi i p(w)/4}$. Here $p$ is a fixed eighth-root exponent, the sum of the signed affine parities defining the T/T-dagger actions, and the difference of the two stabilizer-state phase exponents. The latter exponents are twice an integer linear form plus four times a binary quadratic in the affine parameters. Expanding a parity in binary variables modulo eight, its degree-two coefficients are divisible by two, its degree-three coefficients by four, and all higher coefficients vanish. These same divisibility conclusions hold for $p$.

If $p$ takes an odd value, its parity is affine and is odd on at least half the support. On those sites the cosine of its phase is at most $1/\sqrt2$. Thus the real mean is at most $(1+1/\sqrt2)/2$. If all phases are even, then $p/2\bmod2$ is a degree-two Boolean polynomial. Whenever nonzero it is one on at least a quarter of the support, with cosine zero there. If all phases are divisible by four, $p/4\bmod2$ has degree at most three, so the phase is $-1$ on at least an eighth whenever it occurs. The latter two cases give real mean at most $3/4$. The binary minimum weight used here follows by choosing a top-degree monomial and summing the Boolean polynomial on its associated coordinate cube while holding other coordinates fixed. If no exceptional phase occurs, the mean is exactly one; the normalized equality of the two unit vectors then yields $E=B F B^\dagger$ and $QR=RP$.

## Sharpness with three qubits and three physical bands

Use computational bits $z_1,z_2,z_3$ and parities $\ell_1=z_1+z_3$, $\ell_2=z_2+z_3$, $\ell_3=z_1+z_2+z_3$ over the binary field. The diagonal $D_0=\operatorname{diag}(\omega^{\ell_1+\ell_2-\ell_3})$, $\omega=e^{i\pi/4}$, uses a single actual T layer because the three parities are an invertible linear coordinate system. Direct subtraction of the integer exponents when flipping $z_3$ gives $1-2z_3+4z_1 z_2\bmod 8$. Thus $D_0 X_3 D_0^\dagger=\mathrm{CZ}_{12}\otimes J_3$ where $J|t\rangle=\omega^{1-2t}|1-t\rangle$ is Hermitian and unitary. Put $V=H_2D_0H_2$ and $R=H_3 V^\dagger T_2 V H_3$. For the input and output Pauli $Z_3$ the two end factors produce $E=F=\mathrm{CNOT}_{1\to2}\otimes J_3$. The spectator $J_3$ cancels in $E T_2 F T_2^\dagger$, leaving the phases $\omega^{(z_1\oplus z_2)-z_2}$. These are one on half the volume, $\omega$ on one quarter and $\omega^{-1}$ on one quarter. The bit-disagreement probability is exactly the claimed threshold.
