# Exact search with one private spin and a read-only address

The model has one physical work qubit, serving as the monitored bit. Clifford couplings may read shared computational address bits, and T gates act on the private spin. For each fixed address an address-preserving Clifford interval is a fixed spin Clifford preceded by a Pauli whose labels depend linearly on the address, up to an address phase. In a measured Pauli conjugation that scalar disappears. Moving the spin Cliffords and Paulis to the boundaries leaves d rotations by signed π/4 angles on the Bloch sphere about fixed Pauli axes. Their sign functions are affine in the address, as is the final expectation sign. We allow arbitrary affine functions, including ones that might not be simultaneously needed in a given circuit. Start at +Z by Clifford covariance, and try each of the three output axes. The model uses no spectator work or initialized inputs.

The d rotation signs and one output-sign bit form a point of a (d+1)-dimensional binary space. At a point, a nonzero probability of changing the monitored bit means its signed Bloch overlap is strictly less than one. An affine address parameterization with exactly one exceptional k-bit address must map injectively into the sign space. Each fiber of a noninjective map has even cardinality. Thus it suffices to enumerate every affine k-flat and test whether it contains exactly one exceptional point. RREF enumerates all such flats. Bloch coordinates are pairs of ordinary integers representing a numerator in Z[√2] with denominator (√2)^d. The equality comparisons are exact.

| Native bands | Axis words and output axes | Affine flats per word, all positive dimensions | Largest dimension with a singleton |
|---:|---:|---:|---:|
| 1 | 9 | 7 | 1 |
| 2 | 27 | 43 | 1 |
| 3 | 81 | 291 | 1 |
| 4 | 243 | 2,419 | 2 |
| 5 | 729 | 26,323 | 2 |

For four bands there are 128 distinct axis/flat cases with a singleton on a two-dimensional flat. For five bands there are 2,048. No three-dimensional singleton appears. A dimension result here describes the searched affine-sign representation; its absence excludes that entire one-spin model. The analytic three-band gap elsewhere permits arbitrarily many dirty qubits and arbitrary address motion.
