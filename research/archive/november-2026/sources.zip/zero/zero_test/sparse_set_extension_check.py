"""Finite checks of the sparse difference-support proposal."""
from itertools import product
from functools import reduce
from operator import xor
import numpy as np

rng = np.random.default_rng(442)

def mul(a,b,k,poly):
    r=0
    for _ in range(k):
        if b&1:
            r ^= a
        b >>= 1
        a <<= 1
        if a >> k: a ^= poly
    return r

def combinatorics():
    tested=0
    for k,poly in [(3,11),(4,19),(5,37)]:
        m=2**k
        for _ in range(10):
            S=set(map(int,rng.choice(m,size=2,replace=False)))
            G={min(S)}
            dif={s^t for s in S for t in S}
            lam=next(l for l in range(1,m)
                     if not any(u and mul(l,u,k,poly) in dif for u in dif))
            assert all(u==0 or u not in dif or mul(lam,u,k,poly) not in dif
                       for u in range(m))
            lanes=max(1,m//(4*len(S)))
            origins=rng.integers(m,size=lanes)
            count=0
            for a,b in product(range(m),repeat=2):
                t=[int(z)^mul(a,i,k,poly)^b for i,z in enumerate(origins)]
                count+=sum(x in G for x in t)==1 and sum(x in S for x in t)==1
            expected=lanes*len(G)/m*(1-(lanes-1)*len(S)/m)
            assert count/m**2 >= expected-1e-12
            tested+=1
    return tested

def random_unitary(n):
    q,r=np.linalg.qr(rng.normal(size=(n,n))+1j*rng.normal(size=(n,n)))
    return q*(np.diag(r)/np.abs(np.diag(r)))

def quantum_disjoint():
    m=8; S={0,1,4}; local=random_unitary(2*len(S))
    # Raw oracles can mix all addresses within their active support.
    def op(s,target):
        u=np.eye(m*4,dtype=complex)
        for b in range(2):
            ids=[]
            for x in sorted(S):
                for a in range(2):
                    ids.append((x^s)*4+ (2*a+b if target==0 else 2*b+a))
            u[np.ix_(ids,ids)]=local
        return u
    j=op(0,0)
    c=np.diag([1-2*(i%4==3) for i in range(m*4)])
    n=0
    for delta in range(m):
        if S & {x^delta for x in S}:continue
        k=op(delta,1)
        cj=c@j@c
        out=k.conj().T@cj.conj().T@k@cj
        np.testing.assert_allclose(out,np.eye(4*m),atol=1e-12)
        n+=1
    return n

def block_inequality():
    for _ in range(100):
        g=np.diag([1,1,0,0])
        s=1-2*g.diagonal()
        q=random_unitary(4)
        t=rng.uniform(0,.15)
        v=np.eye(4)+np.outer(q[:,0],q[:,0].conj())*(np.exp(1j*t)-1)
        r=v.conj().T@np.diag(s)@v
        eps=np.linalg.norm((r+np.eye(4))@g,2)
        comp=np.eye(4)-2*g+3*eps*np.eye(4)-r
        assert min(np.linalg.eigvalsh(comp))>=-1e-12
    return 100

if __name__=='__main__':
    print(combinatorics(),'affine finite-field collision and dilation checks')
    print(quantum_disjoint(),'completed disjoint-support quantum address-mixing echoes')
    print(block_inequality(),'unfavorable-branch Hermitian vote bounds')
