"""Exact cube valuations and explicit two-basis Clifford/Hadamard sections."""
from functools import reduce
from random import Random
import numpy as np


def parity(n):
    return n.bit_count() & 1


def phase_sum_valuation(exponents):
    # Valuation above 2 normalized here by v(1-omega)=1 (v(2)=4).
    a=[0]*4
    for e in exponents:
        e%=8
        a[e%4]+=1 if e<4 else -1
    if not any(a):
        return 10**9
    v=0
    while sum(a)%2==0:
        b=(a[0]-a[1]-a[2]-a[3])//2
        a=[b,b+a[1],b+sum(a[1:3]),b+sum(a[1:])]
        v+=1
    return v


def random_joint_phases():
    rng=Random(523)
    cases=0
    for k in range(2,9):
        tdim=3
        N=k+tdim
        for _ in range(12):
            def sample():
                return rng.randrange(1<<N), rng.randrange(2)
            def bit(term, v):
                return parity(term[0]&v)^term[1]
            first=[(rng.randrange(8),sample()) for _ in range(2*k+4)]
            sign_pairs=[(sample(),sample()) for _ in range(k+2)]
            def exp_at(z,t):
                v=z | (t<<k)
                return (sum(c*bit(a,v) for c,a in first)
                        +4*sum(bit(a,v)*bit(b,v) for a,b in sign_pairs))%8
            ref=[exp_at(z,0) for z in range(1<<k)]
            assert phase_sum_valuation(ref)>=k
            for t in range(1<<tdim):
                norm=[exp_at(z,t)-ref[z] for z in range(1<<k)]
                assert all((e-norm[0])%2==0 for e in norm)
                assert phase_sum_valuation(norm)>=2*k
                cases+=1
    return cases


def adapted_bases():
    rng=Random(7001)
    omega=np.exp(1j*np.pi/4)
    checked=0
    for s in range(1,4):
        n=1<<s
        H=np.asarray([[(-1)**parity(x&y) for x in range(n)] for y in range(n)])/np.sqrt(n)
        for _ in range(8):
            k=3
            xflip=rng.randrange(n)
            zsign=rng.randrange(n)
            M=np.zeros((n,n),complex)
            for v in range(n):
                M[v^xflip,v]=(1j**((zsign & xflip).bit_count()))*(-1)**parity(v&zsign)
            # The middle axes can use c-dependent signs; these are actual
            # isotropic work parity phases on centre and active coordinates.
            exA=[(1<<i,rng.randrange(1<<k),rng.choice([-1,1])) for i in range(s)]
            exB=[(1<<i,rng.randrange(1<<k),rng.choice([-1,1])) for i in range(s)]
            for z in range(1<<k):
                eig=lambda ex, y: sum(sg*(parity(z & c)^parity(y & p)) for p,c,sg in ex)
                eA=np.diag([omega**eig(exA,y) for y in range(n)])
                eB=np.diag([omega**eig(exB,y) for y in range(n)])
                scalar=(-1)**((z&1)*((z>>1)&1))
                KA=eA.conj().T@M@eA
                KB=eB.conj().T@(H@M@H)@eB*scalar
                A=eA@KA@eA.conj().T
                B=H@eB@KB@eB.conj().T@H
                np.testing.assert_allclose(A@B,scalar*np.eye(n),atol=1e-12)
                for v in range(n):
                    u=v^xflip
                    terms=[H[u,a]*eB[a,a]*KB[a,b]*eB[b,b].conjugate()*H[b,v] for a in range(n) for b in range(n)]
                    np.testing.assert_allclose(sum(terms)/A[u,v],scalar,atol=1e-12)
                    checked+=1
    return checked


def cube_isolation():
    # Verify all exceptional-set sizes and marked points for every 3-bit set.
    n=8
    all_cubes={1:{frozenset((a,b)) for a in range(n) for b in range(a+1,n)}}
    all_cubes[2]={frozenset((x,x^a,x^b,x^a^b)) for x in range(n)
                  for a in range(1,n) for b in range(a+1,n)}
    all_cubes[3]={frozenset(range(n))}
    checked=0
    for mask in range(1,1<<n):
        S={x for x in range(n) if mask >> x & 1}
        for k,planes in all_cubes.items():
            if len(S)*(1<<k)>n:
                continue
            for x in S:
                assert any(Q & S == {x} for Q in planes)
                checked+=1
    return checked


if __name__=='__main__':
    print(random_joint_phases(), 'exact relative-path quadratic valuations and common-phase bounds')
    print(adapted_bases(), 'explicit Clifford endpoint / Hadamard matrix section ratios')
    print(cube_isolation(), 'all admissible 3-bit set-point isolations')
