"""Exhaustive four-band, one-private-spin read-only address search.

A spin Bloch coordinate is represented in Z[sqrt(2)] divided by (sqrt(2))^j
after j T rotations. No floating point is used by the decision procedure.
"""
from itertools import product
from collections import Counter


def plane_families(bits, dimension):
    # RREF generating matrices yield every linear subspace exactly once.
    from itertools import combinations
    for pivots in combinations(range(bits),dimension):
        variable=[(r,c) for r,p in enumerate(pivots) for c in range(p+1,bits) if c not in pivots]
        for flags in range(1<<len(variable)):
            rows=[1<<p for p in pivots]
            for i,(r,c) in enumerate(variable):
                rows[r] |= ((flags>>i)&1)<<c
            space=[0]
            for row in rows:
                space += [p^row for p in space]
            remaining=set(range(1<<bits))
            while remaining:
                a=min(remaining)
                coset={a^s for s in space}
                remaining.difference_update(coset)
                yield sum(1<<p for p in coset)


def add(a,b,sign):
    return (a[0]+sign*b[0],a[1]+sign*b[1])


def final_bloch(axes,mask):
    v=[(0,0),(0,0),(1,0)]
    for j,axis in enumerate(axes):
        u=(axis+1)%3
        w=(axis+2)%3
        sign=1-2*((mask>>j)&1)
        # cos(pi/4)=sin(pi/4)=1/sqrt(2); common denominator increments.
        v[u],v[w]=add(v[u],v[w],-sign),add(v[w],v[u],sign)
        a,b=v[axis]
        v[axis]=(2*b,a)
    return tuple(v)


def max_singleton(d):
    bits=d+1
    planes={r:list(plane_families(bits,r)) for r in range(1,bits+1)}
    counts=Counter()
    best={}
    nwords=0
    for axes in product(range(3),repeat=d):
        source=[final_bloch(axes,mask) for mask in range(1<<d)]
        denom=(1<<(d//2),0) if d%2==0 else (0,1<<(d//2))
        for out_axis in range(3):
            leaking=0
            for sign in range(2):
                wanted=tuple((1-2*sign)*a for a in denom)
                for mask,v in enumerate(source):
                    if v[out_axis]!=wanted:
                        leaking |=1<<(mask+(sign<<d))
            for rank,cosets in planes.items():
                for cs in cosets:
                    if (leaking&cs).bit_count()==1:
                        counts[rank]+=1
                        best.setdefault(rank,(axes,out_axis,cs,leaking&cs))
            nwords+=1
    return nwords,counts,best, {r:len(p) for r,p in planes.items()}


if __name__=='__main__':
    for d in range(1,6):
        n,counts,witnesses,sizes=max_singleton(d)
        print('bands',d,'axis words and output frames',n,'affine planes per word',sum(sizes.values()),
              'singleton planes by dimension',sorted(counts.items()))
        rank=max(witnesses,default=0)
        assert rank == (1,1,1,2,2)[d-1]
        if rank:
            print('largest witness',rank,witnesses[rank])
