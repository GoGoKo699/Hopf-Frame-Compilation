"""Private address tests, complete commutator echo, and affine scatter identities."""
from itertools import product, combinations
from random import Random
import numpy as np


def field_mul(left, right, k, modulus):
    answer = 0
    while right:
        if right & 1:
            answer ^= left
        right >>= 1
        left <<= 1
        if left & (1 << k):
            left ^= modulus
    return answer


def check_hits():
    rng = Random(6043)
    cases = 0
    for k, modulus in [(2,7), (3,11), (4,19), (5,37)]:
        m = 1 << k
        count = m // 4
        base = [[field_mul(a,t,k,modulus) for t in range(count)] for a in range(m)]
        for _ in range(6):
            origins = [rng.randrange(m) for _ in range(count)]
            hist = [0] * (count + 1)
            for a,b in product(range(m),repeat=2):
                hits = sum(origin ^ offset == b for origin,offset in zip(origins,base[a]))
                hist[hits] += 1
            assert sum(h*n for h,n in enumerate(hist)) == count*m
            assert sum(h*(h-1)*n for h,n in enumerate(hist)) == count*(count-1)
            assert 16*hist[1] >= 3*m*m
            cases += m*m
    return cases


def check_literal_gates():
    rng = Random(5939)
    number = 0
    for k in range(1,5):
        m=1 << k
        for x,a in product(range(m),repeat=2):
            for _ in range(4):
                origin=rng.randrange(m)
                seed=rng.randrange(m)
                w=origin ^ seed
                j,kval = int(w==0), int(w^x^a==0)
                for p,q,b in product(range(2),repeat=3):
                    initial=(p,q,b)
                    for op in ('j','k','j','k'):
                        b ^= p&q
                        if op=='j':
                            p ^= j
                        else:
                            q ^= kval
                    assert (p,q)==initial[:2]
                    assert b==initial[2]^int(a==x and origin==seed)
                    number+=1
    return number


def dense_unitary(rng,n):
    mat=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n))
    q,r=np.linalg.qr(mat)
    return q * np.exp(-1j*np.angle(r.diagonal()))


def check_garbage():
    # Scramble address and all private data after the output, within each
    # final target sector. The raw zero-row target has small coherent error.
    rng=np.random.default_rng(798)
    wcount=4
    I=np.eye(2*wcount)
    z=np.diag([(-1)**(i%2) for i in range(2*wcount)])
    trials=0
    for angle in (0.0,0.002,0.031,0.11):
        first=I.copy()
        first[:2,:2]=[[np.sin(angle), np.cos(angle)],[np.cos(angle),-np.sin(angle)]]
        scrambling=np.zeros_like(I,dtype=complex)
        for bit in range(2):
            scrambling[bit::2,bit::2]=dense_unitary(rng,wcount)
        raw=scrambling @ first
        echo=raw.conj().T @ z @ raw @ z
        np.testing.assert_allclose(echo[:,2:], I[:,2:],atol=1e-12)
        assert np.linalg.norm(echo[:2,:2]+np.eye(2),2) <= 2*np.sin(angle)+1e-10
        trials+=len(I)
    return trials


def check_quantum_silence():
    rng=np.random.default_rng(214)
    ident=np.eye(2)
    exact_cz=np.diag([1,1,1,-1])
    actual=[]
    for same in (False,True):
        for hit in (False,True):
            for _ in range(8):
                j=dense_unitary(rng,2) if hit else ident
                k=dense_unitary(rng,2) if (hit==same) else ident
                J=np.kron(j,ident)
                K=np.kron(ident,k)
                echo=np.eye(4)
                for op in [exact_cz,J,exact_cz,K,exact_cz,J.conj().T,exact_cz,K.conj().T]:
                    echo=op@echo
                if not (same and hit):
                    np.testing.assert_allclose(echo,np.eye(4),atol=1e-12)
                actual.append(echo.shape[0])
    return sum(actual)


if __name__ == '__main__':
    print('Finite-field pairwise masks:',check_hits())
    print('Complete dirty four-corner words:',check_literal_gates())
    print('Raw moving-address columns:',check_garbage())
    print('Conditional unitary echo columns:',check_quantum_silence())
