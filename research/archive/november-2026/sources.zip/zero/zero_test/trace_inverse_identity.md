# A linear-arity multiple-control gate inside the reciprocal trace

Let $F=\mathbb F_{2^s}$, let $\mathrm{Tr}$ be its absolute trace, and take $H=\ker\mathrm{Tr}$. Define $J(0)=0$, $J(u)=u^{-1}$ otherwise. Fix any $d$ with $\mathrm{Tr}(d)=1$. The proposed primitive adds
$$
g_d(u)=\mathrm{Tr}(dJ(u)),\qquad u\in H,
$$
to a target bit and returns all its arbitrary work. The address is physically shareable. More precisely, its operations on address bits consist of stable computational controls for Clifford operations on the private wires, and every affine substitution for these controls can be compiled as elementary Cliffords. Any phases depending on the shared address must be preserved or actually undone. The case $H=\ker\mathrm{Tr}(c\,\cdot)$ follows on substituting $u=cz$, with $d$ replaced by the trace-one element $cd$.

## Three calls suffice on a large linear domain

For $a\in H$ with $g_d(a)=1$, set $T_a(x)=x+x^2/a$. Such a nonzero $a$ exists because the trace inverse bit on $H$ has odd weight and vanishes at zero. Equivalently the sum of the reciprocals in $H^\times$ is one, as follows from the first two coefficients of $\mathrm{Tr}(X)/X$. At $x\ne0,a$ use $J(x)+J(x+a)=J(T_a(x))$. At either pole the difference is $J(a)$. Hence on the legal address subspace $W=H\cap T_a^{-1}(H)$,
$$
 g_d(x)+g_d(x+a)+g_d(T_a(x))=[x\in\{0,a\}].
$$
There are at most two independent binary linear constraints defining $W$ and it contains $a$. On any complement of the line $\langle a\rangle$ within $W$, this is a zero test on at least $s-3$ bits. If $s$ is even, take $a=1$. The whole $H$ is legal, since $1\in H$ and $T_1$ always lands in $H$. The test has $s-2$ control bits. Three serial source XORs act directly on a common arbitrary target, have depth at most $3D$ and accumulate at most $3\epsilon$ full-operator error. Three parallel copies on arbitrary private targets, CNOT parity into the final output, actual parallel uncomputation, and one more parity cost at most $2D$, six source occurrences, six CNOTs and $6\epsilon$ propagated error.

For even $s$, two calls already give a zero test on at least $s/2-2$ bits. Let $K=\mathbb F_{2^{s/2}}$ and restrict to $W'=H\cap T_1^{-1}(dK)$. On every point $T_1(x)$ of this space the third evaluation is zero, since $dJ(T_1(x))$ is in $K$, which has identically zero absolute trace from $F$. This includes $T_1(x)=0$. The image of $T_1|_H$ has binary dimension $s-2$, its intersection with $dK$ has dimension at least $s/2-2$, and the kernel has dimension one. Thus $W'$ has dimension at least $s/2-1$. Take a complement to $\langle 1\rangle$ inside $W'$. The returned result is simply $g_d(x)+g_d(x+1)=[x=0]$. The bound is of interest for $s\ge 6$.

## A cancellation identity

Take two distinct points $b,c\in F$, write $t=b+c$, $v=(x+b)/t$ and $u=v^2+v$. The map $x\mapsto u$ is affine over $\mathbb F_2$ and lands in $H$. With $F_a(x)=\mathrm{Tr}(aJ(x))$, this yields
$$
g_d(u)=F_{dt}(x+b)+F_{dt}(x+c)+[x=b]+[x=c].
$$
Away from the poles this is the ordinary partial fraction identity $1/(v^2+v)=1/v+1/(v+1)$. At either pole the left side is zero, the right side before the correction is $\mathrm{Tr}(d)=1$, and exactly one correction is active.

Now take any two-dimensional binary affine plane $P\subseteq F$. Evaluate that identity on the six edges of the complete graph on its four points and XOR. At every vertex the three incident edge differences are the three nonzero directions in a binary plane. They sum to zero, so the linear-in-coefficient rational terms cancel at every pole. The vertex corrections occur three times each. Consequently
$$
\bigoplus_{\{b,c\}\subset P}
  g_d\!\left(\left(\frac{x+b}{b+c}\right)^2+\frac{x+b}{b+c}\right)=[x\in P].
$$
If $P$ is linear and $x$ is restricted to a binary complementary subspace, this is the exact all-zero test on $s-2$ address bits. An affine shift of these bits converts it to AND.

There is also a direct geometrical optimality statement for this particular cancellation. Build any simple edge graph with the same $d$, taking each pole pair at most once, and require all formal rational residues at participating vertices to cancel. Each used vertex has degree at least three, since all differences incident to it are distinct nonzero elements. A nonempty such graph needs at least four vertices and six edges. At six edges the graph is necessarily the complete graph on four vertices. Its residue equations say exactly that the four vertex labels sum to zero, equivalently they form an affine plane. This minimum applies to cancellation of the formal coefficients in this particular two-pole identity. Other physical constructions, restricted-domain polynomial coincidences, and Frobenius-dependent trace coefficients need not obey it.

## Actual depth, width and tolerance

Use six separate dirty targets $b_i$ and private helpers. Execute the six shifted source circuits in parallel, XOR all six $b_i$ into the desired target, apply the physical inverses in parallel, then repeat the six CNOTs. The arbitrary initial $b_i$ cancel. If one physical source has T-depth $D$, these resource-safe operations take at most $2D$ and 12 total sources or inverses. An alternative runs the six returned XORs serially on the same final target, with six visits and depth at most $6D$. Their error is at most twelve or six times the requested source error, respectively, by the unitary hybrid bound. No clean qubits are introduced in either construction. The affine address substitutions are compile-time linear maps, so the total T cost and dirty width change by constant factors. Literal elementary Clifford count may increase by a factor polynomial in $s$. Finite tests cover every input to examples over seven field degrees. The depth multiplier changes neither a constant nor a sublogarithmic asymptotic order.

## Full binary field inversion from the same query

The following stronger equivalence holds whenever $d$ is normal, so that its Frobenius conjugates form a binary basis of $F$. For $z\in H$ one can query $g_d(z^{2^j})$ for all $0\le j<s$ simultaneously with private arbitrary targets. The results are the pairings of $J(z)$ with the basis formed by inverse Frobenius conjugates of $d$, because the absolute trace is Frobenius invariant. The trace pairing is nondegenerate. An invertible fixed binary transformation therefore recovers the complete $s$-bit $J(z)$. In the case $\mathrm{Tr}(d)=1$ and $s$ a power of two, normality is automatic. Indeed with $\Phi:z\mapsto z^2$ one has $(\Phi+I)^s=0$ and $(\Phi+I)^{s-1}d=\sum_{j=0}^{s-1}\Phi^j(d)=1$. The successive iterates under $\Phi+I$ are linearly independent by their distinct chain heights, and span the same space as the Frobenius conjugates. This sequence of field degrees doubles, so testing it covers input sizes within constant factors. For general $s$ one can choose normal $d$ in the experiment using the normal basis theorem. Every normal element has trace one, since its conjugate basis is independent.

To recover $J(x)$ on the full field, for two distinct nonzero constants $t_0,t_1$ form
$$
z_t=(x/t)^2+x/t\in H,\qquad h_t(x)=(x/t+1)J(z_t)/t .
$$
Then $h_t(x)=J(x)$ except possibly at $x=t$, where $h_t(t)=0$. At $x=0$, both are zero. A fixed affine bit $\ell(x)$ distinguishing the two exceptional points chooses the other chart at each. The entire computation uses only parallel affine substitutions of the original address, returned additions of the $J(z_t)$, a bilinear multiplication with the original stable input, and a one-bit multiplexer. Formally the postprocessing adds to the output a fixed function linear in the two $J(z_t)$ with coefficients of binary degree at most two in $x$. On arbitrary banks containing dirty offsets, apply this controlled linear update, translate those banks by the parallel scalar results, apply the update again and actually undo the translation. The original dirty values cancel. In a Fourier basis on the output the update is a parity of polynomially many terms of degree at most four. Implement those in constant T-depth with private returned phase gadgets reading the shared address through Clifford controls, charging every elementary Clifford. Thus it is sufficient to use $2s$ parallel copies in each of two chronological rounds, for a polynomial total T count and width when the local source complexity is polynomial. The aggregate error is bounded by the actual number of source visits times the individual full error. This full-inversion equivalence is an exact statement; constant per-copy tolerance cannot be substituted uniformly in $s$. The six-edge all-zero reduction has a constant error multiplier even as $s$ grows.

Conversely a physically shareable complete inversion XOR on the full field gives the trace bit on $H$ by a fixed linear readout and actual reversal on an arbitrary target. Either direction is compatible with superpositions on all active and external registers. These deductions identify how much polynomial-width reversible computation the proposed trace source already entails. They give neither a native sublogarithmic inverse nor a lower bound in the unrestricted Clifford+T model.
