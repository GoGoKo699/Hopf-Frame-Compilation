"""Small exact finite-difference and full physical boundary-frame checks."""
from functools import reduce
from itertools import product
from operator import xor
from random import Random
from math import sqrt, pi
import numpy as np

rng=Random(721634)

def rank(dirs):
    piv={}
    for v in dirs:
        while v:
            j=v.bit_length()-1
            if j not in piv:
                piv[j]=v
                break
            v ^= piv[j]
    return len(piv)

def dir_derivative(table,x,dirs):
    points=[x]
    for d in dirs:
        points += [y^d for y in points]
    return sum((-1)**j.bit_count()*table[p] for j,p in enumerate(points))

def quartic_test():
    n_ok=0
    q=[int(i==15) for i in range(16)]
    for dirs in product(range(16),repeat=4):
        d=dir_derivative(q,rng.randrange(16),dirs) % 2
        assert d==(rank(dirs)==4)
        n_ok+=d
    assert n_ok==20160
    n_cub=0
    for rep in range(40):
        k=rng.randrange(2,7)
        coefficients=[(rng.randrange(8)*2**max(0,i.bit_count()-1))%8 if i.bit_count()<=3 else 0 for i in range(2**k)]
        vals=[sum(c for mask,c in enumerate(coefficients) if mask&x==mask)%8 for x in range(2**k)]
        for _ in range(100):
            dirs=[rng.randrange(2**k) for _ in range(4)]
            assert dir_derivative(vals,rng.randrange(2**k),dirs)%8==0
            n_cub+=1
    return n_ok,n_cub

def test_paths():
    qubits=5
    n=2**qubits
    ranges=list(range(n))
    had=np.zeros((n,n),dtype=complex)
    def H(i):
        m=had.copy()
        for v in ranges:
            for b in (0,1):
                w=v^(b<<i)
                m[w,v]=(-1)**(((w&v)>>i)&1)/sqrt(2)
        return m
    def cnot(i,j):
        return np.eye(n)[:,[v^(((v>>i)&1)<<j) for v in ranges]]
    def singlephase(i):
        return np.diag([1j if (v>>i)&1 else 1 for v in ranges])
    def cliff():
        acc=np.eye(n,dtype=complex)
        for _ in range(14):
            i,j=rng.sample(range(qubits),2)
            acc=rng.choice([H(i),cnot(i,j),singlephase(i)]) @ acc
        return acc
    tested=0
    supports=0
    for _ in range(30):
        L,R=cliff(),cliff()
        ops=[]
        for j in range(rng.randrange(1,5)):
            terms=[(rng.randrange(1,n),rng.choice([-1,1])) for _ in range(12)]
            phase=np.exp(1j*pi/4*np.array([sum(t*((v&mask).bit_count()%2) for mask,t in terms) for v in ranges]))
            ops += [('d',phase)]
            i,j=rng.sample(range(qubits),2)
            ops += [('c',(i,j)),('h',i)]
        V=R.copy()
        for key,op in ops:
            if key=='h': V=H(op)@V
            if key=='c': V=cnot(*op)@V
            if key=='d': V=op[:,None]*V
        V=L@V
        ans=np.diag(V)
        count=sum(key=='h' for key,op in ops)
        recovered=np.zeros(n,dtype=complex)
        for branch in range(2**count):
            ip=0
            p=np.arange(n)
            v=np.ones(n,dtype=complex)
            for key,op in ops:
                if key=='d': v=v*op[p]
                if key=='c': p=p^(((p>>op[0])&1)<<op[1])
                if key=='h':
                    newp=p^(((branch>>ip)&1)<<op)
                    v=v*(-1)**(((p&newp)>>op)&1)
                    p=newp
                    ip+=1
            for x in range(n):
                # Label x includes logical address, leaf and any fixed private bit.
                vals=L[x,p]*R[:,x]*v
                lsize=(np.abs(L[x,p])>1e-7).sum()
                rsize=(np.abs(R[:,x])>1e-7).sum()
                common=(np.abs(vals)>1e-7).sum()
                assert common<=min(lsize,rsize)
                assert abs(sum(vals))<=common/sqrt(lsize*rsize)+1e-9
                recovered[x]+=sum(vals)/2**(count/2)
                supports+=1
        assert np.linalg.norm(ans-recovered)<1e-9
        tested+=n
    return tested,supports

if __name__=='__main__':
    print('Quartic independent direction matrices and vanishing weighted cubic differences:',quartic_test())
    print('Full diagonal columns and individual affine-path support bounds:',test_paths())

def lagrangian_tests():
    def span(vectors):
        s={0}
        for x in vectors: s|={v^x for v in list(s)}
        return frozenset(s)
    cases=0
    for n in (1,2,3):
        mask=(1<<n)-1
        lags={frozenset([0])}
        for _ in range(n):
            more=set()
            for s in lags:
                for v in range(1,1<<(2*n)):
                    if v not in s and all(( ((v&mask)&(w>>n)).bit_count() + ((w&mask)&(v>>n)).bit_count())%2==0 for w in s):
                        more.add(frozenset(set(s)|{w^v for w in s}))
            lags=more
        lags=list(lags)
        def dim(s): return len(s).bit_length()-1
        for _ in range(20):
            bands=[]
            for j in range(rng.randrange(2,7)):
                L=rng.choice(lags)
                bands.append(span(rng.choices(list(L),k=rng.randrange(1,4))))
            gamma=min(sum(dim(B)-dim(B&M) for B in bands) for M in lags)
            dp={M:0 for M in lags if M>=bands[0]}
            for B in bands[1:]:
                dp={M:min(v+n-dim(prev&M) for prev,v in dp.items()) for M in lags if M>=B}
            assert min(dp.values())<=2*gamma
            cases+=1
    return cases

if __name__=='__main__':
    for t in range(2):
        for x in range(16):
            a,b,c,d=((x>>j)&1 for j in range(4))
            assert ((t*c*d)^((t^a*b)*c*d))==a*b*c*d
    print('Exact quartic dirty echoes and Lagrangian path comparisons:',32,lagrangian_tests())
