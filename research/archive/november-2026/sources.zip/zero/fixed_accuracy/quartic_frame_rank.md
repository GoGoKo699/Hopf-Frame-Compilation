# Linear noncommuting rank for explicit complete frames at fixed accuracy

Let a native decomposition have ordered T bands. Transport all physical T-axis labels to one Pauli coordinate frame through the fixed Clifford intervals alone. Let L_j be the binary span of the axes in band j. Define
$$
 \Gamma_{\rm all}=\min_{\Lambda\ {\rm isotropic}}\sum_j
       [\dim L_j-\dim(L_j\cap\Lambda)] .
$$
Here the sum includes the first and last bands. Size, depth, and the number of borrowed and initialized qubits may be arbitrary. We assume the unitary, nonadaptive native model of the repository.

Write k=n−1 and set f(x) to the sum over F₂ of floor(k/4) disjoint four-bit products on the k prefix coordinates. Choose the upper real Hopf angles zero and at the final level choose θ_x=π f(x). The deepest real canonical domain is [0,2π). In this convention the block is [(cosθ,−sinθ),(sinθ,cosθ)], so each final block is (−1)^{f(x)}I₂. Thus the complete frame is exactly the sign on each prefix, tensored with identity on the final physical bit. Zero incoming node weights at these canonical boundary angles leave the addressed complete-layer product well defined. In the complex magnitude family the same target follows independently by putting zero in every magnitude angle and selecting leaf phases π f(x).

Suppose the emitted V has initialized-isometry error ε<√2 to this target even up to a single global phase, on all logical inputs with complete dirty return. In particular fix the final physical bit and **every** other private bit to zero. For each k-bit x the resulting input |s_x⟩ is its own target output basis vector, with sign (−1)^{f(x)}. Taking the real part after the allowed common phase gives
$$
 \left|{\mathbb E}_x(-1)^{f(x)}\langle s_x|V|s_x\rangle\right|
   \ge 1-\epsilon^2/2 .
$$
If f has disjoint quartic blocks, then every such decomposition obeys
$$
 \Gamma_{\rm all}\ge
 \frac{\lfloor k/4\rfloor}{16}\log_2\!\frac{1}{\,1-2(20160/65536)\,}
   +\log_2(1-\epsilon^2/2).
$$
In particular the necessary rank grows linearly with n at fixed accuracy. This leaves open the depth of a circuit having wide noncommuting bands.

## Diagonalizing the bands

Take an optimal Λ, extend it to a maximal isotropic space, and choose fixed Clifford coordinates putting it in Z. On those coordinates the jth band's X projection has dimension h_j=dim L_j−dim(L_j∩Λ). It can be diagonalized with ≤h_j Hadamards. First a classical invertible linear change places its X-row space on h_j pivot bits, and choose basis rows with one X pivot each. Remaining Z-only rows have no pivot Z by commutation. The pivot rows' Z entries within the pivots form a symmetric matrix, again by commutation. A symmetric phase shear using S and CZ cancels their entire Z content, extending the pivot rows to a symmetric square matrix on all coordinates. Hadamards on these h_j pivots now make every generator Z-only. The axes originally used in the T rotations keep their actual signs and all terms; changing their span basis serves only to find this diagonalizing Clifford.

Absorb the two end basis changes, which may be arbitrarily large, into Clifford factors C_R,C_L. For the remaining changes of basis use the stated circuits, placing both frames at each internal transition. This gives H≤2Σh_j=2Γ_all middle Hadamards among monomial Cliffords and weighted-cubic diagonal phases. A T band in a Z frame produces ζ₈ raised to a sum of signed binary parities. Written as integer multilinear polynomials modulo eight, parity functions have degree-j coefficients divisible by 2^{j−1}, so the resulting phase is weighted cubic. Quadratic Clifford signs and fourth-root linear phases have the same property. Affine substitutions preserve these weighted powers of two and discard terms of degree >3 modulo eight.

## All boundary Cliffords and work widths are included

Expand each of the H middle single-qubit Hadamards by its binary displacement b, so an input bit t goes to t+b with coefficient 2^{-1/2}(−1)^{t(t+b)}. For a fixed path of displacements the middle word is 2^{-H/2} times an affine computational permutation with entries ζ₈^{q(v)} times a constant phase, for a weighted-cubic q of its initial physical coordinate v. The equation for the successive computational labels is affine, including all monomial Cliffords.

For each x, the two endpoint stabilizer states are C_R|s_x⟩ and C_L†|s_x⟩. Each is flat on an affine support with fixed direction and offset affine in x, with a jointly weighted-cubic phase on x and its free coordinates. An explicit way to see the dependence and its global scalar is to transport X(x) through each fixed Clifford from the all-zero input, obtaining a Pauli with affine labels and fourth-root phase of quadratic type. Its action on the fixed zero-input stabilizer wavefunction produces the asserted joint phase, including the relative scalar between different x. The fixed zero-input stabilizer has constant-magnitude amplitudes with quadratic Clifford phases on its affine support. Equivalently one can use the standard affine quadratic form of Clifford matrix elements.

For any fixed middle path, its affine permutation carries the right support to a support having a fixed direction. An intersection with the left support is possible on an affine set S of x. On S the intersection is affine of a fixed dimension t≤min(h_R,h_L), where h_R,h_L are the dimensions of the two support directions. An affine section in x and t free bits u parametrizes it. After summing over the common points the path contributes to the diagonal entry, up to a constant phase,
$$
 2^{-H/2}2^{\,t-(h_L+h_R)/2}\,{\bf1}_{S}(x)\,
             {\mathbb E}_{u}\zeta_8^{P(x,u)} .
$$
The second factor is at most one. P for fixed u is weighted cubic in x and has such an extension to all x by an affine retraction to S; an empty S contributes zero. This step prevents an arbitrary external Clifford or an arbitrary number of auxiliary bits from enlarging a path's norm.

## Quartic correlation

The sign χ=(−1)^f has correlation with any weighted-cubic phase at most its U⁴ norm. Four applications of Cauchy–Schwarz give this bound since the fourth multiplicative derivative of a weighted-cubic phase is one. To verify the latter directly, a monomial of degree j multiplied by 2^{j−1} in a phase modulo eight has additive-difference degree at most three: a difference decreasing ordinary degree loses at least one variable, and each surviving change at the same ordinary degree acquires a factor of two. Equivalently, polarizing an integer parity raises 2-adic divisibility at every extra derivative. The bound also holds multiplied by any affine-support indicator because its Fourier expansion has absolute coefficient sum one (or zero on the empty set). Its linear characters are themselves weighted-cubic phases.

For one quartic monomial on four variables the fourth derivative of its exponent in four independent uniform directions equals their four-by-four determinant over F₂. This follows by distributing four separate differences over the product; all terms using a variable more than once vanish at order four. The probability the determinant is one equals |GL₄(2)|/2^16=20160/65536. Hence its fourth uniformity norm to the sixteenth power is 1−2·20160/65536. Uniformity norms multiply across independent blocks by factorization of their defining expectations. Summing the 2^H path bounds gives
$$
 \left|{\mathbb E}_x\chi(x)\langle s_x|V|s_x\rangle\right|
 \le 2^{H/2}\|\chi\|_{U^4}\le2^{\Gamma_{\rm all}}\|\chi\|_{U^4}.
$$
Combining with the initialized overlap proves the claim.

For a worst-case rather than explicit sign the coefficient can be improved. There are at most 8^{1+k+binom(k,2)+binom(k,3)} weighted-cubic phases. For a uniformly random truth-table sign χ, Hoeffding on the real and imaginary parts plus a union bound gives a simultaneous correlation O(k^{3/2}2^{-k/2}) with all of them. The path proof used only this correlation bound and arbitrary affine-support indicators of Fourier l1 norm one. Choosing one such target yields Γ_all≥k/2−O(log(k+2)) at fixed ε. There is no restriction on how the Clifford boundaries are selected for this truth table.

## Consecutive diagonal frames

An intrinsically sharper measure for the path proof is
$$
 H_{\min}=\min_{\Lambda_j\supseteq L_j}
       \sum_{j=1}^{D-1}\bigl(q-\dim(\Lambda_j\cap\Lambda_{j+1})\bigr),
$$
where each Λ_j is a full Lagrangian in the physical 2q-dimensional Pauli space. For any chosen completions select Clifford diagonal frames for them. The active Fourier dimension of the transition between two neighboring frames is q−dim(Λ_j∩Λ_{j+1}). Indeed, the rows of either Lagrangian modulo the other have exactly that X rank in its coordinates. The same pivot diagonalization used above sends one full Lagrangian to Z with that many Hadamards; any residual Clifford preserving all Z labels as a subspace is monomial. This proves the required decomposition independently at each transition even if the frames on both ends had already been chosen.

The overlap bound therefore holds with 2^{H_min/2} in place of 2^{Γ_all}. In particular
$$
 H_{\min}\ \ge\ 2\log_2\big((1-\epsilon^2/2)/\|\chi\|_{U^4}\big)
$$
for the explicit witness, and H_min≥k−O(log(k+2)) for a worst-case truth table at fixed accuracy. To see H_min≤2Γ_all, fix a common optimal full Lagrangian Λ. For each j take the Lagrangian completion Λ'_j=L_j+(Λ∩L_j^⊥). It has intersection codimension h_j with Λ, by the perfect symplectic dual pairing and the dimension formula. The triangle inequality for intersection codimension gives distance(Λ'_j,Λ'_{j+1})≤h_j+h_{j+1}.

For the explicit quartic family the linear lower bounds on H_min and Γ_all are both achieved in order of growth, even at **constant** native T-depth. For each four-bit block use one arbitrary dirty bit t. Apply CCZ(t,x₃,x₄), toggle t by x₁x₂ with a Toffoli, repeat the same CCZ and apply the actual inverse Toffoli. The unknown t cancels in the product of these two phases, leaving exactly the desired quartic sign with work restored. The quartets operate in parallel, each with a fixed-size native Clifford+T decomposition. The whole family has O(k) T gates, and Γ_all≤T and H_min≤2Γ_all. The low-depth example shows exactly why the rank conclusion does not on its own close the general native-depth interval.
