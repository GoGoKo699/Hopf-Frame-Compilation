"""Exact Gaussian-integer extension arithmetic and affine-support mask tests for R74."""
from itertools import product
from random import Random
from math import sqrt

Z=(0,0,0,0)
I=(1,0,0,0)
z=(0,1,0,0)
rt=(0,1,0,-1)
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def neg(a): return tuple(-v for v in a)
def mul(a,b):
    c=[0]*4
    for i in range(4):
        for j in range(4):
            c[(i+j)%4] += a[i]*b[j]*(1 if i+j<4 else -1)
    return tuple(c)
def powr(a,n):
    v=I
    for _ in range(n): v=mul(v,a)
    return v
def emb(a,t):
    v=Z
    for i in range(4):
        zi=powr(z,(t*i)%8)
        v=add(v,tuple(a[i]*k for k in zi))
    return v
def norm(a):
    v=I
    for k in (1,3,5,7): v=mul(v,emb(a,k))
    assert not any(v[1:])
    return v[0]
def val(a):
    n=abs(norm(a))
    return ((n&-n).bit_length()-1) if n else 100000
def mobius(row):
    c=list(row)
    for i in range((len(c)-1).bit_length()):
        for j in range(len(c)):
            if (j>>i)&1:
                c[j]=add(c[j],neg(c[j^(1<<i)]))
    return c

rng=Random(6241)
runs=0
coeffs=0
for trial in range(100):
    h=rng.choice([3,4,5])
    m=rng.randrange(4)
    values=[Z]*(1<<h)
    K=4
    for term in range(K):
        e=rng.randrange(h+1)
        hi=rng.sample(range(h),e)
        left=rng.randrange(2)
        bi=rng.randrange(m+1)
        constraints=[(1<<i, rng.randrange(2)) for i in hi]
        if left:
            constraints += [(rng.randrange(1<<h),rng.randrange(2)) for _ in range(m-bi)]
        f=(2*m+e-bi) if left else (m+e-bi)
        scale=powr(rt,f)
        if rng.randrange(2): scale=neg(scale)
        for w in range(1 if left else 2**bi):
            ph=[(s,(2**max(0,s.bit_count()-1))*rng.randrange(8)) for s in range(1<<h) if s.bit_count()<=3]
            for x in range(1<<h):
                if all((x&q).bit_count()%2==b for q,b in constraints):
                    v=sum(a for s,a in ph if (s&x)==s)%8
                    values[x]=add(values[x],mul(scale,powr(z,v)))
    coeff=mobius(values)
    assert all(val(c)>=s.bit_count() for s,c in enumerate(coeff))
    coeffs+=len(coeff)
    vv=min(map(val,values))
    if vv==100000: continue
    minimum=sum(val(v)==vv for v in values)
    assert minimum*(1<<vv)>=len(values)
    assert all(not norm(v) or norm(v)%(1<<vv)==0 for v in values)
    runs+=1
print('Full-hull filtered cyclotomic coefficients:',coeffs,'nonvanishing R74-style stratum tests:',runs)

def rank(vs):
    piv={}
    for x in vs:
        while x:
            j=x.bit_length()-1
            if j in piv:
                x ^= piv[j]
            else:
                piv[j]=x
                break
    return len(piv)

def span(vs):
    vals={0}
    for v in vs:
        vals |= {s^v for s in vals.copy()}
    return frozenset(vals)

def pair(a,b,n):
    mask=(1<<n)-1
    return (((a&mask)&(b>>n)).bit_count()+((b&mask)&(a>>n)).bit_count())%2

def isotropic_spaces(n):
    sub={frozenset([0])}
    for _ in range(n):
        advanced=set()
        for sp in sub:
            for v in range(1,1<<(2*n)):
                if v not in sp and all(pair(v,w,n)==0 for w in sp):
                    advanced.add(frozenset(set(sp)|{w^v for w in sp}))
        sub=advanced
    return sub

def gamma_check():
    checked=0
    for n in (1,2,3):
        lags=list(isotropic_spaces(n))
        for d in (2,3,5):
            for _ in range(15):
                basis=[]
                bands=[]
                for j in range(d):
                    M=rng.choice(lags)
                    vs=[rng.choice(tuple(M)) for _ in range(rng.randint(1,4))]
                    basis.extend(vs)
                    bands.append(span(vs))
                g=min(sum(rank(B)-rank(B & M) for B in bands) for M in lags)
                r=rank([sum(pair(v,w,n)<<j for j,w in enumerate(basis)) for v in basis])//2
                assert r<=g<=d*r
                if d==2:
                    assert g==r
                checked+=1
    return checked
print('Transported-band span minima and middle symplectic ranks:',gamma_check())
