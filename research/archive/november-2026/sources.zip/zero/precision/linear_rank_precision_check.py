"""Exact tests of the cyclotomic filtration, minimum-valuation support and height."""
import random
from itertools import product

ZERO=(0,0,0,0)
ONE=(1,0,0,0)
PI=(1,-1,0,0)


def add(a,b):
    return tuple(x+y for x,y in zip(a,b))


def sub(a,b):
    return tuple(x-y for x,y in zip(a,b))


def mul(a,b):
    z=[0]*4
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            z[(i+j)%4]+=(1 if i+j<4 else -1)*x*y
    return tuple(z)


def root(t):
    return tuple((1 if t%8<4 else -1) * int(j==t%4) for j in range(4))


def automorphism(z,t):
    a=ZERO
    for i,x in enumerate(z):
        a=add(a,tuple(x*y for y in root(i*t)))
    return a


def norm(z):
    out=ONE
    for t in (1,3,5,7):
        out=mul(out,automorphism(z,t))
    assert out[1:]==(0,0,0)
    return abs(out[0])


def val(z):
    if z==ZERO:
        return 10**9
    v=0
    while sum(z)%2==0:
        a=(z[0]-sum(z[1:]))//2
        b=a+z[1]
        c=b+z[2]
        d=c+z[3]
        z=(a,b,c,d)
        v+=1
    return v


def coefficients(values):
    out=values.copy()
    for bit in range((len(out)-1).bit_length()):
        for s in range(len(out)):
            if s>>bit&1:
                out[s]=sub(out[s],out[s^(1<<bit)])
    return out


def audit_cube(values):
    coeffs=coefficients(values)
    assert all(val(a)>=s.bit_count() for s,a in enumerate(coeffs))
    vals=[val(z) for z in values]
    v=min(vals)
    if max(vals)==min(vals)==10**9:
        return len(values)
    assert min(val(a) for a in coeffs)==v
    assert (vals.count(v)<<v)>=len(values)
    for z in values:
        if z!=ZERO:
            assert norm(z)%(1<<val(z))==0
    return len(values)


def main():
    rng=random.Random(8173)
    phase_evals=0
    sparse=0
    for k in range(1,8):
        n=2**k
        for _ in range(12):
            values=[ZERO]*n
            for term in range(3):
                q=[(s,rng.randrange(8)*(1<<max(0,s.bit_count()-1)))
                   for s in range(n) if s.bit_count()<=3]
                checks=[(rng.randrange(1,n),rng.randrange(2)) for _ in range(term)]
                pref=ONE
                for _ in checks: pref=mul(pref,PI)
                for u in range(n):
                    if all((u&mask).bit_count()%2==bit for mask,bit in checks):
                        exponent=sum(c for s,c in q if u&s==s)
                        values[u]=add(values[u],mul(pref,root(exponent)))
            phase_evals+=audit_cube(values)
        marker=[ZERO]*n
        z=ONE
        for _ in range(k): z=mul(z,PI)
        marker[n-1]=z
        sparse+=audit_cube(marker)
        assert sum(1 for a in marker if val(a)==k)==1
    print('Exact weighted-phase and affine-support samples:',phase_evals)
    print('Extremal singleton cube values:',sparse)
    print('a=1 scale sum and coefficient:',sum(6**i for i in range(4)),8)


if __name__=='__main__':
    main()
