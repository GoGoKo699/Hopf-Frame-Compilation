from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
env = dict(os.environ, OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', OMP_NUM_THREADS='1')
for path in sorted(root.rglob('*_check.py')):
    print(path.relative_to(root), flush=True)
    subprocess.run([sys.executable, str(path)], check=True, env=env)
