# Hopf frame compilation · Fixed-accuracy structure, precision, and the zero test

At fixed precision and square-root dirty width, the strongest unconditional general frame T-depth remains $O_L(\log n)$ for $N=2^n$. An explicit fixed-accuracy frame now forces linearly many independent changes of Pauli basis in total across the native T layers. A sublogarithmic zero test with a moving address would suffice to improve the depth upper bound. At growing precision, the four-layer witness now forces middle-layer crossing rank linear in $L$, improving the $\sqrt L$ dependence in R74.

## A fixed-accuracy witness for all native depths

Put $k=n-1$ and let $f(x)$ be the parity of the products of disjoint groups of four prefix bits. Set the deepest real Hopf angles to $\pi f(x)$ and every earlier angle to zero. The resulting complete frame multiplies each prefix by $(-1)^{f(x)}$. These are canonical real angles. The complex family realizes the same signs by prescribing leaf phases. [Hopf angle domains](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/HOPF_INTERFACE.md#canonical-domains)

Transport the axes of the native T gates into common Pauli coordinates through the intervening Cliffords. For each T layer choose a full commuting Pauli basis containing its axes. At each consecutive pair charge the number of independent directions outside the intersection of the two bases. Minimize the sum of these charges over the basis choices, and call it $H_{\min}$. The first and final Clifford changes of computational basis are free in this count.

For this explicit frame, at fixed full error $\eta<\sqrt2$, **every native decomposition at every depth has $H_{\min}=\Omega(n)$**, with arbitrary clean and dirty widths. The cost measures the total number of independent basis directions that must change across the circuit. Some prescribed sign tables require $H_{\min}\ge n-O(\log n)$ at fixed accuracy.

To see the obstruction, expand the internal Hadamards of an optimally chosen sequence of bases into binary paths. The absolute weights sum to $2^{H_{\min}/2}$. After the two boundary Clifford maps, each path contributes an average of eighth-root phases with exponent a weighted cubic polynomial, restricted to an affine set. The restriction has Fourier coefficient absolute sum one. Each independent four-bit block reduces the maximum signed correlation by a factor of at most $(197/512)^{1/16}<1$, by four applications of Cauchy–Schwarz. The required initialized overlap is at least $1-\eta^2/2$. The two bounds force a linear total charge. For a worst-case sign table a random-sign argument gives the stronger coefficient above.

The explicit witness itself admits constant native T-depth. Use a private borrowed bit for each quartet, toggle it by the product of its first two bits, and take the difference of two CCZ phases controlled by the borrowed bit and the remaining two inputs. The borrowed value cancels exactly. All quartets operate in parallel. This gives a concrete example where the total basis-change requirement grows linearly while native depth stays bounded.

## What the inverse trace already computes

Let $F=\mathbb F_{2^s}$ with even $s$, let $H=\ker\operatorname{Tr}$, and put $J(z)=1/z$ for nonzero $z$ and $J(0)=0$. Choose $d$ with $\operatorname{Tr}(d)=1$. The previous candidate was a complete XOR of $g(z)=\operatorname{Tr}(dJ(z))$ on $H$.

For $x\ne0,1$, partial fractions in characteristic two give $J(x)+J(x+1)=J(x^2+x)$. At each exceptional point the difference is one. Consequently
$$
 g(x)+g(x+1)+g(x^2+x)=[x\in\{0,1\}],\qquad x\in H .
$$
All three arguments lie in the permitted hyperplane. On a complement of the line spanned by $1$ in $H$ this implements an all-zero test on $s-2$ bits with three serial XORs and actual work return. The substitutions are binary affine. The same proof gives at least $s-3$ controls for odd field degrees by choosing a suitable nonzero shift. At field degrees that are powers of two, the exact trace oracle can even recover the entire out-of-place field inverse with polynomially many shareable parallel copies. That reconstruction needs a separate aggregate error budget for approximate copies.

## A sufficient native circuit with a moving address

Let $k$ be the zero-test address length. It suffices to find a native unitary with the following property for a designated target bit on arbitrary work.

| Input address | Required target behavior |
|---|---|
| Any $w\ne0$ | The output target equals the input target with certainty, for either input bit. |
| $w=0$ | The target flips, with at most a sufficiently small fixed worst-case amplitude for the original target value. |

Other registers can move, even at completion. Counts and width of $2^{O(k)}$ are allowed in this discovery problem. Copy the target before and after the source and use the actual adjoint. This extracts an operation that is exactly identity on every unmarked address and is close to a cleanly returned toggle on the marked address. Exact off-zero behavior is the accuracy condition that makes the construction work.

To compute the complete indicator, give each output candidate $a$ disjoint private test addresses. For a private word $v$, pair two zero tests at $v$ and $v+x+a$. Their conjunction is identically zero for $a\ne x$, regardless of the dirty origin. For $a=x$ both tests fire exactly when $v=0$. A short random label adds a pairwise independent field offset to each private word. Among $2^k/4$ trials the probability of exactly one hit is at least $3/16$ on **every** initial tuple of words. A constant number of groups gives a biased prediction of the requested Fourier parity. A coherent sampling and uncomputation argument converts this to full operator accuracy on arbitrary states. One additional stage of short classical extraction keeps the sampling depth at $O(\log\log(k+4))$. The proof includes all borrowed addresses, the nonlinear tests, inverse words, and the final removal of initialized sampling bits. [Linear extractor, Lemma 4](https://drops.dagstuhl.de/storage/00lipics/lipics-vol124-itcs2019/LIPIcs.ITCS.2019.53/LIPIcs.ITCS.2019.53.pdf) · [Metric uncertainty, Theorem 2.5](https://arxiv.org/abs/1010.3007)

A fixed partition of the address into blocks absorbs the exponential circuit volume. If the raw zero-test depth has nondecreasing bound $d(k)$, the complete fixed-precision frame therefore has the **conditional** simultaneous bounds
$$
 D_T=O_L\!\left(N/b^2+d(2n+10)+\log\log(n+4)\right),\qquad
 T=O_L(\sqrt N+N/b),\qquad G=O_L(N).
$$
This uses one external clean qubit and the established dirty allocations for the real and prescribed complex magnitude frames. The zero-test circuit itself has yet to be constructed at sublogarithmic depth. The growing-precision frontier remains open. [R96 baseline](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/OPEN_PROBLEM.md#large-width-t-depth) · [R98 transfer](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/QUERY_DEPTH_FRAME_TRANSFER.md)

## Which native words can supply the zero test?

Consider a physical Clifford+T word with at most three T layers and no initialized work. Let $e$ be the probability of changing a designated bit, averaged over all computational inputs. Then
$$
 e=0 \quad\text{or}\quad e\ge (1-1/\sqrt2)/4=0.0732233047\ldots .
$$
This is the sharp Pauli-transfer gap already established in the repository, expressed as bit disagreement. Its application here permits arbitrary dirty width, coherent garbage, and unrestricted address motion. A native three-qubit word attains equality. A single exceptional $k$-bit address gives $e\le 2^{-k}$, so no three-layer word can produce even a small nonzero flip there for $k\ge4$ while remaining exactly silent everywhere else.

The proof expresses the bit correlation as the overlap of two normalized stabilizer states with one diagonal T layer between them. Different affine supports already give a constant gap. On a common support the relative phase is an eighth root whose exponent is a weighted cubic polynomial. A nonzero low bit, middle bit or high bit must occur on a sufficiently large fraction of the support. This yields the stated constant. The matching example is checked as an actual native unitary. [Repository’s three-layer gap, §4.1](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/CLEAN_AWARE_DEPTH_OBSTRUCTION.md#41-a-sharp-gap-below-a-preserved-pauli)

I also enumerated four- and five-band words with one private spin and physically read-only address controls. At four bands the search covered 243 axis/measurement choices times 2,419 affine sign subspaces, and at five bands 729 times 26,323. In this model a single exceptional address appears on at most two independent address bits. Additional quantum work or address motion remains available at four bands and above.

For four native layers there are two simultaneous requirements. For $k\ge6$, at least $k$ independent Pauli directions must belong to **both** middle-layer axis spans in the same Clifford coordinates. The binary commutation matrix between the two spans must also have rank at least $\lceil k/2-1\rceil$. These directions are additional: their pairing vanishes on the common span. Thus each middle layer must contain at least $k+\lceil k/2-1\rceil$ native T gates. This holds even if the raw unitary produces only a nonzero flip on part of the marked row. It follows by confining the discrepancy to the common commuting axes, counting the ranks of their equal-dimensional joint sectors, then isolating one exceptional sector on an affine cube and comparing the two native path sums.

## Precision requires linear crossing rank at four layers

Here $L$ is the precision exponent, with full initialized error $2^{-L}$. Fix the allowed number $a$ of clean qubits, leaving the dirty width unrestricted. R74 uses a complete frame containing the single rotation $R_y(\tfrac12\arccos(1/3))$. For any four-layer native approximation to this witness, its previous proof requires a middle-layer crossing rank $r=\Omega_a(\sqrt L)$. The new proof gives
$$
r=\Omega_a(L).
$$
The proof uses the same circuit and the same initialized-return witness. The earlier argument fixed each quadratic coefficient in an internal path sum, paying a quadratic cost in the number of active coordinates. In the amplitude ring $\mathbb Z[\zeta_8]$, a term on $j$ binary variables instead has coefficient divisible by $(1-\zeta_8)^j$. Reducing at the lowest remaining divisibility level bounds the fraction of sectors with nonzero error. The algebraic norm then bounds the error in those sectors. Together they give an error floor exponential in $r$ for fixed $a$, which yields the linear bound in $L$. The proof applies separately to every four-layer decomposition. At fixed $L$ this result by itself provides no depth growth in $n$. [R74 crossing-rank witness](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/FOUR_LAYER_CROSSING_RANK.md#51-quantitative-rigidity-on-the-initialized-sector)

The proof package also extends the precision obstruction to arbitrary depth. Transport the axes of all interior layers to common Pauli coordinates. Even after choosing the best single commuting Pauli space and exempting the two outer layers, the sum over interior layers of the dimensions outside that space is $\Omega_a(L)$ for this precision witness. At four layers this quantity equals the middle crossing rank.

## The next circuit to test

The first surviving four-band search should enforce both the common-axis dimension and the noncommuting rank before evaluating any candidate. The word needs entangling dirty work or address motion to escape the one-spin search. The first test is the off-address target block of the actual emitted word. A single nonzero matrix element there invalidates the sparse-predicate reduction. On the marked address bound the worst-case target-flip amplitude over the full dirty space and price the actual inverse. A family with $d(k)=o(\log k)$ would lower the general frame depth. A constant-depth family would give $O_L(\log\log n)$ at square-root dirty width.

There is a concrete control experiment with order-three Clifford rotations. One shared spin sector already supports a maximal-degree odd predicate at constant T-depth and fixed one-address accuracy. With an additional reference spin, a bounded clean herald produces the exact local XOR on success with probability $9/64$. Running this word on independent spins gives different hidden offsets to different output cells. The simultaneous shifted bank on one common sector, with full error control, remains the missing operation for that experiment.
