# Reproducing the mask-source results

Read the accompanying Hopf_Mask_Rank_and_Native_Interference.md first. Each file below gives a different part of the argument. The results concern sufficient source conditions or restrictions on particular native words. The first unpaid operation is a uniformly shallow complete source.

| File | Main question |
|---|---|
| hidden_convolution.md | How does the same unknown odd mask cancel on every coherent helper sector? |
| mean_column_indicator.md | How does positive joint address–workspace agreement give a full operator guarantee? |
| positive_rank_mask_correction.md | How is the logarithmic-logarithmic depth overhead obtained for actual returned translations? |
| schur_mask_lift.md and dirty_random_seed.md | How are the scalar sampling layers and bounded-clean accuracy correction implemented? |
| small_field_mask_rank.md | Which explicit translated finite-field predicates have the required rank? |
| conjugation_shear_rank.md | How fast can rank grow under affine-tableau stages? |
| native_path_rank.md and mask_interference_rank.md | What dependence between native T-axes must a Pauli conjugator produce? |
| order_three_mask.md | How does one Boolean modulo-three residue compare with the repository’s order-three construction? |

From the extracted directory, run `python run_checks.py` with Python 3.11+ and NumPy. The finite cases check algebraic identities, operator action and restricted examples. The asymptotic assertions are proved in the notes. TEST_RESULTS.txt records the observed output. The two sampler references in the main report supply the external results used by the joint-density proof. The classical precomputation is finite and can be exhaustive.

The 39 repository tests were run separately at ae613bf8e8a38f6d0407c25910b83d69f01a2733, using the eight test modules named in TEST_RESULTS.txt.
