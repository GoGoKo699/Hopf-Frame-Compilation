"""Finite checks for the classical and unitary identities of the mean-column reduction."""
from itertools import product
from random import Random

import numpy as np


def transfer_check():
    # An input-controlled permutation on the bank, followed by nonclassical garbage.
    m, n = 4, 32
    eye = np.eye(n, dtype=complex)
    hadamard = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
    unitary = np.zeros_like(eye)
    displacement = []
    for index in range(n):
        address, bank, other = index >> 3, (index >> 1) & 3, index & 1
        new_bank = ((bank ^ (address & 1)) + (address % 3)) % m
        displacement.append(bank ^ new_bank)
        for bit in range(2):
            output = (((address ^ 3) * 4 + new_bank) * 2 + bit)
            unitary[output, index] = (1j ** (address + bank)) * hadamard[bit, other]
    np.testing.assert_allclose(unitary.conj().T @ unitary, eye, atol=1e-12)
    result = []
    for dual in range(m):
        sign = np.array([(-1) ** ((((i >> 1) & 3) & dual).bit_count()) for i in range(n)])
        echo = (unitary.conj().T @ (sign[:, None] * unitary)) * sign
        expected = [(-1) ** ((dual & delta).bit_count()) for delta in displacement]
        np.testing.assert_allclose(echo, np.diag(expected), atol=1e-12)
        result.extend(expected)
    return len(result)


def check_cosets():
    # With λ=ln 2 the potential exponential is integer, so this is exact.
    rng = Random(112)
    totals = 0
    for width in range(2, 7):
        n = 2 ** width
        for _ in range(12):
            counts = [rng.randrange(4) == 0 for _ in range(n)]
            for _ in range(3):
                potential = sum(2 ** c for c in counts)
                next_total = sum(2 ** (counts[b] + counts[b ^ s])
                                 for b in range(n) for s in range(n))
                assert next_total == potential ** 2
                shift = rng.randrange(n)
                counts = [c + counts[b ^ shift] for b, c in enumerate(counts)]
                totals += 1
            maximum = max(counts)
            additional_shift = rng.randrange(n)
            assert max(c + counts[b ^ additional_shift] for b, c in enumerate(counts)) <= 2 * maximum
    return totals


def check_validator():
    checked = 0
    for k in range(1, 4):
        m = 2 ** k
        for candidate in range(2 ** m):
            for u in range(m):
                # All a·b are fair for a uniform a whenever b is nonzero.
                active = sum(any((candidate >> i) & 1 and ((i ^ u) & q).bit_count() % 2
                                 for i in range(m)) for q in range(m))
                if candidate == 1 << u:
                    assert candidate.bit_count() % 2 == 1 and active == 0
                elif candidate.bit_count() % 2 == 1:
                    assert 2 * active >= m
                checked += 1
    return checked


def check_extrapolation():
    rng = Random(311)
    checked = 0
    for degree in (1, 2, 3):
        width = 4
        monomials = [i for i in range(2 ** width) if i.bit_count() <= degree]
        for _ in range(100):
            coefficients = [rng.randrange(32) for _ in monomials]
            words = [rng.randrange(16) for _ in range(degree + 1)]
            total = 0
            for selector in range(1, 2 ** len(words)):
                point = 0
                for i, word in enumerate(words):
                    if selector >> i & 1:
                        point ^= word
                for monomial, coefficient in zip(monomials, coefficients):
                    if monomial & point == monomial:
                        total ^= coefficient
            assert total == coefficients[0]
            checked += 1
    return checked


def check_dirty_origin():
    # Each individual dirty column is wrong on some rows. Good rows move with z.
    m, dimension = 8, 4
    def proposal(x, z):
        return (1 << x) if ((z ^ x) & 3) == 0 else 3 << (x % 6)
    base = {(x, r, shift) for x, r, shift in product(range(m), range(dimension), range(m))
            if proposal(x ^ shift, r) != 1 << (x ^ shift)}
    checked = 0
    for x, z in product(range(m), range(dimension)):
        successes = 0
        for offset, shift in product(range(dimension), range(m)):
            u = x ^ shift
            expected = proposal(u, z ^ offset) == 1 << u
            assert expected == ((x, z ^ offset, shift) not in base)
            successes += int(expected)
            checked += 1
        assert successes * 4 == m * dimension
    return checked


if __name__ == "__main__":
    print("Output-copy Fourier columns:", transfer_check())
    print("Exact coset potential identities:", check_cosets())
    print("Validator mask/address pairs:", check_validator())
    print("Nonzero-cube extrapolations:", check_extrapolation())
    print("Translated dirty origins:", check_dirty_origin())
