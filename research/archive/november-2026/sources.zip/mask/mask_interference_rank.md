# High-rank returned masks require interference on almost every independent row

Let V be an actual zero-clean Clifford+T encoder of d native T bands with t physical T/T† gates. Absorb its Clifford intervals into its Pauli axes and the fixed measured Pauli, using input Pauli coordinates. Let h=t−rank_F₂{all t binary axes}. Each individual native band is independent. The quantity h counts dependencies *across* bands of this circuit. Address or work trajectories, choices of intermediate computational basis and all private dirty widths are unrestricted.

Suppose the actual echo O=V†PV has full operator error ε<√2 against W_v|x,z,w⟩=|x,z+v_x,w⟩, m=2^k and the binary row rank of v is r. Put c=(1−ε²/2)²>0 and take
$$
 L=2k+h+\lceil\log_2(1/c)\rceil+1.
$$
Then
$$
 \boxed{ r\le \sum_{i=0}^{\min(d,L)} {L\choose i}.}
$$
This is an unrestricted necessary condition for *this observable representation*. It is not a depth lower bound for general native frame compilers. In particular introducing canceling gates may deliberately raise h without changing the circuit action; the gain criterion below avoids giving that artificial change evidential significance.

**A native path sampler.** In the unit-normalized physical Pauli coefficient vector, start at the final Pauli P. Sweep the absorbed bands backwards. At a native axis a_j an incoming label b branches precisely if ⟨a_j,b⟩=1. The two coefficient magnitudes are then both multiplied by 1/√2, and their labels are b and b+a_j. Otherwise there is no branch. Axis signs affect phases only. Axes in the same band commute, so all branch tests in it use the preceding label b. Sample each branch by an independent uniform bit U_j. The resulting physical label after one band is
$$
 b'=b+\sum_j U_j\langle a_j,b\rangle a_j .
$$
Thus the entire sampled label is a vector polynomial of Boolean degree ≤d in all t random bits, including arbitrary fixed linear changes of coordinates, and so is its bank-X projection F(U). A nonbranching test can simply ignore its random bit. The probability of each distinct history equals the squared magnitude of its term in the actual Pauli expansion. Distinct histories give distinct selected-axis subsets (an inactive branch always selects zero). Before measuring the bank, two histories can land on the same full physical label only if their selected-axis subsets differ by a binary axis dependence. Each full label has at most 2^h such histories. Squaring the coherent sum and applying Cauchy–Schwarz gives
$$
 p_{\rm actual}(a)\le 2^h p_{\rm path}(a)
$$
on full labels, which remains true after summing over each bank-X projection. If a smaller exact maximum number of nonzero histories per label is known, that number can replace 2^h.

**Heavy desired output masks.** The bank-X marginal of the actual squared Pauli coefficients equals the mean, over computational inputs on *all* physical wires, of the probability to see that bit mask of differences on the bank. This follows by Parseval over the binary Z components at each full X translation, then summing over nonbank X translations. On each input with logical address x the matrix element of O at the required output has real part ≥1−ε²/2 by the full-error assumption. Thus every row mask v_x has actual marginal at least c/m, irrespective of duplicate row masks and even when a generic approximate O changes the address. Consequently every desired v_x is an atom of F of mass ≥c/(m2^h).

**Small affine restriction containing all heavy labels.** Let F be *any* vector Boolean polynomial of degree d on any number t of uniform bits. Suppose r' specified labels each have mass ≥p. Pick a uniformly random affine map A:F₂^l→F₂^t (uniform shift and independent uniform entries of its linear part). Distinct points of the sampled l-cube have independent uniform images in the random experiment. This holds without any injectivity requirement. For a fixed target value the count of hits has mean ≥2^l p, variance at most its mean, and hence miss probability ≤1/(2^l p). If 2^l p>r', some one fixed affine map hits all specified values. The composition F∘A is a degree≤d map of l bits. Its output linear span has dimension at most Σ_{i≤min(d,l)}binom(l,i), because every output is a binary sum of its vector polynomial coefficients. Use r'≤m, p=c/(m2^h) to prove the bound. The random map is solely for the lower bound, with no runtime randomness or clean wires.

**Consequences.** For jointly independent axes (h=0), near-full rank m−√m requires d≥(2H₂^{-1}(1/2)−o(1))k at fixed error, where H₂^{-1} is the binary entropy inverse in [0,1/2]. More generally this linear-depth obstruction applies if the path amplitude collisions are at most polynomial in m, with an appropriate constant depending on that polynomial. For d=O(log log(k+4)) and near-full rank, h≥2^{Ω(k/d)} for large k, from Σ_{j≤d}binom(L,j)≤(e L/d)^d when d≤L/2. This leaves a route with engineered cross-band dependencies fully open.

The test can use the **actual coherent gain at a mask**, p_actual(v)/p_path(v), instead of the global 2^h. For a collection of independent desired rows with gain ≤G, take l=2k+max(0,ceil(log₂G))+ceil(log₂(1/c))+1 in the same proof. Its size is at most Σ binom(l,i). At d=o(k) and G=m^C for any fixed C, this is 2^{o(k)}. Hence, for a near-full-rank mask family, all but 2^{o(k)} members of any independent row basis require superpolynomial gain relative to the dephased trajectory law, in the precise sense that for each fixed C the number at or below m^C has that bound. The statement concerns constructive quantum interference in the physical Pauli expansion, including after aggregation of all address and work Paulis. A high h alone does not establish that those gains occur.
