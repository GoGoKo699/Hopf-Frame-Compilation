from fractions import Fraction
from random import Random

MOD={2:7,3:11,4:19,5:37,6:67,7:131}
def mul(a,b,k):
    z=0
    while b:
        if b&1:z^=a
        a<<=1
        if a>>k:a^=MOD[k]
        b>>=1
    return z
def pow_f(a,j,k):
    y=1
    while j:
        if j&1:y=mul(y,a,k)
        a=mul(a,a,k)
        j>>=1
    return y
def tr(a,k):
    z=0
    for _ in range(k):
        z^=a
        a=mul(a,a,k)
    assert z in (0,1)
    return z
def rank(rows):
    basis={}
    for v in rows:
        while v:
            i=v.bit_length()-1
            if i not in basis:
                basis[i]=v
                break
            v^=basis[i]
    return len(basis)
nr=nt=ne=ni=0
for k in range(2,8):
    m=1<<k
    assert all(pow_f(x,m-1,k)==1 for x in range(1,m))
    for e in range(1,m):
        g=[pow_f(x,e,k) for x in range(m)]
        ans=rank(sum(g[a^u]<<(k*a) for a in range(m)) for u in range(m))
        mask=e
        cover=set()
        for _ in range(k):
            cover.update(j for j in range(m) if j&mask==j)
            mask=((mask<<1)&(m-1)) | (mask>>(k-1))
        assert ans==len(cover)
        b=k-e.bit_count()
        if b:
            gap=Fraction(m-ans,m); s=Fraction(2**b-1,2**b)
            denom=b*(b-1)+1
            assert s**k<=gap<=s**((k+denom-1)//denom)
        assert ((m-ans)**2<=m)==(b<=1)
        nr+=1
    inv=[pow_f(x,m-2,k) for x in range(m)]
    for c in range(1,m):
        h=[x for x in range(m) if not tr(mul(c,x,k),k)]
        s=0
        for x in h:s^=inv[x]
        assert s==c
        for d in range(1,m):
            w=sum(tr(mul(d,inv[z],k),k) for z in h)
            assert w%2==tr(mul(d,c,k),k)
            nt+=1
            if w%2 and d==next(j for j in range(1,m) if tr(mul(j,c,k),k)):
                for u in h:
                    bits=[tr(mul(d,inv[z],k),k) for z in h]
                    assert sum(bit*tr(mul(d,inv[u^z],k),k) for z,bit in zip(h,bits))%2==(not u)
                    ni+=1
rng=Random(41)
for k in range(2,7):
    m=1<<k
    for b in range(1,5):
        for _ in range(12):
            comps=[rng.getrandbits(m) for _ in range(b)]
            comps=[h^(h.bit_count()%2) for h in comps]
            rows=[sum(((h>>(u^z))&1)<<(m*j+z) for j,h in enumerate(comps) for z in range(m)) for u in range(m)]
            assert (m-rank(rows))*(1<<b)>=m
            ne+=1
print(nr,'exact field-power translate ranks;',nt,'trace-inverse parities;',ni,'scalar convolution columns;',ne,'even-component deficiency bounds')
