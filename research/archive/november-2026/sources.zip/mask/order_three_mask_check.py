from itertools import product
from math import comb
from random import Random


def gf_cycle(value):
    a, b = value & 1, value >> 1
    b ^= a
    a ^= b
    return a | (b << 1)


def rotate(value, power):
    for _ in range(power % 3):
        value = gf_cycle(value)
    return value


def gf_bank(k, x, z, inverse=False):
    result = list(z)
    indices = range(k - 1, -1, -1) if inverse else range(k)
    for i in indices:
        if x >> i & 1:
            for s in range(1 << k):
                if s >> i & 1:
                    result[s] = rotate(result[s], -1 if inverse else 1)
    return result


def rank(rows):
    basis = {}
    for z in rows:
        while z:
            p = z.bit_length() - 1
            if p not in basis:
                basis[p] = z
                break
            z ^= basis[p]
    return len(basis)


def main():
    rng = Random(43819)
    words = 0
    for k in (1, 2, 3):
        m = 1 << k
        for x in range(m):
            if k <= 2:
                banks = product(range(4), repeat=m)
            else:
                banks = (rng.choices(range(4), k=m) for _ in range(300))
            expected = [rotate(1, -(s & x).bit_count()) for s in range(m)]
            for z in banks:
                v = gf_bank(k, x, z)
                out = gf_bank(k, x, [a ^ 1 for a in v], inverse=True)
                assert out == [a ^ offset for a, offset in zip(z, expected)]
                words += 1
    for k in range(1, 10):
        m = 1 << k
        full, partial, augmented = [], [], []
        for x in range(m):
            exps = [(s & x).bit_count() for s in range(m)]
            row = [rotate(1, -e) for e in exps]
            full.append(sum(a << (2 * s) for s, a in enumerate(row)))
            g = sum(int(e % 3 == 0) << s for s, e in enumerate(exps))
            h = sum(int(e % 3 == 2) << s for s, e in enumerate(exps))
            assert all((1 ^ (a >> 1)) == int(e % 3 == 0) for e, a in zip(exps, row))
            for b in range(2):
                inclusive_first = sum(int((e + b) % 3 == 0) << s for s, e in enumerate(exps))
                inclusive_second = sum(int((e + 1 - b) % 3 == 0) << s for s, e in enumerate(exps))
                assert (g ^ inclusive_first ^ inclusive_second) == h
            partial.append(g)
            augmented.append((g << m) | h)
        target = 1 + sum(comb(k, d) for d in range(1, k + 1) if d % 3)
        assert (rank(full), rank(partial), rank(augmented)) == (m, target, m)
        print(f"k={k} m={m} joint={m} residue={target} two-offset={m}")
    print(f"complete emitted-word comparisons: {words}")


if __name__ == "__main__":
    main()
