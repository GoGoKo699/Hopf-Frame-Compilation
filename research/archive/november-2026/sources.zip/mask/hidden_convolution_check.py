"""Exact combinatorial and finite Hilbert-space checks for shifted calibration."""

import math
from functools import lru_cache
import numpy as np


def shifted(value, offset, size):
    return sum(((value >> (i ^ offset)) & 1) << i for i in range(size))


@lru_cache(maxsize=None)
def convolution(a, b, size):
    result = 0
    for i in range(size):
        if (a >> i) & 1:
            result ^= shifted(b, i, size)
    return result


def transform(bits, p):
    """Involutory coefficient conversion from group to square-zero basis."""
    n = 1 << p
    for i in range(p):
        for s in range(n):
            if not (s >> i) & 1:
                bits ^= ((bits >> (s | (1 << i))) & 1) << s
    return bits


def subset_product(a, b, p):
    """Ranked zeta product; Möbius coefficients equal 1 in characteristic two."""
    n = 1 << p
    bins = lambda: [[0] * (p + 1) for _ in range(n)]
    U, V, F = bins(), bins(), bins()
    for t in range(n):
        for i in range(n):
            if i & ~t == 0:
                U[t][i.bit_count()] ^= (a >> i) & 1
                V[t][i.bit_count()] ^= (b >> i) & 1
        for i in range(p + 1):
            for j in range(p + 1 - i):
                F[t][i + j] ^= U[t][i] & V[t][j]
    result = 0
    for s in range(n):
        for t in range(n):
            if t & ~s == 0:
                result ^= F[t][s.bit_count()] << s
    return result


def check_small():
    cprod = cecho = 0
    for p in (1, 2):
        n = 1 << p
        for a in range(1 << n):
            for b in range(1 << n):
                got = transform(subset_product(transform(a, p), transform(b, p), p), p)
                assert got == convolution(a, b, n)
                cprod += 1
        for h in range(1 << n):
            for r in range(n):
                for x in range(n):
                    f, g = shifted(h, r, n), shifted(h, r ^ x, n)
                    for a in range(1 << n):
                        for b in range(1 << n):
                            A, B, Y = a, b, 0
                            Y ^= convolution(A, B, n)
                            A ^= f
                            Y ^= convolution(A, B, n)
                            B ^= g
                            Y ^= convolution(A, B, n)
                            A ^= f
                            Y ^= convolution(A, B, n)
                            B ^= g
                            assert (A, B, Y) == (a, b, (h.bit_count() % 2) << x)
                            cecho += 1
    return cprod, cecho


def check_larger():
    rng = np.random.default_rng(37)
    count = 0
    for p in (3, 4, 5):
        n = 1 << p
        for _ in range(64):
            a, b, h = (int(rng.integers(0, 1 << n, dtype=np.int64)) for _ in range(3))
            r, x = (int(rng.integers(0, n)) for _ in range(2))
            product = transform(subset_product(transform(a, p), transform(b, p), p), p)
            assert product == convolution(a, b, n)
            assert convolution(shifted(h, r, n), shifted(h, r ^ x, n), n) == (h.bit_count() % 2) << x
            count += 1
    return count


def check_mix():
    # 1 address bit, 1 arbitrary offset bit, 3 two-bit banks, 1 rotated sector.
    # Every matrix column is propagated. A complex sector rotation is applied
    # and actually undone independently on each of the four calls.
    n = 512
    indices = np.arange(n)
    x = (indices >> 8) & 1
    r = (indices >> 7) & 1
    A, B = (indices >> 5) & 3, (indices >> 3) & 3
    sector = indices & 1
    theta, phi = 0.41, 0.73
    U = np.array([[math.cos(theta), -np.exp(-1j * phi) * math.sin(theta)],
                  [np.exp(1j * phi) * math.sin(theta), math.cos(theta)]])
    work = np.eye(n, dtype=np.complex128)

    def rotate(state, M):
        return np.einsum("ab,ibj->iaj", M, state.reshape(-1, 2, n)).reshape(n, n)

    def permute(state, dest):
        assert np.array_equal(np.sort(dest), indices)
        return state[np.argsort(dest)]

    def c(state):
        delta = np.array([convolution(int(a), int(b), 2) for a, b in zip(A, B)])
        return permute(state, indices ^ (delta << 1))

    def gate(state, out_shift):
        # h_0=delta_0 and h_1=delta_1 on G with two elements.
        mask = 1 << (r ^ sector)
        transformed = rotate(state, U.conj().T)
        return rotate(permute(transformed, indices ^ (mask << out_shift)), U)

    def variable(state):
        offset = indices ^ (x << 7)
        return permute(gate(permute(state, offset), 3), offset)

    for op in (c, lambda z: gate(z, 5), c, variable, c, lambda z: gate(z, 5), c, variable):
        work = op(work)
    expected = permute(np.eye(n), indices ^ ((1 << x) << 1))
    err = np.max(np.sum(abs(work - expected), axis=0))
    assert err < 2e-14
    return n, err


def check_garbage_promotion():
    # Physical layout: b (two bits), q, hidden-sector s, unconstrained w,
    # then a separate dirty two-bit target t. The raw 32x32 callable
    # applies an unrelated random 8x8 unitary on all q,s,w after the
    # promised bank write, controlled by output b.
    rng = np.random.default_rng(251)
    d, k = 32, 4
    theta, phi = 0.61, 0.37
    U = np.array([[math.cos(theta), -np.exp(-1j * phi) * math.sin(theta)],
                  [np.exp(1j * phi) * math.sin(theta), math.cos(theta)]])
    to_label = np.kron(np.eye(8), np.kron(U.conj().T, np.eye(2)))
    P = np.zeros((d, d))
    for i in range(d):
        addr, sector = (i >> 2) & 1, (i >> 1) & 1
        P[i ^ ((1 << (addr ^ sector)) << 3), i] = 1
    garbage = np.zeros((d, d), dtype=complex)
    for b in range(4):
        Q, _ = np.linalg.qr(rng.normal(size=(8, 8)) + 1j*rng.normal(size=(8, 8)))
        garbage[8*b:8*b+8, 8*b:8*b+8] = Q
    raw = np.kron(garbage @ P @ to_label, np.eye(k))
    copy = np.zeros((d*k, d*k))
    target = np.zeros_like(copy)
    for j in range(d*k):
        i = j >> 2
        addr, sector, b = (i >> 2) & 1, (i >> 1) & 1, i >> 3
        copy[j ^ b, j] = 1
        target[j ^ (1 << (addr ^ sector)), j] = 1
    expected = np.kron(to_label.conj().T, np.eye(k)) @ target @ np.kron(to_label, np.eye(k))
    work = copy @ raw.conj().T @ copy @ raw
    error = np.max(np.sum(abs(work - expected), axis=0))
    assert error < 2e-14
    return d*k, error


if __name__ == "__main__":
    cprod, cecho = check_small()
    print(f"{cprod} exhaustive basis-converted products; {cecho} dirty echoes with even and odd masks")
    print(f"{check_larger()} larger ranked products and shifted calibration identities")
    n, err = check_mix()
    print(f"{n} coherent operator columns; maximum absolute column sum error {err:.3g}")
    n, err = check_garbage_promotion()
    print(f"{n} garbageful raw-promotion operator columns; maximum column sum error {err:.3g}")
