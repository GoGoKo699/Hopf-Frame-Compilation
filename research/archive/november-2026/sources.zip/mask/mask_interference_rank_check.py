"""Check the coherent/incoherent path bound against explicit full matrices."""
from random import Random
from itertools import product
from math import pi,sin,cos
import numpy as np

rng=Random(125123)

def linspanrank(labels):
    b={}
    for val in labels:
        while val:
            top=val.bit_length()-1
            if top in b: val^=b[top]
            else: b[top]=val; break
    return len(b)

def sym(a,b,n):
    return (((a%(1<<n))&(b>>n)).bit_count()+((b%(1<<n))&(a>>n)).bit_count())&1

def setup(n):
    dim=1<<n; mats=[]
    for lab in range(dim*dim):
        x,z=lab%dim,lab//dim
        mat=np.zeros((dim,dim),complex)
        for j in range(dim):
            mat[j^x,j]=1j**((x&z).bit_count())*(-1)**((j&z).bit_count())
        mats.append(mat)
    return np.array(mats)

trials=pointwise=parses=degree_checks=0
for n in range(2,5):
    P=setup(n); w=1<<n
    for _ in range(65):
        d=rng.randrange(1,5)
        axes=[]
        for j in range(d):
            sub=[]
            for s in range(rng.randrange(1,n+1)):
                good=[a for a in range(1,w*w) if all(sym(a,b,n)==0 for b in sub) and linspanrank(sub+[a])>len(sub)]
                sub.append(rng.choice(good))
            axes.append(sub)
        t=sum(map(len,axes))
        h=t-linspanrank([a for sub in axes for a in sub])
        p=rng.randrange(1,w*w)
        native=P[p].copy(); sampled={p:1.0}
        for sub in axes:
            for a in sub:
                R=cos(pi/8)*np.eye(w)+1j*rng.choice([-1,1])*sin(pi/8)*P[a]
                native=R.conj().T@native@R
                fresh={}
                for lab,pr in sampled.items():
                    if sym(a,lab,n):
                        for out in (lab,lab^a):
                            fresh[out]=fresh.get(out,0.0)+pr/2
                    else: fresh[lab]=fresh.get(lab,0.0)+pr
                sampled=fresh
        coeff=np.abs(np.einsum('aij,ij->a',P.conj(),native)/w)**2
        inc=np.array([sampled.get(a,0.0) for a in range(w*w)])
        assert np.all(coeff<=inc*2**h+1e-9)
        if h==0: assert np.max(np.abs(coeff-inc))<1e-9
        bank_mask=(1<<rng.randrange(1,n+1))-1
        marginal=[sum(coeff[a] for a in range(w*w) if (a%(1<<n))&bank_mask==j) for j in range(bank_mask+1)]
        computational=[sum(abs(native[y,x])**2 for x in range(w) for y in range(w) if ((x^y)&bank_mask)==j)/w for j in range(bank_mask+1)]
        assert np.max(np.abs(np.array(marginal)-computational))<1e-8
        pointwise+=w*w; parses+=len(marginal)
        if t<=10:
            values=[]
            for bits in range(1<<t):
                lab=p; i=0
                for sub in axes:
                    old=lab
                    for a in sub:
                        if bits>>i&1 and sym(a,old,n): lab^=a
                        i+=1
                values.append(lab)
            for i in range(t):
                for zz in range(1<<t):
                    if zz>>i&1: values[zz]^=values[zz^(1<<i)]
            assert all(not val or z.bit_count()<=d for z,val in enumerate(values))
            degree_checks+=len(values)
        trials+=1
print(f"{trials} physical Clifford+T echoes, {pointwise} coherent gain inequalities, {parses} computational marginal identities and {degree_checks} polynomial coefficients")
