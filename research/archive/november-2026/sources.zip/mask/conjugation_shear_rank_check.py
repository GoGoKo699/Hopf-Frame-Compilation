"""Finite exact-rank and full Pauli conjugation probes accompanying the shear rank lemma."""
from itertools import product
from math import comb
from random import Random
import numpy as np

rng=Random(701823)
def gf2rank(rows):
    basis={}
    for v in rows:
        while v:
            j=v.bit_length()-1
            if j in basis: v^=basis[j]
            else: basis[j]=v; break
    return len(basis)
rowschecked=0
for k in range(1,9):
    m=1<<k
    for r in range(k+1):
        rows=[]
        for u in range(m):
            mask=1
            for j in range(1,r+1):
                for S in range(1,m):
                    if S.bit_count()!=j: continue
                    bit=1<<(S.bit_length()-1)
                    if u&bit and ((mask>>(S^bit))&1): mask ^=1<<S
            exp=sum(1<<S for S in range(m) if S.bit_count()<=r and S&u==S)
            assert mask==exp
            rows.append(mask)
        assert gf2rank(rows)==sum(comb(k,j) for j in range(r+1))
        rowschecked+=len(rows)
print(rowschecked,'native shear row masks and all binomial ranks for k<=8 verified')

I,X,Y,Z=[np.array(v,complex) for v in ([[1,0],[0,1]],[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]])]
H=(X+Z)/np.sqrt(2)
Smat=np.diag([1,1j])
def tp(ms):
    a=np.ones((1,1),complex)
    for b in reversed(ms): a=np.kron(a,b)
    return a
def basis(n):
    count=1<<n
    return {(x,z):tp([{(0,0):I,(1,0):X,(0,1):Z,(1,1):Y}[((x>>j)&1,(z>>j)&1)] for j in range(n)]) for x in range(count) for z in range(count)}
def get_expansion(A,B):
    dim=A.shape[0]
    return [(v,np.trace(mat@A)/dim) for v,mat in B.items() if abs(np.trace(mat@A)/dim)>1e-7]
def Dmat(es): return tp([np.diag([1,np.exp(np.pi*1j*e/4)]) for e in es])
def clifford(n):
    d=1<<n
    U=np.identity(d,dtype=complex)
    for _ in range(7):
        i=rng.randrange(n)
        if n>1 and rng.randrange(3)==0:
            j=rng.choice([j for j in range(n) if j!=i])
            op=np.zeros((d,d))
            for a in range(d): op[a^((((a>>i)&1)<<j)),a]=1
        else:
            gs=[I]*n
            gs[i]=rng.choice([H,Smat])
            op=tp(gs)
        U=op@U
    return U

recovered=0
for n in (1,2,3):
    B=basis(n)
    for es in product((-1,0,1),repeat=n):
        D=Dmat(es)
        for (x,z),P in B.items():
            A=D.conj().T@P@D
            for i in range(n):
                bit=1<<i
                assert np.allclose(A@B[0,bit]@A.conj().T,(-1 if x&bit else 1)*B[0,bit])
                qx=int(bool(x&bit)); qz=int(bool(z&bit))
                xb=B[bit,0]@B[0,bit*int(es[i]!=0)*qx]
                assert np.allclose(A@B[bit,0]@A.conj().T,1j**(2*qz-es[i]*qx)*xb)
                recovered+=1
print(recovered,'two-signed-generator inverse label checks')
one=two=0
for n in (1,2,3):
    B=basis(n)
    for _ in range(90):
        es=[rng.choice((-1,0,1)) for i in range(n)]
        D=Dmat(es)
        C=clifford(n)
        for i in range(n):
            for probe in ((1<<i,0),(0,1<<i)):
                L=C@D.conj().T@B[probe]@D@C.conj().T
                Q=D@L@D.conj().T
                if len(get_expansion(Q,B))!=1: continue
                terms=get_expansion(L,B)
                (x,z),s=terms[0]
                ss=int(s.real<0)
                if len(terms)==1:
                    assert np.allclose(Q,(-1)**ss * B[x,z]); one+=1
                else:
                    assert len(terms)==2
                    (bx,bz),t=terms[1]
                    tt=int(t.real<0)
                    assert x==bx and (bz^z).bit_count()==1
                    sb=sum(((x>>j)&1)*(((z>>j)&1)+int(es[j]<0)) for j in range(n) if es[j])%2
                    choose_b=(tt==(ss^sb))
                    assert np.allclose(Q,(-1)**(tt if choose_b else ss)*B[(bx,bz) if choose_b else (x,z)])
                    two+=1
print(one,'singleton and',two,'double-branch signed middle-Clifford readouts')
tests=0
n=3; B=basis(n)
ccz=np.diag([1.0]*7+[-1.0])
for _ in range(5):
    F=clifford(n)@ccz@clifford(n)
    for (x,z),Q in B.items():
        C=F.conj().T@Q@F
        for j in range(n):
            for g in ((1<<j,0),(0,1<<j)):
                J=F.conj().T@B[g]@F
                coeffs=dict(get_expansion(J,B))
                b=next(iter(coeffs))
                (v,sgn),=get_expansion(C.conj().T@B[b]@C,B)
                exponent=((x&g[1])^(z&g[0])).bit_count()%2
                assert np.allclose(sgn*coeffs[v]/coeffs[b],(-1)**exponent)
                tests+=1
print(tests,'projective Pauli coordinate extractions with entangling adjoint-C3 decoders')

# General relative phase formula for a diagonal with weighted degree <=3.
diagtests=0; loops=0
for n in (2,3,4):
    N=1<<n; B=basis(n)
    omega=np.exp(1j*np.pi/4)
    for _ in range(35):
        coefficients={t:(1<<(t.bit_count()-1))*rng.randrange(8) for t in range(1,N) if t.bit_count()<=3}
        f=[sum(c for t,c in coefficients.items() if (a&t)==t)%8 for a in range(N)]
        D=np.diag([omega**z for z in f])
        for _ in range(13):
            x,z=rng.randrange(N),rng.randrange(N)
            Q=B[x,z]
            A=D.conj().T@Q@D
            for j in range(n):
                a=1<<j
                zz=A@B[0,a]@A.conj().T
                assert np.allclose(zz,(-1)**int(bool(x&a))*B[0,a])
                xx=A@B[a,0]@A.conj().T
                extracted=xx[x^a,x]*omega**(-(f[a]-f[x^a]-f[0]+f[x]))
                assert np.isclose(extracted,(-1)**int(bool(z&a)))
                diagtests+=1
            # Literal Gaussian-loop correction of an intervening genuinely cubic diagonal.
            # If C itself is a computational XZ Pauli or Z-diagonal S, K=D C D† is Clifford.
            L=B[rng.randrange(N),rng.randrange(N)]
            K=D@L@D.conj().T
            a=1<<rng.randrange(n)
            J=D.conj().T@B[a,0]@D
            desired=K@B[a,0]@K.conj().T
            (v,sgn),=get_expansion(desired,B)
            E=(D.conj().T@B[v]@D).conj().T@L@J@L.conj().T
            assert np.allclose(E,sgn*np.eye(N))
            loops+=1
print(diagtests,'weighted cubic mask bits and',loops,'literal signed Gaussian middle loops')
