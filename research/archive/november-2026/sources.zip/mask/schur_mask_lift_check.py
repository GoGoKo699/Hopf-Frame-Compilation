"""Finite translated-bank and constant-density scalar checks."""
from itertools import product, combinations
from random import Random
from math import sqrt
import numpy as np
rng=Random(34688)
count=0
for s in range(1,7):
    for _ in range(400):
        w=8
        a=rng.randrange(1<<w)
        bank=[rng.randrange(1<<w) for i in range(s)]
        saved=bank[:]
        selected=[[rng.randrange(w) for i in range(s)] for j in range(5)]
        output=[0]*len(selected)
        gray=[t^(t>>1) for t in range(1<<s)]+[0]
        for t,next_t in zip(gray,gray[1:]):
            for j,indices in enumerate(selected):
                output[j]^=int(all((z>>i)&1 for z,i in zip(bank,indices)))
            l=(t^next_t).bit_length()-1
            bank[l]^=a
        expected=[int(all((a>>i)&1 for i in indices)) for indices in selected]
        assert bank==saved and output==expected
        count+=1
print(f'{count} mixed finite-difference banks, all outputs and borrowed returns')
def gf2rank(words):
    basis={}
    for w in words:
        while w:
            i=w.bit_length()-1
            if i not in basis:
                basis[i]=w
                break
            w^=basis[i]
    return len(basis)
for n in (1,2,3,4):
    for s in (1,2,3):
        d=1<<n
        if d**s>1000:
            continue
        features=[]
        for t in product(range(d),repeat=s):
            features.append(sum(1<<(i*d+b) for i,b in enumerate(t)))
        assert gf2rank(features)==1+s*(d-1)
        columnProducts=[sum((all((word>>(i*d+c))&1 for i,c in enumerate(ix)))<<j for j,word in enumerate(features)) for ix in product(range(d),repeat=s)]
        assert gf2rank(columnProducts)==d**s
print("block-mask rank and full lifted rank checked on feasible grids through k=9")
syndromes=0
for k in (1,2,3):
    m=1<<k
    for u in range(m):
        for w in range(1<<m):
            indices=[i for i in range(m) if (w>>i)&1]
            idx=u
            for i in indices: idx^=i
            detected=(len(indices)%2!=1) or (idx!=0) or any(True for _ in combinations(indices,2))
            assert detected==(w!=1<<u)
            syndromes+=1
print(f"{syndromes} one-hot quadratic syndrome checks")
# Check the weak-extractor first step, projectors on top eigenbasis outcomes and the Gram bound.
for power in (1,2,3):
    local_dim=4
    x=np.eye(local_dim)
    h=np.array([[1.,1.],[1.,-1.]])/sqrt(2)
    h=np.kron(h,h)
    z=np.diag([1.,1.,1.,-1.])
    bases=[h,z@h]
    many=[]
    for f in bases:
        q=np.array([[1.]])
        for _ in range(power): q=np.kron(q,f)
        many.append(q)
    d=len(many[0])
    assert np.allclose(np.abs(many[0].T@many[1]),1/sqrt(d))
    keep=max(1,int(d**(1/3)))
    for _ in range(24):
        ps=[]
        for q in many:
            a=q[:,rng.sample(range(d),keep)]
            ps.append(a@a.T)
        assert np.linalg.norm(sum(ps),ord=2)<=1+keep/sqrt(d)+1e-10
print('72 mutually unbiased restriction and concentration bounds')
from itertools import permutations
# Deterministic bank labels can coexist with coherent discarded output and arbitrary phases.
tested=0
for bank_map in permutations(range(4)):
    E=np.zeros((8,8),dtype=complex)
    for z in range(4):
        phi=np.exp(1j*(.163*z+.271))
        E[2*bank_map[z]:2*bank_map[z]+2,2*z:2*z+2]=phi*np.array([[1,1],[1,-1]])/sqrt(2)
    unit=np.kron(E,np.eye(4))
    cp=np.zeros((32,32))
    for z,w,t in product(range(4),range(2),range(4)):
        cp[(2*z+w)*4+(t^z),(2*z+w)*4+t]=1
    word=unit.conj().T@cp@unit@cp
    for z,w,t in product(range(4),range(2),range(4)):
        j=(2*z+w)*4+t
        wanted=(2*z+w)*4+(t^z^bank_map[z])
        assert abs(word[wanted,j]-1)<1e-10 and np.sum(np.abs(word[:,j]))<1+1e-10
        tested+=1
print(f'{tested} full columns for copying a definite label and reversing a coherent physical word')
def exact_syndrome(w,u,m,k):
    bits=[1^(w.bit_count()&1)]
    bits.extend(((w>>i)&1)*(((i^u)>>j)&1) for i in range(m) for j in range(k))
    return sum(b<<t for t,b in enumerate(bits))
checks=0
for k in range(1,4):
    m=1<<k
    for w in range(1<<m):
        for u in range(m):
            assert (exact_syndrome(w,u,m,k)==0)==(w==(1<<u))
            tail=rng.randrange(1<<(m*k+1))
            assert (exact_syndrome(w^((1<<m)-1),u,m,k)^exact_syndrome((1<<m)-1,u,m,k)^1)==exact_syndrome(w,u,m,k)
            checks+=1
print(f'{checks} deterministic one-hot syndrome and translated-source echo checks')
# Coherent quantized transition recording: direct matrix elements and exact norm upper bound.
count=0
for zbits in (2,3):
    dim=1<<zbits
    for _ in range(65):
        data=np.random.default_rng(rng.randrange(1<<24)).normal(size=(dim,dim))
        e=np.linalg.qr(data)[0]
        k=1 if zbits==2 else 2
        u=rng.randrange(zbits)
        desired=1<<u
        y=rng.randrange(dim)
        alpha=rng.randrange(dim)
        t=rng.randrange(1<<k)
        def passed(d):
            if d.bit_count()%2!=1: return False
            test=0
            for i in range(zbits):
                test^=((d>>i)&1)*((alpha>>i)&1)*(((t&(i^u)).bit_count())%2)
            return not test
        sr=np.zeros((dim,dim))
        bound=0.
        for d in range(dim):
            select=np.zeros_like(e)
            for z in range(dim): select[z^d,z]=e[z^d,z]
            if d!=desired and passed(d): bound+=np.linalg.norm(select,ord=2)
            if passed(d) and (((y&(d^desired)).bit_count())%2):
                sr+=select
        assert np.linalg.norm(sr,ord=2)<=bound+1e-10
        count+=1
print(f'{count} coherent bank transition/false-acceptance norm bounds')
