# Hopf frame compilation · What a shallow mask source must deliver

For a complete real Hopf frame or the prescribed phase-dressed complex magnitude frame on $n$ qubits, put $N=2^n$. At fixed error $2^{-L}$ and square-root dirty width, the best unconditional general T-depth remains $O_L(\log(n+2))$. The unrestricted lower bound remains constant. This work establishes two reductions to the complete indicator and rules out classes of candidate conjugators. It supplies no sublogarithmic source.

## An exact correction using the same dirty helper twice

Let $x$ have $k$ bits and $m=2^k$. Suppose an all-input circuit can add a shifted binary mask to an arbitrary bank. On a sector $σ$ of an arbitrary helper, the mask at address $q$ is the word with entries $h_σ(a+q)$. Its truth table can be unknown, can depend on $σ$, and need only have odd Hamming weight on each sector. The source must work on coherent addresses and all helper inputs, including superpositions of sectors.

Borrow a second arbitrary address $r$. Use the same physical helper to generate shifts at $r$ and $r+x$. In binary group convolution, unequal indices in a square cancel in pairs, and equal indices all contribute at zero. Thus
$$
 h_σ\star h_σ=e_0,\qquad
 (\tau_r h_σ)\star(\tau_{r+x} h_σ)=e_x.
$$
Four evaluations of the bilinear convolution at the corners of the two dirty-bank updates cancel both unknown bank origins. The result adds $e_x$ to the output and returns the banks, $r$, and the entire helper. The identity holds separately on every sector, giving the same operator on their coherent superpositions. The convolution uses the repository’s disjoint-subset multiplication after a fixed binary change of basis.

| Resource before indicator fusion | Cost of the complete correction |
|---|---|
| Calls to a returned shift or its actual inverse | 4 |
| Alternative calls if the raw source produces the prescribed bank value with arbitrary garbage elsewhere | 8, including actual inverses |
| Additional native T-depth | At most 160 |
| Additional T-count and dirty width | $O(m(k+1)^2)$ |
| Additional elementary Clifford gates | $O(m(k+1)^2)$ |
| Error from a raw source of full operator error $δ$ | At most $4δ$ for a returned shift, or $8δ$ with garbage removal |

The open operation is the **single coherent shifted-mask source**. An equivalent way to specify a strict source is a commuting family of Hermitian involutions $E_a$ on the same helper with product $-I$. Their eigenvalue bits have odd weight in every joint sector. One must implement the entire addressed product $\prod_a E_{a+q}^{y_a}$ on arbitrary $q,y$ within the resource budget. Individually cheap involutions give no such guarantee. For example, choosing $E_0=-I$ and all others identity already puts the whole lookup in the phase $(-1)^{y_q}$.

## How much agreement suffices without shift symmetry?

A different sufficient condition permits a native circuit to propose the wrong mask on most inputs. Suppose its designated output bank has a definite computational value for **every** computational input. Copying the new bank value and applying the actual inverse extracts its displacement relative to the input bank, even when the address moves and other outputs are quantum. Apply a fixed binary linear normalization to this displacement.

It suffices that the normalized displacement equals $e_x$ on **any fixed positive fraction of all address–workspace pairs**. The good addresses can depend on the workspace. Random address shifts and workspace offsets give proposals, and short parity tests detect wrong proposals. A common linear space of offsets makes the bad fraction small on every translated workspace. A coherent sampler then works on arbitrary dirty inputs and its reversal pays for their return. The proof uses the strong linear extractor recorded by Lin et al. and the metric uncertainty relation of Fawzi, Hayden and Sen. [Strong extractor, Lemma 4](https://drops.dagstuhl.de/storage/00lipics/lipics-vol124-itcs2019/LIPIcs.ITCS.2019.53/LIPIcs.ITCS.2019.53.pdf) · [Metric uncertainty, Theorem 2.5](https://arxiv.org/abs/1010.3007)

For a source of depth $d(k)$ with $m\operatorname{poly}(k)$ T-count and dirty width and $m^2\operatorname{poly}(k)$ elementary Clifford gates, the complete, zero-clean indicator depth is $O_{ρ,τ}(d(k)+(\log\log(k+4))^C)$ at each fixed error $τ$, for an absolute constant $C$. If the source is already a fully returned translation with independent masks on $ρm$ addresses, a fixed linear map sends those masks to their labeled unit vectors. In this case the additive depth sharpens to $O_{ρ,τ}(\log\log(k+4))$ by an independent random-submatrix estimate. The native source hypotheses and the uniform full-operator error are essential. [Random restriction estimate, Lemma 18](https://tropp.caltech.edu/papers/Tro08-Linear-Independence-preprint.pdf)

## The tested conjugator and the next native experiment

For $V_u^\dagger X_1 V_u$, fixed Clifford basis changes between $r$ affine-tableau shear stages produce mask coordinates of binary degree at most $r$ in the address. Their maximum possible row rank is exactly $\sum_{j=0}^{\min(k,r)}\binom{k}{j}$. Reaching even a fixed fraction of $m$ requires $r\ge k/2-O_ρ(\sqrt k)$. A separate test allows arbitrary address and work motion. With zero clean inputs, if the physical T rotation axes transported through the Clifford intervals are jointly linearly independent, the conjugated Pauli cannot approximate a nonconstant fully returned translation below error $\sqrt{2-\sqrt2}$, at any depth. A general native frame compiler may use different intermediate observables.

A concrete local experiment is to implement the exact read-only XOR of one trace bit of a finite-field inverse. Inside $\mathbb F_{2^{k+1}}$, choose $c\ne0$, take $H=\{z:\operatorname{Tr}(cz)=0\}$ and choose $d$ with $\operatorname{Tr}(dc)=1$. Set the inverse of zero to zero and define $g(z)=\operatorname{Tr}(d\,\mathrm{inv}_0(z))$. Comparing the constant and linear coefficients of the trace polynomial gives $\sum_{z\in H,\,z\ne0}1/z=c$. Hence $g$ has odd weight on $H$. Its $2^k$ translated copies already have full rank. All copies could run simultaneously if the address is accessed only by shareable Clifford controls and each copy has private targets. The experimental objective is a polynomial-size, exact, all-input native XOR with $o(\log k)$ T-depth. An ordinary field-multiplication tree costs order $\log k$ depth. Uniform constant error per local copy can add over the entire bank.

For a candidate with a shared quantum helper, test its raw output against a common family $h_σ$ of odd weight, and charge the whole addressed circuit and its actual inverse. The four-call correction then removes any need to determine that family or prepare its eigenbasis.

## Consequence for the final scaling

For the four-call construction or the positive-rank translation construction, let $d$ be a nondecreasing common native source-depth bound at the fixed tolerances requested by the compilation. Polynomial-overhead fusion and R98 give the following **conditional** complete-frame bound at each fixed $L$, for the repository’s eligible dirty allocations $b$.
$$
 D_T=O_L\!\left(\frac{N}{b^2}+d(2n+10)+\log\log(n+4)\right),\qquad
 T=O_L(\sqrt N+N/b),\qquad G=O_L(N).
$$
The same circuit uses one external clean qubit and returns the arbitrary dirty workspace within the full error. For the weaker joint-density condition the added log-log term can be raised to a fixed power. A constant-depth shifted-mask source would therefore yield $O_L(\log\log(n+4))$ at square-root dirty width. Optimality and the uniform growing-precision problem would remain open.

Repository baseline examined at commit ae613bf8e8a38f6d0407c25910b83d69f01a2733. [R96 resource frontier](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/OPEN_PROBLEM.md#large-width-t-depth) · [Polynomial-overhead fusion](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/POLYNOMIAL_OVERHEAD_INDICATOR_FUSION.md) · [Fixed-precision transfer](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/QUERY_DEPTH_FRAME_TRANSFER.md)
