"""Check the native path, entropy and low-active span estimates on finite physical words."""
from random import Random
from collections import defaultdict
from math import sqrt,log2
RNG=Random(201099)
def rank(vectors):
    pivots={}
    for v in vectors:
        while v:
            i=v.bit_length()-1
            if i in pivots: v^=pivots[i]
            else: pivots[i]=v; break
    return len(pivots)
def sp(p,q,n):
    mask=(1<<n)-1
    return (((p>>n)&q)^((q>>n)&p)).bit_count()%2
def coeff_sign(g,p,n):
    mask=(1<<n)-1
    q=p^g
    expo=(1+((g&mask)&(g>>n)).bit_count()+((p&mask)&(p>>n)).bit_count()
          +2*((g>>n)&p).bit_count()-((q&mask)&(q>>n)).bit_count())%4
    assert expo in (0,2)
    return 1 if expo==0 else -1
def commute_band(n,num):
    arr=[1<<i for i in RNG.sample(range(n),num)]
    for _ in range(5):
        g=RNG.randrange(1,1<<(2*n))
        arr=[x^g if sp(x,g,n) else x for x in arr]
    return arr
words=entropy=cuts=gains=0
for n in range(1,7):
    for _ in range(105):
        d=RNG.randint(1,4)
        bands=[commute_band(n,RNG.randint(1,min(n,3))) for _ in range(d)]
        seed=RNG.randrange(1,1<<(2*n))
        paths=[(seed,0,1.0,0,[])]
        axes=[];active_probs=[]
        for band in bands:
            for g in band:
                new=[]
                active=0.0
                for p,h,v,em,steps in paths:
                    if sp(p,g,n):
                        active+=2**(-h)
                        new.append((p,h+1,v/sqrt(2),em,steps))
                        new.append((p^g,h+1,v*coeff_sign(g,p,n)/sqrt(2),em|(1<<len(axes)),steps))
                    else: new.append((p,h,v,em,steps))
                paths=new; axes.append(g); active_probs.append(active)
            paths=[(p,h,v,em,steps+[p]) for p,h,v,em,steps in paths]
        sums=defaultdict(float);maxpath=defaultdict(float);aliases=defaultdict(int)
        for p,h,v,em,steps in paths:
            sums[p]+=v;maxpath[p]=max(maxpath[p],abs(v));aliases[p]+=1
        assert abs(sum(a*a for a in sums.values())-1)<1e-8
        s=len(axes)-rank(axes)
        assert max(aliases.values())<=2**s
        for p,val in sums.items():
            assert abs(val)<=maxpath[p]*2**s+1e-8
            gains+=1
        for H in range(len(axes)+1):
            subset=[v for v in paths if v[1]<=H]
            if not subset: continue
            prev=0
            for j in range(d):
                lab=[v[4][j] for v in subset]
                adim=rank([x^lab[0] for x in lab])
                assert adim<=prev+H*(prev+1)
                prev=adim
                cuts+=1
        if s==0:
            # Entropy of unique endpoints equals entropy of adaptive independent fair emissions.
            truth=-sum(v*v*log2(v*v) for v in sums.values() if v)
            assert abs(truth-sum(active_probs))<1e-7
            off=0
            for j,b in enumerate(bands):
                assert all(a==0 or a>=2**(-j)-1e-8 for a in active_probs[off:off+len(b)])
                off+=len(b)
            entropy+=1
        words+=1
print(f'{words} native conjugators, {cuts} low-active layer spans, {gains} coherent coefficient gains, {entropy} independent-axis entropies')

import numpy as np
from functools import reduce
from operator import xor
from math import pi, sin, cos

def matrix(g,n):
    mask=(1<<n)-1
    x=g&mask
    z=g>>n
    out=np.zeros((1<<n,1<<n),complex)
    base=1j**((x&z).bit_count())
    for b in range(1<<n):
        out[b^x,b]=base*(-1)**((z&b).bit_count())
    return out

involutions=0
for n in range(1,4):
    for _ in range(80):
        bands=[commute_band(n,RNG.randint(1,n)) for _ in range(RNG.randint(1,4))]
        seed=RNG.randrange(1,1<<(2*n))
        effective=next((j for j,b in enumerate(bands) if any(sp(g,seed,n) for g in b)),None)
        if effective is None: continue
        comb=reduce(xor,(g for g in bands[effective] if sp(g,seed,n)))
        future=[g for b in bands[effective+1:] for g in b]
        if rank(future+[comb])==rank(future): continue
        h=next(p for p in range(1<<(2*n)) if sp(p,comb,n) and all(not sp(p,g,n) for g in future))
        op=matrix(seed,n)
        for band in bands:
            for g in band:
                rot=cos(pi/8)*np.eye(1<<n)+1j*RNG.choice([-1,1])*sin(pi/8)*matrix(g,n)
                op=rot@op@rot.conj().T
        conj=matrix(h,n)@op@matrix(h,n)
        assert np.max(np.abs(op@conj+conj@op))<1e-12
        involutions+=1
x,z=matrix(1,1),matrix(2,1)
rot=cos(pi/8)*np.eye(2)+1j*sin(pi/8)*z
assert abs(np.linalg.norm(rot@x@rot.conj().T-x,2)-sqrt(2-sqrt(2)))<1e-12
print(f'{involutions} native first-band involution witnesses, sharp one-wire operator threshold')
