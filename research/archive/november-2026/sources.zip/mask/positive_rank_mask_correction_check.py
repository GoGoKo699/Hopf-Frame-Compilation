from fractions import Fraction
from itertools import product
from math import comb, sqrt
import numpy as np

def dot(u,v):
    return (u & v).bit_count() % 2

checked=0
for k in range(1,4):
    m=1<<k
    for x in range(m):
        for z in range(1<<m):
            # Compress each independent a-mask average analytically: fair iff nonzero.
            filtered=[sum((1<<i) for i in range(m) if (z>>i)&1 and dot(w,i^x)) for w in range(m)]
            reject=Fraction(sum(bool(v) for v in filtered),2*m)
            if z.bit_count()%2==0:
                reject=1
            assert (reject==0)==(z==(1<<x))
            if reject: assert reject>=Fraction(1,4)
            checked+=1
print(checked,'pointwise one-sided Frobenius-free parity validators, exact soundness')

rng=np.random.default_rng(9141)
z=np.array([[1,0],[0,1]],complex)
h=np.array([[1,1],[1,-1]],complex)/sqrt(2)
sy=np.diag([1,1j])@h
def tensor(m,n):
    out=np.ones((1,1),complex)
    for _ in range(n):
        out=np.kron(out,m)
    return out

matrices=0
for n in (2,3,4):
    D=1<<n
    bases=[tensor(b,n) for b in (z,h,sy)]
    for _ in range(20):
        masks=[rng.integers(0,2,D,dtype=np.int64) & rng.integers(0,2,D,dtype=np.int64) for j in range(3)]
        ps=[(u*m)@u.conj().T for u,m in zip(bases,masks)]
        mu=max(np.linalg.norm(ps[j]@ps[i],2) for i in range(3) for j in range(i+1,3))
        bad=np.zeros((D,D),complex)
        for bits in product([False,True],repeat=3):
            if sum(bits)<2: continue
            w=np.eye(D)
            for p,b in zip(ps,bits):
                w=(p if b else np.eye(D)-p)@w
            bad+=w.conj().T@w
        assert max(np.linalg.eigvalsh(bad))<= 7*mu**2+1e-12
        matrices+=1
print(matrices,'full three-basis postselected wrong-majority Gram operators')

# Test a deterministic low-rank source in dirty coordinates with bad rows containing mixed masks.
k=3
m=1<<k
pivots={1,4,6}
v=[(1<<x) if x in pivots else int(rng.integers(1,1<<m)) for x in range(m)]
cases=0
for u in range(m):
    for y in (0,1,6,87,143,255):
        for s in range(m):
            mask=sum(((y>>(i^s))&1)<<i for i in range(m))
            for dirty in range(1<<m):
                result=dot(mask,dirty)^dot(mask,dirty^v[u])
                assert result==dot(mask,v[u])
                if u in pivots: assert result==(y>>(u^s))&1
                cases+=1
print(cases,'complete character echoes on arbitrary initial feature words')

from itertools import product as cartesian
gates=0
for b,c,g,h,t in cartesian((0,1),repeat=5):
    x,y=b,c
    out=t
    for toggle in ('g','h','g','h'):
        out^=x&y
        if toggle=='g': x^=g
        else: y^=h
    assert (x,y,out)==(b,c,t^(g&h))
    gates+=1
print(gates,'returned bilinear Boolean subformula XOR words')
