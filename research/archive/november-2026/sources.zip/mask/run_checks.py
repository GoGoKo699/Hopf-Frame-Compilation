from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
for path in sorted(root.glob('*_check.py')):
    print(path.name, flush=True)
    subprocess.run([sys.executable, str(path)], check=True,
                   env=dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1'))
