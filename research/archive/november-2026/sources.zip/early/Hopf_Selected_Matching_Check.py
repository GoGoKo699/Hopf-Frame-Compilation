#!/usr/bin/env python3
"""Exact reproducibility checks for the five-bit selected XOR matching.

The default checks use Python 3.10+ and no third-party packages. Pass
--operator-check to also run the numerical gauge recovery, which uses NumPy.
A bank is a Python integer
whose bit u stores the qubit's computational basis value at wire u. An L-wire
ring lane uses the same convention with indices in Z/L. We check the literal
diagonal phase obtained after Hadamards on the output bank. These finite
checks simulate the indicated component words and binary phases, without
allocating a state vector for hundreds of borrowed qubits.
"""

import argparse
from itertools import product
from math import comb
from random import Random


P = 5
M = 1 << P
L = 1 << P.bit_length()
WORD_MASK = (1 << L) - 1
GRAY = (0, 1, 3, 2, 6, 7, 5, 4)
DENSE_CASES = 256
SEED = 20261119


def parity(word):
    return word.bit_count() % 2


def ring_rotate(word, amount):
    """Rotate eight physical wire indices; accept a signed integer amount."""
    amount %= L
    return ((word << amount) & WORD_MASK) | (word >> (L - amount))


def matching_sign(address, bank_a, bank_b):
    exponent = 0
    for wire in range(M):
        exponent ^= ((bank_a >> (wire ^ address)) & 1) * ((bank_b >> wire) & 1)
    return exponent


def cubic_phase(x, y, z, mask):
    """Eight native T/T-adjoint pulses. Return the exponent modulo eight."""
    initial = mask
    exponent = 0
    controls = (x, y, z)
    for i, vertex in enumerate(GRAY):
        exponent += (-1 if parity(vertex) else 1) * mask
        edge = vertex ^ GRAY[(i + 1) % len(GRAY)]
        mask ^= controls[edge.bit_length() - 1]
    assert mask == initial
    return exponent % 8


def toggle_from_phase(target, exp_at_zero, exp_at_one):
    # After the two Hadamards, phases (1, 1) give I and (1, -1) give X.
    assert exp_at_zero == 0 and exp_at_one in (0, 4)
    return target ^ (exp_at_one // 4)


def two_control_toggle(x, y, target, mask):
    return toggle_from_phase(target, cubic_phase(x, y, 0, mask),
                             cubic_phase(x, y, 1, mask))


def quartic_phase(x, y, z, w, borrowed, mask):
    """Dirty CCX, CCZ, actual inverse CCX, CCZ on the original borrowed bit."""
    initial = borrowed
    borrowed = two_control_toggle(x, y, borrowed, mask)
    exponent = cubic_phase(borrowed, z, w, mask)
    borrowed = two_control_toggle(x, y, borrowed, mask)
    assert borrowed == initial
    return (exponent + cubic_phase(borrowed, z, w, mask)) % 8


def three_control_toggle(controls, target, borrowed, mask):
    return toggle_from_phase(target, quartic_phase(*controls, 0, borrowed, mask),
                             quartic_phase(*controls, 1, borrowed, mask))


def check_local_echo():
    for x, y, z, mask in product(range(2), repeat=4):
        assert cubic_phase(x, y, z, mask) == 4 * x * y * z

    for bits in product(range(2), repeat=11):
        a, *rest = bits
        left, right = rest[:3], rest[3:6]
        r, t, borrowed, mask = rest[6:]
        original = (r, t)
        exponent = 0
        for axis in ('left', 'right', 'left', 'right'):
            # The middle acts as CZ on (r,t) when the bank parity a is one.
            exponent += cubic_phase(a, r, t, mask)
            if axis == 'left':
                r = three_control_toggle(left, r, borrowed, mask)
            else:
                t = three_control_toggle(right, t, borrowed, mask)
        assert (r, t) == original
        assert exponent % 8 == 4 * a * int(all(left)) * int(all(right))
    print('Gray and non-Pauli echo: 16 elementary phase cases, 2,048 occupied row cases')


def coset_terms():
    terms = []
    for subset in range(M):
        for base in range(M):
            if base & subset:
                continue
            wires = tuple(v for v in range(M) if (v & ~subset) == base)
            mask = sum(1 << v for v in wires)
            terms.append((subset, wires, mask))
    return terms


def check_coset_factorization(terms):
    assert len(terms) == 3**P
    for address in range(M):
        rows = [0] * M
        for subset, wires, mask in terms:
            if address & subset == subset:
                for u in wires:
                    rows[u] ^= mask
        for u in range(M):
            assert rows[u] == 1 << (u ^ address)
    counts = [comb(P, degree) * (1 << (P - degree)) for degree in range(P + 1)]
    t_cost = (0, 8, 48, 64, 112, 160)
    width = (0, 1, 3, 3, 4, 4)
    assert sum(c * t for c, t in zip(counts, t_cost)) == 8320
    assert sum(c * w for c, w in zip(counts, width)) == 484
    print('Coset expansion: 243 rows and 32,768 exact bilinear coefficients')
    print('Coset circuit bounds: 8,320 T gates, 160 T layers, 484 dirty helpers')


def ring_mul(a, b):
    """Product in the t basis modulo t^L, with coefficients in F_2."""
    out = 0
    while b:
        if b & 1:
            out ^= a
        a = (a << 1) & WORD_MASK
        b >>= 1
    return out


def matrix_mul(a, b):
    return tuple(tuple(ring_mul(a[i][0], b[0][j]) ^ ring_mul(a[i][1], b[1][j])
                       for j in range(2)) for i in range(2))


def check_ring_cell():
    # The integer 2 encodes t and 3 encodes q = 1+t in the t basis.
    t, q = 2, 3
    identity = ((1, 0), (0, 1))
    v, u = ((q, 1), (1, 1)), ((1, 1), (1, q))
    source = ((0, q), (1, t))
    power, q_power = identity, 1
    for _ in range(2 * L):
        diagonal = ((1, 0), (0, q_power))
        assert matrix_mul(matrix_mul(v, diagonal), u) == tuple(
            tuple(ring_mul(t, entry) for entry in row) for row in power)
        power = matrix_mul(power, source)
        q_power = ring_mul(q_power, q)
    assert q_power == 1 and power == identity


def lane_input(mode, bank_a):
    """Coefficients of sum_u A_u q^|u intersect mode| in the q basis."""
    result = 0
    for u in range(M):
        if (bank_a >> u) & 1:
            result ^= 1 << (u & mode).bit_count()
    return result


def lane_dual(mode, bank_b):
    """[t^p] q^j times B's transformed ring value, for all physical indices j."""
    result = 0
    for v in range(M):
        if (bank_b >> v) & 1:
            exponent = ((M - 1) ^ (mode | v)).bit_count()
            for j in range(L):
                # Lucas' identity gives [t^p](1+t)^n = 1 iff p is a submask of n.
                n = (exponent + j) % L
                if (n & P) == P:
                    result ^= 1 << j
    return result


def check_ring_factorization():
    check_ring_cell()
    # Each row bitset represents all B basis inputs in parallel.
    unit_a = [[lane_input(mode, 1 << u) for u in range(M)] for mode in range(M)]
    unit_b = [[lane_dual(mode, 1 << v) for v in range(M)] for mode in range(M)]
    masks = [[sum(((unit_b[mode][v] >> j) & 1) << v for v in range(M))
              for j in range(L)] for mode in range(M)]
    for address in range(M):
        for u in range(M):
            row = 0
            for mode in range(M):
                lane = ring_rotate(unit_a[mode][u], (address & mode).bit_count())
                # A single A basis value gives one active q-coordinate in its lane.
                assert lane.bit_count() == 1
                row ^= masks[mode][lane.bit_length() - 1]
            assert row == 1 << (u ^ address)
    print('Binary ring: 16 cell powers and 32,768 exact bilinear coefficients')


def shared_phase_layers(c, u, v):
    # Each pair of parities below is invertible on (u,v) at fixed c.
    return (((u, 1), (v, 1)),
            ((c ^ u, -1), (u ^ v, -1)),
            ((c ^ v, -1), (c ^ u ^ v, 1)))


def permute(word, index_map):
    return sum(((word >> j) & 1) << k for j, k in enumerate(index_map))


def check_reflection_batches():
    for c, layer in product(range(2), range(3)):
        destinations = set()
        for u, v in product(range(2), repeat=2):
            entries = shared_phase_layers(c, u, v)[layer]
            destinations.add(tuple(parity_value for parity_value, _ in entries))
        assert len(destinations) == 4
    for pairs in (1, 2):
        for inputs in product(range(2), repeat=2 * pairs + 1):
            c = inputs[0]
            exponent = pairs * c
            target = 0
            for i in range(pairs):
                u, v = inputs[2 * i + 1:2 * i + 3]
                target += 4 * c * u * v
                exponent += sum(value * sign for layer in shared_phase_layers(c, u, v)
                                for value, sign in layer)
            assert exponent % 8 == target % 8

    first = [(-i) % L for i in range(L)]
    second = [(1-i) % L for i in range(L)]
    native_step = [permute(permute(word, first), second) for word in range(1 << L)]
    for mode, address, initial in product(range(M), range(M), range(1 << L)):
        word = initial
        for i in range(P):
            if mode & address & (1 << i):
                word = native_step[word]
        assert word == ring_rotate(initial, (mode & address).bit_count())

    # Three remaining address coordinates, four actual permutation calls.
    # Each controls 16 lanes, with 3 swaps and then 4 swaps per selected lane.
    rotation_t = 4 * (P - 2) * 6 * (M // 2) * (3 + 4)
    # Four rank-at-most-32 linear masks, including one possible odd-rank T phase.
    assert rotation_t + 4 * (6 * M + 1) == 8836
    assert 4 * 2 * 3 * (P - 2) + 4 * 3 == 84
    print('Shared-control three-layer CCZ phase and 262,144 occupied rotation cases')
    print('Absorbed-mask ring bounds: 8,836 T gates, 84 T layers, 256 dirty lane wires')


def lane_echo(initial, amount, a, b):
    """Chronological F-adjoint, X, F, Z repeated twice; Z contributes a sign."""
    lane, exponent = initial, 0
    for _ in range(2):
        lane = ring_rotate(lane, -amount)
        lane ^= a
        lane = ring_rotate(lane, amount)
        exponent ^= parity(lane & b)
    assert lane == initial
    return exponent


def check_dense_cases(terms):
    rng = Random(SEED)
    for _ in range(DENSE_CASES):
        address = rng.randrange(M)
        bank_a, bank_b = rng.getrandbits(M), rng.getrandbits(M)
        reference = matching_sign(address, bank_a, bank_b)
        from_cosets = 0
        for subset, _, coset_mask in terms:
            if (address & subset) == subset:
                from_cosets ^= parity(bank_a & coset_mask) * parity(bank_b & coset_mask)
        assert from_cosets == reference
        lifted = [((address >> i) & 1) + 2 * rng.randint(-2 * L, 2 * L)
                  for i in range(P)]
        common_offset = rng.randint(-2 * L, 2 * L)
        plain = absorbed = lifted_plain = lifted_absorbed = 0
        for mode in range(M):
            initial = rng.getrandbits(L)
            a, b = lane_input(mode, bank_a), lane_dual(mode, bank_b)
            selected = mode & address
            plain ^= lane_echo(initial, selected.bit_count(), a, b)
            # First positive rotation moves to the X mask. The second moves, with
            # opposite sign, to the Z mask. The other coordinates rotate the lane.
            a1 = ring_rotate(a, selected & 1)
            b1 = ring_rotate(b, -((selected >> 1) & 1))
            absorbed ^= lane_echo(initial, (selected & ~3).bit_count(), a1, b1)

            contributions = [n if mode & (1 << i) else 0 for i, n in enumerate(lifted)]
            lifted_plain ^= lane_echo(initial, common_offset + sum(contributions), a, b)
            lifted_absorbed ^= lane_echo(initial, common_offset + sum(contributions[2:]),
                                         ring_rotate(a, contributions[0]),
                                         ring_rotate(b, -contributions[1]))
        assert plain == absorbed == lifted_plain == lifted_absorbed == reference
    print(f'Dense full banks: {DENSE_CASES} seeded cases with literal sign, dirty-lane return,')
    print('  mask absorption, parity-preserving integer lifts, and common lane offsets')



def subset_transform(values):
    """Binary subset zeta transform, also its own inverse (ANF coefficients)."""
    result = list(values)
    size = len(result)
    bit = 1
    while bit < size:
        for mode in range(size):
            if mode & bit:
                result[mode] ^= result[mode ^ bit]
        bit <<= 1
    return result


def gauge_admissible(p, address, shifts):
    """Check the degree bound independently for every binary shift digit."""
    size = 1 << p
    for k in range(p.bit_length()):
        cutoff = 1 << k
        difference = [
            ((shifts[mode] ^ (address & mode).bit_count()) >> k) & 1
            for mode in range(size)
        ]
        coeffs = subset_transform(difference)
        if any(c and subset.bit_count() >= cutoff for subset, c in enumerate(coeffs)):
            return False
    return True


def make_matching_checker(p):
    """Build a direct bilinear-coefficient comparator for arbitrary lane-shift tables."""
    size = 1 << p
    lane_size = 1 << p.bit_length()
    modes = range(size)
    # For a unit input u, the A-side transform is q^|T intersect u|.
    # A unit B input v contributes q^|complement(T union v)| on the other side.
    # Each bit of this table is [t^p] in the product after a q^index shift.
    b_rows = [
        [sum((1 << v) for v in modes
             if ((index + ((size - 1) ^ (mode | v)).bit_count()) & p) == p)
         for index in range(lane_size)]
        for mode in modes
    ]

    def matches(address, shifts):
        for u in modes:
            row = 0
            for mode in modes:
                index = (shifts[mode] + (mode & u).bit_count()) % lane_size
                row ^= b_rows[mode][index]
            if row != (1 << (u ^ address)):
                return False
        return True

    return matches


def check_gauge_characterization():
    p = 2
    size = 1 << p
    exhaustive = accepted = 0
    matches = make_matching_checker(p)
    for address in range(size):
        for shifts in product(range(1 << p.bit_length()), repeat=size):
            admissible = gauge_admissible(p, address, shifts)
            assert matches(address, shifts) == admissible
            exhaustive += 1
            accepted += int(admissible)
    assert (exhaustive, accepted) == (1024, 64)
    print('Shift gauge at two bits: all 1,024 address/table cases; 64 accepted')

    rng = Random(SEED + 1)
    allowed = forbidden = 0
    for p in (3, 5):
        size = 1 << p
        matches = make_matching_checker(p)
        # Every address occurs. Each trial draws fresh lower-degree polynomials.
        for trial in range(2 * size):
            address = trial % size
            shifts = [(address & mode).bit_count() for mode in range(size)]
            for k in range(p.bit_length()):
                cutoff = 1 << k
                coefficients = [rng.getrandbits(1) if subset.bit_count() < cutoff else 0
                                for subset in range(size)]
                corrections = subset_transform(coefficients)
                shifts = [h ^ (delta << k) for h, delta in zip(shifts, corrections)]
            assert gauge_admissible(p, address, shifts) and matches(address, shifts)
            allowed += 1
            for k in range(p.bit_length()):
                cutoff = 1 << k
                subset = rng.choice([s for s in range(size) if s.bit_count() >= cutoff])
                corrupted = [h ^ ((1 << k) if (mode & subset) == subset else 0)
                             for mode, h in enumerate(shifts)]
                assert not gauge_admissible(p, address, corrupted)
                assert not matches(address, corrupted)
                forbidden += 1
    print(f'Shift gauge at three/five bits: {allowed} admissible tables; '
          f'{forbidden} single forbidden ANF coefficients rejected')


def check_operator_gauges():
    """Recover the two matching gauges without using their generating factors.

    These small dense-matrix fixtures inspect all input and output masks. The
    right gauge mixes the address coherently. The middle permutation moves the
    bank by that address. The left gauge can rotate an arbitrary private qubit.
    """
    try:
        import numpy as np
    except ImportError as exc:
        raise SystemExit('--operator-check requires NumPy.') from exc

    rng = np.random.default_rng(SEED + 4)

    def random_unitary(size):
        """Sample a complex unitary by QR with normalized diagonal phases."""
        gaussian = rng.standard_normal((size, size)) + 1j * rng.standard_normal((size, size))
        unitary, triangular = np.linalg.qr(gaussian)
        diagonal = np.diag(triangular)
        return unitary * (diagonal / np.abs(diagonal))

    def block_polar(matrix, groups):
        """Discard off-block entries, then take each diagonal block's unitary polar factor."""
        result = np.zeros_like(matrix)
        for group in groups:
            indices = np.ix_(group, group)
            left, _, right_adjoint = np.linalg.svd(matrix[indices])
            result[indices] = left @ right_adjoint
        return result

    def operator_norm(matrix):
        return np.linalg.svd(matrix, compute_uv=False)[0]

    for address_bits, private_dimension in ((1, 2), (2, 1)):
        wires = 1 << address_bits
        bank_words = 1 << wires
        dimension = wires * bank_words * private_dimension
        states = list(product(range(wires), range(bank_words), range(private_dimension)))
        identity = np.eye(dimension)

        def index(address, bank, private):
            return (address * bank_words + bank) * private_dimension + private

        def shifted_bank(address, bank):
            return sum(1 << (wire ^ address) for wire in range(wires) if bank & (1 << wire))

        def character(mask, value):
            return 1 - 2 * parity(mask & value)

        sectors = [[index(address, bank, private) for private in range(private_dimension)]
                   for address, bank in product(range(wires), range(bank_words))]
        frequencies = [[index(address, frequency, private)
                        for address, private in product(range(wires), range(private_dimension))]
                       for frequency in range(bank_words)]
        fourier_bank = np.array([[character(mask, bank) for bank in range(bank_words)]
                                 for mask in range(bank_words)]) / np.sqrt(bank_words)
        fourier = np.kron(np.eye(wires), np.kron(fourier_bank, np.eye(private_dimension)))

        permutation = np.zeros((dimension, dimension))
        for column, (address, bank, private) in enumerate(states):
            permutation[index(address, shifted_bank(address, bank), private), column] = 1
        left_gauge = np.zeros((dimension, dimension), dtype=complex)
        right_fourier_gauge = np.zeros_like(left_gauge)
        for group in sectors:
            left_gauge[np.ix_(group, group)] = random_unitary(len(group))
        for group in frequencies:
            right_fourier_gauge[np.ix_(group, group)] = random_unitary(len(group))
        exact_word = left_gauge @ permutation @ fourier @ right_fourier_gauge @ fourier
        address_sign = np.array([character(1, address) for address, _, _ in states])
        assert operator_norm(exact_word * address_sign - address_sign[:, None] * exact_word) > 0.5

        input_flips, selected_flips, output_signs = [], [], []
        for mask in range(bank_words):
            flip = np.zeros((dimension, dimension))
            for column, (address, bank, private) in enumerate(states):
                flip[index(address, bank ^ mask, private), column] = 1
            input_flips.append(flip)
            selected_flips.append(permutation @ flip @ permutation.T)
            output_signs.append(np.array([character(mask, bank) for _, bank, _ in states]))

        # A generic perturbation can couple the address to the bank and the private work.
        eigenvectors = random_unitary(dimension)
        angles = rng.permutation(np.linspace(-1, 1, dimension))
        for perturbation in (0.0, 0.00025, 0.00125, 0.00625):
            if perturbation:
                rotation = (eigenvectors * np.exp(1j * perturbation * angles)) @ eigenvectors.conj().T
                word = rotation @ exact_word
            else:
                word = exact_word
            actual_flips = [word @ flip @ word.conj().T for flip in input_flips]
            error = 0.0
            for mask, actual in enumerate(actual_flips):
                for dual, sign in enumerate(output_signs):
                    correction = np.array([character(dual, shifted_bank(address, mask))
                                           for address, _, _ in states])
                    # Right multiplication by actual^dagger preserves the norm.
                    defect = actual * sign - (sign * correction)[:, None] * actual
                    error = max(error, operator_norm(defect))
            assert error < 1 / 32

            # For each mask, read its private fiber at syndrome zero. Translation
            # sends that fiber to the required output syndrome in each address block.
            fibers = [block_polar(ideal.T @ actual, sectors)
                      for ideal, actual in zip(selected_flips, actual_flips)]
            recovered_left = np.zeros_like(word)
            for address, bank in product(range(wires), range(bank_words)):
                mask = shifted_bank(address, bank)
                source = sectors[address * bank_words]
                destination = sectors[address * bank_words + bank]
                recovered_left[np.ix_(destination, destination)] = fibers[mask][np.ix_(source, source)]

            remaining = permutation.T @ recovered_left.conj().T @ word
            recovered_right = fourier @ block_polar(fourier @ remaining @ fourier, frequencies) @ fourier
            recovered = recovered_left @ permutation @ recovered_right
            recovery_error = operator_norm(word - recovered)
            assert operator_norm(recovered_left.conj().T @ recovered_left - identity) < 1e-11
            assert operator_norm(recovered_right.conj().T @ recovered_right - identity) < 1e-11
            assert recovery_error <= 64 * error + 1e-12
            if perturbation == 0.0:
                assert max(error, recovery_error) < 1e-12
            print(f'Operator gauges, p={address_bits}, perturbation {perturbation:g}: '
                  f'{bank_words**2} mask pairs, maximal defect {error:.6g}, '
                  f'recovery distance {recovery_error:.6g}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--operator-check', action='store_true',
                        help='also run the small NumPy operator-norm gauge fixtures')
    options = parser.parse_args()
    if not __debug__:
        raise RuntimeError('Run this checker without -O to enable assertions.')
    check_local_echo()
    terms = coset_terms()
    check_coset_factorization(terms)
    check_ring_factorization()
    check_reflection_batches()
    check_dense_cases(terms)
    check_gauge_characterization()
    if options.operator_check:
        check_operator_gauges()
    print('All checks passed.')


if __name__ == '__main__':
    main()
