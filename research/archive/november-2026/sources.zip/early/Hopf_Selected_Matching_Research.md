# Selected matching on arbitrary dirty banks

**Research note · 19 November 2026.** Let $p\ge1$, $m=2^p$, and let $A,B$ be arbitrary $m$-qubit banks. A coherent $p$-bit address $s$ selects the binary translation $P_s e_i=e_{i\oplus s}$. The target is the literal phase
$$
F|s,A,B\rangle=(-1)^{B^\top P_s A}|s,A,B\rangle .
$$
All auxiliary qubits have arbitrary initial states and must return, including when entangled with a reference. The following are exact circuit identities on that space. Resource figures are constructive upper bounds. The five-bit counts calibrate two mechanisms and carry no optimality claim.

| Construction at $p=5$ | Native T layers, at most | T gates, at most | Dirty helpers | Clean helpers |
|---|---:|---:|---:|---:|
| Bank-controlled CZ on two moving helpers | 160 | 8,320 | 484 | 0 |
| Cyclic rails with two address controls absorbed into the bank masks | 84 | 8,836 | 256 | 0 |

## Why this phase is worth compiling

Hadamards on the $B$ bank turn $F$ into the shear $U_s:(A,B)\mapsto(A,B+P_s A)$. Conjugating a flip on $A_0$ by $U_s$ yields $X_{A_0}X_{B_s}$. Another $X_{A_0}$ removes the first flip. Hence a complete shear and its actual inverse implement the dirty indicator, including return of $A$. Two uses of a full-operator $\epsilon$ approximation cost at most $2\epsilon$. A sufficient discovery target allows $T,b=O_\epsilon(m\,\mathrm{poly}(p))$, $G=O_\epsilon(m^2\,\mathrm{poly}(p))$, and asks for $D_T=o(\log(p+2))$. The project's fusion and fixed-precision transfer theorems then apply. At fixed accuracy and square-root dirty width, R96 still gives the strongest unconditional general frame upper bound, $O(\log(n+2))$ in the number $n$ of frame qubits. [Resource frontier](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/OPEN_PROBLEM.md) · [Polynomial-overhead fusion](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/POLYNOMIAL_OVERHEAD_INDICATOR_FUSION.md) · [Approximate transfer](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/APPROXIMATE_QUERY_FRAME_TRANSFER.md)

## 1. A bank-controlled non-Pauli operation

Over $\mathbb F_2$ put $N_i=I+P_{e_i}$. For $S\subseteq[p]$, $N_S=\prod_{i\in S}N_i$ consists of all-ones blocks on cosets $C$ of the coordinate subspace supported on $S$. Therefore
$$
B^\top P_s A=\sum_{S,C}s_S a_C b_C,\qquad
s_S=\prod_{i\in S}s_i,\quad a_C=\bigoplus_{j\in C}A_j,\quad b_C=\bigoplus_{j\in C}B_j.
$$
At five bits the row counts by $|S|$ are $32,80,80,40,10,1$.

For $|S|\ge2$, keep $a=a_C$ as a bank control. Divide the remaining $|S|+1$ factors into two balanced groups with products $x,y$. On arbitrary helper bits $r,t$, apply $(-1)^{art}$ at four successive positions $(r,t),(r+x,t),(r+x,t+y),(r,t+y)$ and restore $t$. The accumulated exponent is $axy$. For $a=1$, the middle operation on the helpers is CZ. The identity holds for every value of both helpers and both banks.

A CCZ costs eight T gates in at most eight layers using one arbitrary mask $k$. Visit the eight parities $k\oplus(v_1a\oplus v_2b\oplus v_3c)$ in cyclic Gray order and apply T or its inverse with sign $(-1)^{|v|}$. The exponent modulo eight is $4abc$. Return the mask after the last visit. The control bits may themselves be parities computed directly into the mask by CNOT. Conjugating by H gives exact CCX. A triple-controlled X costs 32 T gates and 32 layers here. To see this, put its target in the H basis, compute $h\gets h\oplus ij$ by CCX into an arbitrary helper, apply CCZ on $(h,k',\text{target})$, undo the CCX and repeat the CCZ. This gives the quartic phase $(-1)^{ijk'\,\text{target}}$ independently of $h$. One private mask can be reused across these operations.

The rows of sizes zero and one use CZ and CCZ directly. For sizes zero through five the T costs per row are bounded by $0,8,48,64,112,160$, and private work by $0,1,3,3,4,4$. All T gates act on private wires in the mask implementation. The input bits are shared CNOT controls across rows. Thus the T layers align and the first row of the resource table follows. Shared-control Clifford gates still have an elementary gate cost.

**The scaling obstruction.** In any separated bilinear sum $\sum_j f_j(s)\ell_j(A)r_j(B)$ with linear bank forms, the coefficient matrix of the address monomial $s_S$ has rank $2^{p-|S|}$. Every row whose $f_j$ contains $s_S$ contributes rank at most one. Summing over $S$ gives at least $3^p$ incidences between monomials and rows. The coset expansion attains equality. Compiling each non-Clifford row independently therefore exceeds the relaxed T budget. Giving all those rows private work to run them in parallel also exceeds the relaxed width budget. The incidence bound permits sharing work inside other implementations of the functions $f_j$.

## 2. A factorization with one short rail per bank position

Let $L=2^{\lceil\log_2(p+1)\rceil}$, $R=\mathbb F_2[t]/(t^L)$ and $g=1+t$. The powers $1,g,\dots,g^{L-1}$ form a binary basis by triangularity, and $g^L=1$. A rail stores the $L$ coefficients in this basis. Multiplication by $g$ is a cyclic shift by one site. Treat a bit string as its subset of occupied indices. Define
$$
a_u=\sum_i A_i g^{|u\cap i|},\qquad
b_u=\sum_j B_j g^{p-|u\cup j|}.
$$
Then
$$
B^\top P_s A=[t^p]\sum_{u\subseteq[p]} b_u\,g^{|s\cap u|}\,a_u .
$$
For a pair of singleton inputs $A=e_i,B=e_j$, the sum factors as
$$
\prod_{k=1}^p\bigl(g^{1-j_k}+g^{s_k+i_k}\bigr).
$$
Each factor has zero constant term, and its linear coefficient is $1+j_k+s_k+i_k$ in $\mathbb F_2$. The coefficient of $t^p$ is consequently $[j=i\oplus s]$. Bilinearity proves the statement for all banks. This proof also explains a simple freedom in the rotations. Adding a common offset $d$ to every exponent and replacing each bit $s_k$ by any shared integer $c_k\equiv s_k\bmod2$ preserves the top coefficient. Negative powers are defined by $g^L=1$. The integers can depend on the coherent address and on unchanged computational helper labels.

**Physical circuit.** On the $m$ arbitrary rails apply the collective Pauli translation $X(a)$, using the fixed binary-linear map $A\mapsto a$. Let $d_u(k)=[t^p]b_u g^k$ for $0\le k<L$, so $Z(d)$ is a product of fixed bank-to-rail CZs controlled by $B$. These masks cost $O(m^2L)$ elementary Clifford gates. Let $W$ rotate each rail $u$ by $|s\cap u|$. The group commutator
$$
[W X(a) W^\dagger,Z(d)]=(-1)^{B^\top P_s A}I_{\rm rails}
$$
uses four occurrences of $W$ or its actual inverse. This follows from the binary pairing of the rotated X mask with the Z mask. It holds on occupied rails and needs no inverses of the bank-to-mask linear maps. A single uniform operator-norm $\delta$ approximation to the whole batched $W$ gives error at most $4\delta$ for the matching. This permits intermediate address motion. Separate lane estimates can accumulate across $m$ lanes and require a valid shared-address schedule.

**Five-bit native ledger.** A one-site turn on eight sites factors into the reflections $j\mapsto-j$ and $j\mapsto1-j$. For one address bit, 16 rails are active, hence the two simultaneous matchings have 48 and 64 transpositions. A simultaneous matching of $r$ swaps under one common control uses Clifford gates and $r$ common-control CCX gates with disjoint target pairs. Such a CCX batch costs $6r+(r\bmod2)$ T gates in at most three layers. For CCZ on $(c,x,y)$ use the usual mod-eight phase polynomial with positive terms $c,x,y,c\oplus x\oplus y$ and negative terms $c\oplus x,c\oplus y,x\oplus y$. Expose the parity pairs $(x,y)$, $(c\oplus x,x\oplus y)$ and $(c\oplus y,c\oplus x\oplus y)$ in successive Clifford bases. Each change is invertible on its two private bits for fixed $c$. The common $T^r$ on $c$ costs at most one T in the first band. Hadamards convert CCZ to CCX. This gives 672 T gates and six layers per controlled turn.

Absorb the first address bit's turn into $X(a)$, and the inverse of the second bit's turn into $Z(d)$. A modified mask is a fixed binary-linear map plus a single address bit times a second fixed binary-linear map. The second map has rank at most 32 since its input is one bank. Invertible changes of basis on the bank and rails reduce it to at most 32 independent input/output pairs, after which all basis changes are undone. Each masked X or Z therefore adds at most 193 T gates in three layers. Four masked operations and four passes over the three remaining address bits give $4(193+3\cdot672)=8{,}836$ T gates and $4(3+3\cdot6)=84$ layers. All masks act on the original banks and the 256 rail qubits. For general $p$, using the two reflections on each of the $p$ address directions gives the direct bound $O(p)$ T-depth, $O(pmL)$ T gates, $mL$ dirty rail qubits and $O(m^2L+pmL)$ elementary Cliffords without mask absorption.

## 3. Exactly which alternative shifts work?

Fix an address $s$. Let $h_s(u)\in\mathbb Z/L$ be any shift table. Write $h_{s,k}(u)$ for binary digit $k$, and $e_q$ for the elementary symmetric Boolean polynomial of degree $q$. The rail circuit realizes the full matching for this address **if and only if**, for every $q=2^k\le p$,
$$
h_{s,k}(u)=e_q(s_1u_1,\ldots,s_pu_p)+r_{s,k}(u),
\qquad \deg_u r_{s,k}<q .
$$
The lower-degree terms may depend arbitrarily on $s$. This criterion describes the entire freedom to replace exact rotations by other rotations in the same masks.

**Proof.** In the singleton-bank test, the two possible weights for one lane-index bit, at $u_i=0,1$, form one of four pairs $(1,1),(g,1),(1,g),(g,g)$. Their binary span is generated by the constant pair $(1,1)$ and by $t(1,0),t(0,1)$. Tensoring over positions shows that the full set of tests is equivalent to all tests $t^{p-j}$ times the indicator of a $j$-dimensional coordinate face. Subtract the ideal table and take $[t^p]$. On every $j$-face the parity of
$$
D_j(u)=\binom{h_s(u)}{j}+\binom{|s\cap u|}{j}\pmod2
$$
must vanish. This is equivalent to $\deg_u D_j<j$ for $1\le j\le p$, by the Boolean finite-difference characterization of degree. At $j=0$ the difference is identically zero. The second binomial is $e_j(s_iu_i)$ by counting subsets of occupied sites. For $j=2^k$ the first binomial is the $k$th binary digit. Conversely, in characteristic two $(1+t)^h$ factors as the product of $1+t^{2^k}$ over set bits of $h$. For composite $j$, its binomial coefficient is the product of the corresponding digits. In the difference of the actual and ideal products, each summand has at least one factor of degree strictly below its digit weight. Its total degree is therefore strictly below $j$. This proves sufficiency.

For a concrete failure, select exactly two address bits and replace every masked count by its parity. Set $A=B=e_0$. The difference in the generating polynomials is $t^2(1+g)^{p-2}=t^p$, so the scalar sign flips for every $p\ge2$.

There is also a sharp range bound. If $|s|=w$, the functions $\binom{h_s(u)}{j}\bmod2$ have distinct exact degrees $j=0,\ldots,w$, by the face conditions above. They are linearly independent and they all factor through $h_s$. Its range therefore has at least $w+1$ elements. Ordinary masked Hamming weight attains equality for every address.

**Consequence for a proposed rotation circuit.** For $q=2^k\le p$ and any $q$-site set $K$, sum $h_{s,k}(u)$ over the lane indices $u\subseteq K$. The lower-degree terms disappear and the answer is the address monomial $\prod_{i\in K}s_i$. Hence some lane's $k$th displacement digit has address degree at least $q$. An exact reversible XOR/Toffoli network with $d$ nonlinear layers computes bits of degree at most $2^d$ on fixed helper inputs. Even if it only outputs the permuted rails, initialize the witness lane to a single marked site and read digit $k$ by an XOR of output positions. The network therefore needs at least $\lfloor\log_2 p\rfloor$ nonlinear layers for any correct shift table. For a table depending on an additional unchanged helper label, fix that label in this argument. The proof bounds classical nonlinear layers for the rail-permutation task. Native Clifford+T circuits with intermediate basis changes, or a direct implementation of the complete commutator, remain open.

## 4. How short can a commuting binary rail be?

Consider a representation of the matching as a sum of bilinear lane pairings with address action $\prod_{i=1}^pG_i^{s_i}$ in each lane. Suppose the $G_i$ within a lane are commuting binary linear maps and their orders divide the same power of two $Q\ge2$. In a valid representation at least one lane has binary dimension
$$
D\ \ge\ Q^{\lfloor p/(Q-1)\rfloor}\bigl(1+(p\bmod(Q-1))\bigr).
$$
For the proof, set $A=B=e_0$. The matching sign exponent then has top address coefficient one. Thus in some lane $N_1\cdots N_pv\ne0$ with $N_i=I+G_i$, while $N_i^Q=0$. Among the nonzero monomials $N^\beta v$ choose the largest exponent vector in graded lexicographic order. Then $|\beta|\ge p$ and each coordinate is at most $Q-1$. Its divisors $N^\gamma v$, $0\le\gamma\le\beta$, are linearly independent. In any purported relation, multiply by $N^{\beta-\gamma_0}$ for its smallest surviving exponent $\gamma_0$. The chosen term survives and every other exponent is larger than $\beta$. Consequently $D\ge\prod_i(1+\beta_i)$. For a fixed sum this product is minimized by filling coordinates up to $Q-1$ one at a time, which gives the bound.

In particular a polynomial bound on every lane dimension forces $Q=\Omega(p)$. For $Q\le\sqrt p$ the logarithm of the dimension grows at least on the scale of $\sqrt p$. For larger $Q$, $\log Q\ge\tfrac12\log p$ implies $\lfloor p/(Q-1)\rfloor=O(1)$. The $L$-site power-of-two rail has the right order of period in this class. This statement concerns commuting actions of power-of-two order. It leaves odd-order actions and more general joint helper evolution available.

## 5. The observable that remains if one abandons rotations

There is an exact description of the larger search space for the four-visit construction. Keep $X(a(A))$ and $Z(d(B))$ fixed as in Section 2 and allow $W$ to be any unitary on address, rails, and private work. The circuit acts on the two input banks through those two masks. At $s=0$, the masks pair as $d(B)\cdot a(A)=B^\top A$. Thus a fixed CNOT change of basis identifies their actions with ordinary $X^A,Z^B$ on $m$ logical qubits, tensored with the identity on all other work. Take as first $m$ columns the vectors $a(e_i)$ and complete them by a basis of $\ker d^\top$, where the columns of the matrix $d$ are $d(e_j)$. This coordinate change costs at most $O((mL)^2)$ Cliffords and can also be used solely to describe the operator.

In these coordinates put $T_A=W X^A W^\dagger$, let $C_{A,B}$ be the address-diagonal sign $(-1)^{B^\top P_s A}$, and write $\Pi|s,y\rangle=|s,P_s y\rangle$. The following conditions are equivalent.

1. For every $A,B$, $T_A Z^B T_A^\dagger=C_{A,B}Z^B$ on the entire space.
2. $W=R\Pi V$, with $R$ block diagonal by computational address $s$ and logical word $y$, and $V$ commuting with every $X^A$. The blocks can act arbitrarily on remaining work. In particular $V$ can mix addresses inside a Fourier sector of $y$.

**Exact proof.** Compare conjugation of $Z^B$ by $T_A T_{A'}=T_{A+A'}$ in one and in two steps. This shows that $T_A$ commutes with all $C_{A',B}$. For $A'=e_0$, varying $B$ realizes every diagonal sign on the address. Hence $T_A$ preserves $s$ and translates $y$ by $P_s A$. Denote its remaining unitary action from fiber $(s,y)$ by $E_{A;s,y}$. The group law gives
$$
E_{A;s,y}E_{P_s^{-1}y;s,0}=E_{A+P_s^{-1}y;s,0}.
$$
Set $R_{s,y}=E_{P_s^{-1}y;s,0}$. This proves $T_A=R\Pi X^A\Pi^\dagger R^\dagger$, so $V=\Pi^\dagger R^\dagger W$ commutes with all $X^A$. Conversely these commutation and block conditions give the required signs directly.

**Fixed-error version.** Suppose the worst error in condition 1, over all $A,B$, is $\epsilon<1/32$ in operator norm. There is an exact word of the form in condition 2 within $64\epsilon$ of $W$, independently of $m$ and of the private dimension. To see this, the one-step/two-step comparison gives $\|[T_A,C_{A',B}]_{\rm add}\|\le3\epsilon$, where the additive commutator is $TS-ST$. Put $U_A=\Pi X^A\Pi^\dagger$. Then $U_A^\dagger T_A$ commutes with all $Z^B$ up to $\epsilon$, and with all address signs up to $3\epsilon$. Average conjugations by these two commuting sign groups. This changes the unitary by at most $4\epsilon$ and makes it block diagonal in $(s,y)$. Within this algebra the polar unitary costs at most a further $4\epsilon$, by the singular-value bound. Multiplication by $U_A$ gives exact sector translations $\widehat T_A$ within $8\epsilon$ of $T_A$. Their group law has defect at most $24\epsilon$. Applying the preceding fiber argument at input $y=0$ gives a block $R$ with $\|T_A-R U_A R^\dagger\|\le32\epsilon$ for every $A$. Finally average $\Pi^\dagger R^\dagger W$ over $X^A$ and take its polar unitary. The two steps cost at most $64\epsilon$ together and deliver $V$. These are operator statements. Charging the controlled permutation and either block in isolation would discard the possible benefit of jointly synthesizing their product.

**Classical motion across arbitrarily many rails.** Suppose $W$ permutes computational basis states up to arbitrary phases. Every observed commutator is diagonal with signs, so full error below two forces exact equality. Write its output address and tested logical word on input $(y,r)$ as $(\sigma(y,r),z(y,r))$, where $r$ includes input address and all other work. By the exact proof, shifting $y$ by any $A$ before $W$ leaves the output address fixed and adds $P_{\sigma}A$ to the output word. Thus $\sigma$ depends only on $r$, and $z(y,r)=z(0,r)+P_{\sigma(r)}y$. As the complete basis map is a bijection, every output address has a balanced fiber of relative size $2^{-p}$ in $r$. Each fiber indicator has degree at least $p$ by the binary minimum-weight bound. Indeed a nonzero Boolean polynomial of degree $d$ is one on at least a $2^{-d}$ fraction of the cube, as follows by differentiating in a variable of a top monomial and inducting. Now the derivative of $z_j$ in $y_k$ is the fiber indicator $[\sigma(r)=j\oplus k]$. Each $z_j$ therefore has degree at least $p+1$. This argument allows $W$ to move the address and mix all rails, and implies at least $\lceil\log_2(p+1)\rceil$ layers in a realization by quadratic reversible Boolean rounds with affine interlayers. It leaves the native T-depth of quantum implementations of such endpoints open.

For a first exact candidate, suppose $W$ preserves address and uses just the $m$ tested qubits. Then its two blocks in condition 2 are phases in their respective bases. In the mixed basis put $M_s(y,k)=2^{m/2}\langle y|W_s H^{\otimes m}|k\rangle$. All entries must have modulus one, and a directly checkable condition is
$$
M_s(y,k)M_s(y+a,k+b)\overline{M_s(y+a,k)}\,\overline{M_s(y,k+b)}
=(-1)^{a^\top P_s b}.
$$
Taking $a=e_i,b=e_j$ gives a negative sign precisely at $j=i\oplus s$. Conversely these elementary rectangles, together with unit modulus, fix $M_s$ up to row and column phases. This follows by dividing out the target character and integrating the now-trivial mixed differences. This provides a specific amplitude calculation for exact candidates. The fixed-error test is the operator relation above, since each unnormalized matrix element has size $2^{-m/2}$.

## 6. A limit on a pair of complementary cubic phase operations

Consider a different candidate for the full matching sign. For fixed data $z=(s,A,B)$, let $K=H^{\otimes h}D_fH^{\otimes h}$ and $J=D_r$ act on $h$ arbitrary helpers, where $D_f|w\rangle=(-1)^{f(z,w)}|w\rangle$ and $D_r$ is defined similarly. Assume both Boolean polynomials have total degree at most three in the data and helper bits together. If $[K,J]$ approximates $(-1)^{b(z)}I$ at uniform operator error below $1/2$, the scalar identity is exact and $\deg b\le5$. This excludes the five-bit matching from this choice of two complete pulses. On singleton bank supports its exponent contains $A_0B_0\prod_i(1+s_i)$ of degree seven.

**Rounding and removal of cubic helper terms.** At fixed $z$, expand the Fourier-basis operation in shifts using the Walsh coefficients of its sign. Equivalently conjugate the word by $H^{\otimes h}$ so that $D_f$ is diagonal. The normalized squared Hilbert–Schmidt discrepancy is $4\Pr[\Delta_a f(w)\ne b]$, for $w$ uniform and $a$ distributed as the squared Walsh coefficients of $(-1)^r$. The shifts with $\Delta_a f\equiv b$ form an affine subspace, or the empty set. Each bad shift violates the equality on at least a quarter of all $w$ by the minimum-weight bound for a nonzero quadratic. If any Fourier weight lies outside the good affine space, some affine equation defining it has positive violation weight. Walsh autocorrelation identifies that weight with the probability that a derivative of $r$ differs from a constant, again at least a quarter. An empty good set also gives the bound. Thus any nonexact instance has operator error at least $1/2$.

The third helper-difference tensor of $f$ is fixed across $z$ by the total-degree hypothesis. Every shift with constant derivative of $f$ lies in its radical. So the Fourier support of $(-1)^r$ lies in that fixed radical. Choose a complementary linear basis for the helpers. The part of $f$ cubic in helpers has a representative $f_c$ using only the complementary coordinates, since the cubic coefficients are given by the third differences. Its Fourier-basis phase commutes with $J$, whose translations in that basis all preserve the complementary coordinates. Remove this commuting factor from $K$. Repeat for $r$ with the modified $K$. The remaining polynomials are helper-quadratic and still have total degree at most three. Strip their data-only constants, which cancel from the commutator.

**Bounding the sign.** Let $E,F$ be the two helper polar matrices. Comparing the symplectic actions of the two Clifford shears gives $EF=FE=0$, since their commutator is scalar. Comparing $\langle+^{\otimes h}|KJ|0^h\rangle$ with the reverse order gives the normalized Gauss sum
$$
(-1)^b=2^{-h}\sum_{x,y}(-1)^{f(x)+x^\top y+r(y)} .
$$
Its polar matrix is $\left(\begin{smallmatrix}E&I\\I&F\end{smallmatrix}\right)$ with inverse $S=\left(\begin{smallmatrix}F&I\\I&E\end{smallmatrix}\right)$. Represent the quadratic by the upper triangular $Q=Q_0+\operatorname{diag}\ell$ with zero diagonal on $Q_0$. The entries of $S,Q_0$ have data degree at most one and those of $\ell$ at most two. The binary Arf identity gives $b=c_2(SQ)+\binom h2\bmod2$, with $c_2$ the sum of principal two-by-two minors. Put $X=SQ_0$, $Y=S\operatorname{diag}\ell$. The mixed terms in $c_2(X+Y)$ have degree at most five. The pure $X$ terms have degree at most four. Since $S$ is symmetric alternating, $c_2(Y)=\sum_{i<j}S_{ij}^2\ell_i\ell_j$ also has degree at most five, using $S_{ij}^2=S_{ij}$ pointwise. [Proof of the binary Arf identity](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/GAUSSIAN_SCALAR_LOOP_OBSTRUCTION.md#2-a-basis-independent-formula-for-the-arf-sign)

Five is attained. On five helper sites indexed cyclically define $q(w)=\sum_i z_iw_iw_{i+1}$ and $v_i=z_{i+1}z_{i+3}$. In $q(w+v)+q(w)$ the terms linear in $w$ cancel, and each of the five edges contributes $\prod_i z_i$. The commutator of $D_q$ and translation by $v$ therefore gives that degree-five sign on all helpers. Its Fourier-basis phase exponent $x\cdot v$ is jointly cubic. The extra visits in Section 1 are essential to the scope of the comparison.

## Next research question

Can a low-T-depth native word exploit the freedom in $R\Pi V$? The concrete target is the conjugation in condition 1 at fixed accuracy with $T,b=O_\epsilon(m\,\mathrm{poly}(p))$ and $G=O_\epsilon(m^2\,\mathrm{poly}(p))$. The next experiment should let amplitudes interfere between computational basis states of the occupied work. For any proposed word, compute $W X^A W^\dagger$ and its commutator with every $Z^B$ on every work input, then cost the actual forward and inverse circuits together. Section 3 explains the cost retained by every alternative cyclic-shift table. Section 5 gives the test for a candidate that dispenses with those tables entirely. A direct synthesis of the full matching phase remains another way to reach the same indicator. The existing logarithmic dirty counter gives a comparison point. [Dirty sum compression](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/DIRTY_SUM_COMPRESSION.md)

The companion Python file runs exact finite checks of the five-bit constructions and of the shift-table characterization with the standard library. With the optional argument --operator-check and NumPy installed, it also checks numerical recovery of the two blocks in Section 5 for one and two address bits, across all bank masks and six perturbed circuits. The operator and all-size statements above rest on the displayed proofs. This research checkpoint uses the repository frontier at commit ae613bf8e8a38f6d0407c25910b83d69f01a2733.
