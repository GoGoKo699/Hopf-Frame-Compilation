#!/usr/bin/env python3
"""Verify the multiblock dirty-indicator fusion with only Python's standard library.

The operators in this fixture are monomial in the computational basis. We
track their permutations and their literal phase exponents modulo eight.
The all-size ledger is algebraic; finite checks exercise its conventions.
Run as: python Hopf_Indicator_Fusion_Check.py
"""

from dataclasses import dataclass
from itertools import product
from random import Random


def parity(word):
    return word.bit_count() & 1


def grid_xor(parent, program, child, row_count, column_count):
    """A grid of CCX gates, one for every row/column combination."""
    for row in range(row_count):
        if parent & (1 << row):
            child ^= program << (row * column_count)
    return child


def source_phase(address, program, private):
    return (1 + 3 * address + program.bit_count() + 2 * private
            + 2 * parity(address & program)) % 8


def program_source(address, program, private, columns, *, signed, inverse):
    """A signed source can scramble address and private work at its boundary.

    Its program always changes by exactly the input address's point vector.
    The inverse is synthesized by reversing all permutations and the phase.
    """
    if not signed:
        return address, program ^ (1 << address), private, 0
    if inverse:
        old_private = private ^ parity(program) ^ parity(address)
        old_address = address ^ (program & (columns - 1))
        old_program = program ^ (1 << old_address)
        return (old_address, old_program, old_private,
                -source_phase(old_address, old_program, old_private) % 8)
    phase = source_phase(address, program, private)
    new_program = program ^ (1 << address)
    new_address = address ^ (new_program & (columns - 1))
    new_private = private ^ parity(new_program) ^ parity(new_address)
    return new_address, new_program, new_private, phase


def split_node(parent, child, address, program, private, rows, columns,
               *, signed, inverse):
    """Use B,E,B,E† chronologically or execute its actual inverse."""
    if not inverse:
        child = grid_xor(parent, program, child, rows, columns)
    address, program, private, phase = program_source(
        address, program, private, columns, signed=signed, inverse=False)
    child = grid_xor(parent, program, child, rows, columns)
    address, program, private, last_phase = program_source(
        address, program, private, columns, signed=signed, inverse=True)
    if inverse:
        child = grid_xor(parent, program, child, rows, columns)
    return child, address, program, private, (phase + last_phase) % 8


def check_local_split():
    cases = 0
    for parent, child, address, program, private in product(
            range(4), range(16), range(2), range(4), range(2)):
        for signed, inverse in product((False, True), repeat=2):
            result = split_node(parent, child, address, program, private, 2, 2,
                                signed=signed, inverse=inverse)
            expected = grid_xor(parent, 1 << address, child, 2, 2)
            assert result == (expected, address, program, private, 0)
            cases += 1
    return cases


def check_program_probe():
    cases = moved = nontrivial_phases = 0
    for columns in (2, 4):
        for address, old, private, mask in product(
                range(columns), range(1 << columns), range(2), range(1 << columns)):
            new_address, new, new_private, phase = program_source(
                address, old, private, columns, signed=True, inverse=False)
            saved = program_source(new_address, new, new_private, columns,
                                   signed=True, inverse=True)
            assert saved == (address, old, private, -phase % 8)
            assert parity(mask & (new ^ old)) == (mask >> address) & 1
            moved += int(address != new_address)
            nontrivial_phases += int(phase != 0)
            cases += 1
    assert moved > 0 and nontrivial_phases > 0
    return cases


@dataclass
class Tree:
    widths: tuple
    addresses: list
    nodes: list
    programs: list
    private: list
    output: int
    phase: int

    def snapshot(self):
        return (tuple(self.addresses), tuple(self.nodes), tuple(self.programs),
                tuple(self.private), self.output, self.phase)

    def traversal(self, *, signed, inverse):
        layers = range(len(self.widths))
        for j in reversed(layers) if inverse else layers:
            columns = 1 << self.widths[j]
            rows = 1 << sum(self.widths[:j])
            data = split_node(self.nodes[j], self.nodes[j + 1], self.addresses[j],
                              self.programs[j], self.private[j], rows, columns,
                              signed=signed, inverse=inverse)
            self.nodes[j + 1], self.addresses[j], self.programs[j], self.private[j], phase = data
            self.phase = (self.phase + phase) % 8

    def root_difference(self, *, signed):
        self.traversal(signed=signed, inverse=True)
        self.nodes[0] ^= 1
        self.traversal(signed=signed, inverse=False)

    def fused_indicator(self, *, signed):
        # K=F X_root F† is its own actual adjoint. C is the leaf-copy CNOTs.
        self.output ^= self.nodes[-1]
        self.root_difference(signed=signed)
        self.output ^= self.nodes[-1]
        self.root_difference(signed=signed)


def check_trees():
    rng = Random(20261119)
    cases = 0
    for widths in ((1,), (1, 1), (1, 2, 1), (2, 1, 2), (1, 1, 1, 1, 1)):
        columns = [1 << bits for bits in widths]
        node_sizes = [1 << sum(widths[:j]) for j in range(len(widths) + 1)]
        for address_tuple in product(*(range(n) for n in columns)):
            address = 0
            for value, count in zip(address_tuple, columns):
                address = address * count + value
            for _ in range(16):
                for signed in (False, True):
                    state = Tree(widths, list(address_tuple),
                                 [rng.getrandbits(n) for n in node_sizes],
                                 [rng.getrandbits(n) for n in columns],
                                 [rng.getrandbits(1) for _ in widths],
                                 rng.getrandbits(node_sizes[-1]), rng.randrange(8))
                    before = state.snapshot()
                    state.fused_indicator(signed=signed)
                    after = state.snapshot()
                    assert after[:-2] == before[:-2] and after[-1] == before[-1]
                    assert after[-2] == before[-2] ^ (1 << address)
                    cases += 1
    return cases


def check_resource_normalization():
    cases = 0
    for exponent in (1, 2, 3, 5, 8):
        blocks = exponent + 1
        for bits in range(blocks, 181):
            q, remainder = divmod(bits, blocks)
            widths = [q + (i < remainder) for i in range(blocks)]
            bank_size = 1 << bits
            prefixes = [1 << sum(widths[:i+1]) for i in range(blocks)]
            raw_costs = [1 << (exponent * width) for width in widths]
            assert sum(prefixes) < 2 * bank_size
            assert sum(raw_costs) <= blocks * (1 << exponent) * bank_size
            # Eight child calls per boundary and eight grids of each prefix size.
            total_t = 8 * sum(raw_costs) + 64 * sum(prefixes)
            total_g = 8 * sum(raw_costs) + 80 * sum(prefixes) + 2 * bank_size + 8
            total_work = 1 + sum(prefixes) + max(
                (1 << width) + max(private, sites)
                for width, private, sites in zip(widths, raw_costs, prefixes))
            assert total_t <= (8 * blocks * (1 << exponent) + 128) * bank_size
            assert total_g <= (8 * blocks * (1 << exponent) + 170) * bank_size
            assert total_work <= (4 + (1 << exponent)) * bank_size + 1
            cases += 1
    return cases


def main():
    if not __debug__:
        raise RuntimeError("Run without -O so that all assertions are active.")
    print(f"All {check_local_split():,} two-by-two native-grid splitter cases passed.")
    print(f"All {check_program_probe():,} complete signed-source parity probes passed.")
    print(f"All {check_trees():,} end-to-end tree tests passed with literal phase and work return.")
    print(f"All {check_resource_normalization():,} finite resource ledgers passed.")


if __name__ == "__main__":
    main()
