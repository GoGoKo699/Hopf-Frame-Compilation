#!/usr/bin/env python3
"""Exact finite checks of two matching batches and the fixed spectral encoder.

Python 3.10+, standard library only. H has one abstract generator per nonzero
child address per block. The tests never allocate Hilbert vectors on the full
working banks. They compare every character of this finite abelian group using
arbitrary-precision integer multiplicities.
"""

from itertools import product
from random import Random


def binary_rank(columns):
    """Rank over F2; a packed word encodes a column over the standard basis."""
    pivots = {}
    for column in columns:
        while column:
            pivot = column.bit_length() - 1
            if pivot not in pivots:
                pivots[pivot] = column
                break
            column ^= pivots[pivot]
    return len(pivots)


def walsh_transform(values):
    """Unnormalized Walsh transform, in binary character-label order."""
    result = list(values)
    step = 1
    while step < len(result):
        for start in range(0, len(result), 2 * step):
            for i in range(start, start + step):
                left, right = result[i], result[i + step]
                result[i], result[i + step] = left + right, left - right
        step *= 2
    return result


def exact_multiplicities(traces):
    """Recover multiplicity of every joint sign character of a representation."""
    order = len(traces)
    transformed = walsh_transform(traces)
    assert all(value % order == 0 for value in transformed)
    multiplicities = [value // order for value in transformed]
    assert min(multiplicities) >= 0
    assert walsh_transform(multiplicities) == traces
    return multiplicities


def one_block_character_table(q):
    """For each product of child generators, compute its projected shift and rank."""
    modes = 1 << q
    entries = []
    for choice in range(1 << (modes - 1)):
        projection = 0
        columns = [0] * modes
        for label in range(1, modes):
            if choice & (1 << (label - 1)):
                projection ^= label
                for i in range(modes):
                    columns[i] ^= (1 << (i ^ label)) ^ (1 << i)
        rank = binary_rank(columns)
        assert not choice or rank >= 1
        assert not projection or rank == modes // 2
        entries.append((projection, rank))
    return entries


def check_representation(block_sizes, bank_count=1):
    """Check all h in H and all characters, including spectator integrality."""
    p = sum(block_sizes)
    modes = 1 << p
    logical_width = modes * bank_count
    local_modes = [1 << q for q in block_sizes]
    group_log_size = sum(count - 1 for count in local_modes)
    group_order = 1 << group_log_size

    # The first term makes every nontrivial kernel character small. The second
    # handles nonzero projected shifts and leaves room for the logical spectrum.
    copies = [
        max(group_log_size + 2,
            (logical_width // 2 + group_log_size + 2 + count // 2 - 1) // (count // 2))
        for count in local_modes
    ]
    half_width = sum(n * count for n, count in zip(copies, local_modes))
    width = 2 * half_width
    assert half_width >= logical_width + group_log_size

    local_tables = [one_block_character_table(q) for q in block_sizes]
    physical_trace = []
    logical_trace = []
    spectator_trace = []
    for h in range(group_order):
        remainder = h
        rank_cost = 0
        projected_nonzero = False
        for count, n, table in zip(local_modes, copies, local_tables):
            local_element = remainder & ((1 << (count - 1)) - 1)
            remainder >>= count - 1
            projection, rank = table[local_element]
            projected_nonzero |= projection != 0
            rank_cost += n * rank
        assert remainder == 0
        loss = logical_width // 2 if projected_nonzero else 0
        physical = 1 << (width - rank_cost)
        logical = 1 << (logical_width - loss)
        spectator, rest = divmod(physical, logical)
        assert rest == 0
        assert not h or rank_cost - loss >= group_log_size + 2
        physical_trace.append(physical)
        logical_trace.append(logical)
        spectator_trace.append(spectator)

    physical = exact_multiplicities(physical_trace)
    logical = exact_multiplicities(logical_trace)
    spectator = exact_multiplicities(spectator_trace)
    assert min(spectator) > 0
    assert sum(physical) == 1 << width
    assert sum(logical) == 1 << logical_width
    assert sum(spectator) == 1 << (width - logical_width)
    # Joint eigenvalue of a tensor product is an XOR. Only nonzero logical
    # character multiplicities contribute to this direct convolution check.
    active = [(i, value) for i, value in enumerate(logical) if value]
    assert all(physical[i] == sum(count * spectator[i ^ j] for j, count in active)
               for i in range(group_order))
    print(f'blocks {block_sizes}, p={p}, bulk banks d={bank_count}: checked {group_order} group elements and '
          f'{group_order} joint multiplicities, local copies {copies}, '
          f'{width} physical qubits before optional synthesis scratch')


def translate_wires(register, selector, modes):
    """Translate an occupied register's wire indices by XOR with selector."""
    return sum(((register >> i) & 1) << (i ^ selector) for i in range(modes))


def pairing(bank_a, bank_b):
    return (bank_a & bank_b).bit_count() & 1


def check_occupied_banks():
    # Verify the character of the logical permutation by counting its fixed
    # occupied words, and check its conjugation of the dense unselected phase.
    p, modes = 3, 8
    words = range(1 << modes)
    dense_count = 0
    for s in range(1 << p):
        fixed = sum(translate_wires(bank, s, modes) == bank for bank in words)
        assert fixed == 1 << (modes if s == 0 else modes // 2)
        for bank_b in words:
            moved = translate_wires(bank_b, s, modes)
            assert translate_wires(moved, s, modes) == bank_b
            for bank_a in words:
                reference = sum(((bank_b >> j) & 1) * ((bank_a >> (j ^ s)) & 1)
                                for j in range(modes)) & 1
                assert pairing(bank_a, moved) == reference
                dense_count += 1
    print(f'wire translation and known phase: {dense_count} occupied-bank cases')


def check_cocycle():
    # An arbitrary orientation for each outside, middle, and inside basis-change
    # permutation illustrates the normalized two-batch transport law. The two
    # batch representations need only be homomorphisms internally.
    perm_a = (1, 3, 2, 5, 7, 4, 6, 0)
    perm_b = (6, 7, 0, 5, 2, 1, 4, 3)

    def action(basis, label, word):
        return basis[basis.index(word) ^ label]

    def relative(label, word):
        return action(perm_a, label, action(perm_b, label, word))

    def inverse_relative(label, word):
        return action(perm_b, label, action(perm_a, label, word))

    for b, c, x in product(range(8), repeat=3):
        left = action(perm_a, c, relative(b, action(perm_a, c, x)))
        right = relative(b ^ c, inverse_relative(c, x))
        assert left == right
    print('two-batch transport identity: 512 noncommuting permutation instances')


def check_one_bit_source(p, bank_count):
    """The jth selector directly controls n independent CZs: no long child call."""
    modes = 1 << p
    logical_width = bank_count * modes
    log_ceil = (p - 1).bit_length()
    copies = logical_width // 2 + log_ceil
    physical_width = 2 * p * copies
    spectator_width = physical_width - logical_width
    physical_trace = []
    logical_trace = []
    spectator_trace = []
    for address in range(modes):
        physical = 1 << (physical_width - copies * address.bit_count())
        logical = 1 << (logical_width if not address else logical_width // 2)
        spectator, remainder = divmod(physical, logical)
        assert remainder == 0
        physical_trace.append(physical)
        logical_trace.append(logical)
        spectator_trace.append(spectator)

    physical = exact_multiplicities(physical_trace)
    logical = exact_multiplicities(logical_trace)
    spectator = exact_multiplicities(spectator_trace)
    assert min(spectator) == spectator[-1]
    assert (min(spectator) == 0) == (p == 1)
    assert sum(spectator) == 1 << spectator_width
    # Direct sign-character tensor multiplicities. This test uses integer
    # shifts for the largest examples to keep the verification lightweight.
    for label in range(modes):
        assert physical[label] == sum(logical[j] * spectator[label ^ j]
                                      for j in range(modes))
    print(f'one-bit CZ source p={p}, bulk banks d={bank_count}: '
          f'{modes} physical, logical, and spectator characters, '
          f'{copies} CZ pairs per selector, {physical_width} physical qubits')


def check_five_face_difference():
    """Two independent site translations duplicate a five-face into 128 sites."""
    for p in (7, 8):
        modes = 1 << p
        face = sum(1 << index for index in range(1 << 5))
        first = face ^ translate_wires(face, 1 << 5, modes)
        second = first ^ translate_wires(first, 1 << 6, modes)
        assert face.bit_count() == 32 and first.bit_count() == 64
        assert second == (1 << 128) - 1
        print(f'two site differences on a five-dimensional face at p={p}: '
              f'{second.bit_count()} occupied output sites')


def multiply_square_zero(left, right):
    """Elements are sets of square-free monomials; repeated variables give zero."""
    output = set()
    for a in left:
        for b in right:
            if a & b:
                continue
            term = a | b
            if term in output:
                output.remove(term)
            else:
                output.add(term)
    return output


def cube_product(flag_count, coefficients):
    """Multiply 1+sum f_j(b)x_{S_j} over all binary flag vectors b."""
    result = {0}
    for flags in range(1 << flag_count):
        factor = {0}
        for monomial, anf in coefficients:
            value = sum((flags & support) == support for support in anf) & 1
            if value:
                factor.symmetric_difference_update((monomial,))
        result = multiply_square_zero(result, factor)
    return result


def check_commuting_cube_product():
    rng = Random(20261119)
    flags = 5
    terms = [s for s in range(1 << flags) if s.bit_count() <= 2]
    trials = 0
    for variables in range(3, 8):
        for _ in range(40):
            # Include single-variable terms, repeated terms, and products.
            monomials = ([1 << i for i in range(variables)]
                         + [rng.randrange(1, 1 << variables)
                            for _ in range(variables)])
            factors = [(term, [s for s in terms if rng.getrandbits(1)])
                       for term in monomials]
            assert cube_product(flags, factors) == {0}
            trials += 1

    # Four flags give a nonidentity product at the boundary k=2 deg(f).
    four_flag_witness = [(1, [0b0011]), (2, [0b1100])]
    assert cube_product(4, four_flag_witness) == {0, 0b11}
    print(f'commuting square-zero algebra: {trials} five-flag quadratic cubes '
          'and one nonidentity four-flag boundary case')


def check_sparse_encoder():
    """Build every column of the 4096 by 4096 two-bit fixed change of basis.

    The logical part of a column is a signed integer vector on one orbit
    divided by the square root of its orbit size. Orthogonality and operator
    action within that same orbit can therefore be checked with integers.
    """
    p, modes, copies = 2, 4, 3
    width = 2 * p * copies
    physical_size = 1 << width
    spectator_size = 1 << (width - modes)
    spectator_trace = [
        (spectator_size if not address else
         1 << (width - modes + modes // 2 - copies * address.bit_count()))
        for address in range(modes)
    ]
    spectator_counts = exact_multiplicities(spectator_trace)
    assert spectator_counts == [132, 60, 60, 4]
    spectator_labels = [label for label, count in enumerate(spectator_counts)
                        for _ in range(count)]

    # Construct all logical invariant orbit subspaces and their real Walsh bases.
    logical_orbits = {}
    for word in range(1 << modes):
        translations = [translate_wires(word, shift, modes) for shift in range(modes)]
        if min(translations) != word:
            continue
        orbit = sorted(set(translations))
        stabilizer = [shift for shift, site in enumerate(translations) if site == word]
        vectors = []
        for label in range(modes):
            if any((shift & label).bit_count() % 2 for shift in stabilizer):
                continue
            vector = {site: (-1) ** ((label & shift).bit_count() % 2)
                      for shift, site in enumerate(translations)}
            assert set(vector) == set(orbit)
            vectors.append((label, vector))
        assert len(vectors) == len(orbit)
        for i, (_, v) in enumerate(vectors):
            for j, (_, w) in enumerate(vectors):
                assert sum(v[y] * w[y] for y in orbit) == (len(orbit) if i == j else 0)
        logical_orbits[word] = vectors
    assert sum(map(len, logical_orbits.values())) == 1 << modes

    # A target column's joint character is its orbit-Walsh label XOR the
    # independent spectator label. Group actual sparse columns accordingly.
    destinations = [[] for _ in range(modes)]
    for spectator, spectator_label in enumerate(spectator_labels):
        for representative, vectors in logical_orbits.items():
            for orbit_label, vector in vectors:
                destinations[orbit_label ^ spectator_label].append(
                    (spectator, representative, orbit_label, vector))
    mask = (1 << copies) - 1
    columns = []
    for source in range(physical_size):
        label = 0
        for bit in range(p):
            pair = source >> (2 * bit * copies)
            x, y = pair & mask, (pair >> copies) & mask
            label |= (((x & y).bit_count() % 2) << bit)
        columns.append((label, destinations[label].pop()))
    assert all(not group for group in destinations)
    # Across spectator and orbit blocks the supports are disjoint. The preceding
    # dot products check each repeated Walsh block; every column occurs once.
    assert len({(t, r, k) for _, (t, r, k, _) in columns}) == physical_size

    for address in range(modes):
        for source_label, (spectator, _, _, vector) in columns:
            source_sign = (-1) ** ((address & source_label).bit_count() % 2)
            spectator_sign = (-1) ** ((address & spectator_labels[spectator]).bit_count() % 2)
            # Compare V Q_s|source> to (Π_s⊗S_s)V|source> on every nonzero entry.
            transported = {translate_wires(y, address, modes): spectator_sign * value
                           for y, value in vector.items()}
            assert transported == {y: source_sign * value for y, value in vector.items()}
    print(f'explicit sparse encoder p=2: {physical_size} orthonormal columns, '
          f'{modes * physical_size} full input/address operator equalities')


def main():
    if not __debug__:
        raise RuntimeError('Run without -O so all exact checks are enabled.')
    check_representation((1, 1))
    check_representation((1, 2))
    check_representation((2, 2))
    check_representation((2, 2, 2))
    check_representation((3, 1))
    check_representation((2, 2, 2), bank_count=7)
    for p, d in ((1, 1), (1, 3), (2, 1), (3, 2), (5, 3), (7, 1), (8, 3)):
        check_one_bit_source(p, d)
    check_sparse_encoder()
    check_five_face_difference()
    check_commuting_cube_product()
    check_cocycle()
    check_occupied_banks()
    print('All checks passed.')


if __name__ == '__main__':
    main()
