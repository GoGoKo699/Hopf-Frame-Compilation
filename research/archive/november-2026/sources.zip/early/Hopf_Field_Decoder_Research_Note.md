# A logarithmic-depth decoder for the augmented Hopf field query

Research note · 19 November 2026 · Based on Hopf-Frame-Compilation, commit `ae613bf8e8a38f6d0407c25910b83d69f01a2733`.

## Result

Let $p\ge2$, $m=2^p$. The augmented field shear admits a uniform, exact native decoder with zero initialized work,
$$
D_T(E_p)\le 4d_I(p-1)+56,\qquad
T(E_p)=O(mp^2),\qquad
b_{\mathrm{private}}(E_p)=O(mp^2),\qquad
G(E_p)=O(m^2).
$$
Here $d_I(t)$ is the depth of the established exact dirty indicator on $t$ bits. It is $O(\log(t+2))$. $G$ counts elementary Clifford gates. The same bounds apply to the actual reversed word. The displayed count and width use the established indicator's linear count and width. The four-call reduction also works with a different indicator, with its actual resources added as specified below.

The previous uniform decoder used up to $16(p-1)$ T bands. The new construction improves the depth of the **full augmented decoder** even though it uses an existing logarithmic-depth indicator. For the full Hopf frame R96 still gives the strongest unconditional bound. At fixed accuracy and square-root dirty width the general depth interval is still $\Omega(1)$ to $O(\log n)$. [Previous decoder](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/AUGMENTED_FIELD_RECOUPLER.md) · [Exact dirty indicator](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/NONUNIFORM_DIRTY_INDICATOR.md) · [General frontier](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/docs/OPEN_PROBLEM.md#large-width-t-depth)

## 1. A circuit for a selected XOR shift on occupied banks

Let $H=\mathbb F_2^t$, $q=2^t$, and let $A,B,Y$ be arbitrary $q$-qubit banks. Write $P_s A$ for the wire permutation with $(P_s A)_v=A_{v+s}$. Addition of computational bit strings is over the binary field. Define the complete shear
$$
U_s(A,B)=(A,B+P_s A).
$$
The selector $s$ can be in superposition. With one auxiliary bank $Y$, use the complete XOR convolution
$$
K(A,Y,B)=(A,Y,B+A*Y),\qquad (A*Y)_v=\sum_u A_{v+u}Y_u .
$$
Execute $K,I_s,K^\dagger,I_s^\dagger$ in chronological order, where $I_s$ adds the point vector $e_s$ to $Y$. The two contributions to $B$ sum to $A*Y+A*(Y+e_s)=P_s A$, and the inversion of the indicator returns $Y$. This is the selected-shear echo already used for a dense grid. The product implementation below removes the quadratic T-count and width of that grid. [Existing selected-shear and paired-permutation identities](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/PARALLEL_BILINEAR_WORD_QUERY.md)

There is a converse using arbitrary $A,B$. Conjugating the physical flip $X_{A_0}$ by $U_s$ gives $X_{A_0}X_{B_s}$. A second $X_{A_0}$ removes the fixed flip. A native circuit for the shift shear and its actual inverse therefore supply the full dirty indicator on $B$, with its auxiliary $A$ returned. A full-error $\delta$ implementation costs at most $2\delta$ in this echo. In the other direction an indicator of full error $\delta$ gives a shear of error at most $2\delta$. At the polynomial-in-address overhead allowed by fusion, either operation would suffice for sublogarithmic depth. [Fusion resource contract](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/POLYNOMIAL_OVERHEAD_INDICATOR_FUSION.md)

### Eight native T layers for the product

In the group algebra $\mathbb F_2[H]$, write the generator in direction $i$ as $g_i=1+u_i$. Then $u_i^2=0$. Changing between the $g_S$ and $u_S$ bases is an invertible superset zeta transform on $q$ wires. Its inverse is the same transform in characteristic two and costs $O(tq)$ CNOTs. In the $u$ basis multiplication is disjoint-subset convolution. Conjugate its complete product-XOR on all three occupied banks by the corresponding linear basis changes. [Ranked subset convolution](https://arxiv.org/abs/cs/0611101) · [Returned native linear transforms and multiplication](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/ALGEBRA_QUERY_EXTRACTION.md)

For completeness, in the subset basis the exponent of the phase on multiplying $a,b$ into Fourier-basis output $z$ is a sum of $R=q\binom{t+2}{2}$ products of three binary linear forms. The row $(T,i,j)$, $i+j\le t$, uses
$$
\alpha=\sum_{A\subseteq T,\ |A|=i}a_A,\qquad
\beta=\sum_{B\subseteq T,\ |B|=j}b_B,\qquad
\gamma=\sum_{S\supseteq T,\ |S|=i+j}z_S .
$$
For fixed $A,B,S$ the intermediate count is odd exactly if $A\cup B=S$, and the rank condition then forces disjointness. All three banks of forms have XOR programs of size $O(q(t+1)^2)$. A shear from such a program into arbitrary masks has the same asymptotic CNOT cost and returned scratch. One may compute into dirty temporaries, copy into the masks, invert, then cancel the temporaries' contribution using the same program with original-input CNOTs omitted.

Put one arbitrary mask bit $d$ on each row. Follow the three-cube Gray cycle $000,001,011,010,110,111,101,100,000$. At each of the first eight vertices $v$, pulse the mask with $T$ or $T^\dagger$ according to $(-1)^{|v|}$. On each edge XOR the changed linear form into the mask. For $l=(\alpha,\beta,\gamma)$ the accumulated integer exponent satisfies
$$
\sum_v(-1)^{|v|}(d\oplus v\cdot l)
=-4(-1)^d\alpha\beta\gamma\pmod 8 .
$$
The phase is exactly $(-1)^{\alpha\beta\gamma}$ for either value of $d$. All row masks pulse in parallel, and every edge uses only Clifford gates and returned temporary bits. Hadamards on the output convert the resulting phase into the desired XOR. Thus $K,K^\dagger$ cost $8R$ T gates, at most eight T layers, and $O(q(t+1)^2)$ Clifford gates and private dirty bits. [Returned eight-phase field-query word](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/RECURSIVE_FIELD_SHEAR_DECODER.md#an-eight-band-query-for-any-binary-multiplication-matrices)

## 2. The full augmented field decoder

Write the address as $x=h+u b$, with $H=\mathbb F_2^{p-1}$ the lower coordinates, $u\in\mathbb F_2$, and $b$ the top-coordinate basis vector. The field shear on the two $k=m/2$-qubit core banks is
$$
Q_x(U,V)=(U,V+\beta(x)U).
$$
The map $\beta$ is binary linear, with $\beta(b)\ne0$, so $Q_xQ_y=Q_{x+y}$. The target $W_x$ translates the physical bank wires by $x$. The helper Pauli from the augmented construction shifts Fourier-basis helper labels by $r\mapsto r+\Lambda x$. Its kernel is precisely the line spanned by $b$. Indeed the top helper sees the independent coefficients of all $p-1$ lower address bits and none of the helper queries sees the top bit. The trace-pairing coordinate change is invertible. [Tower and field query](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/RECURSIVE_FIELD_SHEAR_DECODER.md) · [Helper definition](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/AUGMENTED_FIELD_RECOUPLER.md)

Select $p-1$ independent rows of $\Lambda$ on $H$. By an invertible binary coordinate change on those selected helper bits we can read $s=s(r)\in H$ with $s(r+\Lambda x)=s(r)+h$. This change and its inverse use Clifford gates and no initialized register. Other helper coordinates need no decoder operation. In the originally specified query their Pauli factors can still act and commute through the decoder. Omitting those spectator factors gives a compressed augmented query with exactly $p-1$ moving helper qubits. Both versions still need private returned scratch.

Use the fixed Clifford basis change
$$
C(U,V)=(V,V+\beta(b)U).
$$
Its actual inverse takes $(A,B)$ to $(\beta(b)^{-1}(A+B),A)$. Multiplication by this fixed field element is a binary linear map. In these coordinates $Q_b$ simply swaps the halves, so $C Q_b C^\dagger=W_b$ with literal phase one.

On helper sector $r$, take
$$
E_r=W_{s(r)}\,C\,Q_{s(r)} .
$$
The decoder acts block-diagonally in the helper Fourier basis. For every $r,x$, writing $s=s(r)$, its block after the source shifts the helper satisfies
$$
E_{r+\Lambda x}Q_x E_r^\dagger
= W_{s+h} C Q_{s+h+x+s} C^\dagger W_s
= W_{s+h} W_{u b} W_s=W_x .
$$
This proves the complete intertwining equation on the whole Hilbert space, including all unused helper coordinates, zero field inputs, phases and external references. Every gate in the inverse is the adjoint of the emitted word in reverse order.

For $s\in H$, $W_s$ applies $P_s$ separately to **both physical halves** $A,B$. Execute $B\mathrel{+}=P_s A$, $A\mathrel{+}=P_s B$, $B\mathrel{+}=P_s A$, then swap the two halves. Since $P_s^2=I$, the output is exactly $(P_s A,P_s B)$. No half is discarded. This costs six product words at $t=p-1$. Four indicator or inverse calls suffice when the three shears share the same dirty bank $Y$. For the first shear, multiply at $Y$, toggle, then multiply at $Y+e_s$. For the second shear, multiply at $Y+e_s$, untoggle, then multiply at $Y$. For the third, repeat the first pair and untoggle at the end. Reverse the complete physical word to obtain the adjoint. The field shear $Q_s$ contributes another eight bands. They give $4d_I(p-1)+56$ in total.

The cost of the field shear's elementary Clifford gates admits a direct tower bound. The coefficient $\alpha_i$ lies in the subfield of binary dimension $2^i$. In the recursive tower basis its multiplication matrix on a $k$-bit field is a direct sum of $k/2^i$ blocks of size $2^i$. Its number of nonzero entries is at most $k2^i$. Summing over the $p-1$ lower coefficients gives at most $k(k-1)$ entries. The eight-band cubic word therefore costs $O(k^2+kp)$ elementary Clifford gates and $O(kp)$ T gates and private masks. The fixed $C,C^\dagger$ cost $O(k^2)$ CNOTs. Including the six convolutions gives the stated $O(m^2)$ Clifford, $O(mp^2)$ T and $O(mp^2)$ private width bounds. Returned pools can be reused after each exact block. For approximate source substitution, ideal component extensions act as identity on the whole pool and telescoping remains valid under this reuse.

If a new indicator or its adjoint has full-operator error $\epsilon$, telescoping over the four calls gives $\|\widetilde E-E\|\le4\epsilon$. Conjugating the source gives at most $8\epsilon$ full error, and the complete probe echo at most $16\epsilon$. Intermediate selector motion is permitted. For another indicator add its actual four forward/inverse costs to the fixed component costs and reserve its peak workspace. The fixed-overhead polynomial orders satisfy the discovery contract. Thus, for the depth target, a successful approximate weak indicator can also supply the full **augmented** field decoder. The statement applies at each requested fixed tolerance.

### A construction that avoids the indicator

There is also a direct way to implement the required paired translation using the He–Robitaille–Tan algebra permutation. It independently explains the logarithmic depth. In the square-zero algebra with one extra generator $u_*$, an arbitrary element of the augmentation ideal splits uniquely as $z+a u_*$, where $z$ has zero constant coefficient by definition of the representation and $a$ is an entirely arbitrary half-bank. The coefficient of the constant in $z$ has no physical wire. The repository’s exact conjugation $J_s=F X^{\iota(s)}F^\dagger$ gives
$$
(z,a)\longmapsto(z+A_s+zA_s,\;a(1+A_s)),\qquad
1+A_s=\prod_{i=1}^{p-1}(1+s_i u_i)=g_s.
$$
The action on the head $z$ is an involution because $A_s^2=0$. Apply $J_s$ to the same arbitrary head first with one half-bank, then with the other. The head returns, while both tails are multiplied by $g_s$. Zeta changes on the tails convert that multiplication into the two wire translations $P_s$. The paid balanced implementation gives four calls to $F$ or its actual adjoint. Using its existing fast-subset-product ledger gives total decoder depth at most $800\lceil\log_2 p\rceil+8$, T-count $O(mp^2\log(p+2))$, and extra dirty width $O(mp^2)$. This independent construction reaches logarithmic depth without the one-hot subroutine. Its balanced multiplication tree still has logarithmic depth. [He–Robitaille–Tan permutation and native compiler](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/BALANCED_ALGEBRA_PERMUTATION.md) · [Complete conjugation and smaller-count ledger](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/ALGEBRA_QUERY_EXTRACTION.md)

## 3. Why weakening the endpoint alone does not rescue fixed-sector Clifford stages

Suppose the decoder preserves the helper Fourier sectors and acts by a Clifford on the core in each sector. Write $M(r)$ for its binary symplectic matrix, $F_x=I+N_x$ for the field shear's matrix, which is affine in $x$, and $z_y$ for the Pauli label of physical $Z_y$. Only require the complete single-probe error $\|S_x Z_0 S_x^\dagger-Z_x\|<\sqrt2$, where $S_x=E(Q_x\otimes P_x)E^\dagger$ and identity factors on work are understood.

For fixed input sector $r$, the core block of $S_x$ onto sector $r+\Lambda x$ is $E_{r+\Lambda x}Q_x E_r^\dagger$. It maps $Z_0$ to a signed Pauli within the stipulated radius of $Z_x$. Distinct signed Hermitian Paulis are separated by at least $\sqrt2$ in operator norm. Thus on labels,
$$
M(r+\Lambda x)F_xM(r)^{-1}z_0=z_x .
$$
The bank coordinate at wire zero on the right is the indicator of $x=0$ and has Boolean degree $p$. On the left the degree is at most one plus the degree of $M$ restricted to this active helper coset. Hence the tableau degree is at least $p-1$ on every coset. At least $p-1$ helper shift coordinates are required in this model. A product of $k$ helper-affine symplectic matrices and fixed Clifford walls has degree at most $k$. Consequently at least $p-1$ such stages are required even for the single probe. A native T band can leave this stage model. The exact compressed construction above attains the shift-rank requirement. [Prior full-intertwiner barrier](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/FIELD_SECTOR_DEGREE_BARRIER.md)

### Exact Boolean degree in the monomial model

There is a separate lower bound when the decoder is any computational permutation with arbitrary phases in the computational-core, Fourier-helper coordinates. It need not fix the helper labels, or be linear on the core. Let $f(w)$ be the physical bank bit zero of its output on basis word $w$. For a fixed $w$, the underlying source permutation $q_x(w)$ is affine in the address: the field multiplier is evaluated on fixed input $U$ and the helper is shifted linearly. Each $q_x$ is an involution. Pulling the weak probe equality back through the decoder gives
$$
f(q_x(w))=\bigl[\text{bank word of }E(w)\bigr]_x .
$$
All bit signs in this equation also agree under uniform probe error strictly below two, because the compared observables are diagonal signs. Choose a preimage $w$ whose decoded bank has a one only at wire zero. The right side is the degree-$p$ point function in $x$. Substitution of affine coordinates cannot increase Boolean degree, so $\deg f\ge p$.

For the explicit $E_r$ above, each physical bank output is linear in $(U,V)$ at fixed $s$ and its coefficients depend on only the $p-1$ bits of $s$, themselves linear in $r$. The maximum Boolean coordinate degree is therefore exactly $p$. A sequence of degree-at-most-two reversible rounds with affine walls has degree at most $2^k$ after $k$ rounds. Such a sequence needs at least $\lceil\log_2 p\rceil$ rounds. This argument counts completed Boolean rounds and leaves fully quantum intermediate operations open.

## 4. Verification and next experiment

Two independent computations checked the intertwiner in the degree-two and degree-four fields. One calculation checked 512 and 131,072 combinations, respectively, of address, active helper label, core input and occupied indicator bank, including the inverse. A second enumerated 128 and 16,384 full address/helper/core combinations in the two sizes and separately exercised dirty routing. A separate check exercised the shared-mask four-call schedule on all 16,512 cases at those two sizes. Additional checks covered all 16 inputs to one eight-pulse row and 84 seeded ranked-convolution and dirty-shear cases at one through seven address bits. The finite checks operate on exact arithmetical identities and permutations. The decomposition and the all-size proof above supply the native resource accounting.

A first shortcut is to apply Hadamards to $B$ and try to emit the entire selected matching as a phase. The target in those coordinates is the literal sign $(-1)^{\sum_v A_{v+s} B_v}$. Test the putative circuit on inputs with only $A_0,B_0$ variable. Its required exponent modulo eight is $4A_0B_0\prod_i(1-s_i)$. For $t\ge2$ its coefficient of degree $t+2$ is four modulo eight. A word built from affine bit permutations and computational-diagonal Clifford and T phases has exponent of degree at most three modulo eight: lifting a parity to integers gives coefficients divisible by $2^{j-1}$ at degree $j$, so all terms of degree four and above vanish. Diagonal Clifford phases obey the same bound after affine substitution. Arbitrary returned workspace can be fixed for this witness. A wrong classical output has distance $\sqrt2$ from the required output vector. The literal phases of the stated native gate set are eighth roots, and different eighth roots have distance at least $2\sin(\pi/8)$. Thus the shortcut already fails at any operator error below $2\sin(\pi/8)$ in this fixed-basis gate class. The calculation leaves non-diagonal intermediate operations available.

The remaining constructive question can be stated with two ordinary occupied arrays. Can one realize the selected matching $B_v\mathrel{+}=A_{v+s}$ for all $v$ in $o(\log(t+2))$ T-depth without first building the one-hot selector? A proposed word can be checked directly by the two-call indicator echo. To change the complete-frame frontier it must work at every requested fixed tolerance with the stated simultaneous budgets and actual adjoints. R98 would then still contribute $O(\log\log n)$ at square-root frame width. [Approximate transfer](https://github.com/GoGoKo699/Hopf-Frame-Compilation/blob/ae613bf8e8a38f6d0407c25910b83d69f01a2733/research/depth/APPROXIMATE_QUERY_FRAME_TRANSFER.md)
