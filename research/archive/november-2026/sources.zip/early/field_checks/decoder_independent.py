from itertools import product

def field_times(a,b,k,poly):
    res=0
    while b:
        if b&1: res ^= a
        b >>= 1
        a <<= 1
        if a>>k: a ^= poly
    return res

def shift(a,t,k):
    return sum(((a>>i)&1)<<(i^t) for i in range(k))

def subset_basis(a,k):
    out=0
    for i in range(k):
        if a>>i & 1:
            j=i
            while True:
                out ^= 1<<j
                if j==0:break
                j=(j-1)&i
    return out

def subset_prod(a,b,k):
    return sum((sum(((a>>u)&(b>>v)&1) for u,v in product(range(k),repeat=2) if u&v==0 and u|v==z)&1)<<z for z in range(k))

def conv(a,b,k):
    return subset_basis(subset_prod(subset_basis(a,k),subset_basis(b,k),k),k)

def selected_add(a,b,t,mask,k):
    return b ^ conv(mask,a,k) ^ conv(mask^(1<<t),a,k)

def paired(a,b,t,mask,k):
    b=selected_add(a,b,t,mask,k)
    a=selected_add(b,a,t,mask,k)
    b=selected_add(a,b,t,mask,k)
    return b,a

for p,poly in [(2,0b111),(3,0b10011)]:
    k=1<<(p-1)
    m=2*k
    planes=list(range(1<<k))
    c=0
    for a,b,t,mask in product(planes,planes,range(k),planes):
        assert paired(a,b,t,mask,k)==(shift(a,t,k),shift(b,t,k))
        c+=1
    print('p',p,'paired all mask, bank and selector checks',c)
    # Canonical helper shift form: p−1 active, remaining m/2−1−(p−1) inactive.
    inv=k-1-(p-1)
    def E(u,v,r):
        t=r%k
        v ^= field_times(t,u,k,poly)
        return shift(v,t,k),shift(v^field_times(k,u,k,poly),t,k),r
    checks=0
    for u,v,r in product(planes,planes,range(1<<(p-1+inv))):
        for x in range(m):
            xx=x%k
            aa,bb,rr=E(u,v,r)
            aa,bb=shift(aa,xx,k),shift(bb,xx,k)
            if x&k: aa,bb=bb,aa
            assert (aa,bb,rr^xx)==E(u,v^field_times(x,u,k,poly),r^xx)
            checks+=1
    print('p',p,'complete augmented basis intertwiner checks',checks)
    n_inputs=2*k+(k-1)
    degree=[]
    hist={}
    for bank_z in range(m):
        anf=[]
        for s in range(1<<n_inputs):
            u=s%(1<<k)
            v=(s>>k)%(1<<k)
            r=s>>(2*k)
            a,b,_=E(u,v,r)
            out=a | (b<<k)
            anf.append((out>>bank_z)&1)
            if not bank_z:
                y=0
                for x in range(m):
                    aa,_,_=E(u,v^field_times(x,u,k,poly),r^(x%k))
                    y |= (aa & 1)<<x
                assert y==out
                hist[y]=hist.get(y,0)+1
        for j in range(n_inputs):
            for s in range(1<<n_inputs):
                if s>>j & 1:
                    anf[s] ^= anf[s^(1<<j)]
        degree.append(max(s.bit_count() for s,b in enumerate(anf) if b))
    assert degree==[p]*m
    assert len(set(hist.values()))==1 and len(hist)==1<<m
    print('degree of each observable',degree,'distinct orbit truth tables',len(hist),'multiplicity',next(iter(hist.values())))
