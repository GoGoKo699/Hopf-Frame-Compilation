from itertools import product
from random import Random
rng = Random(20261119)
def addmask(a,b): return [x ^ y for x,y in zip(a,b)]
verts=(0,1,3,2,6,7,5,4)
gray=0
for d,a,b,c in product(range(2),repeat=4):
    mask=d
    exponent=0
    for i,v in enumerate(verts):
        expected=d ^ ((v&1) and a) ^ (b if v&2 else 0) ^ (c if v&4 else 0)
        assert mask==expected
        exponent+=(-1)**v.bit_count()*mask
        axis=(v^verts[(i+1)%8]).bit_length()-1
        mask^=(a,b,c)[axis]
    assert mask==d and exponent%8==4*a*b*c
    gray+=1
def zeta(a,t):
    a=a.copy()
    for i in range(t):
        b=1<<i
        for j in range(1<<t):
            if j&b: a[j^b]^=a[j]
    return a
def subset_product(a,b,t):
    n=1<<t
    aa=[[a[j] if j.bit_count()==i else 0 for j in range(n)] for i in range(t+1)]
    bb=[[b[j] if j.bit_count()==i else 0 for j in range(n)] for i in range(t+1)]
    for bank in [aa,bb]:
        for row in bank:
            for h in range(t):
                for j in range(n):
                    if j&(1<<h): row[j]^=row[j^(1<<h)]
    cc=[[sum(aa[i][j]*bb[r-i][j] for i in range(r+1))%2 for j in range(n)] for r in range(t+1)]
    for row in cc:
        for h in range(t):
            for j in range(n):
                if j&(1<<h): row[j]^=row[j^(1<<h)]
    return [cc[j.bit_count()][j] for j in range(n)]
def conv(a,b,t):
    return zeta(subset_product(zeta(a,t),zeta(b,t),t),t)
num=0
for t in range(1,8):
    n=1<<t
    for _ in range(12):
        a,b,out=([rng.randrange(2) for j in range(n)] for z in range(3))
        assert zeta(zeta(a,t),t)==a
        direct=[sum(a[u]*b[u^v] for u in range(n))%2 for v in range(n)]
        assert conv(a,b,t)==direct
        s=rng.randrange(n)
        be=b.copy();be[s]^=1
        assert addmask(addmask(out,conv(a,b,t)),conv(a,be,t))==addmask(out,[a[j^s] for j in range(n)])
        num+=1
print('Gray phase truth cases', gray, 'independent ranked-convolution and occupied shear checks',num)
def xb(a,b,q):
    acc=0
    for i in range(q):
        for j in range(q):
            if (a>>i)&(b>>j)&1: acc^=1<<(i^j)
    return acc
four=0
for q in (2,4):
    table={(a,b):xb(a,b,q) for a,b in product(range(1<<q),repeat=2)}
    for a,b,y,s in product(range(1<<q),range(1<<q),range(1<<q),range(q)):
        h=y;u=a;v=b
        v^=table[u,h];h^=1<<s;v^=table[u,h]
        u^=table[v,h];h^=1<<s;u^=table[v,h]
        v^=table[u,h];h^=1<<s;v^=table[u,h];h^=1<<s
        assert (v,u,h)==(table[a,1<<s],table[b,1<<s],y)
        four+=1
print('Shared-mask four-call router cases',four)
