from itertools import product

def xor_convolution(a, b, q):
    c = 0
    for i in range(q):
        for j in range(q):
            if (a >> i) & (b >> j) & 1:
                c ^= 1 << (i ^ j)
    return c

def translate(x, t, q):
    return sum(((x >> i) & 1) << (i ^ t) for i in range(q))

def gf_multiply(a, b, polynomial, degree):
    y = 0
    while b:
        if b & 1:
            y ^= a
        a <<= 1
        if a >> degree:
            a ^= polynomial
        b >>= 1
    return y

def verify(p, modulus, coefficients):
    q = 1 << (p - 1)
    m = 2*q
    mask = (1 << q) - 1
    products = {(a,b):xor_convolution(a,b,q) for a,b in product(range(1 << q),repeat=2)}
    def beta(x):
        a=0
        for i,c in enumerate(coefficients):
            if (x>>i)&1: a^=c
        return a
    def transform(u, v, x):
        return u, v ^ gf_multiply(beta(x), u, modulus, q)
    def pair(u,v,s,h):
        def add(a,b):
            return b ^ products[h,a] ^ products[h ^ (1 << s), a]
        v = add(u,v)
        u = add(v,u)
        v = add(u,v)
        return v,u
    def C(u,v):
        return v, v ^ gf_multiply(beta(q), u, modulus, q)
    invb = next(i for i in range(1 << q) if gf_multiply(i,beta(q),modulus,q)==1)
    def invC(a,b):
        return gf_multiply(invb, a^b, modulus, q), a
    def E(u,v,s,h):
        return pair(*C(*transform(u,v,s)),s,h)
    def invE(u,v,s,h):
        return transform(*invC(*pair(u,v,s,h)),s)
    checks = 0
    for u,v,s,h in product(range(1<<q),range(1<<q),range(q),range(1<<q)):
        assert pair(u,v,s,h)==(translate(u,s,q),translate(v,s,q))
        a,b=invE(u,v,s,h)
        assert E(a,b,s,h)==(u,v)
        for x in range(2*q):
            c,d=E(*transform(a,b,x),s^(x&(q-1)),h)
            assert c|(d<<q)==translate(u|(v<<q),x,m)
            checks+=1
    print(p, checks)
verify(2,0b111,[1,2])
verify(3,0b10011,[1,6,2])
